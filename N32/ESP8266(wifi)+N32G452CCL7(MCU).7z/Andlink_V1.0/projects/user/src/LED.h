/**************************************************************************//**
 * @file     LED.H
 * @brief    ָʾ�� 
 * @version  V1.1
 * @date     2018.10
 * @note
 * Copyright (C) 2018 ���
 *
 * @par      LED��ʾ
 ******************************************************************************/
#ifndef __LED_H__ 
#define __LED_H__

#include "n32g45x.h"
#include "Parameter.h"
#include "stdio.h"

/** the macro definition to trigger the led on or off 
  * 1 - off
  *0 - on
  */

/* �������IO�ĺ� */
#define LED_GPIO_PORT_RCC   RCC_APB2_PERIPH_GPIOA
#define LED_GPIO_PORT       GPIOA
#define LED1_PIN         GPIO_PIN_8


#define LED1_TOGGLE		digitalToggle(LED_GPIO_PORT,LED1_PIN)
#define LED1_OFF		    digitalHi(LED_GPIO_PORT,LED1_PIN)
#define LED1_ON			   digitalLo(LED_GPIO_PORT,LED1_PIN)


void LED_GPIO_Config(void);
void  LED_Status(void);



#endif