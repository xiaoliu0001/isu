/**************************************************************************/
/* Algorithm Engineer:    		liuwen 									  */
/* Date:						20160929								  */
/* Name:					BERpara.c									  */
/**************************************************************************/
#ifndef BERPARA_H
#define BERPARA_H

#ifndef U8
#define U8 unsigned char 
#endif
#ifndef S8
#define S8 signed char
#endif	
#ifndef U16
#define U16 unsigned short
#endif	
#ifndef S16
#define S16 signed short
#endif	
#ifndef U32
#define U32 unsigned int
#endif	
#ifndef S32
#define S32 signed int
#endif	
#ifndef BOOL
#define BOOL unsigned char
#endif

extern U8 gPulseRateHR;      //脉率值
extern U8 gPulseRateRR;      //呼吸值
extern U8 gPeopleFlag;    //床上有人的标记（true）有人
extern U8 gTurnFlag;  //统计5秒内是否翻身的标记
extern U16 ADC_AdjTime;
extern char Flag_ADC_ADJ;
void SleepAlgorithm(U16 sd);


/**
transmitData[0] 原始过滤数据
transmitData[1] 心率滤波数据
transmitData[2] 呼吸滤波数据
transmitData[3] 心率值
transmitData[4] 呼吸值
transmitData[5] 有无体动
transmitData[6] 有无人
transmitData[7] 原始数据
***/
void getSmapleData(void);
extern U32 transmitData[8];

void DataInitial(void);
#endif

