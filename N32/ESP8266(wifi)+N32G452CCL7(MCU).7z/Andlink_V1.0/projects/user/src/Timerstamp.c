/******************************************************************************
 * @file     Timerstamp.h
 * @brief   ��ȡʱ���
 * @version  v1.0
 * @date     2023.05.31
 * @note
 * Copyright (C)  ��� 2023
 *
 * @par      
 *    V1.0    
*******************************************************************************/

#include "Timerstamp.h"
#include "USART.h"

Date specialTime = {
        2000,
        01,
        01,
        00,
        00,
        00
};
//31 : 1  3 5 7 8 10 12 ; 30 : 4 6 9 11
const int daysofmon[] ={0,
                  31 * SECONDS_IN_A_DAY,
                  (28 + 31) * SECONDS_IN_A_DAY,
                  (31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (30 + 31 + 28 + 31 ) * SECONDS_IN_A_DAY,
                  (31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (31 + 31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (30 + 31 + 31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY
                  };
const int _daysofmon[] ={0,
                        31 * SECONDS_IN_A_DAY,
                        (29 + 31) * SECONDS_IN_A_DAY,
                        (31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (30 + 31 + 29 + 31 ) * SECONDS_IN_A_DAY,
                        (31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (31 + 31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (30 + 31 + 31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY
};

/****************************************************************************
*	�� �� ��: GetTimestamp
*	����˵��: ��ȡʱ�������
*	��    �Σ���
*	�� �� ֵ: 
*   ˵    ���� ��ȡ��ʱ�����λΪs
*****************************************************************************/
uint64_t Date2timeStamp(Date standardTime)
{
    //��Ҫ���� �������� standardTime �� specialTime �������
    uint64_t differenceValue = 0;     //���������ֵ����λΪ��
    int leapYears = 0;

    if((standardTime.Year < specialTime.Year) || (standardTime.Year > 2099))//������ specialTime.Year ֮ǰ��ʱ�䴫����
    {
        printf("The year %d is not supported\r\n",standardTime.Year);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Mon < 1) || (standardTime.Mon > 12))//������ ��Ч��mon ����
    {
        printf("The month %.2d is out of line\r\n",standardTime.Mon);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Day < 1) || (standardTime.Day > 31))//������ ��Ч��day ����
    {
        printf("The day %.2d is out of line\r\n",standardTime.Day);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Hour < 0) || (standardTime.Hour > 24))//������ ��Ч��hour ����
    {
        printf("The hour %.2d is out of line\r\n",standardTime.Hour);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Min < 0) || (standardTime.Min > 59))//������ ��Ч��min ����
    {
        printf("The min %.2d is out of line\r\n",standardTime.Min);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Second < 0) || (standardTime.Second > 59))//������ ��Ч��sec ����
    {
        printf("The sec %.2d is out of line\r\n",standardTime.Second);
        return SPECIALTIMESTAMP;
    }


    //�� specialTime ��ʼ���� standardTime ��ǰһ��֮���й��ٸ�����
    for(int i = specialTime.Year; i < standardTime.Year; i++)
    {
        if((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0))
        {
            leapYears++;
        }
    }
    differenceValue += (SECONDS_IN_A_LEAP_YEAR * leapYears +
            SECONDS_IN_A_COMMON_YEAR * (standardTime.Year - specialTime.Year - leapYears));
    //�ж� �ǲ�������
    if((standardTime.Year % 4 == 0 && standardTime.Year % 100 != 0) || (standardTime.Year % 400 == 0))  
    {
        differenceValue += (_daysofmon[standardTime.Mon - 1] +
                            (standardTime.Day - 1) * SECONDS_IN_A_DAY +
                            (standardTime.Hour ) *  SECONDS_IN_AN_HOUR +
                            (standardTime.Min ) * SECONDS_IN_A_MINUTE +
                            standardTime.Second);
    }else
    {
        differenceValue += (daysofmon[standardTime.Mon - 1] +
                           (standardTime.Day - 1) * SECONDS_IN_A_DAY +
                           (standardTime.Hour) *  SECONDS_IN_AN_HOUR +
                           (standardTime.Min) * SECONDS_IN_A_MINUTE +
                           standardTime.Second
                           );
    }
    differenceValue += SPECIALTIMESTAMP;
    return differenceValue;
}
