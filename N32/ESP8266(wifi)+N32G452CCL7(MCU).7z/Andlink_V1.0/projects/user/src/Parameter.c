/******************************************************************************
 * @file     Parameter.c
 * @brief   参数设定
 * @version  
 * @date     2017
 * @note
 * Copyright (C)  2017 张炜
 *
 * @par     此文件仅用于定参数  
*******************************************************************************/
#include "Parameter.h"



//------------串口参数------------------------------
uint8_t Flag_COMDebug = 1;     //串口调试

uint16_t  UART1_Data_Receive_Time = 0;
uint8_t UART1_Receive_Right = 0 ;  //正确格式字符串接收
char UART1_RX_BUFFER[UARTBUF_MAX_LEN]={0};
uint16_t  UART1_RX_LEN = 0;

char WIFI_RX_BUFFER[MAX_WIFIUART_LEN]={0};
uint16_t  WIFI_RX_LEN = 0;
uint16_t  WIFI_Data_Receive_Time = 0;


uint8_t Flag_BT_Linkstatus = 0;
uint8_t ReceiveServerData[64];
uint8_t ReceiveServerDatalen=0;
uint8_t Flag_ReceivedServerOrder=0;
uint8_t Flag_DataSendMode = 0;   //数据传输模式


//------------蓝牙参数-------------------------------------------
uint8_t  BlueTooth_Name[20];    //蓝牙名称，默认为DEVICE_NAME，可APP修改
uint8_t BlueTooth_Name_Len;    //蓝牙名称长度
char APP_Order_Receive_Data[APP_RX_BUF_SIZE];    //用于保存app发送的指令串，
uint8_t APP_Order_Receive_len = 0;    //APP指令串长度
uint8_t APP_Order_Send_len = 0;       //需要发送的数据长度，不包括指令及包头包尾格式数据
uint8_t APP_Receive_Right = 0;      //接收到APP数据
uint8_t Flag_SetWiFiSSID=0; //设置wifi模块连接的路由器
uint8_t Flag_SendLinkStatus; //发送设备当前的连接状态
uint8_t SendLinkStatus_Time;  //发送设备当前的连接状态间隔时间


//----------------时间参数---------------------------

uint8_t delaytime =0;  //
uint8_t delaytime1 =0;
struct Time TimerSim;              //模拟时钟
uint8_t  RealTime[6];              //实时时间

uint16_t  testCnt = 0;

uint16_t  WifiUnconnectTime = 0;     //wifi未连接时间
uint16_t   Monitor_Offline_Time = 0; //脱离监测计时，
uint16_t  Time_NetworkInquire=0;     //查询网络时间计时
uint16_t  WIFI_ConnetTime =0;       //wifi连接时间
uint16_t  WiFi_Time = 0;             //wifi模块指令时间
uint16_t  Link_Time = 0 ;            //网络连接时间
uint8_t   Flag_TimeAdj = 0;          //
uint8_t   Adj_Time = 0;             //校准时间计时
uint8_t   GetSleepDataTimeCount=0;  //发送睡眠数据计时
uint16_t  LedFlash = 0;			//控制ed闪烁
uint16_t  WiFi_InitTime=0;  //wifi初始化时间
uint8_t  BLE_ReceiveDataTime = 0;   //BLE接收数据的时间
uint8_t   HeartBeat = 0;             //心跳包  //test code  220526
//--------ADC采样值处理参数------------------------------------------
uint32_t ADC2_ConvertedValue[1]={0};//压电
uint32_t ADC1_ConvertedValue[1]={0};//压阻

float  ADC_VoltageValue[2]={0};

//uint16_t  ECG_MAX[ECG_COMPARE_TIMES];                //ADC采样数值处理
//uint16_t  SEND_ECG_MAX[ECG_COMPARE_TIMES];                //ADC采样数值处理
//uint16_t  ECG_MIN[ECG_COMPARE_TIMES];
//uint16_t  CHGECG_MAX[ECG_COMPARE_TIMES];                //ADC处理后数据
//uint16_t  CHGECG_MIN[ECG_COMPARE_TIMES];  
//uint8_t   ECG_COMPARE_COUNT = 0;
//uint8_t   CHGECG_COMPARE_COUNT = 0;
//char      Flag_ADC_ADJ = 0;              //调整幅度
//uint16_t  ADC_COUNT=0;
//uint16_t  CHGADC_COUNT=0;
//uint16_t  ADC_AdjTime=0;
//float   ADC_AmpMultiple = 1;    //放大倍数
//float   LastADC_AmpMultiple = 1;    //上一次放大倍数

//------------睡眠数据相关参数-------------------------------------------
unsigned char SleepData[50]={0};

uint8_t Last_gPeopleFlag = 0;   //是否有人的状态
uint8_t Last_noPeopleFlag = 0;
uint8_t Last_gTurnFlag = 0;
uint8_t Last_StatusFlag = 0; //上一个状态
uint8_t Keep_StatusFlag = 0; //现在保持的状态状态
uint8_t BeforeLast_StatusFlag=0;
uint8_t Flag_PowerOn = 1;       //是否是上电
//实时数据
uint8_t HR_real = 0;
uint8_t RR_real = 0;
uint8_t STATUS_real = 0;
uint8_t CSQ_real = 0;
//uint8_t Flag_SendAMPCHGToServer = 0;  //发送放大倍数到服务器

unsigned char Buffer_SleepData[SLEEPDTATABUF][40];   //数据缓存
uint16_t  Flag_SleepDataBuffer_Save = 0;
uint16_t  Flag_SleepDataBuffer_Send = 0;
uint8_t   SleepDataBuffer_SendTime = 0;
uint8_t   Flag_SleepData_SendOver = 0;
uint8_t   Last_SendIntervalTime = 0; 

unsigned char Statist_TurnStartTimebuf[6];    
unsigned char Statist_PeopleStartTimebuf[6];    
unsigned char Statist_NoPeopleStartTimebuf[6];
unsigned char Statist_TurnEndTimebuf[6];  
unsigned char Statist_PeopleEndTimebuf[6];    
unsigned char Statist_NoPeopleEndTimebuf[6];

uint32_t  Statist_AddHR = 0;       //断网统计心率累加
uint32_t  Statist_AddRR = 0;       //断网统计呼吸累加
uint16_t  Statist_AddCount = 0;    //断网统计呼吸/心率累加次数
unsigned char  Save_SleepHRData[6];  //断网情况下保存10分钟状态
unsigned char  Save_SleepRRData[6];
uint8_t   Flag_SavepPos = 0;
uint16_t  TurnKeepTime = 0;       //统计计时时间
uint16_t  PeopleKeepTime = 0;       //统计计时时间
uint16_t  NoPeopleKeepTime = 0;       //统计计时时间
uint8_t   Flag_NoNetWorkStart=0;        //断网开始标志
uint8_t  Flag_CanSendStatistData = 0;      //可以发送统计数据
uint8_t  CanSendStatistTime = 0;          //统计数据接收间隔时间

uint8_t    Last_gPulseRateHR = 0;   //保存上次的心率数值，当心率异常时发送上次的数据，
uint8_t    Last_gPulseRateRR = 0;   //保存上次的呼吸数值，当心率异常时发送上次的数据，
uint8_t    ABN_gPulseRateHR = 0;   //保存异常的心率数值，当心率异常时发送上次的数据，
uint8_t    ABN_gPulseRateRR = 0;   //保存异常的呼吸数值，当心率异常时发送上次的数据
uint8_t    Flag_SendDataAbnormal = 0;   //发送一次标记，当心率呼吸异常的时候发送


//--------------网络参数--------------------------
uint8_t Flag_StepStatus;   //连接步骤的状态，分为发送数据和接收数据
char CSQNual = 0;
int Position_LAC;
int Position_CID;
uint8_t Socket = 0;
unsigned char SIMCard_IMSI[20];
uint8_t SIMCard_IMSI_Len = 0;
uint8_t Command_SendCount = 0;
uint8_t Flag_Reset_RouterSSID=0;  //重新设置wifi模块连接的路由器

char  Router_Name[35];  //路由器名称和密码
uint8_t Router_NameLen;  
char Router_PWD[35];
uint8_t  Router_PWDLen;
char RouterName_InWIFI[75];  //wifi模块中路由器名称和密码


char IP2[30];
char Port2[5];
char Token2[15];
uint8_t Token2_Len=0;
uint8_t LinkStep=0;         //服务器连接步骤
uint8_t LinkVerfyDataSendOver=0; //校验数据已发送
uint8_t LinkIPCount = 0;     //服务器连接次数

uint8_t    Flag_Binding_Users = 0;  //设备是否绑定用户,
uint16_t   SleepData_SendTime=0;  //睡眠数据发送的时间
uint16_t   No_Binding_Users_Time = 0; //未关联用户计时，
uint8_t    Flag_No_Binding_Users_Time = 0;//未关联用户计时标志，
uint8_t Flag_WIFIInitStep;     //wifi初始化的过程步骤

/******************压力开关******************************/
uint8_t Status_ExtSensorIn = 0;    //外部传感器是否插入状态  
uint8_t Status_ExtSensorOnbed = 0;    //外部传感器是否有人在床状态  
uint8_t ExtSensor_OnbedStatus_Count = 0;  //传感器在床状态次数统计，累计多次状态一致才确定是否在床 
uint8_t OnbedStatus_CountTimer = 0;   //外部传感器在床状态统计间隔时间
uint8_t LastOnbedStatus = 0;          //上一次的在床状态 
uint8_t Flag_SendPresensorStatus = 0;  //发送压力传感器状态
uint8_t SendPresensorStatus_Time = 0;  //发送压力传感器时间
char Flag_PeopleTurnforPresensor = 0;       //体动信号为压力检测c

/******************设备保存信息******************************/
//char MAC_ID[30] = {0};
//char CMCC_CMEI[16] = {0}; 
//uint8_t MAC_LEN = 0;

DeviceInfo_Para Device_Info;
uint8_t Flag_ErrInfo = 0;   //设备错误信息
uint8_t Flag_InitStatus; //系统初始化状态
uint8_t Flag_SystemReset=0; //系统复位原因


//------------------------------------------------
uint8_t Flag_WiFiSmartConfig = 0;  //需要进行WiFi配置
uint8_t Flag_WiFiAPConfig = 0; //
uint8_t Flag_LED_Status=0;       //LED显示状态
uint8_t LED_FlickerCount=0;      //LED闪烁次数
uint8_t Flag_Reregistration=0;  //重新注册
uint8_t Flag_Start_Mode = 0;   //网络重连的原因：上电重启还是断网重连，
uint8_t Flag_Send_GPRS_Position = 0;  //发送一次GPRS位置
int32_t Max_ECG = 0;    //最大心率强度
int32_t Min_ECG = 2000;    //最小心率强度
uint16_t Average_MAXECG = 0; //

uint8_t Flag_ReportAndlinkManagedata = 0; //20230617增加，定时上报终端管理数据