#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "n32g45x.h"
#include "Delay.h"

void SysTick_Init(void);
void Delay_us(__IO u32 nTime);

//#define Delay_ms(x) Delay_us(100*x)	 //��λms
//#define Delay_ms(x) delay_ms(x)	 //��λms

#endif /* __SYSTICK_H */
