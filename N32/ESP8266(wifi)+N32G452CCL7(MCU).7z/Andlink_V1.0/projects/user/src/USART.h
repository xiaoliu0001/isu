/***********************************************************************************
 * @file     USART.h
 * @brief    ���ں���
 * @version  V1.0
 * @date     2017.09
 * @note
 * Copyright (C) 2017 ���
 *
 * @par      
************************************************************************************/

#ifndef __USART_H
#define	__USART_H

#include <n32g45x.h>
#include <stdio.h>


void SendDataToUSART( USART_Module* USARTx,uint8_t ch);
void SendDatasToUSART( USART_Module* USARTx,uint16_t ch);
void ClearUSARTBUF(USART_Module* USARTx);
void UART5_DMA_Config(void);
void UART5_SendString(unsigned char* s);
void UART5_SendData(unsigned char* data,uint16_t len);


#endif /* __USART1_H */
