/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/

/**
 * @file main.h
 * @author Nations
 * @version v1.0.0
 *
 * @copyright Copyright (c) 2019, Nations Technologies Inc. All rights reserved.
 */
#ifndef __MAIN_H__
#define __MAIN_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "n32g45x.h"
#include "LED.h"

#define _USART1_USART2_

#ifdef _USART1_USART2_
#define USART_DEBUG            USART1
#define USART_DEBUG_GPIO       GPIOA
#define USART_DEBUG_CLK        RCC_APB2_PERIPH_USART1
#define USART_DEBUG_GPIO_CLK   RCC_APB2_PERIPH_GPIOA
#define USART_DEBUG_RxPin      GPIO_PIN_10
#define USART_DEBUG_TxPin      GPIO_PIN_9
#define USART_DEBUG_APBxClkCmd RCC_EnableAPB2PeriphClk
#define USART_DEBUG_IRQn       USART1_IRQn
#define USART_DEBUG_IRQHandler USART1_IRQHandler

#define USART_WIFI          UART5
#define USART_WIFI_GPIO       GPIOB
#define USART_WIFI_CLK        RCC_APB1_PERIPH_UART5
#define USART_WIFI_GPIO_CLK   RCC_APB2_PERIPH_GPIOB
#define USART_WIFI_RxPin      GPIO_PIN_9
#define USART_WIFI_TxPin      GPIO_PIN_8
#define USART_WIFI_APBxClkCmd RCC_EnableAPB1PeriphClk
#define USART_WIFI_IRQn       UART5_IRQn
#define USART_WIFI_IRQHandler UART5_IRQHandler


#endif


unsigned char SelectWorkModule(void);
void WIFIUPDATE(void);
void GetMac(unsigned char Type);
void COM1ProcessCmd(void);
void LinkServer(uint8_t AP);
	

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H__ */
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */
