/******************************************************************************
 * @file     Fun.c
 * @brief   GPRS��WIFI����
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par      �ϱ� 2016
 *     ���20170522 �����µ�ͨѶЭ���޸���غ���
 *     ���20170612���Ӷ�ȡSIM����IMSI�Ų����ͷ������ͱ���Ĺ���
*******************************************************************************/
#include "Fun.h"
//#include "GPRS.h"
#include "m26.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "BERpara.h"
#include "ADC.h"
#include "Parameter.h"
#include "Calculate.h"
#include "Flash.h"
#include <math.h>
#include "LED_Key.h"
#include "Delay.h"

//const unsigned char *IPstring = "AT+CIPSTART=\"TCP\",\"117.78.41.203\",6006";	//IP��¼������

unsigned char *IPstring = "AT+IP=117.78.41.203:6006#";	//IP��¼������				03 29  test
//unsigned char *IPstring = "AT+IP=devstv100r001.ibreezee.cn:6006#";	//IP��¼������				03 29  test
//unsigned char *IPstring = "AT+IP=betadev.isuke.com.cn:6011#";
//unsigned char *IPstring = "AT+IP=devstv100r001.ibreezee.cn:6006#";
unsigned char RecTrue[] = "CONNECT  OK";						//���ӷ��������ص��ַ�
unsigned char ucIP2buff[50] = {0};									//��¼���÷�������ַ��buff
unsigned char *ForIP = "AT+CIPSTART=\"TCP\",\"117.78.41.203\",6006\r\n";	//IP��¼������
char *IP1="device.isuke.com.cn";//"114.116.105.56";//"117.78.41.203";
char *PORT1="6011";//"6007";
//char *IP1="device.isuke.com.cn";
//char *PORT1="6011";
uint8_t CheckCount_ExtSensor = 0;    //�ⲿ������������
uint16_t ExtSensor_PeopleOFFBed_Time = 0;
uint32_t ADCVol_ExtSensor = 0;

#define  PRESSURESENSOR_BASEMAXVALUE   500
#define  PRESSURESENSOR_BASEMINVALUE   300

uint16_t PressureSensor_BaseValue = PRESSURESENSOR_BASEMAXVALUE;    //ѹ������������ֵ
uint8_t CheckCount_ExtSensorMaxVal = 0;
uint8_t CheckCount_ExtSensorMinVal = 0;
void uart_send_sleep_data(void);
/*****************************************************************************/
//name:		GetToken1
//explain:	��ȡtoken1
//para:		NULL
//return:	NULL
/*****************************************************************************/
void GetToken1(void)
{
    unsigned char ucCmd[] = "2509C_SESSION12";  //12ΪMAC���ȣ�������Ҫ�޸�Ϊ�䳤�ȵ���,���20170522
    unsigned char ucdata[30] = {0};
    unsigned char ucSdata[50] = {0};
    unsigned char ucLingshi[20] = {0};
    //unsigned char tokenlen[2]={0};
    char *pstr = NULL;

    ClearUSART3BUF();
    memcpy(ucdata, MAC_IDstring, MAC_LEN);  //���20170522�޸ģ�chipid���Ȳ��̶������ҵ�һ���ֽ�Ϊ��������

    sprintf(ucSdata, "%s%s", ucCmd, ucdata);

    //printf("GetToken1 Data:%s\r\n", ucSdata);

    if(GPRS_or_WIFI == GPRS)
    {
        GPRSSendData(ucSdata, strlen(ucSdata));
        token1time = 0;
        while(1)
        {
            pstr = strstr(ucUar3tbuf, "8");
            if(pstr == NULL)
            {
                pstr = strstr(ucUar3tbuf, "7");
            }
            if(pstr != NULL)
            {
                delay_ms_YB();
                memcpy(ucLingshi, ucUar3tbuf, 9);
                if(ucUar3tbuf[0] == '8')
                {
                    memcpy(Token1, ucLingshi, 9);
                }
                else
                {
                    memcpy(Token1, ucLingshi, 8);
                }
//                printf("Fuwuqi data:%s\r\n", ucLingshi);
//                printf("Token1:%s\r\n", Token1);
                break;
            }
            if(token1time > 5) 				//��ʱʱ��Ϊ3s
            {
//                printf("Time Out!%s\r\n", ucUar3tbuf);
                break;
            }
            if(strstr(ucUar3tbuf, "CLOSED") != NULL)
            {
//                printf("CL:%s\r\n", ucUar3tbuf);
                break;
            }
        }
    }
}


/************************************************************************************/
// C prototype : void StrToHex(BYTE *pbDest, BYTE *pbSrc, int nLen)
// parameter(s): [OUT] pbDest - ���������
// [IN] pbSrc - �ַ���
// [IN] nLen - 16���������ֽ���(�ַ����ĳ���/2)
// return value:
// remarks : ���ַ���ת��Ϊ16������
/************************************************************************************/
void StrToHex(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    char h1, h2;
    unsigned char s1, s2;
    int i;

    for (i = 0; i < nLen; i++)
    {
        h1 = pbSrc[2 * i];
        h2 = pbSrc[2 * i + 1];

        s1 = toupper(h1) - 0x30;
        if (s1 > 9)
            s1 -= 7;

        s2 = toupper(h2) - 0x30;
        if (s2 > 9)
            s2 -= 7;

        pbDest[i] = s1 * 16 + s2;
    }
}

/**************************************************************************/
// C prototype : void HexToStr(BYTE *pbDest, BYTE *pbSrc, int nLen)
// parameter(s): [OUT] pbDest - ���Ŀ���ַ���
// [IN] pbSrc - ����16����������ʼ��ַ
// [IN] nLen - 16���������ֽ���
// return value:
// remarks : ��16������ת��Ϊ�ַ���
/*************************************************************************/
void HexToStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    char ddl, ddh;
    int i;

    for (i = 0; i < nLen; i++)
    {
        ddh = 48 + pbSrc[i] / 16;
        ddl = 48 + pbSrc[i] % 16;
        if (ddh > 57) ddh = ddh + 7;
        if (ddl > 57) ddl = ddl + 7;
        pbDest[i * 2] = ddh;
        pbDest[i * 2 + 1] = ddl;
    }

    pbDest[nLen * 2] = '\0';
}

void HexToLowerStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    char ddl, ddh;
    int i;

    for (i = 0; i < nLen; i++)
    {
        ddh = 48 + pbSrc[i] / 16;
        ddl = 48 + pbSrc[i] % 16;
        if (ddh > 57) ddh = ddh + 39;//'9'��'a'���39
        if (ddl > 57) ddl = ddl + 39;
        pbDest[i * 2] = ddh;
        pbDest[i * 2 + 1] = ddl;
    }

    pbDest[nLen * 2] = '\0';
}
/*******************************************************************************
* ������ : ConnectFrontServer
* ����   : ����ǰ�÷�����
* ����   :
* ���   :
* ����   :
* ע��   :
*******************************************************************************/
void ConnectFrontServer(void)
{
    char cmd[100]={0};
    if((GPRS_or_WIFI == GPRS) && (AngelPace == CONECTIP1))
    {
//        GPRS_CloseSocket();
        if(SendDataStatus != OK) 			//��������
        {
            ClearUSART3BUF();
//            UART3_SendString_YB(IPstring, strlen(IPstring));
//            UART3_SendLR();
            //sprintf(cmd,"AT+QIOPEN=\"TCP\",\"%s\",\"%s\"\r\n",IP1,PORT1);  //
            sprintf(cmd,"AT+MIPOPEN=1,0,\"%s\",%s,0\r\n",IP1,PORT1); 
            UART3_SendString(cmd);
					  //if(Flag_COMDebug == 1)
							printf("%s", cmd);
            SendDataStatus = OK;
            mytime = 0;
        }
    }
}
void ConnectServertEST(void)
{
    char cmd[100]={0};
	GPRS_CloseSocket();
	ClearUSART3BUF();
	sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",IP1,PORT1); 
	UART3_SendString(cmd);
	printf("%s", cmd);
	SendDataStatus = OK;
	mytime = 0;
}

/*******************************************************************************
* ������ : ConnectFrontServerRcvCtr
* ����   : ����ǰ�÷�����ָ����մ���
* ����   :
* ���   :
* ����   :
* ע��   :
*******************************************************************************/
void ConnectFrontServerRcvCtr(void)
{
        if((strstr(ucUar3tbuf, "OK") != NULL))					//�Ƿ񷵻�ָ���ַ���
        {
			  if(Flag_COMDebug == 1)
				{
					printf("%s\r\n", ucUar3tbuf);
					printf("CMD Success!\r\n");
				}
            //AngelPace = CONECTIP1OK;							//���ӷ������ɹ�
              AngelPace=GETFRONTSERVEROK;
              SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "ERROR") != NULL) 		//����error�Ļ������������ط����ݣ�ȥ�����ݴ��䲻�ȶ���Ӱ��
        {
			  if(Flag_COMDebug == 1)
				  printf(" ERROR:%s\r\n", ucUar3tbuf);
                      
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "CONNECT FAIL") != NULL)
        {
					  if(Flag_COMDebug == 1)
                          printf("CONNECT:%s\r\n", ucUar3tbuf);
             Flag_init = MAC_INIT_OK;  //���Խ�������ģ���ʼ��          
            SendDataStatus = NO;
        }
        if(mytime > 5) 						//��ʱ
        {
					  if(Flag_COMDebug == 1)
							printf("Timer Out:%s\r\n", ucUar3tbuf);
                      Flag_init = MAC_INIT_OK;  //���Խ�������ģ���ʼ��
            SendDataStatus = NO;
        }
}

/*******************************************************************************
* ������ : GetFrontEndServerPw
* ����   : ��ȡǰ�÷�����token
* ����   :
* ���   :
* ����   :
* ע��   :
*******************************************************************************/
void GetFrontEndServerPw(void)
{
    unsigned char CMD[] = "C_SESSION";
    unsigned char CMD_LEN = 0, TOTAL_LEN = 0;  //���20170522ɾ��MAC_LEN = 0
    unsigned char ucSendData[40] = {0};
    unsigned char ucLingshi[20] = {0};
    char *pstr = NULL;


    if(AngelPace == CONECTIP1OK) 							//ֻ������ǰ�÷���ɹ�����ܽ�����һ��
    {
        if(SendDataStatus != OK)
        {
            memset(SendDataBuff, 0x00, sizeof(SendDataBuff));
            memset(Token1, 0x00, sizeof(Token1));				//Tokenʹ��ǰ��clear��
            CMD_LEN = strlen(CMD);							//����ƴ��
            MAC_LEN = strlen(MAC_IDstring);					//����mac����
            if(CMD_LEN < 10) 								//���CMD���Ȳ�����λ������Ҫ��0
            {
                sprintf(ucSendData, "%d%d%s%d%s", CMDLenFill, CMD_LEN, CMD, MAC_LEN, MAC_IDstring);	//ƴ�ӷ��͵�����
            }
            else
            {
                sprintf(ucSendData, "%d%s%d%s", CMD_LEN, CMD, MAC_LEN, MAC_IDstring);	//ƴ�ӷ��͵�����
            }
            TOTAL_LEN = strlen(ucSendData);					//�����ܳ���

            if(GPRS_or_WIFI == GPRS)
            {
                sprintf(SendDataBuff, "AT+GPRS=%d%s", TOTAL_LEN, ucSendData);					//ƴ�����շ�������
            }
            else
            {
                sprintf(SendDataBuff, "%d%s", TOTAL_LEN, ucSendData);					//ƴ�����շ�������
            }
            //sprintf(SendDataBuff,"AT+SEND=2509C_SESSION12%s",MAC_IDstring);

            /*****************************���ݷ���*******************************************/
            if(GPRS_or_WIFI == GPRS)
            {
                GPRSSendData(SendDataBuff, strlen(SendDataBuff));		//��������
							  if(Flag_COMDebug == 1)
									printf("C_SESSION:%s\r\n",SendDataBuff);
            }

            SendDataStatus = OK;							//�������
            mytime = 0;										//��ʼ��ʱ��ʱ
            ClearUSART3BUF();				
        }
    }
    else
    {
        return;
    }
}
/*******************************************************************************
* ������ : GetFrontEndServerPwRcvCtr
* ����   : ��ȡǰ�÷�����token,�������ݴ���
* ����   :
* ���   :
* ����   :
* ע��   :
*******************************************************************************/
void GetFrontEndServerPwRcvCtr(void)
{
    char *pstr1 = NULL;
    char *pstr2 = NULL;
	  uint8_t i = 0;
	
    if(GPRS_or_WIFI == GPRS)
    {
        pstr1 = strstr(ucUar3tbuf, "8");
        pstr2 = strstr(ucUar3tbuf, "7");
        if((pstr1 != NULL)||(pstr2 != NULL))
        {
            delay_ms_YB();
					  delay_ms_YB();
					  if(Flag_COMDebug == 1)
							printf("ucUar3tbuf:%s\r\n", ucUar3tbuf);
          
						if((pstr1 != NULL)&&(pstr2 != NULL))
						{
							  if(pstr1>pstr2)
								{
									 memcpy(Token1, pstr2, TokenLen8);
								}
								else
								{
									 memcpy(Token1, pstr1, TokenLen9);
								}
						}
						else 
						{
								if(pstr1[0] == '8')
								{
										memcpy(Token1, pstr1, TokenLen9);
								}
								else
								{
										memcpy(Token1, pstr2, TokenLen8);
								}
					  }
            //printf("Fuwuqi data:%s\r\n",ucLingshi);
						if(Flag_COMDebug == 1)
							printf("Token1:%s\r\n", Token1);
            if(Token1[0] == '7' || Token1[0] == '8')
            {
                AngelPace = GETFRONTSERVEROK;
                SendDataStatus = NO;
							  if(Flag_COMDebug == 1)
									printf("GETFRONTSERVEROK\r\n");
            }
            else
            {
                SendDataStatus = NO;
							  if(Flag_COMDebug == 1)
									printf("GETFRONTSERVERNO\r\n");
            }
        }
			 
        if(mytime > GetFirstDataTimeOut) 			//��ʱʱ��Ϊ30s
        {
					  if(Flag_COMDebug == 1)
							printf("Time Out!%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//��������ǰ�÷�����
            SendDataStatus = NO;					//�򿪷��Ϳ���
        }
        if(strstr(ucUar3tbuf, "CLOSED") != NULL)
        {
					  if(Flag_COMDebug == 1)
							printf("CL:%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//��������ǰ�÷�����
            SendDataStatus = NO;					//�򿪷��Ϳ���
        }
        if(strstr(ucUar3tbuf, "SHUT OK") != NULL)
        {
					  if(Flag_COMDebug == 1)
							printf("CL:%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//��������ǰ�÷�����
            SendDataStatus = NO;					//�򿪷��Ϳ���
        }
        CheckSystemErrorContrl();					//ģ������쳣���
    }
}

/*******************************************************************************
* ������ : GetBackEndServerIP
* ����   : ��ȡ���÷�����IP
* ����   :
* ���   :
* ����   :
* ע��   :
*******************************************************************************/
void GetBackEndServerIP(void)
{
    unsigned char CMD[] = "G_IP";
    unsigned char CMD_LEN = 4, TOTAL_LEN = 0, MD5_LEN = 32, i = 0; //���20170522ɾ��,MAC_LEN = 12
    unsigned char ucSendData[100] = {0};
    unsigned char ucdata[30] = {0};
    unsigned char ucMd5data[30] = {0};
    unsigned char ucmd5string[40] = {0};
    unsigned char ucSenddata1[40] = {0};
    unsigned char ucSenddata2[40] = {0};

    if(AngelPace == GETFRONTSERVEROK)
    {
        if(SendDataStatus != OK) 									//��������
        {

					memset(SendDataBuff,0x00,sizeof(SendDataBuff));
					memcpy(ucdata,MAC_IDstring,MAC_LEN);							//��ȡMD5����
					sprintf(ucMd5data,"%s%s",ucdata,Token1+1);
					MDString(ucMd5data,ucmd5string);
					HexToLowerStr(ucSenddata1,ucmd5string,16);
          ClearUSART3BUF();
					if(Flag_COMDebug == 1)
					{
						printf("MD5data:%s\r\n",ucMd5data);
						printf("MD5rcvdara:%s\r\n",ucSenddata1);
          }
            if(CMD_LEN < 10)
            {
                sprintf(ucSendData, "%d%d%s%d%s%d%s", CMDLenFill, CMD_LEN, CMD, MAC_LEN, ucdata, MD5_LEN, ucSenddata1);			//ƴ�ӷ��͵�����
            }
            else
            {
                sprintf(ucSendData, "%d%s%d%s%d%s", CMD_LEN, CMD, MAC_LEN, ucdata, MD5_LEN, ucSenddata1);			//ƴ�ӷ��͵�����
            }
            TOTAL_LEN = strlen(ucSendData);										//�����ܳ���
            if(GPRS_or_WIFI == GPRS)
            {
                sprintf(SendDataBuff, "AT+GPRS=%d%s", TOTAL_LEN, ucSendData);					//ƴ�����շ�������
            }
            else
            {
                sprintf(SendDataBuff, "%d%s", TOTAL_LEN, ucSendData);					//ƴ�����շ�������
            }

            if(GPRS_or_WIFI == GPRS)
            {
                GPRSSendData(SendDataBuff, strlen(SendDataBuff));
            }


            SendDataStatus = OK;							//�������
            mytime = 0;										//��ʼ��ʱ��ʱ
            memset(SendDataBuff, 0x00, sizeof(SendDataBuff));
            memset(IP2, 0x00, sizeof(IP2));
            memset(chanl2, 0x0, sizeof(chanl2));

        }
    }
    else
    {
        return;
    }
}
/*******************************************************************************
* ������ : GetBackEndServerIPRcvCtr
* ����   : ��ȡ���÷�����IP���մ���
* ����   :
* ���   :
* ����   :
* ע��   :
*******************************************************************************/
void GetBackEndServerIPRcvCtr(void)
{
    char *pstr = NULL;
	  unsigned int TDNum = 0;
    unsigned char ucLingshi[30] = {0};
    unsigned char uclenbuf[3] = {0}, uclen = 0;
    unsigned char uciplenbuf[3] = {0}, uciplen = 0;
    unsigned char ucip2[20] = {0};

    if(GPRS_or_WIFI == GPRS) 				//GPRS���մ���
    {
        pstr = strstr(ucUar3tbuf, "1");
        if(pstr != NULL)
        {
            delay_ms_YB();
					  delay_ms_YB();
            memcpy(ucLingshi, pstr, 25);
            memcpy(uciplenbuf, ucLingshi, 2);
            uciplen = atoi(uciplenbuf);
            memcpy(ucip2, ucLingshi + 2, uciplen);
            strcpy(IP2, ucip2);
            memcpy(chanl2, ucLingshi + 2 + uciplen + 1, 4);
					  TDNum = atoi(chanl2);
					  if(Flag_COMDebug == 1)
						{
							printf("IPdata:%s\r\n", ucUar3tbuf);
							printf("IP2:%s\r\n", IP2);
							printf("chanl2:%s\r\n", chanl2);
						}
            if((MyCountChar(IP2, 20) == 3) &&(strlen(IP2)>7)&& (TDNum >100 ))
            {
                AngelPace = GETBACKSERVERIPOK;
                SendDataStatus = NO;
							  
            }
            else
            {
                memset(IP2, 0x00, sizeof(IP2));
                memset(chanl2, 0x0, sizeof(chanl2));
                SendDataStatus = NO;
            }
        }
        if(mytime > GetDataTimerOut)
        {
					  if(Flag_COMDebug == 1)
							printf("Timer out!%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//��������ǰ�÷�����
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "CLOSED") != NULL)
        {
					  if(Flag_COMDebug == 1)
							printf("CL:%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//��������ǰ�÷�����
            SendDataStatus = NO;
        }
        CheckSystemErrorContrl();				//ģ������쳣���
    }
}

/*******************************************************************************
* ������ : ConnectBackServer
* ����   : ���Ӻ��÷�����
* ����   :
* ���   :
* ����   :
* ע��   :
*******************************************************************************/
void ConnectBackServer(void)
{
    unsigned int TDNum = 0;
    unsigned char len = 0;
    unsigned char ucstatu = 0;

	
    if(AngelPace == GETBACKSERVERIPOK)
    {
        if(SendDataStatus != OK) 			//��������
        {
            ClearUSART3BUF();
            TDNum = atoi(chanl2);
            if(GPRS_or_WIFI == GPRS)
            {
                //TDNum=6008;				//17-03-06   ��YB  test
                sprintf(ucIP2buff, "AT+IP=%s:%d#", IP2, TDNum);
							if(Flag_COMDebug == 1)
							{
                printf("ucIP:%s\r\n", ucIP2buff);
							}
                UART3_SendString_YB(ucIP2buff, strlen(ucIP2buff));
                UART3_SendLR();
            }
						if(Flag_COMDebug == 1)
							printf("%s", ucIP2buff);
            SendDataStatus = OK;
            mytime = 0;
        }
        else 								//��ʼ��������
        {
            if(GPRS_or_WIFI == GPRS)
            {
                if(strstr(ucUar3tbuf, "CONNECT  OK") != NULL)							//�Ƿ񷵻�ָ���ַ���
                {
									 if(Flag_COMDebug == 1)
                     printf("%s\r\n", ucUar3tbuf);
//                    printf("CMD Success!\r\n");
                    AngelPace = CONECTIP2OK;							//���ӷ������ɹ�
                    SendDataStatus = NO;
					          RegEnable=1;
									
                }
                if(strstr(ucUar3tbuf, "ERROR") != NULL || strstr(ucUar3tbuf, "error") != NULL) 		//����error�Ļ������������ط����ݣ�ȥ�����ݴ��䲻�ȶ���Ӱ��
                {
									  if(Flag_COMDebug == 1)
											printf("%s\r\n", ucUar3tbuf);
                    SendDataStatus = NO;
                }
                if(strstr(ucUar3tbuf, "CONNECT FAIL") != NULL)
                {
									  if(Flag_COMDebug == 1)
											printf("%s\r\n", ucUar3tbuf);
                    SendDataStatus = NO;
                }
								 if(strstr(ucUar3tbuf, "SHUT") != NULL)
								 {
										if(Flag_COMDebug == 1)
											printf("IP2 shut:%s\r\n", ucUar3tbuf);
										Flag_Check_Status |= ERROR_NO_TOKEN2;
										AngelPace = CONECTIP1;
										SendDataStatus = NO;					//�򿪷��Ϳ���
										SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
								 }
                if(mytime > ConnetServerTimeOut) 									//��ʱ
                {
									  if(Flag_COMDebug == 1)
											printf("Timer Out:%s\r\n", ucUar3tbuf);
									 
                    SendDataStatus = NO;
                }
                CheckSystemErrorContrl();				//ģ������쳣���
            }
        }
    }
    else
    {
        return;
    }
}

/*******************************************************************************
* ������ : GetBackServerPw
* ����   : ��ȡ���÷�������֤��token2
* ����   :
* ���   :
* ����   :
* ע��   :���20170523�޸�Ϊ��Э�������֤���ȡ
*******************************************************************************/
void GetBackServerPw(void)
{
    unsigned char CMD[] = "C_SESSION";
    unsigned char ucMd5data[30] = {0};
    unsigned char ucMd5string[40] = {0};
    unsigned char ucMd5string1[40] = {0};
    unsigned char ucMAC[15] = {0};
    unsigned char ucSdata[70] = {0};
    int i = 0;
    char *pstr = NULL;
    unsigned char TOTAL_LEN = 0, CMD_LEN = 9, MD5_LEN = 32;  //���20170522ɾ��MAC_LEN = 12�Ķ���
    uint8_t ucjiaoyan = 0;
																
    if(AngelPace == CONECTIP2OK)
    {
        if((SendDataStatus != OK)&&(AT_CGATT_Ctrl() == 1))
        {
           
            if(GPRS_or_WIFI == GPRS)
            {
								ClearUSART3BUF();	
               memset(ucUar3tbuf,0x00,sizeof(ucUar3tbuf));  //������ڻ���;
//--------------����Ϊ���20170522�����µ�Э���޸ķ��͵�����----------------------
							 UART3_SendString("AT+GPRS=\0");
							 SendDataToUSART(USART3,0x24);
							 SendDataToUSART(USART3,0x01);
							 SendDataToUSART(USART3,(MAC_LEN+2)|0x80);			
							 SendDataToUSART(USART3,REQ_SECOND_TOKEN);
							 for(i=0;i<MAC_LEN ;i++)
							 {
									SendDataToUSART(USART3,MAC_ID[i]);
							 }  
							 for(i = 0;i< MAC_LEN;i++)
								{
									ucjiaoyan += MAC_ID[i];
								}
							 ucjiaoyan +=REQ_SECOND_TOKEN;
							 SendDataToUSART(USART3,ucjiaoyan|0x80 );
							 SendDatasToUSART(USART3,0x6942 );
							 UART3_SendLR();
            }
            
            mytime = 0;
            SendDataStatus = OK;
            						
            memset(Token2, 0x00, sizeof(Token2));					//Tokenʹ��ǰ��clear��
        }
        else
        {
           AngelPace = GETBACKSERVERIPOK;
				  
				   SendDataStatus = NO;					//�򿪷��Ϳ���
        }
        //ClearUSART3BUF();
    }
    else
    {
        return;
    }
}
/*******************************************************************************
* ������ : GetADCSampleData
* ����   : ��ȡ˯������
* ����   :
* ���   :
* ����   :
* ע��   :���2017.5.17�޸ģ����µ�ͨѶЭ��
*******************************************************************************/
void GetADCSampleData(void)
{
    uint16_t ucjiaoyan = 0, i = 0;
    STATUS status = {0, 0, 0};
    int wave[12];
    const int waveOffset = 18;

	SleepData[0] = 0x24;  //��ͷ
	SleepData[1] = 0x01;  //�豸���
	SleepData[2] = 0x0F|0x80;  //���ݰ�����14�ֽ�
	SleepData[3] = 0x10;  //ָ�ʵʱ����   
    for(i=0;i<12;i++)
        wave[i]=i*40;
   
	if(((gPeopleFlag==1) || (gTurnFlag==1))&&(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED))
	{
		if(((gPulseRateHR>45)&&(gPulseRateHR<100))||(gPulseRateHR == 0))//��������
		{
		   SleepData[5] = gPulseRateHR;							
			 Last_gPulseRateHR = gPulseRateHR;	
			 Flag_SendDataAbnormal &= 0xFE;
		}
		else
		{
			 ABN_gPulseRateHR = gPulseRateHR;	
			 SleepData[5] = Last_gPulseRateHR;
			 Flag_SendDataAbnormal |= HR_ABNORMAL;
		}
		if(((gPulseRateRR>5)&&(gPulseRateRR<35))||( gPulseRateRR == 0))
		{
			SleepData[6] = gPulseRateRR;
			Last_gPulseRateRR = gPulseRateRR;
			Flag_SendDataAbnormal &= 0xFD;
		}	
		else
		{
			 ABN_gPulseRateRR = gPulseRateRR;
			SleepData[6] = Last_gPulseRateRR;
			 Flag_SendDataAbnormal |= RR_ABNORMAL;
		}				
//		SleepData[7] = (gPowerHeart << 4) | gPowerBreath;	//ǿ����������	����
//		SleepData[8] = (gPowerSample << 4) | gPowerTurn;	//ԭʼ�ź�ǿ��	����
        SleepData[7] = 128;	//ǿ����������	����
		SleepData[8] = 128;
		if(gTurnFlag)
			 SleepData[9] = 0x03 | (0x03 << 3);
		else
			SleepData[9] = 0x03 ;
	}
	else if((gPeopleFlag == 0)&&(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED))   //�����޷��������ʣ���״̬5
	{
		SleepData[5] = 0x00;	
		SleepData[6] = 0x00;	
		SleepData[7] = 0x00;	
		SleepData[8] = 0x00;	
		SleepData[9] = (0x05<<3)|0x02;   //0x02��ʾ���ź�
	}
	else
	{
		SleepData[5] = 0xFF;	
		SleepData[6] = 0xFF;	
		SleepData[7] = 0x00;	
		SleepData[8] = 0x00;	
		SleepData[9] = 0x00;	
	}
	SleepData[10] = CSQNual;			
	SleepData[4] = GetDataHead(&SleepData[5],6);  //����ͷ

//-----------------------ʱ������-------------------------------
	SleepData[11] = Timebuf[0];			//��
	SleepData[12] = Timebuf[1];			//��
	SleepData[13] = Timebuf[2];			//��
	SleepData[14] = Timebuf[3];			//ʱ
	SleepData[15] = Timebuf[4];			//��
	SleepData[16] = Timebuf[5];			//��
	//for(i = 0;i < 28;i++)
	//{
	//	printf("[%d]..%02x",i,SleepData[i]);
	//}
//--------------����У���-------------------------------------
	for(i = 3;i< 17;i++)
	{
		ucjiaoyan += SleepData[i];
	}
	SleepData[17] = ucjiaoyan|0x80;
//ȫ�����ݻ���0x80
    for ( i = 4; i < 18; i++)
    {
        SleepData[i] |= 0x80;
    }
//		gPeopleFlag = TRUE ;   
		if((gPeopleFlag == FALSE )&&(Monitor_Offline_Time >=SLEEPDATA_CHANGETIME))  //�����ⲻ���ͺ�����������
		{
			SleepData[18] = 0x69; //��β
			SleepData[19] = 0x42;
			SleepData[20] = '\0';
		}
/*****************ʵʱ���ݺ����12��������������******************************/
		else //����ʱ���ͺ�����������
		{
				getFilterWave(wave);
		//    SleepData[waveOffset + 0] = 0x24;		//��ͷ		
		//    SleepData[waveOffset + 1] = 0x01;		// �豸���
				SleepData[waveOffset + 0] = 0x10|0x80;		//���ݳ���		
				SleepData[waveOffset + 1] = 0x11;		// ָ�����
				
				// ��һ��
				SleepData[waveOffset + 3] = wave[0];	//��һ���������1
				SleepData[waveOffset + 4] = wave[1];	//��һ���������2
				SleepData[waveOffset + 5] = wave[2];	//��һ���������3
				SleepData[waveOffset + 6] = wave[3];	//��һ���������4

				// �ڶ���
				SleepData[waveOffset + 7] = wave[4];	//�ڶ����������1
				SleepData[waveOffset + 8] = wave[5];	//�ڶ����������2
			
				SleepData[waveOffset + 10] = wave[6];	//�ڶ����������3
				SleepData[waveOffset + 11] = wave[7];	//�ڶ����������4

				// ������
				SleepData[waveOffset + 12] = wave[8];	//�������������1
				SleepData[waveOffset + 13] = wave[9];	//�������������2
				SleepData[waveOffset + 14] = wave[10];	//�������������3
				SleepData[waveOffset + 15] = wave[11];	//�������������4

				SleepData[waveOffset + 2] = GetDataHead(&SleepData[waveOffset + 3],6);
				SleepData[waveOffset + 9] = GetDataHead(&SleepData[waveOffset + 10],6);

			//--------------����У���-------------------------------------
				for(i = 1;i< 16;i++)
				{
					ucjiaoyan += SleepData[waveOffset+i];
				}
				SleepData[waveOffset+16] = ucjiaoyan|0x80;
				for ( i = 2; i < 16; i++)
				{
						SleepData[waveOffset + i] |= 0x80;   
				}
				SleepData[waveOffset +17] = 0x69; //��β
				SleepData[waveOffset +18] = 0x42;
				SleepData[waveOffset +19] = '\0';
	 }
		if(Flag_COMDebug == 1)
		{
				printf("Time is:%d-%d-%d %d:%d:%d\r\n",Timebuf[0],Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5]);//���20170524���ӣ���ӡ����ʱ��
				printf("SampleData:%d mV  gPulseRateRR:%d  gPulseRateHR:%d\r\n",SampleData,gPulseRateRR,gPulseRateHR);
				printf("gTurnFlag:%d  gPeopleFlag:%d \r\n",gTurnFlag,gPeopleFlag);
				printf("gPowerHeart:%d  gPowerBreath:%d  gPowerSample:%d gPowerTurn:%d \r\n",gPowerHeart,gPowerBreath,gPowerSample,gPowerTurn); //���20170601����
		}
	}
/*******************************************************************************
* ������ : SendSleepData
* ����   : �������ݣ���ȡ��������֤
* ����   :
* ���   :
* ����   :
* ע��   :���2017023�޸ģ������µ�Э�鷢��MD5У�飬
*         У���ʽΪ����ͷ+ID+����+ָ��+MAC+"123456"+TOKEN2
*******************************************************************************/
unsigned char uCMD[] = "P_DATA";
void SendSleepData(void)
{
    unsigned char i = 0;
    unsigned char ucMd5data[30] = {0};
    unsigned char ucMd5string[40] = {0};
    unsigned char ucMd5string1[40] = {0};
    unsigned char ucSenddata[100] = {0};
    unsigned char TOTAL_LEN = 0, CMD_LEN = 6, MD5_LEN = 32; //���20170522ɾ��MAC_LEN = 12
    uint8_t len = 0; 
    uint8_t ucjiaoyan=0;		
		
	if(AngelPace == GETBACKSERVEROK)
	{
		memset(SendDataBuff,0x00,sizeof(SendDataBuff));
		if((SendDataStatus != OK)&&(AT_CGATT_Ctrl()==1))   //��������
		{	
			
//			if(SendSleepDataStatus == NO) //��Ҫ������װ����,���0170620�޸�
//				{	
         ClearUSART3BUF();						
					memset(TemporaryBuff,0x0,sizeof(TemporaryBuff));
						//��ȡMD5����
					sprintf(ucMd5data,"%s123456%s",MAC_IDstring,Token2);
					  if(Flag_COMDebug == 1)
						{
							printf("Token2:%s",Token2);						
							printf("ucMd5data:%s\r\n",ucMd5data);
						}
						MDString(ucMd5data,ucMd5string);
						HexToLowerStr(ucMd5string1,ucMd5string,16);
						//log	
						if(Flag_COMDebug == 1)
						  printf("ucMd5string1:%s\r\n",ucMd5string1);
            }

//           GetADCSampleData();	//��ȡ˯������

            if(GPRS_or_WIFI == GPRS)
            {
//                sprintf(SendDataBuff, "AT+GPRS=%s%s", TemporaryBuff, SleepData);
            }
            else
            {
//                sprintf(SendDataBuff, "%s%s", TemporaryBuff, SleepData);
            }
//            ClearUSART3BUF();
            if(GPRS_or_WIFI == GPRS)
            {
//                GPRSSendData(SendDataBuff, strlen(SendDataBuff));
//--------------����Ϊ���20170523�����µ�Э���޸ķ��͵�����----------------------
								 UART3_SendString_YB("AT+GPRS=",8);
								 SendDataToUSART(USART3,0x24);
								 SendDataToUSART(USART3,0x01 );
							   len = strlen(ucMd5string1);
								 SendDataToUSART(USART3,(len+MAC_LEN+2)|0x80);							
								 SendDataToUSART(USART3,REQ_SECOND_MD5);
							   for(i=0;i<len ;i++)
							   {
									  SendDataToUSART(USART3,ucMd5string1[i]);
								 }
								 for(i=0;i<MAC_LEN ;i++)
								 {
										SendDataToUSART(USART3,MAC_ID[i]);
								 } 
                 for(i = 0;i< len;i++)
									{
										ucjiaoyan += ucMd5string1[i];
									}								 
								 for(i = 0;i< MAC_LEN;i++)
									{
										ucjiaoyan += MAC_ID[i];
									}
								 ucjiaoyan +=REQ_SECOND_MD5;
								 SendDataToUSART(USART3,ucjiaoyan|0x80 );
								 SendDatasToUSART(USART3,0x6942 );
								 UART3_SendLR();
								 if(Flag_COMDebug == 1)
										printf("Send MD5 data!\r\n");						
//            }
            SendDataStatus = OK;
            mytime = 0;										//��ʼ��ʱ��ʱ
            YZTime = 0;	
           															
//            memset(SendDataBuff, 0x00, sizeof(SendDataBuff));
        }
       else   //��������
			 {
				   AngelPace = GETBACKSERVERIPOK;
				   
				   SendDataStatus = NO;					//�򿪷��Ϳ���
			 }       
    }
    else
    {
        return;
    }
}
/*******************************************************************************
* ������ : SendSleepDataRcvCtr
* ����   : ��ȡ���÷�������֤�Ƿ�ɹ�
* ����   :
* ���   :
* ����   :
* ע��   :
*******************************************************************************/
void SendSleepDataRcvCtr(void)
{
 	SendSleepDataRece(ucUar3tbuf);   
}
/*******************************************************************************
* ������ : GetBackServerPwRece
* ����   : ��ȡtoken2ʱ�����պ�������
* ����   :
* ���   :
* ����   :
* ע��   :���20170523�����µ�Э���޸�GPRS����ͨѶ��δ�޸�WiFi���ղ���
*******************************************************************************/
void GetBackServerPwRece(unsigned char ucP)
{
    char *pstr = NULL;
    unsigned char ucTokenOK = 0,i=0;
    uint8_t ucjiaoyan = 0;
	  uint8_t cmd[20];
	  
    if(ucP == GPRS)
    {
			  delay_ms_YB();									//�ȴ�����������
//			  delay_ms_YB2();
//			  delay_ms_YB2();
        pstr = strstr(ucUar3tbuf, "$");		  
        if(pstr != NULL)
        {
          delay_ms_YB2();
//					printf("Receinved Token2:%s\r\n",ucUar3tbuf);		
				  if((pstr[0] == CMD_START)&&(pstr[1] == TypeID)&&(pstr[3] == REQ_SECOND_TOKEN))   //���ص�ָ���ǻ�ȡtokenָ��
         {             					 
					  TOKEN2_LEN = (pstr[2]&0x7F)-2;
						 for(i = 0;i< TOKEN2_LEN;i++)
								{
									Token2[i] = pstr[i+4];
								}
						 for(i = 0;i< TOKEN2_LEN;i++)
							{
								ucjiaoyan += Token2[i];
							}
						   ucjiaoyan +=REQ_SECOND_TOKEN;
												
//							if(ucUar3tbuf[TOKEN2_LEN+2] == (ucjiaoyan|0x80) ) 			//token2У��ɹ�
//							{									
								  ucTokenOK = 1;
							    if(Flag_COMDebug == 1)
											printf("Get Token2 is:%s\r\n", Token2);
									WriteToken2ToFlash();    //���20170523���ӣ���ȡ�ɹ��򱣴�
							    Flag_Check_Status &= 0xFD;
								  AngelPace = GETBACKSERVEROK;		//�����֤��Ϸ���������һ��
								  SendDataStatus = NO;   //
							    
							    ClearUSART3BUF();  //������ڻ���;
//							}
//							else 											//У�鲻�ɹ�
//							{
//									printf("ERROR Token2:%s\r\n", ucUar3tbuf);
//									SendDataStatus = NO;
//								  ucTokenOK = 0;
//								  memset(Token2, 0x00, sizeof(Token2));
//							}	
						}
				    if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== SERVER_ABNORMAL_MESSAGE)) //MAC��֤����
						 {								
							 if(pstr[4] == SERVER_CHECK_MAC_ERR)
							 {
								  if(Flag_COMDebug == 1)
										printf("Server Return MAC Verify Error!\r\n");
									AngelPace = CONECTIP1;
									Flag_Check_Status |= ERROR_NO_TOKEN2;
									SendDataStatus = NO;					//�򿪷��Ϳ���
									SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
					//			  Flag_Check_Status = ERROR_MAC_ERR;
							 }
							 ClearUSART3BUF();
						 }
         }	
        if(strstr(ucUar3tbuf, "SHUT") != NULL)
       {
				  if(Flag_COMDebug == 1)
						printf("SendSleepData U3 ERROR2:%s\r\n", ucUar3tbuf);
					Flag_Check_Status |= ERROR_NO_TOKEN2;
					AngelPace = CONECTIP1;
					SendDataStatus = NO;					//�򿪷��Ϳ���
					SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
       }				
        if(mytime > GetFirstDataTimeOut) 				//��ʱʱ��Ϊ3s		//�ȴ��������ݳ�ʱ
        {
					  if(Flag_COMDebug == 1)
							printf("Time Out!%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
            AngelPace = GETBACKSERVERIPOK;
        }
        CheckSystemErrorContrl();				//ģ������쳣���
        if(strstr(ucUar3tbuf, "CLOSED") != NULL)
        {
					  if(Flag_COMDebug == 1)
							printf("CL:%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
            AngelPace = GETBACKSERVERIPOK;
        }
#if 0
        /***********************2017-03-02 start ��ȡtoken����OK�Ľ���취******************************/
        pstr = strstr(ucUar3tbuf, "OK\n");				//�ж��жϽ����Ƿ�����Ҫ������
        if(pstr != NULL)
        {
            delay_ms_YB2();
            if(strstr(ucUar3tbuf, "CLOSED") != NULL)
            {
                printf("CL:%s\r\n", ucUar3tbuf);
            }
            if(pstr[3 + 8] == '\n' || pstr[3 + 9] == '\n')
            {
                if(pstr[3] == '7')
                {
                    memcpy(Token2, pstr + 3, 8);
                }
                if(pstr[3] == '8')
                {
                    memcpy(Token2, pstr + 3, 9);
                }
                printf("Token2:%s\r\n", Token2);
            }
        }
        pstr = strstr(ucUar3tbuf, "K\n");
        if(pstr != NULL)
        {
            delay_ms_YB2();
            if(strstr(ucUar3tbuf, "CLOSED") != NULL)
            {
                printf("CL:%s\r\n", ucUar3tbuf);
            }
            if(pstr[2 + 8] == '\n' || pstr[2 + 9] == '\n')
            {
                if(pstr[2] == '7')
                {
                    memcpy(Token2, pstr + 2, 8);
                }
                if(pstr[2] == '8')
                {
                    memcpy(Token2, pstr + 2, 9);
                }
                printf("Token2:%s\r\n", Token2);
            }
        }
        /***********************2017-03-02 end ��ȡtoken����OK�Ľ���취******************************/
#endif
        //if(strstr(ucUar3tbuf,"C_SESSION or P_DATA is null")!=NULL){
        if(ucUar3tbuf[0] == '1' || ucUar3tbuf[0] == '2' || ucUar3tbuf[0] == '3')
        {
					  if(Flag_COMDebug == 1)
							printf("DataErr:%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        if(ucUar3tbuf[0] == '4' || ucUar3tbuf[0] == '5' || ucUar3tbuf[0] == '6' || ucUar3tbuf[0] == '7')
        {
					  if(Flag_COMDebug == 1)
							printf("DataErr:%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
            AngelPace = GETBACKSERVERIPOK;
        }
    }   			
}
/*******************************************************************************
* ������ : SendSleepDataRece
* ����   : ������MD5��֤���ݷ���
* ����   :
* ���   :
* ����   :
* ע��   :���20170523���µ�Э���޸ģ���֤�ɹ�����0x0401����֤ʧ�ܷ���0xF201
*******************************************************************************/
void SendSleepDataRece(unsigned char * p)
{
	unsigned char SeverTimebuf[20]={0},i=0;
	char Fbuff[3]={0};
	uint8_t len = 0;
	char *pstr = NULL;
	char *pstr1 = NULL;
	unsigned char receivetime[6];
	
	
	 ucUar3InterrFlag = 0;
	 								//��ֹ���ղ�����	
	 pstr = strstr(ucUar3tbuf, "$");
   pstr1 = strstr(ucUar3tbuf, "iB");	
   if((pstr != NULL)&&(pstr1 != NULL))
	 {
		 if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== REQ_SECOND_MD5)) //MD5��֤�ɹ�
		 {
             if(Flag_COMDebug == 1)
						printf("[OK]Server Return MD5 Verify OK!\r\n");
			 len = pstr[2]&0x7F-2;	
				for(i=0;i<6;i++)  //��ȡ������ʱ��
				{
					receivetime[i] = (pstr[4+i*2]&0x7F-0x30)*10+(pstr[5+i*2]&0x7F-0x30); //��ASCII�ַ��������ֽڵ�ʱ��ת��Ϊ1���ֽڵ�ʱ��		 
				}
				if(Flag_PowerOn == 0)   //����ͳ�ƵĽ���״̬
				{
					 Set_StatistEndTime();
				}
				if((receivetime[0]>0)&&(receivetime[0]<99)&&(receivetime[1]>0)&&(receivetime[1]<13)&&(receivetime[2]>0)&&(receivetime[2]<32))
				{
					 for(i=0;i<6;i++)
					{
						 Timebuf[i] = receivetime[i];
					}
					if(Flag_COMDebug == 1)
						printf("[OK]Server time is:%d-%d-%d %d:%d:%d\r\n",Timebuf[0],Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5]);
				}		
				SendDataStatus = NO;					//�򿪷��Ϳ���
//				UART3_SendString("AT+REGISTER=1");		//�����ⷢ������������
//				UART3_SendLR();
				REGISTEFlag = 1;
				Flag_TimeAdj = 0;
				Network_connect_time=0;
							
			  //GetGPRSPosition();
			  Send_GPRSPosition(Flag_Start_Mode,Position_LAC,Position_CID);
			  //if(Flag_CARD_ISCHANGE == CARD_HASCHANGE)  //���Ϳ���IMSI��
			  {
					if(Flag_COMDebug == 1)
							printf("SIM Card has changed!\r\n");
					//Send_CARD_IMSI();
                    Send_CARD_ICCID();
                    WriteMACToFlash();
					CARD_IMSI_Time = 0;
			  }			 
				 Flag_LinkStatus = START_GPRS_LINKOK;
				 AngelPace = SendSleepDataR;				//���뷢��˯������ģʽ
				 Flag_start_time = 0;
				 GPRS_ConnetTime =0;
				 Flag_CanSendStatistData = 1;
				 SleepDataBuffer_SendTime = 0;
				 Flag_PowerOn = 0;	
				Repower_GPRS_Count = 0;	
		 }
		 if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== SERVER_ABNORMAL_MESSAGE)) 
		 {		 
			 if(pstr[4] == SERVER_CHECK_MD5_ERR)  //MD5��֤����
			 {
				  if(Flag_COMDebug == 1)
						printf("Server Return MD5 Verify Error!\r\n");
					AngelPace = CONECTIP2OK;
					Flag_Check_Status |= ERROR_NO_TOKEN2;
					SendDataStatus = NO;					//�򿪷��Ϳ���
					SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
	//			  Flag_Check_Status = ERROR_MD5_ERR;					
			 }
			 if(pstr[4] == SERVER_CHECK_MAC_ERR)  //MAC��֤����
			 {
				  if(Flag_COMDebug == 1)
						printf("Server Return MAC Verify Error!\r\n");
					AngelPace = CONECTIP1;
				  Flag_Check_Status |= ERROR_NO_TOKEN2;
					SendDataStatus = NO;					//�򿪷��Ϳ���
					SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
	//			  Flag_Check_Status = ERROR_MAC_ERR;
					
			 }				 
		 }
		 ClearUSART3BUF();
     return ;		 
	 }
    if(strstr(ucUar3tbuf, "SEND FAIL") != NULL) 	//����ʧ��
    {
			  if(Flag_COMDebug == 1)
					printf("SendSleepData U3 ERROR0:%s\r\n", ucUar3tbuf);
        AngelPace = GETBACKSERVERIPOK;			//��������ģʽ
        SendDataStatus = NO;					//�򿪷��Ϳ���
        SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
    }
    if(strstr(ucUar3tbuf, "CLOSED") != NULL) 		//��·����ر�
    {
			  if(Flag_COMDebug == 1)
						printf("SendSleepData U3 ERROR1:%s\r\n", p);
        AngelPace = GETBACKSERVERIPOK;			//��������ģ��
        SendDataStatus = NO;					//�򿪷��Ϳ���
        SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
    }
    if(strstr(ucUar3tbuf, "SHUT") != NULL)
    {
			  if(Flag_COMDebug == 1)
					printf("SendSleepData U3 ERROR2:%s\r\n", ucUar3tbuf);
        Flag_Check_Status |= ERROR_NO_TOKEN2;
        AngelPace = CONECTIP1;
        SendDataStatus = NO;					//�򿪷��Ϳ���
        SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
    }
    if(YZTime >= GetFirstDataTimeOut)
    {
    	  YZTime =0;
			  if(Flag_COMDebug == 1)
					printf("Send MD5 TimeOut:%s\r\n", ucUar3tbuf);
        ClearUSART3BUF();								//��ջ���
        SendDataStatus = NO;					//�򿪷��Ϳ���
        SendSleepDataStatus = OK;				//���ͳɹ�

    }
    //CheckSystemErrorContrl();					//ģ������쳣���
}

/*******************************************************************************
* ������ : CheckSystemErrorContrl
* ����   : ���ģ������쳣�������POWER ON
* ����   :
* ���   :
* ����   :
* ע��   :
*******************************************************************************/
char CheckSystemErrorContrl(void)
{
    char statue = 0;

    if((strstr(ucUar3tbuf, "POWER ON") != NULL)||(strstr(ucUar3tbuf, "SMS Ready") != NULL))
    {
			 if(AngelPace == SendSleepDataR)
			 {
          Set_StatistStartTime();	
				  Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
				  GPRS_ConnetTime =0;	
			 }
        SendDataStatus = NO;					//�����ݷ���
        SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
        statue = 1;
			  if(Flag_COMDebug == 1)
					printf("Restart GPRS!\r\n");		 	
			 Flag_Send_GPRS_Position = 0;								 
			 SendDataStatus = NO;					//�򿪷��Ϳ���
			 SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
			 Flag_init = MAC_INIT_OK;  //��������ģ���ʼ��
			 start_time = 0; 
			 Flag_start_time = 1;	
			 ClearUSART3BUF();					 						 
    }

    return statue;
}
#if 0
void uart_send_sleep_data(void)
{
    //�·�ҽ��-9600bps
    char send_data[20];
    char sum_check;
    char i=0,j;
    //send_data[i++]=gPulseRateHR;
    send_data[i++]=SleepData[5]&(~0x80);
    //send_data[i++]=gPulseRateRR;
    send_data[i++]=SleepData[6]&(~0x80);
    send_data[i++]=gTurnFlag;
    send_data[i++]=gPeopleFlag;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    send_data[i++]=0x0d;
    send_data[i++]=0x0a;
   UART1_SendString_YB(send_data,7);
    //printf("%s",send_data);

}
#else
void uart_send_sleep_data(void)
{
    //������-����������
    char send_data[35];
    char sum_check;
    char i=0,j;
    uint16_t heart,resp;
    //����
    heart=SleepData[5]&(~0x80);
    resp=SleepData[5]&(~0x80);
    send_data[i++]=1;
    send_data[i++]=heart/256;
    send_data[i++]=heart%256;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
    //����
    i=0;
    send_data[i++]=3;
    send_data[i++]=resp/256;
    send_data[i++]=resp%256;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
     //��Ϣ
     i=0;
    send_data[i++]=0x4a;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
         //�鴤
    i=0;
    send_data[i++]=0x4b;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
         //������
    i=0;     
    send_data[i++]=0x4c;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
          //շת
    i=0;      
    send_data[i++]=0x4d;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=0x32;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
           //���˵�����
    i=0;       
    send_data[i++]=0x4e;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;

   UART1_SendString_YB(send_data,5);
    //printf("%s",send_data);

}
#endif
/*******************************************************************************
* ������ : SendSleepDataReally
* ����	 : ����˯�����ݴ���
* ����	 :
* ���	 :
* ����	 :
* ע��	 :
*******************************************************************************/
char SendSleepDataReally(void)
{
	int i=0;

    if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0)) 								//��������
     {

			for(i=0;i<50;i++)
				SleepData[i] = 0;
			ClearUSART3BUF();
			GetADCSampleData();									//��ȡ˯������				 
//			while(Flag_SleepData_SendOver ==1);
//			Flag_SleepData_SendOver = 1;				  
			//sprintf(SendDataBuff, "AT+SEND=%s",SleepData);		//��˯�����ݼ���GPRS���͵�AT+SENDָ��ͷ
			if(Flag_COMDebug == 1)
			{
				printf("SampleData AmpMultiple is:%f \r\n",ADC_AmpMultiple);					
				//					printf("GPRS SendData len is:%d \r\n",strlen(SendDataBuff));
				//					printf("GPRS SendData is ��AT+SEND=");  //���ڴ�ӡGPRS���͵�ָ������
				//					for(i=0;i<len;i++)
				//					{
				//						printf("0x%02x ",SleepData[i]);
				//					}
				printf("\r\n------------------------\r\n");
			}
            //GPRS_Send_Data(SleepData,strlen(SleepData));
			//GPRSSendData(SendDataBuff, strlen(SendDataBuff));
            if(0)
            {
                 //printf("send_data\r\n");
                uart_send_sleep_data();
            }
			if(AngelPace != SendSleepDataR)
			{				
				Statist_SleepStatus();					
			}
            else
            {
				GPRS_Send_Data(SleepData,strlen(SleepData));
//                if(GPRS_Send_Data(SleepData,strlen(SleepData))==0)
//                {
//                    RePowerOn_GPRS(); //����ģ���ʼ����ɣ����Խ�������������֤ 
//                } 
            }                
			Flag_SleepData_SendOver = 0;
                            
	 }

	 return 1;
}
/*******************************************************************************
*	�� �� ��:  Statist_SleepStatus
*	����˵��:  ͳ��˯��״̬
*	��    �Σ�
*	�� �� ֵ:
* ˵    �����ڶ����������ͳ��˯��״̬
*          ͳ��������״̬�ı��ʱ�򱣴棬����/����/�嶯��С��20s�嶯��ͳ�ƣ�С��1��������໤��ͳ��
*          ÿ��������ౣ��һ��Сʱ�����ݣ����ʺ���ֵ10����ͳ��һ��
*******************************************************************************/
void Statist_SleepStatus(void)
{
	  uint8_t i = 0;
	  uint8_t AveraveHR = 0;
	  uint8_t AveraveRR = 0;
	  unsigned char buf[2];
	
	  if((gPulseRateHR!=0)&&(gPulseRateRR!=0)&&(gPulseRateHR<200)&&(gPulseRateRR<60))//�ۻ����ʺ�����ֵ
		 {
				Statist_AddHR += gPulseRateHR;
				Statist_AddRR += gPulseRateRR;
				Statist_AddCount++;
		 }	 
/*******************************�嶯״̬**********************************/
		 if(gTurnFlag == 1)    //
		 {
			 if(Keep_StatusFlag == STATIST_TURN)  //�����嶯״̬
			 {
				  TurnKeepTime += AT_CGATT_Count;  //�嶯ʱ���ۼ�
			 }
			 if(Keep_StatusFlag != STATIST_TURN)   //��ʼ�嶯
			 {
				 if(Keep_StatusFlag == STATIST_NOPEOPLE )
				 {
					   NoPeopleKeepTime += AT_CGATT_Count;
				 }
				 if(Keep_StatusFlag == STATIST_PEOPLE )
				 {
					   PeopleKeepTime += AT_CGATT_Count;
				 }
				 if(Flag_NoNetWorkStart == 1)
				 {
					  Flag_NoNetWorkStart = 2;
					  Last_StatusFlag  = Keep_StatusFlag;
					  Keep_StatusFlag = STATIST_TURN;
					  if(Flag_COMDebug == 1)
					     printf("First Change! \r\n");
				 }
				 else
				 {
				 //---------------------------�嶯֮ǰ������״̬����60s----------------------------------------
				  if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60))//
					{
						  if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�ϴγ���20s�嶯���򱣴�
							{
								  AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
									AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
									Statist_AddCount = 0;
									Statist_AddHR=0;
									Statist_AddRR = 0;
								  Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
							}
							if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //���ϴ�����20s�嶯�����嶯ʱ�丳ֵ����֮ǰ״̬
							{
									for(i=0;i<6;i++)
									{
										 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
									}
							}
							if(Last_StatusFlag == STATIST_PEOPLE) //���ϴ�Ϊ����״̬
							{
								 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
								 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
								 Statist_AddCount = 0;
								 Statist_AddHR=0;
								 Statist_AddRR = 0;
								 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
								 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
								 Flag_SavepPos++;
								 PeopleKeepTime = 0;
								 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
								 if( Flag_SavepPos == 6)
									  Flag_SavepPos = 0;						
							}
							Last_StatusFlag  = Keep_StatusFlag;
							TurnKeepTime = 0;
							for(i=0;i<6;i++)
							{
								 Statist_TurnStartTimebuf[i]= Timebuf[i];  //��ȡ״̬�ı俪ʼʱ��
								 Statist_NoPeopleEndTimebuf[i]= Timebuf[i];
							}	
					}
					if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60))//�嶯֮ǰ������״̬С��60s��״̬��Ч
				 	{
						  if(Last_StatusFlag == STATIST_PEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_PeopleEndTimebuf[i] = Timebuf[i];
										Statist_TurnStartTimebuf[i]= Timebuf[i];
									}
								  PeopleKeepTime += NoPeopleKeepTime;
								  TurnKeepTime = 0;									
							}							
						  if(Last_StatusFlag == STATIST_TURN)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_TurnEndTimebuf[i] = Timebuf[i];
									}
									TurnKeepTime += NoPeopleKeepTime;
							}
							
					}
		//-----------------------�嶯֮ǰ������״̬---------------------------------------------------		
					if(Keep_StatusFlag ==STATIST_PEOPLE)  //�ϸ�״̬�����ˣ���ֱ�ӱ������ϸ�״̬
					{
						 if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�ϴγ���20s�嶯���򱣴�
							{
								  AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
									AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
									Statist_AddCount = 0;
									Statist_AddHR=0;
									Statist_AddRR = 0;
								  Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
							}
							if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  
							{
								 for(i=0;i<6;i++)
									{
										 Statist_PeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
									}
									PeopleKeepTime += TurnKeepTime;	
							}
							if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //���ϸ�״̬������
							{
								buf[0] = 0;
								buf[1]= 0;
								Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
							}
							if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //���ϸ�״̬������
							{
								 for(i=0;i<6;i++)
									{
										 Statist_PeopleStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];
									}
									PeopleKeepTime += NoPeopleKeepTime;	
							}
							Last_StatusFlag  = Keep_StatusFlag;
							TurnKeepTime = 0;
							for(i=0;i<6;i++)
							{
								 Statist_TurnStartTimebuf[i]= Timebuf[i];  //��ȡ״̬�ı俪ʼʱ��
								 Statist_PeopleEndTimebuf[i]= Timebuf[i];  //��ȡ״̬�ı俪ʼʱ��
							}	
					}
																		
					Keep_StatusFlag = STATIST_TURN;						
					Flag_SavepPos = 0;
					if(Flag_COMDebug == 1)
					   printf("Start Turn! \r\n");
		 	 }
		  }				 
		}

/*******************************��ʼ����״̬**********************************/		 
		 if(gPeopleFlag == 0) //
		 {
			 if(Keep_StatusFlag == STATIST_NOPEOPLE)  //��������״̬
			 {
				  NoPeopleKeepTime += AT_CGATT_Count;  //����ʱ���ۼ�
			 }
			 if(Keep_StatusFlag != STATIST_NOPEOPLE)   //��ʼ����
			 {
				 if(Keep_StatusFlag == STATIST_TURN )
				 {
					  TurnKeepTime += AT_CGATT_Count;
				 }
				 if(Keep_StatusFlag == STATIST_PEOPLE )
				 {
					   PeopleKeepTime += AT_CGATT_Count;
				 }
				 
				if(Flag_NoNetWorkStart == 1)
				 {
					  Flag_NoNetWorkStart = 2;
					  Last_StatusFlag  = Keep_StatusFlag;
					  Keep_StatusFlag = STATIST_NOPEOPLE;
						if(Flag_COMDebug == 1)
							printf("First Change! \r\n");
				 }
				 else
				 {				 
	//--------------�ϸ�״̬���嶯----------------------------------------			 
				  if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //�嶯С��20s
					{
						 if(Last_StatusFlag == STATIST_PEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_PeopleEndTimebuf[i] = Timebuf[i];
										Statist_NoPeopleStartTimebuf[i] = Timebuf[i];										
								}	
									PeopleKeepTime += TurnKeepTime;
								NoPeopleKeepTime = 0;									
							}							
						  if(Last_StatusFlag == STATIST_NOPEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_NoPeopleEndTimebuf[i] = Timebuf[i];
									}
									NoPeopleKeepTime += TurnKeepTime;
							}						
					}
					if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�嶯����20s
					{
						if(Last_StatusFlag == STATIST_PEOPLE)  //�嶯֮ǰ�����ˣ�ֱ�ӱ���
						{
							 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
							 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
							 Statist_AddCount = 0;
							 Statist_AddHR=0;
							 Statist_AddRR = 0;
							 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
							 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
							 Flag_SavepPos++;
							 PeopleKeepTime = 0;
							 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
							 if( Flag_SavepPos == 6)
									Flag_SavepPos = 0;			
							
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //���ϸ�״̬������
						{
								buf[0] = 0;
								buf[1]= 0;
								Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //���ϸ�״̬������
						{
							 for(i=0;i<6;i++)
								{
									 Statist_TurnStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];								 
								}
						}
						Last_StatusFlag  = Keep_StatusFlag;	
						NoPeopleKeepTime = 0;
						for(i=0;i<6;i++)
						{
							 Statist_NoPeopleStartTimebuf[i]= Timebuf[i];  //��ȡ״̬�ı俪ʼʱ��
							 Statist_TurnEndTimebuf[i]= Timebuf[i];
						}
						
					}
//--------------�ϸ�״̬������----------------------------------------	
				 if(Keep_StatusFlag == STATIST_PEOPLE) 
				 {
					  if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //���ϸ�״̬������
						{
								buf[0] = 0;
								buf[1]= 0;
								Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //���ϸ�״̬������
						{
							 for(i=0;i<6;i++)
								{
									 Statist_PeopleStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];
								}
								PeopleKeepTime += NoPeopleKeepTime;	
						}
						if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�ϴγ���20s�嶯���򱣴�
							{
								  AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
									AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
									Statist_AddCount = 0;
									Statist_AddHR=0;
									Statist_AddRR = 0;
								  Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
							}
							if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //���ϴ�����20s�嶯�����嶯ʱ�丳ֵ����֮ǰ״̬
							{
									for(i=0;i<6;i++)
									{
										 Statist_PeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
									}
									PeopleKeepTime += TurnKeepTime;	
							}						
							Last_StatusFlag  = Keep_StatusFlag;
						NoPeopleKeepTime = 0;	
						for(i=0;i<6;i++)
					  {
						   Statist_PeopleEndTimebuf[i]= Timebuf[i];  //��ȡ״̬�ı俪ʼʱ��
							 Statist_NoPeopleStartTimebuf[i]= Timebuf[i];
					  }	
           						
				 }
				 					
					Keep_StatusFlag = STATIST_NOPEOPLE;						
					Flag_SavepPos = 0;
					if(Flag_COMDebug == 1)
						printf("Start no people on bed! \r\n");	
			 }
		 }				 
	 }
/*******************************����״̬**********************************/	
   if((gPeopleFlag == 1)&&(gPowerTurn == 0)) //
	 {				 
      if(Keep_StatusFlag == STATIST_PEOPLE)  //��������
			{
				 PeopleKeepTime+= AT_CGATT_Count;
				 if(PeopleKeepTime>=540)  //  9���Ӽ���һ������
				 {
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;				  
						Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
						Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
						Flag_SavepPos++;
						if( Flag_SavepPos == 6)   //6������Ϊ1��Сʱ
						{
							 Save_StatistStatusData(Statist_PeopleStartTimebuf,Timebuf,STATIST_PEOPLE ,6,Save_SleepHRData,Save_SleepRRData);
							 Flag_SavepPos = 0;
							 for(i=0;i<6;i++)
								{
										Statist_PeopleStartTimebuf[i]= Timebuf[i];  //��ȡ״̬�ı俪ʼʱ��
								}
						}
						if(Flag_COMDebug == 1)
							printf("People keep on bed!,keep time:%d s,average HR:%d,average RR:%d \r\n",PeopleKeepTime,AveraveHR,AveraveRR);
						PeopleKeepTime = 0;
				 }
			}
		if(Keep_StatusFlag != STATIST_PEOPLE)  //��ʼ����
		 {
			 if(Keep_StatusFlag == STATIST_TURN )
				 {
					  TurnKeepTime += AT_CGATT_Count;
				 }
				 if(Keep_StatusFlag == STATIST_NOPEOPLE )
				 {
					   NoPeopleKeepTime += AT_CGATT_Count;
				 }
			if(Flag_NoNetWorkStart == 1)
			 {
					Flag_NoNetWorkStart = 2;
					Last_StatusFlag  = Keep_StatusFlag;
				 Keep_StatusFlag = STATIST_PEOPLE;
				if(Flag_COMDebug == 1)
						printf("First Change! \r\n");
			 }
			 else
			 {
		//-----------------�ϸ�״̬Ϊ�嶯-------------------------	 
			  if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //�嶯С��20s
					{
						 if(Last_StatusFlag == STATIST_PEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_PeopleEndTimebuf[i] = Timebuf[i];									
									}	
									PeopleKeepTime += TurnKeepTime;										
							}							
						  if(Last_StatusFlag == STATIST_NOPEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_NoPeopleEndTimebuf[i] = Timebuf[i];
										Statist_PeopleStartTimebuf[i]= Timebuf[i]; 
									}
									NoPeopleKeepTime += TurnKeepTime;
									PeopleKeepTime = 0;									
							}						
					}
					if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�嶯����20s
					{
						if(Last_StatusFlag == STATIST_PEOPLE)  //�嶯֮ǰ�����ˣ�ֱ�ӱ���
						{
							 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
							 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
							 Statist_AddCount = 0;
							 Statist_AddHR=0;
							 Statist_AddRR = 0;
							 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
							 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
							 Flag_SavepPos++;
							 PeopleKeepTime = 0;
							 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
							 if( Flag_SavepPos == 6)
									Flag_SavepPos = 0;			
							
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //���ϸ�״̬������
						{
								buf[0] = 0;
								buf[1]= 0;
								Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //���ϸ�״̬������
						{
							 for(i=0;i<6;i++)
								{
									 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
								}
								TurnKeepTime += NoPeopleKeepTime;
						}
						Last_StatusFlag  = Keep_StatusFlag;
						PeopleKeepTime = 0;
						for(i=0;i<6;i++)
						{
							 Statist_PeopleStartTimebuf[i]= Timebuf[i];  //��ȡ״̬�ı俪ʼʱ��
							 Statist_TurnEndTimebuf[i] = Timebuf[i];
						}						
					}
			//-----------------�ϸ�״̬Ϊ����-------------------------		
					if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60))//
					{
						  if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�ϴγ���20s�嶯���򱣴�
							{
								  AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
									AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
									Statist_AddCount = 0;
									Statist_AddHR=0;
									Statist_AddRR = 0;
								  Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
							}
							if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //���ϴ�����20s�嶯�����嶯ʱ�丳ֵ����֮ǰ״̬
							{
									for(i=0;i<6;i++)
									{
										 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
									}
							}
							if(Last_StatusFlag == STATIST_PEOPLE) //���ϴ�Ϊ����״̬
							{
								 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
								 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
								 Statist_AddCount = 0;
								 Statist_AddHR=0;
								 Statist_AddRR = 0;
								 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
								 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
								 Flag_SavepPos++;
								 PeopleKeepTime = 0;
								 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
								 if( Flag_SavepPos == 6)
									  Flag_SavepPos = 0;						
							}
							Last_StatusFlag  = Keep_StatusFlag;
							PeopleKeepTime = 0;
							for(i=0;i<6;i++)
							{
								 Statist_PeopleStartTimebuf[i]= Timebuf[i];  //��ȡ״̬�ı俪ʼʱ��
								 Statist_NoPeopleEndTimebuf[i]= Timebuf[i];
							}
					}
					if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60))//�嶯֮ǰ������״̬С��60s��״̬��Ч
				 	{
						  if(Last_StatusFlag == STATIST_PEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_PeopleEndTimebuf[i] = Timebuf[i];
									}
									PeopleKeepTime += NoPeopleKeepTime;	
							}							
						  if(Last_StatusFlag == STATIST_TURN)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_TurnEndTimebuf[i] = Timebuf[i];
										Statist_PeopleStartTimebuf[i]= Timebuf[i];
									}
									TurnKeepTime += NoPeopleKeepTime;	
									PeopleKeepTime = 0;
							}
							
					}						   					
					Keep_StatusFlag = STATIST_PEOPLE;	
					
				if(Flag_COMDebug == 1)
					printf("Start people on bed! \r\n");
		  }
	   }
	 }	
}
/*******************************************************************************
*	�� �� ��:  Save_StatistStatusData
*	����˵��:  ����״̬ͳ������ʱ��
*	��    �Σ�*starttime��ʼʱ�䣬*endtime����ʱ��,status״̬��len ���ʺ������鳤�ȣ�averavehrƽ�����ʣ�averagerrƽ������
*	�� �� ֵ:
* ˵    ����
*******************************************************************************/
void  Save_StatistStatusData(unsigned char *starttime,unsigned char *endtime,uint8_t status,uint8_t len,unsigned char *averavehr,unsigned char *averagerr)
{
	  uint8_t i=0;
	
	  Buffer_SleepData[Flag_SleepDataBuffer_Save][0] = CMD_START;
	  Buffer_SleepData[Flag_SleepDataBuffer_Save][1] = TypeID;
	  Buffer_SleepData[Flag_SleepDataBuffer_Save][2] = (2*len+15)|0x80;
	  Buffer_SleepData[Flag_SleepDataBuffer_Save][3] = SEND_STATISTICS_SLEEPDTAT;
	  for(i=0;i<6;i++)
		{
			Buffer_SleepData[Flag_SleepDataBuffer_Save][4+i] = starttime[i]|0x80;
		}
		for(i=0;i<6;i++)
		{
			Buffer_SleepData[Flag_SleepDataBuffer_Save][10+i] = endtime[i]|0x80;
		}		
		Buffer_SleepData[Flag_SleepDataBuffer_Save][16] = status|0x80;
		for(i=0;i<len;i++)
		{
			Buffer_SleepData[Flag_SleepDataBuffer_Save][17+2*i] = averavehr[i]|0x80;
			Buffer_SleepData[Flag_SleepDataBuffer_Save][18+2*i] = averagerr[i]|0x80;
		}

		Buffer_SleepData[Flag_SleepDataBuffer_Save][17+2*len] = 0xff;
		Buffer_SleepData[Flag_SleepDataBuffer_Save][18+2*len] = 0x69;
		Buffer_SleepData[Flag_SleepDataBuffer_Save][19+2*len] = 0x42;
		Buffer_SleepData[Flag_SleepDataBuffer_Save][20+2*len] = '\0';
		
		Flag_SleepDataBuffer_Save++;    //��һ������λ��
		if(Flag_SleepDataBuffer_Save==SLEEPDTATABUF)
		{
			  Flag_SleepDataBuffer_Save=0;
			  if(Flag_SleepDataBuffer_Send == Flag_SleepDataBuffer_Save)
					Flag_SleepDataBuffer_Send++;
		}
			
		 if(Flag_COMDebug == 1)
		{
			printf("\r\n--------Save Statistics Data:%d-----------\r\n",Flag_SleepDataBuffer_Save-1);
			printf("Start Time is:%d-%d-%d %d:%d:%d\r\n",starttime[0],starttime[1],starttime[2],starttime[3],starttime[4],starttime[5]);
		  printf("Finish Time is:%d-%d-%d %d:%d:%d\r\n",endtime[0],endtime[1],endtime[2],endtime[3],endtime[4],endtime[5]);
		  printf("Statistics data len is:%d",len);
			printf("Statistics status is:%d\r\n",status);
		}
}
/*******************************************************************************
*	�� �� ��:  Send_StatistStatusData
*	����˵��:  ���ͱ����״̬ͳ������ʱ��
*	��    �Σ�
*	�� �� ֵ:
* ˵    ����
*******************************************************************************/
void  Send_StatistStatusData(void)
{
	  uint8_t len =0;
	  uint8_t i=0;
	  uint8_t sendstatistdata[60];
	
//	  len = strlen(Buffer_SleepData[Flag_SleepDataBuffer_Send]);
	
	  //sprintf(sendstatistdata, "AT+GPRS=%s",Buffer_SleepData[Flag_SleepDataBuffer_Send]);		//��˯�����ݼ���GPRS���͵�AT+SENDָ��ͷ
		if(Flag_COMDebug == 1)
		{
			 printf("GPRS send Statistics buff is :%d \r\n",Flag_SleepDataBuffer_Send);
//			  for(i=0;i<len;i++)
//			  {
//					printf("0x%02x ",Buffer_SleepData[Flag_SleepDataBuffer_Send][i]);
//			   }
			  printf("\r\n----------------------------\r\n");
		}
		GPRS_Send_Data(Buffer_SleepData[Flag_SleepDataBuffer_Send], strlen(Buffer_SleepData[Flag_SleepDataBuffer_Send]));
	  
}
/*******************************************************************************
*	�� �� ��:  Set_StatistStartTime
*	����˵��:  ������ʼʱ������ͳ�ƵĿ�ʼʱ��
*	��    �Σ�
*	�� �� ֵ:
* ˵    ����
*******************************************************************************/
void  Set_StatistStartTime(void)
{
	uint8_t i = 0;
		printf("Set_StatistStartTime...%d\r\n",Flag_COMDebug);
		Flag_NoNetWorkStart = 1;         //��ʼ����
		if((gPeopleFlag == 1)&&(gPowerTurn == 0))  //����״̬
		 {      
				
				Keep_StatusFlag = STATIST_PEOPLE;
				Last_StatusFlag = STATIST_PEOPLE;
		 }
		 if((gPeopleFlag == 0)&&(gPowerTurn == 0))  //����״̬
		{

			Keep_StatusFlag = STATIST_NOPEOPLE;
			Last_StatusFlag = STATIST_NOPEOPLE;
		}	
		if(gPowerTurn == 1)   //�嶯״̬
		{
		  
			Keep_StatusFlag = STATIST_TURN;
			Last_StatusFlag = STATIST_TURN;
		}
		PeopleKeepTime = 0;
		TurnKeepTime = 0;
		NoPeopleKeepTime = 0;
		for(i=0;i<6;i++)
		{
				Statist_NoPeopleStartTimebuf[i]= Timebuf[i];
			  Statist_NoPeopleEndTimebuf[i]= Timebuf[i];
				Statist_TurnStartTimebuf[i]= Timebuf[i];
			  Statist_TurnEndTimebuf[i]= Timebuf[i];
				Statist_PeopleStartTimebuf[i]= Timebuf[i];
			  Statist_PeopleEndTimebuf[i]= Timebuf[i];
		}	
		if(Flag_COMDebug == 1)
			printf("Network start disconnect! \r\n");
}
/*******************************************************************************
*	�� �� ��:  Set_StatistEndTime
*	����˵��:  �������������ý���ʱ�䲢ͳ��
*	��    �Σ�
*	�� �� ֵ:
* ˵    ����
*******************************************************************************/
void  Set_StatistEndTime(void)
{
	 uint8_t AveraveHR = 0;
	 uint8_t AveraveRR = 0;
	 uint8_t i = 0;
	 unsigned char buf[2];
	
	  Flag_NoNetWorkStart = 0;         //������
/**********************����ʱΪ����****************************************/
	  if(Keep_StatusFlag == STATIST_PEOPLE) 
		 {
				if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //���ϸ�״̬������
				{
						buf[0] = 0;
						buf[1]= 0;
						Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);					  
					
				}
				if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //���ϸ�״̬������
				{
					 for(i=0;i<6;i++)
						{
							 Statist_PeopleStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];
						}
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�ϴγ���20s�嶯���򱣴�
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //���ϴ�����20s�嶯�����嶯ʱ�丳ֵ����֮ǰ״̬
				{
						for(i=0;i<6;i++)
						{
							 Statist_PeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
						}
				}						
				 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
				 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
				 Statist_AddCount = 0;
				 Statist_AddHR=0;
				 Statist_AddRR = 0;
				 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
				 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
				 Flag_SavepPos++;
				 PeopleKeepTime = 0;
				 Save_StatistStatusData(Statist_PeopleStartTimebuf,Timebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
				 Flag_SavepPos = 0;							
		 }
/**********************����ʱΪ����********************************************/	
   if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60))//
		{
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�ϴγ���20s�嶯���򱣴�
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;
						Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //���ϴ�����20s�嶯�����嶯ʱ�丳ֵ����֮ǰ״̬
				{
						for(i=0;i<6;i++)
						{
							 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
						}
				}
				if(Last_StatusFlag == STATIST_PEOPLE) //���ϴ�Ϊ����״̬
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);			 
					 Flag_SavepPos = 0;						
				}
				buf[0] = 0;
				buf[1]= 0;
			 Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);		
		}
		if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60))//����ʱΪ���˲���С��60s
		{
				if(Last_StatusFlag == STATIST_PEOPLE)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,Timebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
					 Flag_SavepPos = 0;						
				}							
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime >= 20))  //�嶯20s
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;
						Save_StatistStatusData(Statist_TurnStartTimebuf,Timebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime < 20))  //�嶯С��20s
				{
						buf[0] = 0;
					  buf[1]= 0;
					  Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);	
				}
				if(Last_StatusFlag == STATIST_NOPEOPLE)
				{
					 buf[0] = 0;
					 buf[1]= 0;
					 Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);	
				}
		}			 
 /*******************�ϸ�״̬���嶯******************************************************/
		if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //�嶯С��20s
		{
			 if(Last_StatusFlag == STATIST_PEOPLE)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,Timebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
					 Flag_SavepPos = 0;	
					
				}							
				if(Last_StatusFlag == STATIST_NOPEOPLE)
				{
						buf[0] = 0;
			      buf[1]= 0;
			      Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);
				}	
				if(Last_StatusFlag == STATIST_TURN)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					Statist_AddCount = 0;
					Statist_AddHR=0;
					Statist_AddRR = 0;
					Save_StatistStatusData(Statist_TurnStartTimebuf,Timebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);	
				}			
		}
		if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�嶯����20s
		{
			if(Last_StatusFlag == STATIST_PEOPLE)  //�嶯֮ǰ�����ˣ�ֱ�ӱ���
			{
				 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
				 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
				 Statist_AddCount = 0;
				 Statist_AddHR=0;
				 Statist_AddRR = 0;
				 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
				 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
				 Flag_SavepPos++;
				 PeopleKeepTime = 0;
				 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);				 
				 Flag_SavepPos = 0;			
				
			}
			if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //���ϸ�״̬������
			{
					buf[0] = 0;
					buf[1]= 0;
					Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
			}
			if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //���ϸ�״̬������
			{
				 for(i=0;i<6;i++)
					{
						 Statist_TurnStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];					 
					}
			}
			AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
			AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
			Statist_AddCount = 0;
			Statist_AddHR=0;
			Statist_AddRR = 0;
			Save_StatistStatusData(Statist_TurnStartTimebuf,Timebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);			
		}	  
}
/*******************************************************************************
*	�� �� ��:  Statist_NextDayStart
*	����˵��:  ÿ������12������ͳ��
*	��    �Σ�
*	�� �� ֵ:
* ˵    ����
*******************************************************************************/
void  Statist_NextDayStart(void)
{
	 uint8_t AveraveHR = 0;
	 uint8_t AveraveRR = 0;
	 uint8_t i = 0;
	 unsigned char buf[2];
	 unsigned char time[6];
	
	 for(i=0;i<3;i++)
	 {
		  time[i] = Timebuf[i];
	 }
	 time[3] = 11;
	 time[4] = 59;
	 time[5] = 59;
	  
/**********************����ʱΪ����****************************************/
	  if(Keep_StatusFlag == STATIST_PEOPLE) 
		 {
				if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //���ϸ�״̬������
				{
						buf[0] = 0;
						buf[1]= 0;
						Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);					  
					
				}
				if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //���ϸ�״̬������
				{
					 for(i=0;i<6;i++)
						{
							 Statist_PeopleStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];
						}
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�ϴγ���20s�嶯���򱣴�
					{
							AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
							AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
							Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
					}
					if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //���ϴ�����20s�嶯�����嶯ʱ�丳ֵ����֮ǰ״̬
					{
							for(i=0;i<6;i++)
							{
								 Statist_PeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
							}
					}						
				 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
				 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
				 Statist_AddCount = 0;
				 Statist_AddHR=0;
				 Statist_AddRR = 0;
				 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
				 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
				 Flag_SavepPos++;
				 PeopleKeepTime = 0;
				 Save_StatistStatusData(Statist_PeopleStartTimebuf,time,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
				 Flag_SavepPos = 0;							
		 }
/**********************����ʱΪ����********************************************/	
   if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60))//
		{
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�ϴγ���20s�嶯���򱣴�
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;
						Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //���ϴ�����20s�嶯�����嶯ʱ�丳ֵ����֮ǰ״̬
				{
						for(i=0;i<6;i++)
						{
							 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
						}
				}
				if(Last_StatusFlag == STATIST_PEOPLE) //���ϴ�Ϊ����״̬
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);			 
					 Flag_SavepPos = 0;						
				}
       buf[0] = 0;
			 buf[1]= 0;
			 Save_StatistStatusData(Statist_NoPeopleStartTimebuf,time,STATIST_NOPEOPLE,1,buf,buf);		
		}
		if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60))//�嶯֮ǰ������״̬С��60s��״̬��Ч
		{
				if(Last_StatusFlag == STATIST_PEOPLE)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,time,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
					 Flag_SavepPos = 0;	
						
				}							
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime >= 20))  //�嶯20s
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;
						Save_StatistStatusData(Statist_TurnStartTimebuf,time,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime < 20))  //�嶯С��20s
				{
						buf[0] = 0;
			      buf[1]= 0;
			      Save_StatistStatusData(Statist_NoPeopleStartTimebuf,time,STATIST_NOPEOPLE,1,buf,buf);	
				}
				if(Last_StatusFlag == STATIST_NOPEOPLE)
				{
					 buf[0] = 0;
			     buf[1]= 0;
			     Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);	
				}
				
		}			 
 /*******************�ϸ�״̬���嶯******************************************************/
		if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //�嶯С��20s
		{
			 if(Last_StatusFlag == STATIST_PEOPLE)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,time,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
					 Flag_SavepPos = 0;	
					
				}							
				if(Last_StatusFlag == STATIST_NOPEOPLE)
				{
						buf[0] = 0;
			      buf[1]= 0;
			      Save_StatistStatusData(Statist_NoPeopleStartTimebuf,time,STATIST_NOPEOPLE,1,buf,buf);
				}	
        if(Last_StatusFlag == STATIST_TURN)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					Statist_AddCount = 0;
					Statist_AddHR=0;
					Statist_AddRR = 0;
					Save_StatistStatusData(Statist_TurnStartTimebuf,Timebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);	
				}					
		}
		if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //�嶯����20s
		{
			if(Last_StatusFlag == STATIST_PEOPLE)  //�嶯֮ǰ�����ˣ�ֱ�ӱ���
			{
				 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
				 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
				 Statist_AddCount = 0;
				 Statist_AddHR=0;
				 Statist_AddRR = 0;
				 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
				 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
				 Flag_SavepPos++;
				 PeopleKeepTime = 0;
				 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);				 
				 Flag_SavepPos = 0;			
				
			}
			if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //���ϸ�״̬������
			{
					buf[0] = 0;
					buf[1]= 0;
					Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
			}
			if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //���ϸ�״̬������
			{
				 for(i=0;i<6;i++)
					{
						 Statist_TurnStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];					 
					}
			}
			AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
			AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
			Statist_AddCount = 0;
			Statist_AddHR=0;
			Statist_AddRR = 0;
			Save_StatistStatusData(Statist_TurnStartTimebuf,time,STATIST_TURN,1,&AveraveHR,&AveraveRR);			
		}
  //���³�ʼ������  
    Statist_AddCount = 0;
	  Statist_AddHR = 0;
		Statist_AddRR = 0;
		Flag_SavepPos = 0;
		TurnKeepTime = 0;
		PeopleKeepTime = 0;
		NoPeopleKeepTime = 0;
		Set_StatistStartTime();
		
}
/****************************************************************************
*	�� �� ��:  Req_Users_Binding
*	����˵��:  ��ѯ�Ƿ�����û�
*	��    �Σ�
*	�� �� ֵ:
* ˵    �������20170523����
*****************************************************************************/
void Req_Users_Binding(void)
{
	 Flag_SleepData_SendOver = 1;
	 UART3_SendString_YB("AT+SEND=",8);
	 SendDataToUSART(USART3,0x24);
	 SendDataToUSART(USART3,0x01 );
	 SendDataToUSART(USART3,0x82);			
	 SendDataToUSART(USART3,REQ_BINDING_USERS);
	 SendDataToUSART(USART3,0xFF);
	 SendDatasToUSART(USART3,0x6942 );
	 UART3_SendLR();
	 delay_ms(10);
	 Flag_SleepData_SendOver = 0;
}
/****************************************************************************
*	�� �� ��:  SendSleepDataReallyRcvCtr
*	����˵��:  ��������ģ�鷵�ص�����
*	��    �Σ�
*	�� �� ֵ:
* ˵    ����
*****************************************************************************/
char SendSleepDataReallyRcvCtr(void)
{
	uint8_t i,j;
	char *pstr =NULL;
	char *pstr1=NULL;
	unsigned char  receivetime[6];

	if(!ucUar3InterrFlag){
		return 0;
	}
	Delay(200);
	pstr = strstr(ucUar3tbuf,"$");
	if(pstr != NULL)
		delay_ms(5);
	pstr1 = strstr(ucUar3tbuf,"iB");
		
	if((pstr != NULL)&&(pstr1 != NULL))
	{
		ucUar3InterrFlag = 0;
		//----------------------����Ϊ�����������Ƿ�����û������20170523����------------------------
		if((pstr[0]==CMD_START)&&(pstr[1]==TypeID)&&(pstr[3]==SERVER_ABNORMAL_MESSAGE))   //���������ش���δ�����û�
		{
			if((pstr[2]== 0x84 )&&(pstr[5]== BINDING_USERS_NO))
			{
				Flag_Binding_Users = BINDING_USERS_NO;
				if(Flag_No_Binding_Users_Time == 0)  //δ�����û���ʱ��־
				{
					Flag_No_Binding_Users_Time = 1;
					No_Binding_Users_Time = 0;						 
				}
				if(Flag_COMDebug == 1)
					printf("The device does not binding to users!\r\n");

			}
			if((pstr[2]== 0x84 )&&(pstr[5]== BINDING_USERS_YES))
			{
				Flag_Binding_Users = BINDING_USERS_YES;
				Flag_No_Binding_Users_Time = 0;		
				if(gPeopleFlag == TRUE)
				{
					if((Timebuf[3] >= 9)&&(Timebuf[3] <= 17)) //9~18��3��1֡������10��һ֡ test code!!!  
						SleepData_SendTime = CGATTime_3;
					else
						SleepData_SendTime = CGATTime_10; 
				}
				if(Flag_COMDebug == 1)
					printf("The device is  binding to users!\r\n");

			}				 
		}
		if((pstr[0]==CMD_START)&&(pstr[1]==TypeID)&&(pstr[3]==REQ_SERVER_TIME))//���������ظ��µ�ʱ��
		{	
			for(i=0;i<6;i++)  //��ȡ������ʱ��
			{
				receivetime[i] = (pstr[4+i*2]&0x7F-0x30)*10+(pstr[5+i*2]&0x7F-0x30); //��ASCII�ַ��������ֽڵ�ʱ��ת��Ϊ1���ֽڵ�ʱ��		 
			}
			if((receivetime[0]>0)&&(receivetime[0]<99)&&(receivetime[1]>0)&&(receivetime[1]<13)&&(receivetime[2]>0)&&(receivetime[2]<32))
			{
				if((receivetime[3]>=0)&&(receivetime[3]<60)&&(receivetime[4]>=0)&&(receivetime[4]<60)&&(receivetime[5]>=0)&&(receivetime[5]<60))
				{
					for(i=0;i<6;i++)
					{
						Timebuf[i] = receivetime[i];
					}
					Flag_TimeAdj = 0;
                    Heartbeat=0;
					if(Flag_COMDebug == 1)
						printf(">>>[��]Renew Server time is:%d-%d-%d %d:%d:%d\r\n",Timebuf[0],Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5]);
				}
			}
		}
		if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== SERVER_ABNORMAL_MESSAGE)) //MAC��֤����
		{
			if(pstr[4] == SERVER_CHECK_MAC_ERR)
			{
				if(Flag_COMDebug == 1)
					printf("Server Return MAC Verify Error!\r\n");
				AngelPace = GETBACKSERVERIPOK;					 
				SendDataStatus = NO;					//�򿪷��Ϳ���
				SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
				Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
				//			  Flag_Check_Status = ERROR_MAC_ERR;
				Set_StatistStartTime();	
			}
		}
		if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== CARD_IMSI)) //���ؽ��յ�IMSI����			 
		{			  
		//			  for(i=0;i<7;i++)
		//			 {
		//			   printf("0x%x",pstr[i]);
		//			 }
			if(pstr[4] == 0x81)
			{
				WriteMACToFlash();
				Flag_CARD_ISCHANGE = CARD_NOCHANGE;
				if(Flag_COMDebug == 1)
					printf("Server has received IMSI!\r\n");					
			}
		}
		if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== SEND_STATISTICS_SLEEPDTAT)) //��Ӧ���͵�ͳ������
		{
			if((pstr[4] == 0x81)&&(Flag_SleepDataBuffer_Save != Flag_SleepDataBuffer_Send))   //���յ���ȷ��ͳ������
			{
				if(Flag_COMDebug == 1)
					printf("Server Receive Right Statistics Data:%d!\r\n",Flag_SleepDataBuffer_Send);
				Flag_CanSendStatistData = 1;
				CanSendStatistTime = 0;				
				Flag_SleepDataBuffer_Send++;
				if(Flag_SleepDataBuffer_Send == Flag_SleepDataBuffer_Save)
				{
					Flag_SleepDataBuffer_Send = 0;
					Flag_SleepDataBuffer_Save = 0;
					Flag_SavepPos = 0;
					Flag_CanSendStatistData = 0;
					for(i=0;i<SLEEPDTATABUF;i++)
					{
						for(j=0;j<40;j++)
							Buffer_SleepData[i][j] = 0;
					}
				} 
				if(Flag_SleepDataBuffer_Send ==SLEEPDTATABUF )
				{
					Flag_SleepDataBuffer_Send = 0;
				}
			}	
		//        if(pstr[4] == 0x80)   //���յ������ͳ������
		//				 {
		//					  if(Flag_COMDebug == 1)
		//							printf("Server Receive Error Statistics Data:%d,!Resend\r\n",Flag_SleepDataBuffer_Send);
		//						Flag_CanSendStatistData = 1;
		//            CanSendStatistTime = 0;						
		//			   }
		}
		#ifdef ENABLE_SENDPRESSSERSONSTATUS
		if((pstr[1]== TypeID)&&(pstr[3]== CMD_PRESSSENSER)) //ѹ��������״̬����
		{
			if(pstr[4] == 0x81)
			{
				Flag_SendPresensorStatus = 0;
				SendPresensorStatus_Time = 0;
				if(Flag_COMDebug == 1)
					printf("Server Received pressure sensor status\r\n");

			}								 
		}
		#endif
		ClearUSART3BUF();
	}	 
	//-------------------------------------------------------------------------------------------------
	if(strstr(ucUar3tbuf, "RESET") != NULL)
	{	//�������Ӻ��÷�����
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);
		AngelPace = CONECTIP1;					//��������ģ��
		SendDataStatus = NO;					//�򿪷��Ϳ���
		SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
		ucUar3InterrFlag = 0;
		Set_StatistStartTime();	
	}
	else if(strstr(ucUar3tbuf,"SEND FAIL")!=NULL)
	{		//����ʧ��
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);
	
		SendDataStatus=NO;					//�򿪷��Ϳ���
		SendSleepDataStatus=NO;				//����ʧ��,��Ҫ������װ����
		ADCTimeCount = 0;					//��ʱ���
		REGISTEFlag = 0;
		if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
			SendSleepDataReally();				//��������
		else
			Send_SyncDataToServer();		
		AngelPace = GETBACKSERVERIPOK;		//����ע��
		ucUar3InterrFlag = 0;
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
		Set_StatistStartTime();	
	}	
	else if(strstr(ucUar3tbuf,"CLOSED")!=NULL)
	{			//��·����ر�
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
		SendDataStatus=NO;					//�򿪷��Ϳ���
		SendSleepDataStatus=NO;				//����ʧ��,��Ҫ������װ����
		Flag_Send_GPRS_Position = 0;	
		REGISTEFlag = 0;
		if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
			SendSleepDataReally();				//��������
		else
			Send_SyncDataToServer();
		AngelPace = GETBACKSERVERIPOK;		//����ע��
		ucUar3InterrFlag = 0;
		Set_StatistStartTime();	
	}
	else if(strstr(ucUar3tbuf,"SHUT")!=NULL)
	{
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);

		SendDataStatus=NO;					//�򿪷��Ϳ���
		SendSleepDataStatus=NO;				//����ʧ��,��Ҫ������װ����
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
		Flag_Send_GPRS_Position = 0;	
		REGISTEFlag = 0;
		if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
			SendSleepDataReally();				//��������
		else
			Send_SyncDataToServer();
		AngelPace = GETBACKSERVERIPOK;		//����ע��
		ucUar3InterrFlag = 0;
		GPRS_ConnetTime =0;	
		Set_StatistStartTime();			
	}
	else if(strstr(ucUar3tbuf,"+REGISTE:0")!=NULL)
	{
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);
		REGISTEFlag = 0;
		if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
			SendSleepDataReally();				//��������
		else
			Send_SyncDataToServer();
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
		AngelPace = GETBACKSERVERIPOK;		//����ע��
		ucUar3InterrFlag = 0;
		Set_StatistStartTime();	
	}
	else
		{
		if(ucUar3tbuf[1] != 0)
			{
			if(Flag_COMDebug == 1)
				printf("U3 :%s\r\n",ucUar3tbuf);
			ucUar3InterrFlag = 0;
		}
	}
	CheckSystemErrorContrl();					//ģ������쳣���,������
	return 1;
}

char My_strstr(unsigned char *str1,unsigned char *str2)
{
	int len = 0;
	char ch = 0,i=0,count=0;

	if(str2[0] == '7'){
		len = 8;
	}else if(str2[0] == '8'){
		len = 9;
	}

	for(i=0;i<len;i++){
		if(str1[i] == str2[i]){
			count++;
		}
		else{
			break;
		}
	}

	if(count == len){
		return 1;			//��ʾ�����ַ���һ��
	}
	else{
		return 0;			//��ʾ��һ��
	}

}
/****************************************************************************
*	�� �� ��: ADDTime
*	����˵��: ����ʱ��
*	��    �Σ���
*	�� �� ֵ: ��
* ˵    ����
*****************************************************************************/
static int timeCorrectionCount=0;//10���ӣ��豸�ȷ�������1s
void ADDTime(void)
{
	char len=0,i=0;
	u8 year = 0,month = 0,daysPerMonth = 0;
	//Timebuf[len + 0]			//��
	//Timebuf[len + 1]			//��
	//Timebuf[len + 2]			//��
	//Timebuf[len + 3]			//ʱ
	//Timebuf[len + 4]			//��
	//Timebuf[len + 5]			//��
	timeCorrectionCount++;
	if(timeCorrectionCount > 600)
	{
		//10���ӵ�ʱ���豸����һ��
		timeCorrectionCount = 0;
	}
	Timebuf[len + 5] += 1;						//���ʱ
	if(Timebuf[len + 5] == 60)    //60s �ֽ�λ
	{			
		Timebuf[len + 5]= 0;
		Timebuf[len + 4]++;
		if(Timebuf[len + 4] == 60)  //60min ʱ��λ
	  {				
			Timebuf[len + 4]=0;
			Timebuf[len + 3]++;
			if(Flag_TimeAdj == 0)
			{
				Adj_Time = 0;
				Flag_TimeAdj = 1;		  //����ָ��ͬ��������ʱ��
			}
		}
		if(Timebuf[len + 3] == 24)  //24h �ս�λ
		{				
			Timebuf[len + 3]=0;
			Timebuf[len + 2]++;
		}
		//�ж�ÿ���·ݵ�����
		year = Timebuf[len + 0];
		month = Timebuf[len + 1];
		if(year % 4 == 0 && month == 2){
			daysPerMonth= 29;
		}else{
			switch(month){
				case 1:
				case 3:
				case 5:
				case 7:
				case 8:
				case 10:
				case 12:
					daysPerMonth = 31;
					break;
				case 2:
					daysPerMonth = 28;
					break;
				default:
					daysPerMonth = 30;
					break;
			}
		}
		if(Timebuf[len + 2] > daysPerMonth){				//�½�λ
			Timebuf[len + 2]=1;
			Timebuf[len + 1]++;
		}
		if(Timebuf[len + 1] >  12){				//���λ
			Timebuf[len + 1]=1;
			Timebuf[len + 0]++;
		}
		if(Timebuf[len + 0] >=  99){				//�긴λ
			Timebuf[len + 0] = 0;
		}
	}	
//	printf("time...%d/%d/%d %02d:%02d:%02d\r\n",Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5],Timebuf[6]);
}
/****************************************************************************
*	�� �� ��: GetServerTime
*	����˵��: ��ȡ������ʱ��
*	��    �Σ���
*	�� �� ֵ: ��
* ˵    ����
*****************************************************************************/
void GetServerTime(void)
{
//	 Flag_SleepData_SendOver = 1;
//	 UART3_SendString_YB("AT+GPRS=",8);
//	 SendDataToUSART(USART3,0x24);
//	 SendDataToUSART(USART3,0x01 );
//	 SendDataToUSART(USART3,0x82);			
//	 SendDataToUSART(USART3,REQ_SERVER_TIME);
//	 SendDataToUSART(USART3,0xFF);
//	 SendDatasToUSART(USART3,0x6942 );
//	 UART3_SendLR();
//	 //Flag_TimeAdj = 1;
    uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
     
	 uint16_t data_len=0;
	 SendData[data_len++] = CMD_START;
	 SendData[data_len++] = TypeID;
	 SendData[data_len++] = 0x82;
	 SendData[data_len++] = REQ_SERVER_TIME;
	 SendData[data_len++] = 0xff ;
	 SendData[data_len++] = CMD_LF1;
	 SendData[data_len++] = CMD_LF2;
     ClearUSART3BUF();
     GPRS_Send_Data(SendData,data_len);
	 //Adj_Time = 0;
	 Flag_SleepData_SendOver = 0; 
}
/****************************************************************************
*	�� �� ��: LedContrl
*	����˵��: LED��˸״̬�ı�
*	��    �Σ���
*	�� �� ֵ: ��
* ˵    ����
*****************************************************************************/
void LedContrl(int csq,int Tcpstatues)
{
	if((csq < 7) && (RegEnable == 1) && (Tcpstatues == 0) && (AngelPace == SendSleepDataR)){
		if(LedFlash < 50){
			GPIO_SetBits(LED_GPIO_PORT,LED5_PIN);	//�صƣ��������ݳɹ�		
		}else if(LedFlash < 100){
			GPIO_ResetBits(LED_GPIO_PORT,LED5_PIN);	//���ƣ���ʾ�ڿ�ʼ����
		}else if(LedFlash >= 100){
			LedFlash = 0;
		}
	}
	else if((csq < 99) && (RegEnable == 1) && (Tcpstatues == 0) && (AngelPace == SendSleepDataR))
	{
		GPIO_SetBits(LED_GPIO_PORT,LED5_PIN);	//�صƣ��������ݳɹ�	
	}
	else
	{
		GPIO_ResetBits(LED_GPIO_PORT,LED5_PIN);	//���ƣ���ʾ�ڿ�ʼ����
	}	
}
/****************************************************************************
*	�� �� ��: Send_GPRSPosition
*	����˵��: ����GPRS��λ����
*	��    �Σ�st ��ʾ����ģʽ����Դ������������������lac��cidΪ��λ����
*	�� �� ֵ: 
* ˵    �������20170526����
*****************************************************************************/
void  Send_GPRSPosition(uint8_t st,int lac,int cid)
{
	 uint8_t podata[13];
	 uint8_t  i =0;
	 uint8_t jiaoyan = 0;
	
	 podata[0] = 0x24;
   podata[1] = 0x01;
   podata[2] = 0x08|0x80;	//���ݳ���8�ֽ�	
	 podata[3] = GPRS_LOCATION;
	 podata[5] = st;
	 podata[6] = lac/256;
	 podata[7] = lac%256;
	 podata[8] = cid/256;
	 podata[9] = cid%256;
	 podata[4] = GetDataHead(&podata[5],5);  //����ͷ
	  
	 for(i=3;i<10;i++)
	 { 
		 jiaoyan += podata[i];
	  }	 
	 podata[10] = jiaoyan;
	 for(i=4;i<11;i++)
	 { 
		 podata[i] |= 0x80;
	  }	
	 podata[11] = 0x69;
	 podata[12] = 0x42;
	 
	 Flag_SleepData_SendOver = 1;
	GPRS_Send_Data(podata,13);
	 delay_ms(10);
	 Flag_SleepData_SendOver = 0;
}
/****************************************************************************
*	�� �� ��: Send_DataUnusual
*	����˵��: ���������쳣����
*	��    �Σ�flag_un�쳣���  unHr�쳣�������� unRr �쳣��������
*	�� �� ֵ: 
* ˵    �������20170527����
*****************************************************************************/
void Send_DataUnusual(uint8_t flag_un,uint8_t unHr,uint8_t unRr)
{
	 uint8_t podata[11];
	 uint8_t  i =0;
	 uint8_t jiaoyan = 0;
	
	 podata[0] = 0x24;
   podata[1] = 0x01;
   podata[2] = 0x06|0x80;	//���ݳ���8�ֽ�	
	 podata[3] = SLEEPDATA_ABNORMAL_MESSAGE;
	 podata[5] = flag_un;
	 podata[6] = unHr;
	 podata[7] = unRr;
	 podata[4] = GetDataHead(&podata[5],3);  //����ͷ
	  
	 for(i=3;i<8;i++)
	 { 
		 jiaoyan += podata[i];
	  }
	 podata[8] = jiaoyan;
	 for(i=4;i<9;i++)
	 { 
		 podata[i] |= 0x80;
	  }	
	 podata[9] = 0x69;
	 podata[10] = 0x42;
	 
	 Flag_SleepData_SendOver = 1;
	 UART3_SendString_YB("AT+SEND=",8);	 
	 for(i=0;i<11;i++)
	 {
		  SendDataToUSART(USART3,podata[i]);
	 }	 
	 UART3_SendLR();
	 delay_ms(10);
	 Flag_SleepData_SendOver = 0;
}
/****************************************************************************
*	�� �� ��:  Send_SyncDataToServer
*	����˵��:  ����ͬ�����ݰ���������
*	��    �Σ�
*	�� �� ֵ:
* ˵    �������豸�ͷ�����δ���ӳɹ�����У��ɹ�������·���,���20170601����
*****************************************************************************/
void Send_SyncDataToServer(void)
{
	 Flag_SleepData_SendOver = 1;
	 UART3_SendString_YB("AT+SEND=",8);
	 SendDataToUSART(USART3,0x24);
	 SendDataToUSART(USART3,0x01 );
	 SendDataToUSART(USART3,0x82);			
	 SendDataToUSART(USART3,SYNC);
	 SendDataToUSART(USART3,0xFF);
	 SendDatasToUSART(USART3,0x6942 );
	 UART3_SendLR();
	 if(Flag_COMDebug == 1)
			printf("Send SyncData To Server!\r\n");
	 Flag_SleepData_SendOver = 0;
}
/****************************************************************************
*	�� �� ��: Send_CARD_IMSI
*	����˵��: ���Ϳ��Ż���IMSI��
*	��    �Σ�
*	�� �� ֵ: 
* ˵    �������20170610����
*****************************************************************************/
void Send_CARD_IMSI(void)
{
	 uint8_t podata[50]={0};
	 uint8_t  i =0,j;
	 uint8_t jiaoyan = 0;
	 
	 podata[i++] = 0x24;
    podata[i++] = 0x01;
    podata[i++] = (SIMCard_ICCID_Len+2)|0x80;	//���ݳ���8�ֽ�	
	 podata[i++] = CARD_IMSI;

	 for(j=0;j<SIMCard_ICCID_Len;j++)
	 { 
		 podata[i++] = SIMCard_ICCID[j];
	 }
	 	for(j=0;j<SIMCard_ICCID_Len+1;j++)
	 { 
		 jiaoyan += podata[j+3];
	  }	 
	 podata[i++] = jiaoyan|0x80;			
	 podata[i++] = 0x69;
	 podata[i++] = 0x42;
	 
	 Flag_SleepData_SendOver = 1;
	 GPRS_Send_Data(podata,i);
	 delay_ms(10);
	 Flag_SleepData_SendOver = 0;
   if(Flag_COMDebug == 1)
	 {		 
		 printf("Send MAC and IMSI to Server!\r\n");
//			 for(i=0;i<ICCID_LEN+7;i++)
//		 {
//			 printf("0x%x ",podata[i]);
//		 }
//		 printf("\r\n");
  }
}
void Send_CARD_ICCID(void)
{
	 uint8_t podata[50]={0};
	 uint8_t  i =0,j;
	 uint8_t jiaoyan = 0;
	 
	 podata[i++] = 0x24;
    podata[i++] = 0x01;
    podata[i++] = (SIMCard_ICCID_Len+2)|0x80;	//���ݳ���8�ֽ�	
	 podata[i++] = CARD_IMSI;

	 for(j=0;j<SIMCard_ICCID_Len;j++)
	 { 
		 podata[i++] = SIMCard_ICCID[j];
	 }
	 	for(j=0;j<SIMCard_ICCID_Len+1;j++)
	 { 
		 jiaoyan += podata[j+3];
	  }	 
	 podata[i++] = jiaoyan|0x80;			
	 podata[i++] = 0x69;
	 podata[i++] = 0x42;
	 
	 Flag_SleepData_SendOver = 1;
	 GPRS_Send_Data(podata,i);
	 delay_ms(10);
	 Flag_SleepData_SendOver = 0;
   if(Flag_COMDebug == 1)
	 {		 
		 printf("Send MAC and ICCID to Server!\r\n");
//			 for(i=0;i<ICCID_LEN+7;i++)
//		 {
//			 printf("0x%x ",podata[i]);
//		 }
//		 printf("\r\n");
  }
}
/****************************************************************************
*	�� �� ��: RePowerOn_GPRS
*	����˵��: GPRSģ�������ϵ�����
*	��    �Σ�
*	�� �� ֵ: 
* ˵    �������20170705����
*****************************************************************************/
void  RePowerOn_GPRS(void)
{
    GPRS_or_WIFI = GPRS;
    Set_StatistStartTime();
	 GPRS_POWER(0);
	 delay_ms(2000);
	 GPRS_POWER(1);
	 delay_ms(1000);
     Flag_Init_Step=3;
	 AngelPace = CONECTIP1;
   if(Flag_Start_Mode == START_NETWOEK_RECONNECT )	
	     Flag_Start_Mode = START_GPRS_RESTART;  //����ر�����	
	 Flag_Send_GPRS_Position = 0;								 
	 SendDataStatus = NO;					//�򿪷��Ϳ���
	 SendSleepDataStatus = NO;				//����ʧ��,��Ҫ������װ����
	 Flag_init = MAC_INIT_OK;  //��������ģ���ʼ��
	 start_time = 0; 
	 Flag_start_time = 1;	
	 ClearUSART3BUF();		
	 GPRS_ConnetTime =0;	
	 flag_Gprs_Reconn=1;
}
/****************************************************************************
*	�� �� ��: AMPCHGDataToServer
*	����˵��: ���ͷŴ���
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void Send_AMPCHGDataToServer(void)
{
	 uint8_t dat[8];
	 uint8_t  i = 0;
	
	 dat[0]= (uint8_t)(ADC_AmpMultiple*10);
	 dat[1] = SEND_ECG_MAX[0]/256;
	 dat[2] = SEND_ECG_MAX[0]%256;
	 dat[3] = SEND_ECG_MAX[1]/256;
	 dat[4] = SEND_ECG_MAX[1]%256;
	 dat[5] = SEND_ECG_MAX[2]/256;
	 dat[6] = SEND_ECG_MAX[2]%256;
	 dat[7] = GetDataHead(&dat[0],7);  //����ͷ
	 
	 Flag_SleepData_SendOver = 1;
	 UART3_SendString_YB("AT+SEND=",8);
	 SendDataToUSART(USART3,0x24);
	 SendDataToUSART(USART3,0x01 );
	 SendDataToUSART(USART3,0x8A);			
	 SendDataToUSART(USART3,AMP_CHG);
	 for(i=0;i<8;i++)
	 {
		 SendDataToUSART(USART3,dat[i]|0x80);
	 }
	 SendDataToUSART(USART3,0xFF);
	 SendDatasToUSART(USART3,0x6942 );
	 UART3_SendLR();
   delay_ms(10);
	 Flag_SleepData_SendOver = 0;
	 if(Flag_COMDebug == 1)
		 printf("Send Amplification Data:%f To Server!\r\n",ADC_AmpMultiple);
}

/****************************************************************************
*	�� �� ��: DealADCSampleData
*	����˵��: ����ADC����ֵ
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/	
void  DealADCSampleData(void)
{
   uint32_t Dvalue0 = 0;
	 uint32_t Dvalue1 = 0;
	 uint16_t maxaerage = 0;
	 uint16_t minaerage = 0;
	 uint16_t maxecgaerage = 0;
	 uint16_t minecgaerage = 0;
	 uint16_t ecgdata = 0;
	 uint16_t i = 0 ;
	 uint8_t ampchange = 0;
	 s32 ecgaeragedata = 0;

//----------------------------״̬�ж�------------------------------------------------------------			   
//	 if((PeopleOn_Time > 10)&&(gTurnFlag==0)&&(Flag_ADC_ADJ == 0)&&(Flag_HasPeople == 1)&&(SampleData>STANDARD_VOLTAGE))
//	 {
//		 ADC_DATA[ADC_QuietCount] = SampleData;
//		 ADC_QuietCount++;
//		 if(ADC_QuietCount == 50)
//		 {
//				for(i=0;i<50;i++)
//				 {
//					 Dvalue0 += ADC_DATA[i];
//				 }	
//				 maxaerage =  (uint16_t)(Dvalue0/50);
//				 if(ECG_MAX[ECG_COMPARE_COUNT]<1750)
//				 {
//						Flag_ADC_ADJ = 1;
//						PeopleOn_Time = 0;
//						Flag_HasPeople = 0;
////					  ADC_AmpMultiple = 4;
//				 }
//				ADC_QuietCount =0;
//		 }
//	 }				 
	 if(SampleData > ECG_MAX[ECG_COMPARE_COUNT])
	 {
			ECG_MAX[ECG_COMPARE_COUNT] = SampleData;
	 }
	 if(SampleData< ECG_MIN[ECG_COMPARE_COUNT])
	 {
			ECG_MIN[ECG_COMPARE_COUNT] = SampleData;
	 }
	 ADC_COUNT++;
	 if(ADC_COUNT >= 500)
	 {
			ECG_COMPARE_COUNT++;
			ADC_COUNT = 0;
	 }
	 if(ECG_COMPARE_COUNT >= ECG_COMPARE_TIMES)
	 {
			for(i=0;i<ECG_COMPARE_TIMES;i++)
		 {
			 Dvalue0 += ECG_MAX[i];
			 Dvalue1 += ECG_MIN[i];
			 SEND_ECG_MAX[i]=ECG_MAX[i];
		 }				
		 maxaerage =  (uint16_t)(Dvalue0/ECG_COMPARE_TIMES);
		 minaerage =  (uint16_t)(Dvalue1/ECG_COMPARE_TIMES);
		 maxecgaerage = abs(maxaerage - STANDARD_VOLTAGE);
		 minecgaerage = abs(STANDARD_VOLTAGE - minaerage);
		 
		if((ECG_MAX[0] < ADC_MAXDATA1)&&(ECG_MAX[1] < ADC_MAXDATA1)&&(ECG_MAX[2] < ADC_MAXDATA1)&&(ADC_AmpMultiple != 1))
		{
			 Flag_ADC_ADJ = 0;
			 ADC_AmpMultiple = 1;
			 Flag_SendAMPCHGToServer = 1;	
		}	
		if(((maxaerage-minaerage)<50)&&(ADC_AmpMultiple != 1))
		{
			 Flag_ADC_ADJ = 0;
			 ADC_AmpMultiple = 1;
			 Flag_SendAMPCHGToServer = 1;	
		}
    if((ECG_MAX[0] > ADC_MAXDATA4)&&(ECG_MAX[1] > ADC_MAXDATA4)&&(ECG_MAX[2] > ADC_MAXDATA4)&&(ADC_AmpMultiple != 1))
		{
			 Flag_ADC_ADJ = 0;
			 ADC_AmpMultiple = 1;
			 Flag_SendAMPCHGToServer = 1;		
		}			
		if((abs(ECG_MAX[1]-ECG_MAX[0])< 100)&&(abs(ECG_MAX[2]-ECG_MAX[1])< 100)&&((maxaerage-minaerage)>50))  //ƽ��״̬
		 {
			 if((maxaerage < ADC_MAXDATA4)&&(ECG_MAX[0]> ADC_MAXDATA1)&&(ECG_MAX[1]> ADC_MAXDATA1)&&(ECG_MAX[2]> ADC_MAXDATA1)&&(minaerage<ADC_MINDATA1)&&(Flag_ADC_ADJ == 0))
			 {			
						Flag_ADC_ADJ = 1;
				    ampchange = 1;			 
			 }
//-------------------�Ŵ�������---------------------------------------------------------------------
			if( ampchange == 1)
			{
					ampchange = 0;
					if(Flag_ADC_ADJ != 0)
					{
						 ADC_AmpMultiple =(float)(ADC_AMPSTADATA-STANDARD_VOLTAGE)/(maxaerage-STANDARD_VOLTAGE);					
							if(ADC_AmpMultiple > 10)	
								 ADC_AmpMultiple = 10;	

						 if(LastADC_AmpMultiple != ADC_AmpMultiple)
						 {
									LastADC_AmpMultiple = ADC_AmpMultiple;
									ADC_AdjTime = 0;
						 }
						 Flag_SendAMPCHGToServer = 1;					 
					}				 
	//			printf("Amplification parameter is:%f \r\n",ADC_AmpMultiple);
			}		 
		 }					
			for(i=0;i<ECG_COMPARE_TIMES-1;i++)
			{
				ECG_MAX[i] = ECG_MAX[i+1];
				ECG_MIN[i] = ECG_MIN[i+1];
			}			
			ECG_COMPARE_COUNT = 2;
			ECG_MAX[ECG_COMPARE_COUNT] = STANDARD_VOLTAGE;
			ECG_MIN[ECG_COMPARE_COUNT] = ECG_MAX[1];
		}       									
}
/****************************************************************************
*	�� �� ��: DealSmallADCSampleData
*	����˵��: ����С�ź�ADC����ֵ
*	��    �Σ��ź�״̬��״̬��ͬ���������Ȳ�ͬ
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/	
void  DealSmallADCSampleData(float status)
{
	 float absdata = 0;	
	 uint8_t i =0;

	 if(SampleData > STANDARD_VOLTAGE)
	 {
		 absdata = SampleData -STANDARD_VOLTAGE;
		 absdata *= status;
		 SampleData = (uint16_t)(STANDARD_VOLTAGE+ absdata);
		 if(SampleData>3299)
		 {
			 SampleData = 3299;
		 }
	 }
	 else
	 {
		 absdata = STANDARD_VOLTAGE - SampleData;
		 absdata *= status;
		 SampleData = (uint16_t)(STANDARD_VOLTAGE - absdata);
		 if(SampleData < 1)
		 {
			 SampleData = 1;
		 }
	 }	 							
}
/****************************************************************************
*	�� �� ��: CheckAmpADCData
*	����˵��: ���Ŵ���ADC����
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void CheckAmpADCData(void)
{
	 uint32_t Dvalue0 = 0;
	 uint32_t Dvalue1 = 0;
	 uint16_t maxaerage = 0;
   uint16_t minaerage = 0;
	 uint16_t i = 0 ;

//----------------------------״̬�ж�------------------------------------------------------------			   				 
	 if(SampleData > CHGECG_MAX[CHGECG_COMPARE_COUNT])
	 {
			CHGECG_MAX[CHGECG_COMPARE_COUNT] = SampleData;
	 }
	 if(SampleData< ECG_MIN[CHGECG_COMPARE_COUNT])
	 {
			CHGECG_MIN[CHGECG_COMPARE_COUNT] = SampleData;
	 }	 
	 CHGADC_COUNT++;

	 if(CHGADC_COUNT >= 500)
	 {
			CHGECG_COMPARE_COUNT++;
			CHGADC_COUNT = 0;
	 }
	 if(CHGECG_COMPARE_COUNT >= ECG_COMPARE_TIMES)
	 {
		 for(i=0;i<ECG_COMPARE_TIMES;i++)
		 {
			 Dvalue0 += CHGECG_MAX[i];
			 Dvalue1 += CHGECG_MIN[i];
		 }
		 maxaerage =  (uint16_t)(Dvalue0/ECG_COMPARE_TIMES);
		 minaerage =  (uint16_t)(Dvalue1/ECG_COMPARE_TIMES);
		 
//    if((abs(CHGECG_MAX[1]-CHGECG_MAX[0])< 50)&&(abs(CHGECG_MAX[2]-CHGECG_MAX[1])< 50)&&((maxaerage-minaerage)<80)&&(ADC_AmpMultiple != 1))
//		{
//			 Flag_ADC_ADJ = 0;
//			 ADC_AmpMultiple = 1;
//			
//		}			 
		if((CHGECG_MAX[0]>ADC_CHGMAXDATA)&&(CHGECG_MAX[1]>ADC_CHGMAXDATA)&&(CHGECG_MAX[2]>ADC_CHGMAXDATA))  //�Ŵ�����ݳ�������
		 {
			  if((Flag_ADC_ADJ != 0)&&(ADC_AdjTime > 60))  //���1���Ӳſ��Ե���
				{
					 Flag_ADC_ADJ = 0;
				}
		 }
		if((CHGECG_MAX[0]<ADC_CHGMINDATA)&&(CHGECG_MAX[1]<ADC_CHGMINDATA)&&(CHGECG_MAX[2]<ADC_CHGMINDATA)&&(maxaerage > 1600))  //�Ŵ�����ݳ�������
		 {
			  if((Flag_ADC_ADJ != 0)&&(ADC_AdjTime > 60))  //���1���Ӳſ��Ե���
				{
					 Flag_ADC_ADJ = 0;
				}
		 }		 
			for(i=0;i<ECG_COMPARE_TIMES-1;i++)
			{
				CHGECG_MAX[i] = CHGECG_MAX[i+1];
				CHGECG_MIN[i] = CHGECG_MIN[i+1];
			}			
			CHGECG_COMPARE_COUNT = 2;
			CHGECG_MAX[CHGECG_COMPARE_COUNT] = STANDARD_VOLTAGE;
			CHGECG_MIN[CHGECG_COMPARE_COUNT] = CHGECG_MAX[1];
		}
}
/****************************************************************************
*	�� �� ��: SleepDataCalculate
*	����˵��: ����˯������
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void SleepDataCalculate(void)
{
		SampleData = GetADCData();	
	//����SampleDataԽ�� 2019/6/5by DYP
    if(SampleData>3300)
        SampleData=3300;
    if(SampleData<1)
        SampleData=1;
	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)  //����״̬��ִ�зŴ�
	{
		DealADCSampleData();					 //����ԭʼ�����ź�
		if((gTurnFlag != 1)&&(ADC_AmpMultiple != 1))  //�Ŵ�ԭʼ�����ź�
		{						
			DealSmallADCSampleData(ADC_AmpMultiple);					
		}
		CheckAmpADCData();  //���Ŵ����ź�
	}	
	SleepAlgorithm();	 						//���ݴ�������						
	putWaveDataToBuf(SampleData,EcgData,RespData);//+128);

	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEOFFBED)  //ѹ����δѹ�£�������ȫ����0
	{
		gPeopleFlag = 0;	
		gTurnFlag = 0;
	}
	
	if(gTurnFlag == 1)
		Flag_PeopleTurnforPresensor = 1;
		
}
/****************************************************************************
*	�� �� ��: SendPressSenserStatus
*	����˵��: ����ѹ��������״̬
*	��    �Σ���
*	�� �� ֵ: ��
* ˵    ����
*****************************************************************************/
void SendPressSenserStatus(uint8_t status)
{
	 uint8_t senddata[8]={0};
	 uint8_t  i = 0;
	 
	senddata[0] = CMD_START;
	senddata[1] = TypeID;
	senddata[2] = 0x83;
	senddata[3] = CMD_PRESSSENSER;
	if(status == EXTSENSOR_PEOPLEONBED)
		senddata[4] = PRESSSENSER_ON|0x80;
	else
		senddata[4] = PRESSSENSER_OFF|0x80;
	senddata[5] = 0xFF;
	senddata[6] = 0x69;
	senddata[7] = 0x42;
    GPRS_Send_Data(senddata,8);
}
void SendSensorTestOver(uint32_t times)
{
	 uint8_t senddata[8]={0};
	 uint8_t  i = 0;
	 uint8_t len=0;
	senddata[len++] = CMD_START;
	senddata[len++] = TypeID;
	senddata[len++] = 0x83;
	senddata[len++] = SENSORTESTOVER;
	senddata[len++] = times/256;
    senddata[len++] = times%256;
	senddata[len++] = 0xFF;
	senddata[len++] = 0x69;
	senddata[len++] = 0x42;
	 UART3_SendString_YB("AT+SEND=",len);
	 for(i=0;i<len;i++)
	 {
		 SendDataToUSART(USART3,senddata[i]);
	 }
	UART3_SendLR();
}
/****************************************************************************
*	�� �� ��: Check_ExtSensor_PeopleOnBed
*	����˵��: ����ⲿ�������Ƿ������ڴ�
*	��    �Σ���
*	�� �� ֵ: 
* ˵    ����200ms���һ��״̬���������10��״̬һ�£��������״̬�ȶ�
*****************************************************************************/
void Check_ExtSensor_PeopleOnBed(void)
{
	float adcvlaue = 0;
    static float last_adcvlaue=0;
#if 1	
	if(OnbedStatus_CountTimer >= 10)
	{		
		adcvlaue = ADC_VoltageValue[1];
        #if 0
        adcvlaue=1500;
        #endif 
		//adcvlaue *= 2;
		if(adcvlaue>3299)
		{
			 adcvlaue = 3299;
		}
       
		CheckCount_ExtSensor++;	
		OnbedStatus_CountTimer = 0;		
		if( abs((int)adcvlaue -(int)last_adcvlaue) >1000)   //���ݳ��������ʱ��״̬�����㣬��ֹ�źŸ���
		{
			last_adcvlaue = adcvlaue;
			CheckCount_ExtSensor = 0;
			ExtSensor_OnbedStatus_Count = 0;
			ADCVol_ExtSensor = 0;
			return;
		}
		last_adcvlaue = adcvlaue;	
		ADCVol_ExtSensor += (uint32_t)adcvlaue;		
		if(adcvlaue > 400)
        //if(adcvlaue > 400)
		{
			ExtSensor_OnbedStatus_Count++;				
		}
		if(CheckCount_ExtSensor >= 25)
		{
			ADCVol_ExtSensor /= 25;
//			if(Flag_COMDebug == 1)
//			{		
//				printf("\r\naverage pressure adc vol:%d mV \r\n\r\n",ADCVol_ExtSensor);
//				
//			}
            if((ADCVol_ExtSensor>=800)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED))  //ѹ��ƽ��ֵ����500mV
			//if((ADCVol_ExtSensor>=500)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED))  //ѹ��ƽ��ֵ����500mV
			{
//				if(Flag_PeopleTurnforPresensor == 1)
				{
					if(Flag_COMDebug == 1)
					{		
						printf("\r\n======����======\r\n");
						
					}									
					Status_ExtSensorOnbed = EXTSENSOR_PEOPLEONBED;

					Monitor_Offline_Time = 0;
					#ifdef ENABLE_SENDPRESSSERSONSTATUS
					Flag_SendPresensorStatus = 1;
					SendPresensorStatus_Time = 4;
					#endif
				}
			}
			if((ExtSensor_OnbedStatus_Count<5)&&(ADCVol_ExtSensor<400)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEOFFBED))  //ÿ��ѹ��ֵ��С��400
			{
				if(Flag_COMDebug == 1)
				{		
					printf("\r\n======����======\r\n");
					
				}			
				Status_ExtSensorOnbed = EXTSENSOR_PEOPLEOFFBED;
				#ifdef ENABLE_SENDPRESSSERSONSTATUS
				Flag_SendPresensorStatus = 1;
				SendPresensorStatus_Time = 4;
				#endif				
			}
			ExtSensor_OnbedStatus_Count = 0;
			CheckCount_ExtSensor = 0;
			Flag_PeopleTurnforPresensor = 0;	
	
			ADCVol_ExtSensor = 0;
		}
	}
#else
	if(OnbedStatus_CountTimer >= 10)
	{		
		adcvlaue = ADC_ConvertedValue[1]*3300/4096.0;
		if(adcvlaue>3299)
		{
			 adcvlaue = 3299;
		}
	   if(adcvlaue<0)
	   {
		   adcvlaue = 0;
	   }
	   	   
		CheckCount_ExtSensor++;	
		OnbedStatus_CountTimer = 0;		
		if( abs((int)adcvlaue -(int)ADC_VoltageValue[1] ) >1000)   //���ݳ��������ʱ��״̬�����㣬��ֹ�źŸ���
		{
			ADC_VoltageValue[1] = adcvlaue;
			CheckCount_ExtSensor = 0;
			ExtSensor_OnbedStatus_Count = 0;
			ADCVol_ExtSensor = 0;
			return;
		}
		ADC_VoltageValue[1] = adcvlaue;	
		ADCVol_ExtSensor += (uint32_t)adcvlaue;		
		if(adcvlaue > PressureSensor_BaseValue)
		{
			ExtSensor_OnbedStatus_Count++;				
		}
		if(CheckCount_ExtSensor >= 25)
		{
			ADCVol_ExtSensor /= 25;
            if(Flag_COMDebug == 1)
			{		
				printf("\r\naverage pressure adc vol:%d mV \r\n\r\n",ADCVol_ExtSensor);
				
			}
			if((ADCVol_ExtSensor>=PressureSensor_BaseValue)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED))  //ѹ��ƽ��ֵ����500mV��ԭʼ��ѹֵ�����˷�ѹ����
			{
				if((ADCVol_ExtSensor>PRESSURESENSOR_BASEMAXVALUE)||(CheckCount_ExtSensorMaxVal>2))
				{
					if(Flag_COMDebug == 1)
					{		
						printf("\r\n======����======\r\n");
						
					}									
					Status_ExtSensorOnbed = EXTSENSOR_PEOPLEONBED;
					CheckCount_ExtSensorMaxVal = 0;
					Monitor_Offline_Time = 0;
					#ifdef ENABLE_SENDPRESSSERSONSTATUS
					Flag_SendPresensorStatus = 1;
					SendPresensorStatus_Time = 4;
					#endif
				}
				else
				{					
					CheckCount_ExtSensorMaxVal++;
				}
				CheckCount_ExtSensorMinVal = 0;
				
				PressureSensor_BaseValue = ADCVol_ExtSensor-50;		
				if(PressureSensor_BaseValue>PRESSURESENSOR_BASEMAXVALUE)
				{
					PressureSensor_BaseValue = PRESSURESENSOR_BASEMAXVALUE;
				}
				if(PressureSensor_BaseValue<PRESSURESENSOR_BASEMINVALUE)
				{
					PressureSensor_BaseValue = PRESSURESENSOR_BASEMINVALUE;
				}
			}
			if((ExtSensor_OnbedStatus_Count<1)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEOFFBED))  //ÿ��ѹ��ֵ��С��400
			{
				if((ADCVol_ExtSensor<PRESSURESENSOR_BASEMINVALUE)||(CheckCount_ExtSensorMinVal>2))
				{
					if(Flag_COMDebug == 1)
					{		
						printf("\r\n======����======\r\n");
						
					}			
					Status_ExtSensorOnbed = EXTSENSOR_PEOPLEOFFBED;
					CheckCount_ExtSensorMinVal = 0;
					#ifdef ENABLE_SENDPRESSSERSONSTATUS
					Flag_SendPresensorStatus = 1;
					SendPresensorStatus_Time = 4;
					#endif	
				}
				else
				{
					
					CheckCount_ExtSensorMinVal++;
				}
				CheckCount_ExtSensorMaxVal = 0;

				PressureSensor_BaseValue = ADCVol_ExtSensor;		
				if(PressureSensor_BaseValue>PRESSURESENSOR_BASEMAXVALUE)
				{
					PressureSensor_BaseValue = PRESSURESENSOR_BASEMAXVALUE;
				}
				if(PressureSensor_BaseValue<PRESSURESENSOR_BASEMINVALUE)
				{
					PressureSensor_BaseValue = PRESSURESENSOR_BASEMINVALUE;
				}
			}			
			ExtSensor_OnbedStatus_Count = 0;
			CheckCount_ExtSensor = 0;
			Flag_PeopleTurnforPresensor = 0;
						
			ADCVol_ExtSensor = 0;
		}
	}	
#endif	
}
/****************************************************************************
*	�� �� ��: IWDG_Config
*	����˵��: ���� IWDG �ĳ�ʱʱ��
*	��    �Σ�prv:Ԥ��Ƶ��ֵ  rlv:Ԥ��Ƶ��ֵ
*	�� �� ֵ: ��
 * Tout = prv/40 * rlv (s)
 *      prv������[4,8,16,32,64,128,256]
 * prv:Ԥ��Ƶ��ֵ��ȡֵ���£�
 *     @arg IWDG_Prescaler_4: IWDG prescaler set to 4
 *     @arg IWDG_Prescaler_8: IWDG prescaler set to 8
 *     @arg IWDG_Prescaler_16: IWDG prescaler set to 16
 *     @arg IWDG_Prescaler_32: IWDG prescaler set to 32
 *     @arg IWDG_Prescaler_64: IWDG prescaler set to 64
 *     @arg IWDG_Prescaler_128: IWDG prescaler set to 128
 *     @arg IWDG_Prescaler_256: IWDG prescaler set to 256
 *
 * rlv:Ԥ��Ƶ��ֵ��ȡֵ��ΧΪ��0-0XFFF
 * �������þ�����
 * IWDG_Config(IWDG_Prescaler_64 ,625);  // IWDG 1s ��ʱ���
*****************************************************************************/
void IWDG_Config(uint8_t prv ,uint16_t rlv)
{	
	// ʹ�� Ԥ��Ƶ�Ĵ���PR����װ�ؼĴ���RLR��д
	IWDG_WriteConfig( IWDG_WRITE_ENABLE );
	
	// ����Ԥ��Ƶ��ֵ
	IWDG_SetPrescalerDiv( prv );
	
	// ������װ�ؼĴ���ֵ
	IWDG_CntReload( rlv );
	
	// ����װ�ؼĴ�����ֵ�ŵ���������
	IWDG_ReloadKey();
	
	// ʹ�� IWDG
	IWDG_Enable();	
}

/****************************************************************************
*	�� �� ��: IWDG_Feed
*	����˵��: ι������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void IWDG_Feed(void)
{
	// ����װ�ؼĴ�����ֵ�ŵ��������У�ι������ֹIWDG��λ
	// ����������ֵ����0��ʱ������ϵͳ��λ
	IWDG_ReloadKey();
}
