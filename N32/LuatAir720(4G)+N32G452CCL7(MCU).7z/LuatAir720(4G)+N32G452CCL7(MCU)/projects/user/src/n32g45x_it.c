/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/

/**
 * @file n32g45x_it.c
 * @author Nations
 * @version v1.0.0
 *
 * @copyright Copyright (c) 2019, Nations Technologies Inc. All rights reserved.
 */
#include "n32g45x_it.h"
#include "main.h"
#include <BERpara.h>
#include <stdio.h>
#include "Parameter.h"
#include "USART.h"
#include "m26.h"
#include "ADC.h"

/** @addtogroup N32G45X_StdPeriph_Template
 * @{
 */

uint16_t capture = 0;
extern __IO uint16_t CCR1_Val;
extern __IO uint16_t CCR2_Val;
extern __IO uint16_t CCR3_Val;
extern __IO uint16_t CCR4_Val;
extern __IO uint16_t MY_CCR_Val;
extern __IO uint16_t ADC1_ConvertedValue;
extern __IO uint16_t ADC3_ConvertedValue;

extern uint8_t TxBuffer1[];
extern uint8_t TxBuffer2[];
extern uint8_t RxBuffer1[];
extern uint8_t RxBuffer2[];
extern __IO uint8_t TxCounter1;
extern __IO uint8_t TxCounter2;
extern __IO uint8_t RxCounter1;
extern __IO uint8_t RxCounter2;
extern uint8_t NbrOfDataToTransfer1;
extern uint8_t NbrOfDataToTransfer2;
extern uint8_t NbrOfDataToRead1;
extern uint8_t NbrOfDataToRead2;


void timer1sProcess();
void timer3sProcess();
void timer20msProcess();


/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
 * @brief  This function handles NMI exception.
 */
void NMI_Handler(void)
{
}

/**
 * @brief  This function handles Hard Fault exception.
 */
void HardFault_Handler(void)
{
    /* Go to infinite loop when Hard Fault exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles Memory Manage exception.
 */
void MemManage_Handler(void)
{
    /* Go to infinite loop when Memory Manage exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles Bus Fault exception.
 */
void BusFault_Handler(void)
{
    /* Go to infinite loop when Bus Fault exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles Usage Fault exception.
 */
void UsageFault_Handler(void)
{
    /* Go to infinite loop when Usage Fault exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles SVCall exception.
 */
void SVC_Handler(void)
{
}

/**
 * @brief  This function handles Debug Monitor exception.
 */
void DebugMon_Handler(void)
{
}

/**
 * @brief  This function handles SysTick Handler.
 */
void SysTick_Handler(void)
{
}

/******************************************************************************/
/*                 N32G45X Peripherals Interrupt Handlers                     */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_n32g45x.s).                                                 */
/******************************************************************************/

/**
 * @brief  This function handles TIM2 global interrupt request.
 */
int cnt = 0;
int AG_cnt = 0;
const int FRE = 100;
const int AG_FRE = 2;//20ms的计数
int COUNT = 0;
void TIM2_IRQHandler(void)
{
    if (TIM_GetIntStatus(TIM2, TIM_INT_CC1) != RESET)
    {
        TIM_ClrIntPendingBit(TIM2, TIM_INT_CC1);
        capture = TIM_GetCap1(TIM2);

				TIM_SetCmp1(TIM2, capture + MY_CCR_Val);

				//1s标记
				cnt++; 
				if(cnt == FRE){
					//1秒
					timer1sProcess();
//					printf("1 sec\r\n");
				}
				cnt = cnt % FRE;	

				//20ms标记
				AG_cnt++;
				if(AG_cnt == AG_FRE)
				{
					//打印adc1 adc3的采样值
					//printf("get adc1_ch1..%d...%d\r\n",ADC1_ConvertedValue, ADC3_ConvertedValue);
					timer20msProcess();
				}
				AG_cnt = AG_cnt % AG_FRE;
    }
//    else if (TIM_GetIntStatus(TIM2, TIM_INT_CC2) != RESET)
//    {
//        TIM_ClrIntPendingBit(TIM2, TIM_INT_CC2);

//        /* Pin PC.07 toggling with frequency = 109.8 Hz */
//        GPIO_WriteBit(GPIOC, GPIO_PIN_7, (Bit_OperateType)(1 - GPIO_ReadOutputDataBit(GPIOC, GPIO_PIN_7)));
//        capture = TIM_GetCap2(TIM2);
//        TIM_SetCmp2(TIM2, capture + CCR2_Val);
//    }
//    else if (TIM_GetIntStatus(TIM2, TIM_INT_CC3) != RESET)
//    {
//        TIM_ClrIntPendingBit(TIM2, TIM_INT_CC3);

//        /* Pin PC.08 toggling with frequency = 219.7 Hz */
//        GPIO_WriteBit(GPIOC, GPIO_PIN_8, (Bit_OperateType)(1 - GPIO_ReadOutputDataBit(GPIOC, GPIO_PIN_8)));
//        capture = TIM_GetCap3(TIM2);
//        TIM_SetCmp3(TIM2, capture + CCR3_Val);
//    }
//    else
//    {
//        TIM_ClrIntPendingBit(TIM2, TIM_INT_CC4);

//        /* Pin PC.09 toggling with frequency = 439.4 Hz */
//        GPIO_WriteBit(GPIOC, GPIO_PIN_9, (Bit_OperateType)(1 - GPIO_ReadOutputDataBit(GPIOC, GPIO_PIN_9)));
//        capture = TIM_GetCap4(TIM2);
//        TIM_SetCmp4(TIM2, capture + CCR4_Val);	
//    }
}


/**
 * @brief  This function handles USARTy global interrupt request.
 */
u8 a[20]  = {0};
void USARTy_IRQHandler(void)
{
	uint8_t Res;
	int i,j=0;
    if (USART_GetIntStatus(USART1, USART_INT_RXDNE) != RESET)
    {
        /* Read one byte from the receive data register */
		
  	  	Res =USART_ReceiveData(USART1);   //读取接收到的数据，以下张炜20170519修改

		 if((ucUar1InterrFlag&0x8000)==0)
		 {
			if(ucUar1InterrFlag&0x4000)  //接收到数据长度
			{
				ucUar1tbuf[ucUar1InterrFlag&0x00FF]=Res;   //已经按照指令协议去掉了协议头部分，第一个字节就是CMD参数
				ucUar1InterrFlag++;
				if((ucUar1InterrFlag&0x00FF)==USART1_RX_LEN)   //接收完成
				{
					ucUar1InterrFlag|=0x8000;
					COM1ProcessCmd();
				}         					
			}
			else if(ucUar1InterrFlag&0x2000)
			{
				USART1_RX_LEN = Res+2;    //接收到数据包长度
				ucUar1InterrFlag|=0x4000;    
			}
			else if(ucUar1InterrFlag&0x1000)
			{
				if(Res == TypeID)              //接收到标识符设备类型
					 ucUar1InterrFlag|=0x2000;    
				else
					 ucUar1InterrFlag=0;//标识符1错误重新开始接收
			}
			else
			{
				if(Res == 0x24)
					 ucUar1InterrFlag=0x1000;    //接收到开始字符
				else
					 ucUar1InterrFlag=0;//标识符错误重新开始接收
			}	
	   }  	   
    }
}

/**
 * @brief  This function handles USARTz global interrupt request.
 */
void USART3_IRQHandler(void)
{
	uint8_t Res;
    if (USART_GetIntStatus(USART_4G, USART_INT_RXDNE) != RESET)
    {
        /* Read one byte from the receive data register */
        Res = USART_ReceiveData(USART_4G);

		//printf("u3 r %d %d %c \r\n",ReceEnd3,Res,Res);
		ucUar3InterrFlag = 1;
	    ucUar3tbuf[ReceEnd3++] = Res;
		if(ReceEnd3 >= BufMAX)
		{
			ReceEnd3 = 0;		
		}
    }

}

void timer3sProcess(){
	if((AT_CGATT_Count >= SleepData_SendTime)&&(Flag_PowerOn == 0))  //发送实时数据
	{		  
		  SendSleepDataReally();				//发送数据，发送到缓存里面
		  AT_CGATT_Count=0;
	}
}

void timer20msProcess(){
	ADCTimer++; 									//采样时间累加
	LedFlash++; 									//控制灯的闪烁
	gQuickFlashTimer++; 							//init Led闪烁
	SleepDataBuffer_SendTime++;

    if((Flag_init == MAC_INIT_OK))
    {
        if(gQuickFlashTimer>5)
        {
            gQuickFlashTimer=0;
            Toggle_LED;
        }
    }
    if((Flag_init == WIRELESS_INIT_OK)&&(AngelPace != SendSleepDataR))
    {
        LED_ON;
    }
    if((AngelPace == SendSleepDataR)&&(Flag_LinkStatus == START_GPRS_LINKOK))
    {
      LED_OFF;
    }

	if(Flag_PowerOn == 0)
	 {
		 OnbedStatus_CountTimer++;
		 Algorithm_TIMER_FLAG = 1;//算法计算标记
	 }

}

/**
 * 1s调用一次
*/
void timer1sProcess(){
			IWDG_Feed();
			Heartbeat++;
    
			if(Heartbeat>251)//251秒没收到后台的数据就重启
			{
				Heartbeat=0;
				printf("Heartbeat over ！ NVIC_SystemReset!\r\n");
				NVIC_SystemReset();  //重启
				Heart_beat=1;
			}
			mytime++;
			//printf("1s timer: mytime....%d\r\n",mytime);
			ip1time++;		//前置服务器回应超时计数
			token1time++;	//获取token1超时计数
			token2time++;	//获取token2超时计数
			sleeptime++;	//睡眠数据发送完毕超时计数
			mytime2++;
			AUTOTime++; 	//wifi是否自动连接
			AT_CGATT_Count++;
			CREGTime++; 	//CREG超时计数
			JSPriTime++;	//计时打印
			YZTime++;		//验证超时计数
			ATCGATT_Count++;
			ADDTime();//同步服务器的时间 
			if(Flag_Init_Step==10)
				 Init_pauseTime++;
			else
				GPRS_ConnetTime++;
			//if(Flag_TimeAdj == 0)
			{
				Adj_Time++;
				//半小时的累积误差在3-5S左右
				if( Adj_Time >= 120)
				{
					Adj_Time = 0;
					Flag_TimeAdj = 1;
										
				}			
			}
			if(Flag_TimeAdj ==2)
						sync_sever_time_count++;
			if(Flag_start_time == 1)
			{
				start_time++;
	//			if(Flag_COMDebug == 1)
	//				printf("Start time:%ds\r\n",start_time );
	//			printf("Token2:%s %d\r\n", Token2,AngelPace);
			}
			if(Flag_CanSendStatistData == 2)
			{
				 CanSendStatistTime++;
				 if(CanSendStatistTime == 10)
				 {
					 CanSendStatistTime = 0;
					 Flag_CanSendStatistData = 1;
				 }
			}
	//		if((AT_CGATT_Count >= 3))  //发送实时数据
	//		{		  
	//			  SendSleepDataReally();				//发送数据，发送到缓存里面
	//			  AT_CGATT_Count=0;
	//		}
	 // 	  delay_ms(3000);
		#ifdef ENABLE_SENDPRESSSERSONSTATUS
			if(Flag_SendPresensorStatus == 1)  //发送压力状态
			{
				SendPresensorStatus_Time++;
			}
		#endif
	//-----------------脱离监测时，5min后数据发送时间改为1min发送一次，张炜20170525修改-----------			
			if(gPeopleFlag == TRUE)   //人员在线，清除计时，数据发送时间3s
			{
				 if(Flag_Binding_Users == BINDING_USERS_YES)
				 {
					if((Timebuf[3] >= 9)&&(Timebuf[3] <= 17)) //9~18点3秒1帧、其余10秒一帧 test code!!!  
						SleepData_SendTime = CGATTime_3; 
					else
						SleepData_SendTime = CGATTime_10; 
				 }
				  Monitor_Offline_Time = 0;
			}
			if((gPeopleFlag == FALSE )&&(Monitor_Offline_Time >SLEEPDATA_CHANGETIME))
			{
				 SleepData_SendTime = SLEEPDATA_SENDTIME_30S;
				 Monitor_Offline_Time = SLEEPDATA_CHANGETIME;
			}		
			if((gPeopleFlag == FALSE)&&(Flag_Register_OK == 1)) 	   //无人员并与服务器连接成功则开始计时，张炜2017525增加
			{
				Monitor_Offline_Time++;
	//			  printf("Monitor OFF Line Time:%d s\r\n",Monitor_Offline_Time);
			}
			if(Flag_No_Binding_Users_Time == 1)  //未关联用户计时，张炜2017525增加
			{
			  No_Binding_Users_Time++;
			  if(No_Binding_Users_Time >= SLEEPDATA_CHANGETIME)
				{
					 No_Binding_Users_Time = SLEEPDATA_CHANGETIME;
					 SleepData_SendTime = SLEEPDATA_SENDTIME_30S;
				}
			}
			if(Flag_CARD_ISCHANGE == CARD_HASCHANGE) //发送IMSI等待计时
				CARD_IMSI_Time++;	
			if(AngelPace != SendSleepDataR)  //GPRS模块连接计时
			{
				GPRS_ConnetTime++;
				//if(Flag_COMDebug == 1)
					//printf("Network connect time is:%dS\r\n",GPRS_ConnetTime);
			}
			 if(Flag_ADC_ADJ == 1)
			 {
				  ADC_AdjTime++;
			 }
			 if(flag_Gprs_Reconn==0)
				 GPRS_Wait_Reconn++;
		

	//-----------------------------断网情况下中午12点统计一次数据-------------------------------------------------
//			if((Timebuf[3] ==12)&&(Timebuf[4] ==0)&&(Timebuf[5] ==0))	   //每天中午12点统计一次数据
//			 {
//				if((AngelPace != SendSleepDataR)&&(Flag_PowerOn == 0))
//					Statist_NextDayStart();
//				__set_FAULTMASK(1);//2019/1/14DYP Add;
//				NVIC_SystemReset();
//			 }	 

}


/**
 * @}
 */
