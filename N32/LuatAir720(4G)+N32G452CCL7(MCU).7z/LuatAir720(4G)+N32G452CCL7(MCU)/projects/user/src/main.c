/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/

/**
 * @file main.c
 * @author Nations 
 * @version v1.0.1
 *
 * @copyright Copyright (c) 2019, Nations Technologies Inc. All rights reserved.
 */
#include "main.h"
#include <stdio.h>
#include <BERpara.h>
#include "Parameter.h"
#include "USART.h"
#include "Delay.h"
#include "Flash.h"
#include "Calculate.h"
#include "LED_Key.h"
#include "m26.h"
#include "Fun.h"
#include "string.h"


/** @addtogroup TIM_TimeBase
 * @{
 */

TIM_TimeBaseInitType TIM_TimeBaseStructure;
OCInitType TIM_OCInitStructure;
ErrorStatus HSEStartUpStatus;

__IO uint16_t CCR1_Val  = 40961;
__IO uint16_t CCR2_Val  = 27309;
__IO uint16_t CCR3_Val  = 13654;
__IO uint16_t CCR4_Val  = 6826;
__IO uint16_t MY_CCR_Val  = 40060;
uint16_t PrescalerValue = 0;

USART_InitType USART_InitStructure;


ADC_InitType ADC_InitStructure;
DMA_InitType DMA_InitStructure;
__IO uint16_t ADC1_ConvertedValue = 0;
__IO uint16_t ADC3_ConvertedValue = 0;
//__IO uint16_t ADC1_ConvertedValue[2]={0};


#define TxBufferSize1 (countof(TxBuffer1) - 1)
#define TxBufferSize2 (countof(TxBuffer2) - 1)
#define RxBufferSize1 TxBufferSize2
#define RxBufferSize2 TxBufferSize1

#define countof(a) (sizeof(a) / sizeof(*(a)))

#define SYSTEMRESET_POWER       1   //��Դ��λ
#define SYSTEMRESET_WATCHDOG    2   //���Ź���λ
#define SYSTEMRESET_SOFT        3   //������λ
#define SYSTEMRESET_UNKNOW      4   //����ԭ��λ ����������λ��

#define  START_POWERON            0X01     //��Դ����
#define  START_NETWOEK_RECONNECT  0X02     //��������
#define  START_LTE_RESTART       0X03     //LTEģ���ϵ�����
#define  START_SOFTRESET          0X04     //������λ
#define  START_IWDGRESET          0X05     //���Ź���λ
/****************��Ӳ���汾��Ϣ,�����汾�ź��ʱ��Ϊ�������ʱ�䣬��쿼�********************/

USART_InitType USART_InitStructure;
uint8_t TxBuffer1[] = "USART Interrupt Example: USARTy -> USARTz using Interrupt";
uint8_t TxBuffer2[] = "USART Interrupt Example: USARTz -> USARTy using Interrupt";
uint8_t RxBuffer1[RxBufferSize1];
uint8_t RxBuffer2[RxBufferSize2];
__IO uint8_t TxCounter1         = 0x00;
__IO uint8_t TxCounter2         = 0x00;
__IO uint8_t RxCounter1         = 0x00;
__IO uint8_t RxCounter2         = 0x00;
uint8_t NbrOfDataToTransfer1    = TxBufferSize1;
uint8_t NbrOfDataToTransfer2    = TxBufferSize2;
uint8_t NbrOfDataToRead1        = RxBufferSize1;
uint8_t NbrOfDataToRead2        = RxBufferSize2;
__IO TestStatus TransferStatus1 = FAILED;
__IO TestStatus TransferStatus2 = FAILED;


void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);
void Timer_Configuration(void);
void USART_Configuration(void);
void DMA_ADC_Configuration(void);
void InitParam(void);

 char  *SoftVer = "Hardware:V5.0-20190523\r\nSoftware:V4.6.8<20190927>\r\n";  
 unsigned char sDebugMode = 0;
uint8_t  ucConectFlag=0;
 u32 CpuID[3]={0}; 

void Get_CPU_ID(void)
   
{
//read CPU ID,stm32lxx,add+4
CpuID[0] = *(__IO u32 *)(0X1FFFF7AC);
CpuID[1] = *(__IO u32 *)(0X1FFFF7B0);
CpuID[2] = *(__IO u32 *)(0X1FFFF7B4);	
}


enum
{
    SYSCLK_PLLSRC_HSI,
    SYSCLK_PLLSRC_HSE,
};
void SetSysClockToPLL(uint32_t freq, uint8_t src)
{
    uint32_t pllsrc = (src == SYSCLK_PLLSRC_HSI ? RCC_PLL_SRC_HSI_DIV2 : RCC_PLL_SRC_HSE_DIV2);
    uint32_t pllmul;
    uint32_t latency;
    uint32_t pclk1div, pclk2div;

    if (HSE_VALUE != 8000000)
    {
        /* HSE_VALUE == 8000000 is needed in this project! */
        while (1)
            ;
    }

    /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration
     * -----------------------------*/
    /* RCC system reset(for debug purpose) */
    RCC_DeInit();

    if (src == SYSCLK_PLLSRC_HSE)
    {
        /* Enable HSE */
        RCC_ConfigHse(RCC_HSE_ENABLE);

        /* Wait till HSE is ready */
        HSEStartUpStatus = RCC_WaitHseStable();

        if (HSEStartUpStatus != SUCCESS)
        {
            /* If HSE fails to start-up, the application will have wrong clock
               configuration. User can add here some code to deal with this
               error */

            /* Go to infinite loop */
            while (1)
                ;
        }
    }

    switch (freq)
    {
    case 24000000:
        latency  = FLASH_LATENCY_0;
        pllmul   = RCC_PLL_MUL_6;
        pclk1div = RCC_HCLK_DIV1;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 36000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_9;
        pclk1div = RCC_HCLK_DIV1;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 48000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_12;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 56000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_14;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 72000000:
        latency  = FLASH_LATENCY_2;
        pllmul   = RCC_PLL_MUL_18;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 96000000:
        latency  = FLASH_LATENCY_2;
        pllmul   = RCC_PLL_MUL_24;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    case 128000000:
        latency  = FLASH_LATENCY_3;
        pllmul   = RCC_PLL_MUL_32;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    case 144000000:
        /* must use HSE as PLL source */
        latency  = FLASH_LATENCY_4;
        pllsrc   = RCC_PLL_SRC_HSE_DIV1;
        pllmul   = RCC_PLL_MUL_18;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    default:
        while (1)
            ;
    }

    FLASH_SetLatency(latency);

    /* HCLK = SYSCLK */
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);

    /* PCLK2 = HCLK */
    RCC_ConfigPclk2(pclk2div);

    /* PCLK1 = HCLK */
    RCC_ConfigPclk1(pclk1div);

    RCC_ConfigPll(pllsrc, pllmul);

    /* Enable PLL */
    RCC_EnablePll(ENABLE);

    /* Wait till PLL is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_PLLRD) == RESET)
        ;

    /* Select PLL as system clock source */
    RCC_ConfigSysclk(RCC_SYSCLK_SRC_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while (RCC_GetSysclkSrc() != 0x08)
        ;
}

/**
 * @brief  Configures LED GPIO.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedInit(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_InitType GPIO_InitStructure;

    /* Check the parameters */
    assert_param(IS_GPIO_ALL_PERIPH(GPIOx));


    /* Enable the GPIO Clock */
    if (GPIOx == GPIOA)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
    }
    else if (GPIOx == GPIOB)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
    }
    else if (GPIOx == GPIOC)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    }
    else if (GPIOx == GPIOD)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOD, ENABLE);
    }
    else if (GPIOx == GPIOE)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOE, ENABLE);
    }
    else if (GPIOx == GPIOF)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOF, ENABLE);
    }
    else
    {
        if (GPIOx == GPIOG)
        {
            RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOG, ENABLE);
        }
    }

    /* Configure the GPIO pin */
    if (Pin <= GPIO_PIN_ALL)
    {
        GPIO_InitStructure.Pin        = Pin;
        GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitPeripheral(GPIOx, &GPIO_InitStructure);
    }
}
/**
 * @brief  Turns selected Led on.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedOn(GPIO_Module* GPIOx, uint16_t Pin)
{
        GPIOx->PBC = Pin;
}
/**
 * @brief  Turns selected Led Off.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedOff(GPIO_Module* GPIOx, uint16_t Pin)
{
	GPIOx->PBSC = Pin;
}
/**
 * @brief  Turns selected Led on or off.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be one of the following values:
 * 	@arg GPIO_PIN_0~GPIO_PIN_15: set related pin on
 *   	@arg (GPIO_PIN_0<<16)~(GPIO_PIN_15<<16): clear related pin off
 */
void LedOnOff(GPIO_Module* GPIOx, uint32_t Pin)
{
    GPIOx->PBSC = Pin;
}
/**
 * @brief  Toggles the selected Led.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedBlink(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIOx->POD ^= Pin;
}

/****************************************************************************
*	�� �� ��:  SystemReset_CheckStatus
*	����˵��:  ���Ҹ�λ��ԭ��
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ������Դ��λ�����Ź���λ
*****************************************************************************/
void SystemReset_CheckStatus(void)
{

	if((RCC_GetFlagStatus(RCC_FLAG_IWDGRST) == SET)||(RCC_GetFlagStatus(RCC_FLAG_WWDGRST) == SET))
	{
		 //Flag_SystemReset = SYSTEMRESET_WATCHDOG;
		Flag_Start_Mode = START_IWDGRESET;  //���Ź���λ����
		 if(Flag_COMDebug == 1)
				printf("\r\n���Ź���λ\r\n");
	}
	else if(RCC_GetFlagStatus(RCC_FLAG_LPWRRST) == SET)
	{
		 //Flag_SystemReset = SYSTEMRESET_POWER;
		Flag_Start_Mode = START_POWERON;  //�ϵ�����
		 if(Flag_COMDebug == 1)
				printf("\r\n�͵�ѹ��λ\r\n");
	}
	else if((RCC_GetFlagStatus(RCC_FLAG_PORRST) == SET)||(RCC_GetFlagStatus(RCC_FLAG_PINRST) == SET))
	{
		 //Flag_SystemReset = SYSTEMRESET_POWER;
		Flag_Start_Mode = START_POWERON;  //�ϵ�����
		 if(Flag_COMDebug == 1)
				printf("\r\n��Դ��λ\r\n");
	}
	else if(RCC_GetFlagStatus(RCC_FLAG_SFTRST) == SET)
	{
		 //Flag_SystemReset = SYSTEMRESET_SOFT;
		Flag_Start_Mode = START_SOFTRESET;  //������λ����
		 if(Flag_COMDebug == 1)
				printf("\r\n������λ\r\n");
	}
	else
	{
		 //Flag_SystemReset = SYSTEMRESET_UNKNOW ;
		Flag_Start_Mode = START_POWERON;  //�ϵ�����
		 if(Flag_COMDebug == 1)
				printf("\r\n����ԭ��λ\r\n");
	}
		
	
}


/****************************************************************************
*	�� �� ��: LinkServer
*	����˵��: ���ӷ�����
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void LinkServer(uint8_t AP)
{

	switch(AngelPace)
    {
        case CONECTIP1:								//����ǰ�÷�����
            ucConectFlag = 1;
            if(SendDataStatus != OK)
            {				//��������
                 //Set_IPLink_Mode(1); 
                printf("try to ConnectFrontServer\r\n");
                ConnectServertEST();				//����ǰ�÷�����		
            }
            else
            {
                //printf("rec check");
                ConnectFrontServerRcvCtr();			//���մ���
                //AngelPace=GETFRONTSERVEROK;
            }
            break;
//        case CONECTIP1OK:							//����ǰ�÷������ɹ�
//        printf("connect ok...try to get token\r\n");
//        if(SendDataStatus != OK)
//        {	
//            GetFrontEndServerPw();				//��ȡǰ�÷�������֤��
//        }
//        else
//        {
//            GetFrontEndServerPwRcvCtr();		//���մ���
//        }
//        break;
        case GETFRONTSERVEROK:						//��ȡtoken1�ɹ�
            if(SendDataStatus != OK)
                {
                    //GetBackEndServerIP();				//��ȡ���÷�����IP
                    printf("try to get backserver ip\r\n");
                    GetBackServerIP();
              }
            else
            {
                //printf("�������صĺ��÷�����IP: %d\r\n",SendDataStatus);
                //GetBackEndServerIPRcvCtr();			//���մ���
                AnalysisBackServerIP();
            }
            
            break;
        case GETBACKSERVERIPOK:						//��ȡ���÷�����IP�ɹ�
            ucConectFlag = 1;						//
            //ConnectBackServer();					//���Ӻ��÷�����
                 //  Set_IPLink_Mode(0); 
                Connect_BackServer();
           
                //Analysis_BackServer();
            break;
        case CONECTIP2:								//���Ӻ��÷�����
            ucConectFlag = 1;						//���Ź����У����ܷ�������
            //ConnectBackServer();					//���Ӻ��÷�����
            Connect_BackServer();
            break;
        case CONECTIP2OK:							//���Ӻ��÷������ɹ�����ȡtoken2
            //if((Flag_Check_Status&ERROR_NO_TOKEN2) == ERROR_NO_TOKEN2 )
            {

                    if(SendDataStatus != OK)
                    {					
                        //GetBackServerPw();					//���ͻ�ȡtoken2ָ��
                        GetBackServerToken2();
                    }
                    else
                    {
                        //GetBackServerPwRece(GPRS_or_WIFI);	//��ȡ���÷�������֤��token2
                        AnalysisBackServerToken2();
                    }
            }
//				else
//				{
//					 AngelPace = GETBACKSERVEROK;
//					 SendDataStatus = NO;					
//				}
          
            break;
        case GETBACKSERVEROK:						//��ȡtoken2�ɹ� 
                if(SendDataStatus != OK)  
                {
                        //SendSleepData();					//�豸������֤
                    SendBackServerVerify();
                }
                else
                {
                    SendSleepDataRcvCtr();				//���մ���
                }
          
            break;
        case SendSleepDataR:
            ucConectFlag = 0;						//��ʾע��ɹ�
          Flag_Register_OK = 1;
    
            break; 
        case POWERERROR:   //GPRS  ģ���Դ����

            break;
        case MACERROR:								//MAC�����ڴ���

            break;			
    }
}


/**
 * @brief  Main program
 */
int main(void)
{
	uint16_t i,ADC_COUNT = 0;

	InitParam();
		
    /* System Clocks Configuration */
		SetSysClockToPLL(96000000, SYSCLK_PLLSRC_HSI);
		RCC_EnableClockSecuritySystem(ENABLE);
    RCC_Configuration();

    /* NVIC Configuration */
    NVIC_Configuration(); 
	
    /* GPIO Configuration */
    GPIO_Configuration();

	/* Timer Configuration */
	Timer_Configuration();
	
    /* USART Configuration */
	USART_Configuration();

	/* DMA ADC Configuration */
	DMA_ADC_Configuration();

	//LED
	LedInit(GPIOA, GPIO_PIN_15);

	DataInitial();

	delay_init();

	ClearUSART3BUF(); 
		SleepData_SendTime = CGATTime;	//��ʼĬ�Ϸ���ʱ����Ϊ3s	
		
	
		delay_ms(500);
	
		LedOn(GPIOA, GPIO_PIN_15);
		ReadMACFromFlash();
	
		printf("\r\n------------------------\r\n");
		printf("%s",SoftVer);
		printf("Build time is:%s %s\r\n", __DATE__, __TIME__);
		printf("\r\n------------------------\r\n"); 
		printf("System Init!\r\n");
		SystemReset_CheckStatus();
		Get_CPU_ID();
		printf("CPU_ID: %08X-%08X-%08X\r\n",CpuID[0],CpuID[1],CpuID[2]);
		
		ReadFlash();
		CheckMac();
		
		if((Flag_Check_Status&ERROR_N0_MAC) !=ERROR_N0_MAC)
		{
			 
			Flag_init = MAC_INIT_OK;  //���Խ�������ģ���ʼ��
			start_time = 0; 
			Flag_start_time = 1;	
			ClearUSART3BUF();		
			delay_ms(500);	
			GPRS_ConnetTime =0; 	
		}

		IWDG_Config(IWDG_PRESCALER_DIV64 ,1250);	 //���Ź�	
//		IWDG_Config(IWDG_PRESCALER_DIV64 ,500);	 //���Ź�	

		while(1)
		{	
	//------------------------ѹ��������---------------------------------------------			
			if(Flag_PowerOn == 0)
			{
				Check_ExtSensor_PeopleOnBed(); //����ⲿ�������ڴ�״̬
			}			
		//-------------------------GPRS��ʼ��--------------------------------------------		
			if(Flag_init == MAC_INIT_OK)
			{
				if(GPRS_or_WIFI == GPRS)//GPRS��ʼ��
				{
					Init_M26(Flag_Init_Step);				 
				}
			}		
			if(Flag_init == WIRELESS_INIT_OK)
			{
				//-----------------------�����������ݴ���----------------------------------------	 		  
					LinkServer(AngelPace);
	
				//-------------------------------10s��ѯһ������״̬--------------------------------------------------
				//printf("ATCGATT_Count..%d,AngelPace...%d, GPRS_or_WIFI...%d\r\n",ATCGATT_Count,AngelPace,GPRS_or_WIFI);
				if((ATCGATT_Count > 10) && (AngelPace == SendSleepDataR) && (GPRS_or_WIFI == GPRS))
				{
					ATCGATT_Count = 0;
					if(Flag_SendDataAbnormal != NO_ERROR)  //�����쳣ʱ����
					{
						Send_DataUnusual(Flag_SendDataAbnormal,ABN_gPulseRateHR,ABN_gPulseRateRR);
						if(Flag_COMDebug == 1)
							printf("Sleep data abnormal:0x%x 0x%x 0x%x",Flag_SendDataAbnormal,ABN_gPulseRateHR,ABN_gPulseRateRR);
						Flag_SendDataAbnormal = NO_ERROR;
					}
					if(Flag_Binding_Users == BINDING_USERS_NO)	 //���δ�����û������ѯ����״̬,���20170523����
					{
						Req_Users_Binding();
					}
					
//					if((REGISTEFlag==1)&&(AngelPace == SendSleepDataR))
//					{						//ע��֮����ܲ�ѯ״̬
//						//UART3_SendString("AT+REGISTER\r\n");					
//					}
				
					InquireCSQ();
					if((Flag_CARD_ISCHANGE == CARD_HASCHANGE)&&(CARD_IMSI_Time>600)) //10���ӷ���һ��
					{
						Send_CARD_IMSI();
						CARD_IMSI_Time = 0;
					}
					if(CheckLinkStatus() == 0)//��ѯ����״̬
					{
						AngelPace = CONECTIP2;
						printf("Reconnect Server!\r\n");
						NVIC_SystemReset();  //����
					}
				}	
				if((Flag_SleepDataBuffer_Save != Flag_SleepDataBuffer_Send)&&(AngelPace == SendSleepDataR)&&(SleepDataBuffer_SendTime>50)&&(Flag_CanSendStatistData == 1))
				{
					SleepDataBuffer_SendTime = 0;
					Flag_CanSendStatistData = 2;
					CanSendStatistTime = 0;
					Send_StatistStatusData();	//����״̬ͳ������
				}		
				//-----------------------------���߽������ݴ���--------------------------------------------------
				if((AngelPace == SendSleepDataR) && (GPRS_or_WIFI == GPRS))
				{
					SendSleepDataReallyRcvCtr();
				}
				if((Flag_TimeAdj == 1)&&(AngelPace == SendSleepDataR)) //У׼ʱ��
				{
					GetServerTime();
					Flag_TimeAdj = 2;				
				}
				if((Flag_TimeAdj ==2)&&(sync_sever_time_count>=5))//ÿ��ͬ��ʱ�����ͬ���ɹ� 2019/4/24 by dyp
				{
					sync_sever_time_count=0;
					Flag_TimeAdj=1;
					printf("����������Ӧ,�������������ʱ��\r\n");
				}
			}
	
			//�����㷨����м���
			if(Algorithm_TIMER_FLAG)
			{
					Algorithm_TIMER_FLAG = 0;
					if(Flag_PowerOn == 0)
					{
						 OnbedStatus_CountTimer++;
						 SleepDataCalculate();
					}	
			}
			
			if((AT_CGATT_Count >= SleepData_SendTime)&&(Flag_PowerOn == 0))  //����ʵʱ����
			{		  
					SendSleepDataReally();				//�������ݣ����͵���������
				  AT_CGATT_Count=0;
			}
//			if(GPRS_Wait_Reconn>Repower_GPRS_Count*120)
//			{
//				GPRS_Wait_Reconn=0;
//				flag_Gprs_Reconn=1;
//				printf("============>repower M26 \r\n");
//				RePowerOn_GPRS();
//			}
			//-------------------------�������ӳ�ʱ������GPRSģ��------------------------------------------	
			if((GPRS_ConnetTime > 60)&&(AngelPace != SendSleepDataR)&&((Flag_Check_Status&ERROR_N0_MAC) !=ERROR_N0_MAC)/*&&(Flag_PowerOn == 0)*/)  //���豸10����δ�����Ϸ��������������ϵ�wifiģ��
			{
				GPRS_ConnetTime = 0;
				if(flag_Gprs_Reconn)
				{
					flag_Gprs_Reconn=0;
					Repower_GPRS_Count++;
					if(Repower_GPRS_Count > 10)   //24Сʱ�����Ӳ��ϣ���Ƭ����λ
					{
						__set_FAULTMASK(1);
						NVIC_SystemReset();
					}
				}
			}		
		}	
}

void InitParam(void)
{
	int i ,j;
	//------------------������ʼ��--------------------------------------	
	ADCTimer = 0;						//���ݲɼ���ʱ����
	Times = 0;							//�ź�����ʱ����
	AngelPace = CONECTIP1;
	Flag_No_Binding_Users_Time =0; //δ�����û���ʱ��־����
	Flag_Binding_Users = BINDING_USERS_YES;	
	gQuickFlashTimer = 0;
	CREGTime = 0;
	SampleData = 0;
	Flag_Register_OK = 0;
	Monitor_Offline_Time = 0;
	Flag_Check_Status = NO_ERROR;
	Flag_Start_Mode = START_POWERON;  //�ϵ�����
	Flag_LinkStatus = START_POWERON;
	Flag_Send_GPRS_Position = 0;
	ucUar1InterrFlag = 0;
	start_time = 0; 
	Flag_SendDataAbnormal = NO_ERROR;
	Flag_init = SYSTEM_INIT;
	Flag_TimeAdj = 0;	
	Network_connect_time=0;
	
	Flag_SendAMPCHGToServer = 0;
	for(i=0;i<ECG_COMPARE_TIMES;i++)
	{
		ECG_MAX[i] = STANDARD_VOLTAGE;
		ECG_MIN[i] = STANDARD_VOLTAGE;
		CHGECG_MAX[i] = STANDARD_VOLTAGE;
		CHGECG_MIN[i] = STANDARD_VOLTAGE;
	}
	ECG_COMPARE_COUNT = 0;
	Flag_ADC_ADJ = 0;

	CHGADC_COUNT = 0;
	Last_gPeopleFlag  = 0;
	Flag_PowerOn = 1; 

	Flag_SendAMPCHGToServer = 0;
	Flag_SleepDataBuffer_Save = 0;
	Flag_SleepDataBuffer_Send = 0;
	for(i=0;i<SLEEPDTATABUF;i++)
	{
		for(j=0;j<40;j++)
		   Buffer_SleepData[i][j] = 0;
	}

	Status_ExtSensorIn = EXTSENSOR_ISOUT;    
	Status_ExtSensorOnbed = EXTSENSOR_PEOPLEOFFBED; 
	ExtSensor_OnbedStatus_Count = 0;
	OnbedStatus_CountTimer = 0;
	LastOnbedStatus = 1;
	Flag_SendPresensorStatus = 1;//Ĭ�Ͽ���ѹ��״̬���� 2019/4/23   BY DYP
    Flag_COMDebug = 1;     //Ĭ�ϴ��ڲ���ӡ
}

/**
 * @brief  Configures the different system clocks.
 */
void RCC_Configuration(void)
{
    /* PCLK1 = HCLK/4 */
    //RCC_ConfigPclk1(RCC_HCLK_DIV4);

    /* TIM2 clock enable */
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM2, ENABLE);

    /* GPIOC clock enable */
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
	
	/* Enable GPIO clock */
    RCC_EnableAPB2PeriphClk(USARTy_GPIO_CLK | USART_4G_GPIO_CLK | RCC_APB2_PERIPH_AFIO, ENABLE);
	
    /* Enable USARTy and USART_4G Clock */
    USARTy_APBxClkCmd(USARTy_CLK, ENABLE);
    USART_4G_APBxClkCmd(USART_4G_CLK, ENABLE);

	//ADC DMA
		/* Enable peripheral clocks ------------------------------------------------*/
    /* Enable DMA1 and DMA2 clocks */
    RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_DMA1 | RCC_AHB_PERIPH_DMA2, ENABLE);
    /* Enable GPIOC clocks */
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    /* Enable ADC1, ADC2, ADC3 and ADC4 clocks */
    RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_ADC2,ENABLE);
    /* RCC_ADCHCLK_DIV16*/
    ADC_ConfigClk(ADC_CTRL3_CKMOD_AHB,RCC_ADCHCLK_DIV16);

}

/**
 * @brief  Configure the GPIO Pins.
 */
void GPIO_Configuration(void)
{
    GPIO_InitType GPIO_InitStructure;

	//JTAG���Ÿ���ΪGPIO
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO, ENABLE);

	GPIO_ConfigPinRemap(GPIO_RMP_SW_JTAG_SW_ENABLE, ENABLE);		// ������ΪGPIO

    /* Configure USARTy Rx as input floating */
    GPIO_InitStructure.Pin       = USARTy_RxPin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitPeripheral(USARTy_GPIO, &GPIO_InitStructure);

    /* Configure USART_4G Rx as input floating */
    GPIO_InitStructure.Pin = USART_4G_RxPin;
    GPIO_InitPeripheral(USART_4G_GPIO, &GPIO_InitStructure);

    /* Configure USARTy Tx as alternate function push-pull */
    GPIO_InitStructure.Pin        = USARTy_TxPin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitPeripheral(USARTy_GPIO, &GPIO_InitStructure);

    /* Configure USART_4G Tx as alternate function push-pull */
    GPIO_InitStructure.Pin = USART_4G_TxPin;
    GPIO_InitPeripheral(USART_4G_GPIO, &GPIO_InitStructure);
	
	//ADC
    /* Configure PA1 PA2 as analog inputs */
    GPIO_InitStructure.Pin       = GPIO_PIN_4 | GPIO_PIN_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitPeripheral(GPIOA, &GPIO_InitStructure);

//	//PB3 ���͵�ƽ
//	GPIO_InitStructure.Pin		  = GPIO_PIN_3;
//	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);
	
}

/**
 * @brief  Configure the nested vectored interrupt controller.
 */
void NVIC_Configuration(void)
{
    NVIC_InitType NVIC_InitStructure;
	
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

    /* Enable the TIM2 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel                   = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the USART1 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel            = USARTy_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd         = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the USART_4G Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel            = USART_4G_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd         = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

	//ԭ��Ŀ��ֲ��������FLASH���ж�
 	//NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);

}

void Timer_Configuration(void){
 /* ---------------------------------------------------------------
    TIM2 Configuration: Output Compare Timing Mode:
    TIM2 counter clock at 6 MHz
    CC1 update rate = TIM2 counter clock / CCR1_Val = 146.48 Hz
    CC2 update rate = TIM2 counter clock / CCR2_Val = 219.7 Hz
    CC3 update rate = TIM2 counter clock / CCR3_Val = 439.4 Hz
    CC4 update rate = TIM2 counter clock / CCR4_Val = 878.9 Hz
    --------------------------------------------------------------- */

    /* Compute the prescaler value */
    PrescalerValue = (uint16_t)(SystemCoreClock / 12000000) - 1;

    /* Time base configuration */
    TIM_TimeBaseStructure.Period    = 65535;
    TIM_TimeBaseStructure.Prescaler = 0;
    TIM_TimeBaseStructure.ClkDiv    = 0;
    TIM_TimeBaseStructure.CntMode   = TIM_CNT_MODE_UP;

    TIM_InitTimeBase(TIM2, &TIM_TimeBaseStructure);

    /* Prescaler configuration */
    TIM_ConfigPrescaler(TIM2, PrescalerValue, TIM_PSC_RELOAD_MODE_IMMEDIATE);

    /* Output Compare Timing Mode configuration: Channel1 */

    TIM_OCInitStructure.OcMode      = TIM_OCMODE_TIMING;
    TIM_OCInitStructure.OutputState = TIM_OUTPUT_STATE_ENABLE;
    TIM_OCInitStructure.Pulse       = MY_CCR_Val;
    TIM_OCInitStructure.OcPolarity  = TIM_OC_POLARITY_HIGH;

    TIM_InitOc1(TIM2, &TIM_OCInitStructure);

    TIM_ConfigOc1Preload(TIM2, TIM_OC_PRE_LOAD_DISABLE);

    /* TIM IT enable */
    TIM_ConfigInt(TIM2, TIM_INT_CC1, ENABLE);

    /* TIM2 enable counter */
    TIM_Enable(TIM2, ENABLE);
}

void USART_Configuration(void){

	/* USARTy and USARTz configuration ------------------------------------------------------*/
	USART_InitStructure.BaudRate			= 115200;
	USART_InitStructure.WordLength			= USART_WL_8B;
	USART_InitStructure.StopBits			= USART_STPB_1;
	USART_InitStructure.Parity				= USART_PE_NO;
	USART_InitStructure.HardwareFlowControl = USART_HFCTRL_NONE;
	USART_InitStructure.Mode				= USART_MODE_RX | USART_MODE_TX;

	/* Configure USARTy and USARTz */
	USART_Init(USARTy, &USART_InitStructure);
	USART_Init(USART_4G, &USART_InitStructure);

	/* Enable USARTy Receive interrupts */
	USART_ConfigInt(USARTy, USART_INT_RXDNE, ENABLE);
	
	/* Enable USART 4G Receive interrupts */
	USART_ConfigInt(USART_4G, USART_INT_RXDNE, ENABLE);

	/* Enable the USARTy and USARTz */
	USART_Enable(USARTy, ENABLE);
	USART_Enable(USART_4G, ENABLE); 

}

void DMA_ADC_Configuration(void){
    /* DMA1 channel1 configuration ----------------------------------------------*/
    DMA_DeInit(DMA1_CH8);
    DMA_InitStructure.PeriphAddr     = (uint32_t)&ADC2->DAT;
    DMA_InitStructure.MemAddr        = (uint32_t)ADC_ConvertedValue;
    DMA_InitStructure.Direction      = DMA_DIR_PERIPH_SRC;
    DMA_InitStructure.BufSize        = 2;
    DMA_InitStructure.PeriphInc      = DMA_PERIPH_INC_DISABLE;
    DMA_InitStructure.DMA_MemoryInc  = DMA_MEM_INC_ENABLE;
    DMA_InitStructure.PeriphDataSize = DMA_PERIPH_DATA_SIZE_WORD;
    DMA_InitStructure.MemDataSize    = DMA_MemoryDataSize_Word;
    DMA_InitStructure.CircularMode   = DMA_MODE_CIRCULAR;
    DMA_InitStructure.Priority       = DMA_PRIORITY_HIGH;
    DMA_InitStructure.Mem2Mem        = DMA_M2M_DISABLE;
    DMA_Init(DMA1_CH8, &DMA_InitStructure);
    /* Enable DMA1 Channel1 */
    DMA_EnableChannel(DMA1_CH8, ENABLE);

    /* ADC2 configuration ------------------------------------------------------*/
    ADC_InitStructure.WorkMode       = ADC_WORKMODE_REG_SIMULT;
    ADC_InitStructure.MultiChEn      = ENABLE;
    ADC_InitStructure.ContinueConvEn = ENABLE;
    ADC_InitStructure.ExtTrigSelect  = ADC_EXT_TRIGCONV_NONE;
    ADC_InitStructure.DatAlign       = ADC_DAT_ALIGN_R;
    ADC_InitStructure.ChsNumber      = 2;
    ADC_Init(ADC2, &ADC_InitStructure);
    /* ADC2 regular channels configuration */
    ADC_ConfigRegularChannel(ADC2, ADC2_Channel_01_PA4, 1, ADC_SAMP_TIME_239CYCLES5);
    ADC_ConfigRegularChannel(ADC2, ADC2_Channel_02_PA5, 2, ADC_SAMP_TIME_239CYCLES5);
    /* Enable ADC2 external trigger conversion */
    ADC_EnableExternalTrigConv(ADC2, ENABLE);

//    /* Enable Vrefint channel17 */
    ADC_EnableTempSensorVrefint(ENABLE);

    /* Enable ADC2 */
    ADC_Enable(ADC2, ENABLE);
		ADC_EnableDMA(ADC2, ENABLE);
    /*Check ADC Ready*/
    while(ADC_GetFlagStatusNew(ADC2,ADC_FLAG_RDY) == RESET)
        ;
    /* Start ADC2 calibration */
    ADC_StartCalibration(ADC2);
    /* Check the end of ADC2 calibration */
    while (ADC_GetCalibrationStatus(ADC2))
        ;

		  ADC_EnableSoftwareStartConv(ADC2, ENABLE);

    /* Test on DMA1 channel1 transfer complete flag */
    while (!DMA_GetFlagStatus(DMA1_FLAG_TC8, DMA1))
        ;
    /* Clear DMA1 channel1 transfer complete flag */
    DMA_ClearFlag(DMA1_FLAG_TC8, DMA1);
}

/****************************************************************************
*	�� �� ��: COM1ProcessCmd
*	����˵��: ����1�������ô���
*	��    �Σ���
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void COM1ProcessCmd(void)
{
   uint8_t i;
	 uint8_t Res = 0;
	 switch( ucUar1tbuf[0])
	 {
		 case READ_REALTIME_ADCDATA:   //��ȡʵʱ����
			     if(sDebugMode == 0 )
					 {
			        sDebugMode = 1;
						  Flag_COMDebug = 0;
					 }
					 else
						  sDebugMode = 0;		 
		 break;
					 
		 case READ_COM_DEBUG:     //��ӡ������־
			     if(Flag_COMDebug == 0 )
					 {
			        Flag_COMDebug = 1;
						  sDebugMode = 0;
					 }
					 else
						  Flag_COMDebug = 0;	 
		 break;

		 //24 01 0f 22 31 32 33 34 35 36 31 32 33 34 35 36 ff 69 42
		 //24 01 0f 22 30 30 30 41 30 30 30 34 42 43 37 43 ff 69 42
		 //24 01 0f 22 41 44 38 43 32 44 35 44 36 42 35 37 ff 69 42
		 case SET_DEVICE_MAC:      //�����豸MAC
			    MAC_LEN = USART1_RX_LEN-4;
		      for(i=0;i<MAC_LEN;i++)
	          {
							 MAC_ID[i] = ucUar1tbuf[1+i];
						}
					printf("�豸��ų���Ϊ:%d\r\n �豸���Ϊ:",MAC_LEN);
			     for(i=0;i<MAC_LEN;i++)
			    printf("%c ",MAC_ID[i]);
			    printf("\r\n");
					Res = WriteMACToFlash();
					if(Res == 0x01)
					{
						 Flag_Check_Status &= 0xFE;
					   COMRetuenOneByte(USART1,SET_DEVICE_MAC,0x01);
						 CheckMac();
						 Flag_init = MAC_INIT_OK;
             Flag_Check_Status |=ERROR_NO_TOKEN2;							
             start_time = 0; 
	           Flag_start_time = 1;	
						 AngelPace=CONECTIP1;
					}
					else
					{
						COMRetuenOneByte(USART1,SET_DEVICE_MAC,0x00);
					}
		 break;
				 
		 case READ_DEVICE_MAC:   //��ȡ�豸MAC
			    SendDeviceMacToUart1();		      
		 break;
		 
		 case READ_DEVICE_VER:  //��ȡ�豸�汾��
			    SendDeviceVerInfoToUart1(SoftVer);
		 break;
		 
		 default :
			 
		 break;
	 }
   ucUar1InterrFlag = 0;	 
}


/**
 * @brief  Compares two buffers.
 * @param  pBuffer1, pBuffer2: buffers to be compared.
 * @param BufferLength buffer's length
 * @return PASSED: pBuffer1 identical to pBuffer2
 *         FAILED: pBuffer1 differs from pBuffer2
 */
TestStatus Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength)
{
    while (BufferLength--)
    {
        if (*pBuffer1 != *pBuffer2)
        {
            return FAILED;
        }

        pBuffer1++;
        pBuffer2++;
    }

    return PASSED;
}

/* retarget the C library printf function to the USART */
int fputc(int ch, FILE* f)
{
    USART_SendData(USART1, (uint8_t)ch);
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXDE) == RESET)
        ;

    return (ch);
}


#ifdef USE_FULL_ASSERT

/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param file pointer to the source file name
 * @param line assert_param error line source number
 */
void assert_failed(const uint8_t* expr, const uint8_t* file, uint32_t line)
{
    /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

    while (1)
    {
    }
}

#endif

/**
 * @}
 */

/**
 * @}
 */
