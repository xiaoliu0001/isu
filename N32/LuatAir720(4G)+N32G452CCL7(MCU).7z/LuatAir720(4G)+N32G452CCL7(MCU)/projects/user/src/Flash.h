/******************************************************************************
 * @file     flash.h
 * @brief   �洢����
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par     FLASH���ݴ洢  �ϱ� 2016
*******************************************************************************/
#ifndef __FLASH_H_
#define __FLASH_H_

#include "n32g45x.h"

/* Private typedef -----------------------------------------------------------*/
typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;
/* Private define ------------------------------------------------------------*/
#define FLASH_PAGE_SIZE         ((uint32_t)0x00000400)   /* FLASH Page Size */
#define FLASH_USER_START_ADDR   ((uint32_t)0x08020000)   /* Start @ of user Flash area */
#define FLASH_USER_END_ADDR     ((uint32_t)0x08020400)   /* End @ of user Flash area */

//------------------���20170522���ӣ�����ͬ������д�벻ͬ�ĵ�ַ��---------------------
#define MAC_FLASH_ADDR       ((uint32_t)0x08020000)
#define TOKEN2_FLASH_ADDR    ((uint32_t)0x08020800)
//-----------------------------------------------------------------------------------


void SetMac(uint8_t* mac);
void SetVersion(uint8_t* ver);
void CheckMac(void);
char SendDataBegin(void);
void ReadFlash(void);
void WriteFlash(void);
uint8_t ReadMACFromFlash(void);
uint8_t WriteMACToFlash(void);
uint8_t ReadMACFromFlash(void);
uint8_t WriteToken2ToFlash(void);


#endif

