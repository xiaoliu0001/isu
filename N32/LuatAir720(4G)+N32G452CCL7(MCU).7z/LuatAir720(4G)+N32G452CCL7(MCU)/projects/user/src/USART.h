/******************************************************************************
 * @file     USART.h
 * @brief   ���ڳ���
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par   �ϱ� 2016   
*******************************************************************************/

#ifndef __USART_H
#define __USART_H

#include "n32g45x.h"
#include "stdio.h"


/* Private function prototypes -----------------------------------------------*/
	
#define UART1_SendLR() UART1_SendString("\r\n")
#define UART2_SendLR() UART2_SendString("\r\n")
#define UART3_SendLR() UART3_SendString("\r\n")

#define LTE_UART    USART3
#define UART3_SendDA() UART3_SendString("\x0d\0a")

#define EXTSENSOR_IN_GPIO_PORT        		GPIOA    //�ⲿ������������
#define EXTSENSOR_IN_GPIO_CLK            RCC_AHBPeriph_GPIOA
#define EXTSENSOR_IN_PIN                 GPIO_Pin_9
	
#define EXTSENSOR_ONBED_GPIO_PORT        		GPIOA    //�ⲿ�������ڴ����
#define EXTSENSOR_ONBED_GPIO_CLK            RCC_AHBPeriph_GPIOA
#define EXTSENSOR_ONBED_PIN                 GPIO_Pin_10

#define 	EXTSENSOR_ISIN            1
#define 	EXTSENSOR_ISOUT           0
#define 	EXTSENSOR_PEOPLEONBED     1
#define 	EXTSENSOR_PEOPLEOFFBED    0	
	
	
	
void UART1_USE_AS_GPIO(void);

uint8_t ComCpuRece(unsigned char ucusart,uint8_t *Str);
uint8_t ComCpuReceAtTime(unsigned char ucusart,uint8_t *Str,uint8_t length);

void NVIC_Configuration(void);
void USART1_Configuration(u32 bound);
void UART1_SendString(unsigned char* s);
void USART2_Configuration(u32 bound);
void UART2_SendString(unsigned char* s);
void USART3_Configuration(u32 bound);
void UART3_SendString(unsigned char* s);
void UART3_SendData(unsigned char* data,uint16_t len);
void UART1_SendString_YB(unsigned char* s,unsigned int count);
void UART2_SendString_YB(unsigned char* s,unsigned int count);
void UART3_SendString_YB(unsigned char* s,unsigned int count);

void CompressString(unsigned char *cpSrc,unsigned char *cpDes,unsigned int iLen);
void SplitString(unsigned char *cpSrc,unsigned char *cpDes,int iLen);
void SendDataToUSART( USART_Module* USARTx,uint8_t ch);
void SendDatasToUSART( USART_Module* USARTx,uint16_t ch);
void ClearUSART2BUF(void);
void ClearUSART3BUF(void);



#endif
