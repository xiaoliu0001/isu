/******************************************************************************
 * @file     File.h
 * @brief   �ļ���������
 * @version  
 * @date     2018
 * @note
 * Copyright (C)  2018 ���
 *
 * @par       
*******************************************************************************/
#ifndef __FILE_H__
#define __FILE_H__

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "rtc.h"
#include "ff.h"
#include "Parameter.h"
#include "diskio.h"		/* FatFs lower layer API */
#include "sdio_sdcard.h"
#include "string.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "FilterPeak.h"
#include "Fun.h"

char CreateNewTXTfile(void);
void CloseTXTfile(void);
char  SDcardFileInfo(void);
char WriteLogInfoToTXT(char *str);
char CreateNewLogfile(void);
char  ReadConfigFile(void);
char  ReadFileAndCalculate(void);
uint8_t StringToFloatDataBuf(char *str,float *buf);


#endif