/**
  ******************************************************************************
  * @file    Project/STM32F4xx_StdPeriph_Templates/stm32f4xx_it.c 
  * @author  MCD Application Team
  * @version V1.4.0
  * @date    04-August-2014
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_it.h"
#include "sys.h"
#include "rtc.h"
#include "Parameter.h"
#include "Timer.h"
#include "ff.h"
#include "usb_core.h"
#include "usbd_core.h"
#include "usb_conf.h"
#include "usb_bsp.h"
#include "usbd_msc_core.h"
#include "string.h"
#include <stdio.h>
#include "sdio_sdcard.h"
#include "diskio.h"
#include "usart.h"
#include "clkconfig.h"
#include "iwdg.h"
#include "key.h"
#include "led.h" 

extern void TimingDelay_Decrement(void);
extern void Time_Control(void);

extern USB_OTG_CORE_HANDLE  USB_OTG_dev;

/* Private function prototypes -----------------------------------------------*/
extern uint32_t USBD_OTG_ISR_Handler (USB_OTG_CORE_HANDLE *pdev);

#ifdef USB_OTG_HS_DEDICATED_EP1_ENABLED 
extern uint32_t USBD_OTG_EP1IN_ISR_Handler (USB_OTG_CORE_HANDLE *pdev);
extern uint32_t USBD_OTG_EP1OUT_ISR_Handler (USB_OTG_CORE_HANDLE *pdev);
#endif

#ifdef USE_USB_OTG_HS  
void OTG_HS_IRQHandler(void)
{
  USBD_OTG_ISR_Handler (&USB_OTG_dev);
}
#endif

#ifdef USE_USB_OTG_FS  
void OTG_FS_IRQHandler(void)
{
  USBD_OTG_ISR_Handler (&USB_OTG_dev);
}
#endif
#ifdef USB_OTG_HS_DEDICATED_EP1_ENABLED 
/**
  * @brief  This function handles EP1_IN Handler.
  * @param  None
  * @retval None
  */
void OTG_HS_EP1_IN_IRQHandler(void)
{
  USBD_OTG_EP1IN_ISR_Handler (&USB_OTG_dev);
}

/**
  * @brief  This function handles EP1_OUT Handler.
  * @param  None
  * @retval None
  */
void OTG_HS_EP1_OUT_IRQHandler(void)
{
  USBD_OTG_EP1OUT_ISR_Handler (&USB_OTG_dev);
}
#endif
/*******************************************************************************
*	�� �� ��: RTC_IRQHandler
*	����˵��: RTC�жϣ�1s
*	��    �Σ���
*	�� �� ֵ: ��
 *******************************************************************************/
void RTC_WKUP_IRQHandler(void)
{    
	if(RTC_GetFlagStatus(RTC_FLAG_WUTF)==SET)//WK_UP�ж�
	{ 
		RTC_ClearFlag(RTC_FLAG_WUTF);	//����жϱ�־ 
		Flag_TimeChange = 1;
		IWDG_Feed();   //ι��
		RTC_GetTime(RTC_Format_BIN,&RTC_TimeStruct);
		RTC_GetDate(RTC_Format_BIN, &RTC_DateStruct); 
	}   
	EXTI_ClearITPendingBit(EXTI_Line22);//����ж���22���жϱ�־ 								
}
/*******************************************************************************
*	�� �� ��: TIM2_IRQHandler
*	����˵��: ��ʱ��2 100ms��ʱ�жϣ����ڼ�ʱʱ��
*	��    �Σ���
*	�� �� ֵ: ��
 *******************************************************************************/
void TIM2_IRQHandler(void)
{
	if ( TIM_GetITStatus(TIM2 , TIM_IT_Update) != RESET ) 
	{		
		TIM_ClearITPendingBit(TIM2 , TIM_IT_Update);
		 TimerSim.Msec++;
		 if(TimerSim.Msec>=10)    //1s ��ʱ		 
		 {
			 TimerSim.Msec = 0;
			 TimerSim.Sec++;
			 
			 WiFi_Time++;
			 WiFi_InitTime++;
			 delaytime1++;
			 delaytime++;
			 
			 WIFI_ConnetTime++;
			 Time_NetworkInquire++;
			 Monitor_Offline_Time++;
			 Link_Time++;
	
		 }
		 if(TimerSim.Sec == 60)
			{
				 TimerSim.Sec = 0;
				 TimerSim.Min++;
			}
			if(TimerSim.Min == 60)
			{
				 TimerSim.Min = 0;
				 TimerSim.Hour++;
			}	
		if(TimerSim.Hour == 24)
			{
				 TimerSim.Hour = 0;
				 TimerSim.Day++;
			}	
		Time_Keep++;			
		LED_Time++;
		LED_Flash();	
	}			
}
/*******************************************************************************
*	�� �� ��: TIM3_IRQHandler
*	����˵��: ��ʱ��3 2ms��ʱ�жϣ�����ADC����
*	��    �Σ���
*	�� �� ֵ: ��
 *******************************************************************************/
void TIM3_IRQHandler(void)
{
		if ( TIM_GetITStatus(TIM3 , TIM_IT_Update) != RESET ) 
		{		
			TIM_ClearITPendingBit(TIM3 , TIM_IT_Update); 
      ADCdataSaveTime++;	
		}			
}
/*******************************************************************************
*	�� �� ��: KEY1_IRQHandler
*	����˵��: �����ж�
*	��    �Σ���
*	�� �� ֵ: ��
 *******************************************************************************/
void KEY1_IRQHandler(void)
{
  //ȷ���Ƿ������EXTI Line�ж�
	if(EXTI_GetITStatus(KEY1_INT_EXTI_LINE) != RESET) 
	{
		delay_ms(10);
		if(GPIO_ReadInputDataBit(KEY1_INT_GPIO_PORT,KEY1_INT_GPIO_PIN) == 0 )
		{
			Flag_KeyStatus = KEY_DOWN;
		}
    //����жϱ�־λ
		EXTI_ClearITPendingBit(KEY1_INT_EXTI_LINE);     
	}  
}
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
