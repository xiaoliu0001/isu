/******************************************************************************
 * @file     Fun.h
 * @brief   ���ܺ���
 * @version  
 * @date     2017
 * @note
 * Copyright (C)  2017 ���
 *
 * @par       
*******************************************************************************/
#ifndef __FUN_H_
#define __FUN_H_

#include "delay.h"
#include "usart.h"
#include "led.h"
#include "rtc.h"
#include "Parameter.h"
#include "string.h"
#include "Flash.h"
#include "EMW3080.h"
#include "MD5.h"
#include "file.h"


#define midLen 13

void RePowerOn_WIFI(void);
char LinkServerVerifyStep(uint8_t step);	
void ConnectFrontServer(void);
void FrontServerLinkStatus(void);
void GetBackServerIP(void);
void AnalysisBackServerIP(void);
void ConnectBackServer(void);
void BackServerLinkStatus(void);
void GetBackServerToken2(void);
void AnalysisBackServerToken2(void);
void SendBackServerVerify(void);
void GetBackServerVerifyResult(void);
void SendReConnectMode(uint8_t st,int lac,int cid);
char SendDataBegin(void);
void HexToStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen);
void HexToLowerStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen);
unsigned char GetDataHead(unsigned char* datas,unsigned char len);
	
void RenewRealTime(uint8_t *time);
void SendDeviceMacToUart(USART_TypeDef* USARTx);
void SendDeviceVerInfoToUart(USART_TypeDef* USARTx,char *str);
void COMRetuenOneByte(USART_TypeDef* USARTx,uint8_t cmd,uint8_t data);
void CalculateHrRrData(void);
void SystemReset_CheckStatus(void);

float countHeartScore(int x);
float avgFilter(float x);

int midFilter(int *f,int len);


#endif

