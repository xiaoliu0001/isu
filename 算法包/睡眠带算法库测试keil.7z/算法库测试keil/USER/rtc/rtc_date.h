/******************** (C) COPYRIGHT 2009 www.armjishu.com ************************
* File Name          : date.h
* Author             : www.armjishu.com Team
* Version            : V1.0
* Date               : 12/1/2009
* Description        : ������غ���
*******************************************************************************/
#ifndef __DATE_H
#define __DATE_H

#include "sys.h"
#include "Parameter.h"

    
void GregorianDay(void);
uint32_t mktimev(void);



#endif 
