/***********************************************************************************
 * @file     EC20.c
 * @brief    main�ļ�
 * @version  V1.0
 * @date     2018.02
 * @note
 * Copyright (C) 2018 ���
 *
 * @par      ��Զ4Gģ��EC20����
************************************************************************************/
 
 #ifndef __EC20_H__
 #define __EC20_H__
 
 #include "sys.h"
#include "delay.h"
#include "usart.h"
#include "string.h"
#include "Parameter.h"


#define LTE_USART   UART4

void LTE_GPIO_CONFIG(void);
	

char  LTE_InquireIMSI(void);



 void LTEUSART_SendBuf(char *tx_buf,uint16_t buflen);
 void LTEUSART_SendString(char *s);
 
 #endif
