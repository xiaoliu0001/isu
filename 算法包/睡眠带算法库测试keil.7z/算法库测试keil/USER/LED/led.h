/**************************************************************************//**
 * @file     led.c
 * @brief    LED��ʾ
 * @version  V1.0
 * @date     2017.12
 * @note
 * Copyright (C) 2017 ���
 *
 * @par    
 *   
 ******************************************************************************/


#ifndef __LED_H
#define __LED_H
#include "sys.h"
#include "Parameter.h"

//LED�˿ڶ���
#define LED1_PIN                  GPIO_Pin_11                 
#define LED1_GPIO_PORT            GPIOF                      
#define LED1_GPIO_CLK             RCC_AHB1Periph_GPIOF


#define ON  0
#define OFF 1

#define LED1(a)	if (a)	\
					GPIO_SetBits(LED1_GPIO_PORT,LED1_PIN);\
					else		\
					GPIO_ResetBits(LED1_GPIO_PORT,LED1_PIN)
					

/* �������IO�ĺ� */
#define LED1_TOGGLE		digitalToggle(LED1_GPIO_PORT,LED1_PIN)
#define LED1_OFF			digitalHi(LED1_GPIO_PORT,LED1_PIN)
#define LED1_ON				digitalLo(LED1_GPIO_PORT,LED1_PIN)					

void LED_Init(void);//��ʼ��	
void LED_Flash(void);



#endif
