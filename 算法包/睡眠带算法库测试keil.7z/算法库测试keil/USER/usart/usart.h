/**************************************************************************//**
 * @file     USART.h
 * @brief    ����ͨ��
 * @version  V1.0
 * @date     2017.12
 * @note
 * Copyright (C) 2017 ���
 *
 * @par    
 *   
 ******************************************************************************/
#ifndef __USART_H
#define __USART_H

#include "stdio.h"	
#include "stm32f4xx_conf.h"
#include "sys.h" 
#include "Parameter.h"

#define EN_USART1_RX 			1		//ʹ�ܣ�1��/��ֹ��0������1����

#define DEBUG_UART    USART2

void UART1_Init(u32 bound);
void UART2_Init(u32 bound);
void UART4_Init(u32 bound);
void USART1_IRQHandler(void);
void USART2_IRQHandler(void);
void UART4_IRQHandler(void);
void ClearUSARTBUF(USART_TypeDef* USARTx);
void SendDataToUSART( USART_TypeDef* USARTx,uint8_t ch);
void SendDatasToUSART( USART_TypeDef* USARTx,uint16_t ch);
void UART1_SendString(unsigned char* s);
void UART2_SendString(unsigned char* s);

#endif


