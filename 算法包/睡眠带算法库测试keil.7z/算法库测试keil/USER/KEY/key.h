/**************************************************************************//**
 * @file     KEY.H
 * @brief    ����
 * @version  V1.0
 * @date     2018.01
 * @note
 * Copyright (C) 2018 ���
 *
 * @par    
 *   
 ******************************************************************************/
#ifndef __KEY_H
#define __KEY_H

#include "sys.h" 
#include "delay.h"  

/********************���Ŷ���***********************************/
#define KEY1_INT_GPIO_PORT                GPIOA
#define KEY1_INT_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define KEY1_INT_GPIO_PIN                 GPIO_Pin_5
#define KEY1_INT_EXTI_PORTSOURCE          EXTI_PortSourceGPIOA
#define KEY1_INT_EXTI_PINSOURCE           EXTI_PinSource5
#define KEY1_INT_EXTI_LINE                EXTI_Line5
#define KEY1_INT_EXTI_IRQ                 EXTI9_5_IRQn

#define KEY1_IRQHandler                   EXTI9_5_IRQHandler

#define KEY_DOWN     1
#define KEY_UP       0


extern uint8_t Flag_KeyStatus;


void Key_GPIO_Config(void);
static void NVIC_Key_Configuration(void);


#endif
