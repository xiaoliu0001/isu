/******************************************************************************
 * @file     MAIN.h
 * @brief    main�ļ�ȫ�ֱ���
 * @version  V1.0
 * @date     2017.12
 * @note
 * Copyright (C) 2017 ���
 *
 * @par     
 *   
 ******************************************************************************/
#ifndef __MAIN_H__
#define __MAIN_H__

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "rtc.h"
#include "ff.h"
#include "Parameter.h"
#include "ADC.h"
#include "Timer.h"
#include "diskio.h"		
#include "sdio_sdcard.h"
#include "usbd_msc_core.h"
#include "usbd_usr.h"
#include "usbd_desc.h"
#include "usb_conf.h"
#include "clkconfig.h"
#include "string.h"
#include "iwdg.h"
#include "Flash.h"
#include "Fun.h"
#include "key.h"
#include "file.h"
#include "EMW3080.h"


void Parameter_Init(void);
void System_Init(void);
void COM1ProcessCmd(void);


#endif
