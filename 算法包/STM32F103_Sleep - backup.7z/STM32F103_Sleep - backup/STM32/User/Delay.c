/**
  ******************************************************************************
  * @file   : Delay.c
  * @author : fengzi
  * @version:
  * @date   : 2015,03,26
  * @brief  : ϵͳƵ��Ϊ 72Mʱʹ��
  ******************************************************************************
  */
/* ---------------------------------------------------------------------------*/

#include "Delay.h"

static u8  fac_us=0;
static u16 fac_ms=0;

void delay_init(void)
{
	
	SysTick->CTRL&=0xfffffffb;
	fac_us=9;		    
	fac_ms=(u16)fac_us*1000;

}

void delay_us(uint32_t nus)
{
	u32 temp;	    	 
	SysTick->LOAD=nus*fac_us; //ʱ�����	  		 
	SysTick->VAL=0x00;        //��ռ�����
	SysTick->CTRL=0x01;      //��ʼ���� 	 
	do
	{
		temp=SysTick->CTRL;
	}
	while(temp&0x01&&!(temp&(1<<16)));//�ȴ�ʱ�䵽��   
	SysTick->CTRL=0x00;       //�رռ�����
	SysTick->VAL =0X00;       //��ռ�����	 
}
	
void delay_ms(uint16_t nms)
{
	u32 temp;		   
	SysTick->LOAD=(u32)nms*fac_ms;
	SysTick->VAL =0x00;          
	SysTick->CTRL=0x01 ;         
	do
	{
		temp=SysTick->CTRL;
	}
	while(temp&0x01&&!(temp&(1<<16)));
	SysTick->CTRL=0x00;      
	SysTick->VAL =0X00;       

}
	

