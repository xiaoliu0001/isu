#include "ADC.h"
#include "main.h"

void ADC_Comfig(void)
{
	ADC_InitTypeDef       ADC_InitStructure;
	ADC_CommonInitTypeDef ADC_CommonInitStructure;
	GPIO_InitTypeDef    GPIO_InitStructure;
	__IO uint32_t calibration_value = 0;

	
 	RCC_ADCCLKConfig(RCC_ADC12PLLCLK_Div2);				/* Configure the ADC clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_ADC12, ENABLE);	/* Enable ADC1 clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE); /* GPIOC Periph clock enable */

	/* Configure ADC Channel4 as analog input */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;  
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
  
	ADC_StructInit(&ADC_InitStructure);
	ADC_VoltageRegulatorCmd(ADC2, ENABLE);		/* Calibration procedure */ 
  
	Delay(500);/* Insert delay equal to 10 �s */
  
	ADC_SelectCalibrationMode(ADC2, ADC_CalibrationMode_Single);
	ADC_StartCalibration(ADC2);
  
	while(ADC_GetCalibrationStatus(ADC2) != RESET );
	calibration_value = ADC_GetCalibrationValue(ADC2);
     
	ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;                                                                    
	ADC_CommonInitStructure.ADC_Clock = ADC_Clock_AsynClkMode;                    
	ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;             
	ADC_CommonInitStructure.ADC_DMAMode = ADC_DMAMode_OneShot;                  
 	ADC_CommonInitStructure.ADC_TwoSamplingDelay = 0;          
	ADC_CommonInit(ADC2, &ADC_CommonInitStructure);
  
	ADC_InitStructure.ADC_ContinuousConvMode = ADC_ContinuousConvMode_Enable;
	ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b; 
	ADC_InitStructure.ADC_ExternalTrigConvEvent = ADC_ExternalTrigConvEvent_0;         
	ADC_InitStructure.ADC_ExternalTrigEventEdge = ADC_ExternalTrigEventEdge_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_OverrunMode = ADC_OverrunMode_Disable;   
	ADC_InitStructure.ADC_AutoInjMode = ADC_AutoInjec_Disable;  
	ADC_InitStructure.ADC_NbrOfRegChannel = 1;
	ADC_Init(ADC2, &ADC_InitStructure);
  
	ADC_RegularChannelConfig(ADC2, ADC_Channel_1, 1, ADC_SampleTime_601Cycles5);/* ADC1 regular channel7 configuration */ 
	ADC_Cmd(ADC2, ENABLE);							 	/* Enable ADC1 */
  
	while(!ADC_GetFlagStatus(ADC2, ADC_FLAG_RDY));		/* wait for ADRDY */
	ADC_StartConversion(ADC2);   						/* Start ADC1 Software Conversion */ 
}

void Delay(unsigned int us)
{
	while(us--){
		if(us<0){
			break;
		}
	}
}


