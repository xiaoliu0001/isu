/**
  ******************************************************************************
  * @file   : Delay.h
  * @author : fengzi
  * @version:
  * @date   : 2015,03,26
  * @brief  :
  ******************************************************************************
  */
/* ---------------------------------------------------------------------------*/

#ifndef __DELAY_H
#define __DELAY_H

#include "stm32f30x.h"

void delay_init(void);
void delay_ms(uint16_t nms);
void delay_us(uint32_t nus);


#endif /*__DELAY_H*/
