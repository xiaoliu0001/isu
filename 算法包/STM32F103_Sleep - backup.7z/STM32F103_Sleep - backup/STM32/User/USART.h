/**
  ******************************************************************************
  * @file   : USARTtest.h
  * @author : wind
  * @version: 
  * @date   : 2015,03,29
  * @brief  :
  ******************************************************************************
  */
/* ---------------------------------------------------------------------------*/

#ifndef __USART_H
#define __USART_H

#include "stm32f30x.h"
#include "stm32f30x_rcc.h"
#include "stm32f30x_usart.h"
#include "stm32f30x_misc.h"
#include "stdio.h"


void USART_test(void);
void USART_GPIO_Config(void);
void USART_Config(void);
void USART_NVIC_Config(void);
void USART2_IRQHandler (void);
void USART1_SendByte(unsigned char temp);
void USART1_Printf(u8 *pch);


void USART_Configuration(void);//���ڳ�ʼ������
void UART_send_byte(uint8_t byte);
void UART_Send(uint8_t *Buffer, uint32_t Length);
void NVIC_Configuration(void);








//int fputc(int ch,FILE *f);

#endif
