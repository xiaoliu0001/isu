#ifndef __ADC_H_
#define __ADC_H_

void ADC_Configuration(void);
void ADC1_DMA_Config(void);
void ADC_Comfig(void);
void Delay(unsigned int us);

#endif