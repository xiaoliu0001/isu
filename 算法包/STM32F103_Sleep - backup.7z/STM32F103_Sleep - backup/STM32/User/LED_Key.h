/**
  ******************************************************************************
  * @file    LED_Key.h
  * @author  fengzi
  * @version 
  * @date    2015,05,23
  * @brief   
  ******************************************************************************
  */

/*------------------------------------------------------------------*/

#ifndef __LED_KEY_H
#define __LED_KEY_H

#include "stm32f30x_rcc.h"
#include "stm32f30x_gpio.h"
#include "delay.h"
#include "USART.h"
#include "stm32f30x_misc.h"

#define LED_GPIO_PORT        		GPIOB
#define LED_GPIO_CLK                    RCC_AHBPeriph_GPIOB
#define LED2_PIN                         GPIO_Pin_15
#define LED3_PIN                         GPIO_Pin_14
#define LED4_PIN                         GPIO_Pin_13
#define LED5_PIN                         GPIO_Pin_12




#define KEY_GPIO_CLK                   RCC_AHBPeriph_GPIOC
#define KEY_GPIO_PORT 			GPIOC
#define KEY_GPIO_PIN			GPIO_Pin_13


void LED_Init(void);

void key_interruptmode(void);
void EXTI15_10_IRQHandler(void);


#endif/*__LED_H*/


