#include "BER_PROGRAM.h"
#include <math.h>
#include <stdio.h>
#include "string.h"   

/***********
ADC�ź�Ԥ����
**************/


#ifndef abs
#define abs(tt) ((tt<0)?(-tt):(tt)) 
#endif

#define  ECG_COMPARE_TIMES  3
#define  STANDARD_VOLTAGE  1500
#define  ADC_MAXDATA1     1510     //��ֵ�Ŵ�����1
#define  ADC_MAXDATA4     2000       //��ֵ�Ŵ�����4
#define  ADC_MINDATA1     1490     //��ֵ��С����1
#define  ADC_AMPSTADATA   2400
#define  ADC_CHGMAXDATA   2400
#define  ADC_CHGMINDATA   2000
float   LastADC_AmpMultiple = 1;    //��һ�ηŴ���
float   ADC_AmpMultiple = 1;    //�Ŵ���
U16  ADC_AdjTime = 0;
char  Flag_ADC_ADJ = 0;              			 //��������

U16  CHGADC_COUNT=0;
U8 Flag_SendAMPCHGToServer = 0;  //���ͷŴ�����������
U16  ECG_MAX[ECG_COMPARE_TIMES];                //ADC������ֵ����
U16  SEND_ECG_MAX[ECG_COMPARE_TIMES];           //ADC������ֵ����
U16  ECG_MIN[ECG_COMPARE_TIMES];
U16  CHGECG_MAX[ECG_COMPARE_TIMES];             //ADC����������
U16  CHGECG_MIN[ECG_COMPARE_TIMES];  
U8   ECG_COMPARE_COUNT = 0;
U8   CHGECG_COMPARE_COUNT = 0;
U16 ADC_COUNT = 0;


/****************************************************************************
*	������: DealADCSampleData
*	������˵��: ����ADC����ֵ
*	�Ͳ�:
*	����ֵ: 
* ˵��:
*****************************************************************************/	
void  DealADCSampleData(void)
{
	 U32 Dvalue0 = 0;
	 U32 Dvalue1 = 0;
	 U16 maxaerage = 0;
	 U16 minaerage = 0;
	 U16 i = 0 ;
	 U8 ampchange = 0;

//----------------------------�ж�״̬------------------------------------------------------------			   				 
	 if(SampleData > ECG_MAX[ECG_COMPARE_COUNT])
	 {
			ECG_MAX[ECG_COMPARE_COUNT] = SampleData;
	 }
	 if(SampleData< ECG_MIN[ECG_COMPARE_COUNT])
	 {
			ECG_MIN[ECG_COMPARE_COUNT] = SampleData;
	 }
	 ADC_COUNT++;
	 if(ADC_COUNT >= 500)
	 {
			ECG_COMPARE_COUNT++;
			ADC_COUNT = 0;
	 }
	 if(ECG_COMPARE_COUNT >= ECG_COMPARE_TIMES)
	 {
		 for(i=0;i<ECG_COMPARE_TIMES;i++)
		 {
			 Dvalue0 += ECG_MAX[i];
			 Dvalue1 += ECG_MIN[i];
			 SEND_ECG_MAX[i]=ECG_MAX[i];
		 }				
		 maxaerage =  (U16)(Dvalue0/ECG_COMPARE_TIMES);
		 minaerage =  (U16)(Dvalue1/ECG_COMPARE_TIMES);
		 
		if((ECG_MAX[0] < ADC_MAXDATA1)&&(ECG_MAX[1] < ADC_MAXDATA1)&&(ECG_MAX[2] < ADC_MAXDATA1)&&(ADC_AmpMultiple != 1))
		{
			 Flag_ADC_ADJ = 0;
			 ADC_AmpMultiple = 1;
			 Flag_SendAMPCHGToServer = 1;
		}	
		if(((maxaerage-minaerage)<50)&&(ADC_AmpMultiple != 1))
		{
			 Flag_ADC_ADJ = 0;
			 ADC_AmpMultiple = 1;
			 Flag_SendAMPCHGToServer = 1;
		}
		if((ECG_MAX[0] > ADC_MAXDATA4)&&(ECG_MAX[1] > ADC_MAXDATA4)&&(ECG_MAX[2] > ADC_MAXDATA4)&&(ADC_AmpMultiple != 1))
		{
			 Flag_ADC_ADJ = 0;
			 ADC_AmpMultiple = 1;
			 Flag_SendAMPCHGToServer = 1;			
		}		
		if((abs(ECG_MAX[1]-ECG_MAX[0])< 100)&&(abs(ECG_MAX[2]-ECG_MAX[1])< 100)&&((maxaerage-minaerage)>50))  //????
		{
			 if((maxaerage < ADC_MAXDATA4)&&(ECG_MAX[0]> ADC_MAXDATA1)&&(ECG_MAX[1]> ADC_MAXDATA1)&&(ECG_MAX[2]> ADC_MAXDATA1)&&(minaerage<ADC_MINDATA1)&&(Flag_ADC_ADJ == 0))
			 {			
					Flag_ADC_ADJ = 1;
				    ampchange = 1;			 
			 }
//-------------------�Ŵ�������---------------------------------------------------------------------
			if(ampchange == 1)
			{
					ampchange = 0;
					if(Flag_ADC_ADJ != 0)
					{
						ADC_AmpMultiple =(float)(ADC_AMPSTADATA-STANDARD_VOLTAGE)/(maxaerage-STANDARD_VOLTAGE);					
						if(ADC_AmpMultiple > 10)	
							ADC_AmpMultiple = 10;	

						 if(LastADC_AmpMultiple != ADC_AmpMultiple)
						 {
							LastADC_AmpMultiple = ADC_AmpMultiple;
							ADC_AdjTime = 0;
						 }
						 Flag_SendAMPCHGToServer = 1;
					}				 
			}		 
		 }					
		for(i=0;i<ECG_COMPARE_TIMES-1;i++)
		{
			ECG_MAX[i] = ECG_MAX[i+1];
			ECG_MIN[i] = ECG_MIN[i+1];
		}			
		ECG_COMPARE_COUNT = 2;
		ECG_MAX[ECG_COMPARE_COUNT] = STANDARD_VOLTAGE;
		ECG_MIN[ECG_COMPARE_COUNT] = ECG_MAX[1];
	}  			
}

/****************************************************************************
*	������: DealSmallADCSampleData
*	����˵��: ����С�ź�ADC����ֵ
*	�βΣ��ź�״̬��״̬��ͬ���������Ȳ�ͬ
*	����ֵ: 
* ˵��:
*****************************************************************************/	
void  DealSmallADCSampleData(float status)
{
	 float absdata = 0;

	 if(SampleData > STANDARD_VOLTAGE)
	 {
		 absdata = SampleData -STANDARD_VOLTAGE;
		 absdata *= status;
		 SampleData = (U16)(STANDARD_VOLTAGE+ absdata);
		 if(SampleData>3299)
		 {
			  SampleData = 3299;
		 }
	 }
	 else
	 {
		 absdata = STANDARD_VOLTAGE - SampleData;
		 absdata *= status;
		 SampleData = (U16)(STANDARD_VOLTAGE - absdata);
		 if(SampleData<1)
		 {
			  SampleData = 1;
		 }
	 }	 							
}



/****************************************************************************
*	������: CheckAmpADCData
* ����˵�������Ŵ���ADC����
*	�β�:
*	����ֵ: 
* ˵��:
*****************************************************************************/
void CheckAmpADCData(void)
{
	 U32 Dvalue0 = 0;
	 U32 Dvalue1 = 0;
	 U16 maxaerage = 0;
	 U16 i = 0 ;

//----------------------------????------------------------------------------------------------			   				 
	 if(SampleData > CHGECG_MAX[CHGECG_COMPARE_COUNT])
	 {
		CHGECG_MAX[CHGECG_COMPARE_COUNT] = SampleData;
	 }
	 if(SampleData< ECG_MIN[CHGECG_COMPARE_COUNT])
	 {
		CHGECG_MIN[CHGECG_COMPARE_COUNT] = SampleData;
	 }	 
	 CHGADC_COUNT++;

	 if(CHGADC_COUNT >= 500)
	 {
		CHGECG_COMPARE_COUNT++;
		CHGADC_COUNT = 0;
	 }
	 if(CHGECG_COMPARE_COUNT >= ECG_COMPARE_TIMES)
	 {
		 for(i=0;i<ECG_COMPARE_TIMES;i++)
		 {
			 Dvalue0 += CHGECG_MAX[i];
			 Dvalue1 += CHGECG_MIN[i];
		 }
		 maxaerage =  (U16)(Dvalue0/ECG_COMPARE_TIMES);
		 		 
		if((CHGECG_MAX[0]>ADC_CHGMAXDATA)&&(CHGECG_MAX[1]>ADC_CHGMAXDATA)&&(CHGECG_MAX[2]>ADC_CHGMAXDATA))  //�Ŵ�����ݳ�������
		 {
			  if((Flag_ADC_ADJ != 0)&&(ADC_AdjTime > 60))  //���1���Ӳſ��Ե���
				{
					 Flag_ADC_ADJ = 0;
				}
		 }
		if((CHGECG_MAX[0]<ADC_CHGMINDATA)&&(CHGECG_MAX[1]<ADC_CHGMINDATA)&&(CHGECG_MAX[2]<ADC_CHGMINDATA)&&(maxaerage > 1600))  //�Ŵ�����ݳ�������
		 {
			  if((Flag_ADC_ADJ != 0)&&(ADC_AdjTime > 60))  //���1���Ӳſ��Ե���
				{
					 Flag_ADC_ADJ = 0;
				}
		 }		 
			for(i=0;i<ECG_COMPARE_TIMES-1;i++)
			{
				CHGECG_MAX[i] = CHGECG_MAX[i+1];
				CHGECG_MIN[i] = CHGECG_MIN[i+1];
			}			
			CHGECG_COMPARE_COUNT = 2;
			CHGECG_MAX[CHGECG_COMPARE_COUNT] = STANDARD_VOLTAGE;
			CHGECG_MIN[CHGECG_COMPARE_COUNT] = CHGECG_MAX[1];
		}
}

void algorithmsInit(U16 sd){
		SampleData = sd;
		if(SampleData > 3299){
			SampleData = 3299;
		}
		if(SampleData < 1){
			SampleData = 1;
		}
		
		if(gPeopleFlag == 1){
			DealADCSampleData();
			if(gTurnFlag != 1 && ADC_AmpMultiple != 1){
				DealSmallADCSampleData(ADC_AmpMultiple);
			}
			CheckAmpADCData();
		}
}
/*-----------------------------------------------*/
