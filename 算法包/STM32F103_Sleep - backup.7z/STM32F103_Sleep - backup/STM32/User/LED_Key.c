/**
  ******************************************************************************
  * @file    LED_Key.c
  * @author  fengzi
  * @version 
  * @date    2015,05,23
  * @brief   
  ******************************************************************************
  */

/*------------------------------------------------------------------*/

#include "LED_Key.h"
#include "main.h"

__IO uint8_t flag=0x0;

delay_ms_YB(void)
{
	unsigned int ms=10000;
	int i;
	while(ms--)                                //ÿһ��ѭ��1ms
	{
		for(i = 0; i < 120; i++);
	}
}
void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;

	RCC_AHBPeriphClockCmd(LED_GPIO_CLK, ENABLE);

	GPIO_InitStruct.GPIO_Pin =LED2_PIN;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;

	GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin =LED3_PIN;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;

	GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin =LED4_PIN;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;

	GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.GPIO_Pin =LED5_PIN;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;

	GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);

}


/***********************��ʱ���е�����**********************
void key_interruptmode(void)
{
	EXTI_InitTypeDef 		EXTI_InitStructure;
	NVIC_InitTypeDef 		NVIC_InitStruct;
	GPIO_InitTypeDef    	GPIO_InitStructure;

	RCC_AHBPeriphClockCmd(KEY_GPIO_CLK,ENABLE);

	GPIO_InitStructure.GPIO_Pin = KEY_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	

	GPIO_Init(KEY_GPIO_PORT,&GPIO_InitStructure);



	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitStruct.NVIC_IRQChannel =EXTI15_10_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	
	NVIC_Init(&NVIC_InitStruct);
	
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOC, EXTI_PinSource13);
	EXTI_ClearITPendingBit(EXTI_Line13);
	
	EXTI_InitStructure.EXTI_Line=EXTI_Line13;
	EXTI_InitStructure.EXTI_LineCmd =ENABLE;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=EXTI_Trigger_Rising;

	EXTI_Init(&EXTI_InitStructure);

}


void EXTI15_10_IRQHandler(void)
{

	if(EXTI_GetITStatus(EXTI_Line13))
		{
			flag =~flag;
			if(flag)				//��������
				{
					GPIO_SetBits(GPIOE, 0xff00);
					printf("��������...\n");
				}
			else					//�����ɿ�
				{
					GPIO_ResetBits(GPIOE, 0xff00);
					printf("�����ɿ�...\n");
				}
		}
	
	EXTI_ClearITPendingBit(EXTI_Line13);
}

***********************��ʱ���е�����**********************/








