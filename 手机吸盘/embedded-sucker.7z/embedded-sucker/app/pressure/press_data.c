/**
*********************************************************************************************************
* @file   : press_data.c
* @author : liumingcai
* @date   : 02 Dec 2024
* @brief  :	��̬�ж�ѹǿֵ�����е������
*
*********************************************************************************************************
*/

/**
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/
#include "press_data.h"
#include "wfsensor.h"
#include "uart.h"

/**
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/
static u8 task_step = STEP_ONE;    // ������
static u8 motor_en_time = 0;       // �������ʱ��
static u8 motor_interval_time = 0; // �����Ъʱ��
static s32 back_press_data = 0;    // ������һ�ε�ѹǿֵ

/**
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/
static s32 abs_value(s32 num);
static void press_motor_ctl(void);

/**
*********************************************************************************************************
* @brief ����ȡ����ֵ
* @param :
* @return��
*********************************************************************************************************
*/
static s32 abs_value(s32 num)
{
    return num >= 0 ? num : -num;
}

/**
*********************************************************************************************************
* @brief ������ѹ�����Ƶ��
* @param :
* @return��
*********************************************************************************************************
*/
static void press_motor_ctl(void)
{
    u8 data[5] = {0};
    s32 press_data = 0; // ѹǿֵ

    press_data = sensor_get_press();

    switch (task_step)
    {
    case STEP_ONE:
        MOTOR_EN = 0;
        // �����ѹ��
        if ((back_press_data != 0) && (abs_value(press_data - back_press_data) > PRESS_DIFF))
        {
            task_step = STEP_TWO;
        }
        break;
    case STEP_TWO:
        MOTOR_EN = 1;
        motor_en_time++;
        // ��ѹ�����趨ֵ
        if (press_data < PRESS_MIN)
        {
            task_step = STEP_THREE;
        }
        // �жϵ������5s״̬
        if (motor_en_time > 25)
        {
            // 0~���ѹ
            if ((press_data < 0) && (press_data > PRESS_MIN))
            {
                task_step = STEP_FIVE;
            }
            motor_en_time = 0;
        }
        break;
    case STEP_THREE:
        MOTOR_EN = 0;
        task_step = STEP_FOUR;
        break;
    case STEP_FOUR:
        // ����ѹ���ڷ�ֵ
        if (press_data > PRESS_RELEASE)
        {
            task_step = STEP_TWO;
        }
        else
        {
            // ��������ڷ�ֵ����ѹǿ����
            if (abs_value(press_data - back_press_data) > PRESS_DIFF)
            {
                task_step = STEP_TWO;
            }
        }
        break;
    case STEP_FIVE:
        // ����ȴ�5s
        MOTOR_EN = 0;
        motor_interval_time++;
        if (motor_interval_time > 25)
        {
            motor_interval_time = 0;
            task_step = STEP_FOUR;
        }
        break;
    }
    // 0~0X4F
    if ((press_data > 0) && (press_data < PRESS_INITIAL))
    {
        task_step = STEP_ONE;
    }
    // ����ѹǿ
    back_press_data = press_data;
    // ��ӡ
    if (press_data < 0)
    {
        press_data = -press_data;
        press_data |= 0x80000000;
    }

    data[0] = (press_data & 0xFF);
    data[1] = (press_data >> 8) & 0xFF;
    data[2] = (press_data >> 16) & 0xFF;
    data[3] = (press_data >> 24) & 0xFF;
    data[4] = task_step;
    uart_send_data(&data, 5);
}

/**
*********************************************************************************************************
* @brief ��ѹǿ������ѯ 200ms
* @param :
* @return��
*********************************************************************************************************
*/
void press_task(void)
{
    sensor_proc();
    press_motor_ctl();
}