/**
*********************************************************************************************************
* @file   : wfsensor.h
* @author : liumingcai
* @date   : 02 Dec 2024
* @brief  :	
*
*********************************************************************************************************
*/

#ifndef _WFSensor_H_
#define _WFSensor_H_

/**
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/
#include "math_i2c.h"

/**
*********************************************************************************************************
*                                               DEFINES
*********************************************************************************************************
*/
#define SENSOR_POWER PD5
#define SENSOR_CS PC7

#define CMD_CONVERT 0X0A

/**
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/
void WFSensor_WriteByte(u8 addr, u8 Data);
u8 WFSensor_ReadByte(u8 addr);

void WFSensor_indicateGroupConvert(void);
void WFSensor_getTPData(void);
void WFSensor_indicateOneByOneConvert(void);
void calculatePress(void);

void get_decData(void);

void sensor_init(void);
void sensor_proc(void);
s32 sensor_get_press(void);
s32 sensor_get_temp(void);

#endif  /* _WFSensor_H_ */
