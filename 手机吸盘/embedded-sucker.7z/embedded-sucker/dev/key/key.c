/**
*********************************************************************************************************
* @file   : key.c
* @author : liumingcai
* @date   : 02 Dec 2024
* @brief  :	ʵ�ְ�������
*
*********************************************************************************************************
*/

/**
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/
#include "key.h"
/**
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/

static u16 key_press_time = 0;  // ��������ʱ��
static u8 key_release_time = 0; // �����ͷ�ʱ��

static u8 key_short_flag = FALSE;
static u8 key_long_flag = FALSE; // ����������־����������һ��

/**
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

/**
*********************************************************************************************************
* @brief ����ֵ��ȡ��ѯ 10ms
* @param :
* @return��
*********************************************************************************************************
*/
u8 get_key_value(void)
{
    u8 key_io = KEY_RELEASE;

    key_io = KEY_IO;
    if (key_io == KEY_PRESS)
    {
        if (key_press_time > KEY_PRESS_TIME)
        {
            key_short_flag = TRUE;
            if (key_press_time > KEY_LONG_TIME)
            {
                key_short_flag = FALSE;

                if (key_long_flag)
                {
                    return KEY_TYPE_NONE;
                }
                key_long_flag = TRUE;
                return KEY_TYPE_LONG;
            }
        }
        key_press_time++;
        key_release_time = 0;
    }
    else
    {
        if (key_short_flag)
        {
            if (key_release_time > KEY_RELEASE_TIME)
            {
                key_short_flag = FALSE;
                return KEY_TYPE_SHORT;
            }
            key_release_time++;
        }
        key_long_flag = FALSE;
        key_press_time = 0;
    }

    return KEY_TYPE_NONE;
}