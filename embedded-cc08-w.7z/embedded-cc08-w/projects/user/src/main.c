/****************************************************************************
 * @file     mian.c
 * @brief    ������
 * @version  V2.0.0
 * @date     2023.5.17
 * @note
 * Copyright (C) 2023 
 *
 * @par    WIFI ��˯�ߴ�
 *         ����оƬ�汾
 *   V2.0  ʹ���ƶ�andlink Э������
*****************************************************************************/

#include "main.h"
#include <stdio.h>
#include <BERpara.h>
#include "Parameter.h"
#include "USART.h"
#include "ADC.h"
#include "Delay.h"
#include "LED.h"
#include "Fun.h"
#include "string.h"

#include "MobileAndlink.h"

/** @addtogroup TIM_TimeBase
 * @{
 */

TIM_TimeBaseInitType TIM_TimeBaseStructure;
OCInitType TIM_OCInitStructure;
ErrorStatus HSEStartUpStatus;

__IO uint16_t CCR1_Val  = 40961;
__IO uint16_t CCR2_Val  = 27309;
__IO uint16_t CCR3_Val  = 13654;
__IO uint16_t CCR4_Val  = 6826;
__IO uint16_t MY_CCR_Val  = 40270;
uint16_t PrescalerValue = 0;

USART_InitType USART_InitStructure;

ADC_InitType ADC_InitStructure;
DMA_InitType DMA_InitStructure;


USART_InitType USART_InitStructure;


enum
{
    SYSCLK_PLLSRC_HSI,
    SYSCLK_PLLSRC_HSE,
};
#define MCUID_ADDRESS          0x1FFFF7E8
#define MCUFLASHSIZE_ADDRESS   0x1FFFF7E0


void Server_Order_Dispose(uint8_t *dat);
void COMProcessCmd(void);
//void  WIFIUART_Receive_Order_Analys(void);

void LedInit(GPIO_Module* GPIOx, uint16_t Pin);
void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);
void Timer_Configuration(void);
void USART_Configuration(void);
void DMA_ADC1_Configuration(void);
void DMA_ADC2_Configuration(void);
void SetSysClockToPLL(uint32_t freq, uint8_t src);
void InitParam(void);

 char  *SoftVer = "Hardware:V5.0-20190523\r\nSoftware:V4.6.8<20190927>\r\n";  
 unsigned char sDebugMode = 0;
uint8_t  ucConectFlag=0;
 u32 CpuID[3]={0}; 

void Get_CPU_ID(void)
   
{
//read CPU ID,stm32lxx,add+4
CpuID[0] = *(__IO u32 *)(0X1FFFF7AC);
CpuID[1] = *(__IO u32 *)(0X1FFFF7B0);
CpuID[2] = *(__IO u32 *)(0X1FFFF7B4);	
}


/**
 * @brief  Turns selected Led on.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedOn(GPIO_Module* GPIOx, uint16_t Pin)
{
        GPIOx->PBC = Pin;
}
/**
 * @brief  Turns selected Led Off.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedOff(GPIO_Module* GPIOx, uint16_t Pin)
{
	GPIOx->PBSC = Pin;
}
/**
 * @brief  Turns selected Led on or off.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be one of the following values:
 * 	@arg GPIO_PIN_0~GPIO_PIN_15: set related pin on
 *   	@arg (GPIO_PIN_0<<16)~(GPIO_PIN_15<<16): clear related pin off
 */
void LedOnOff(GPIO_Module* GPIOx, uint32_t Pin)
{
    GPIOx->PBSC = Pin;
}
/**
 * @brief  Toggles the selected Led.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedBlink(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIOx->POD ^= Pin;
}

/****************************************************************************
*	�� �� ��: COMProcessCmd
*	����˵��: ���ڲ������ô���
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void COMProcessCmd(void)
{
	uint8_t  i ,j;
	uint8_t order_data_len = 0;
    uint8_t order_data[UARTBUF_MAX_LEN];
	uint8_t dealorder = 0;
	uint8_t Res = 0;
    uint8_t send_data[10];
	uint16_t flashsize = 0;
    uint32_t mcuid[3];
	uint8_t len;
	char SoftVer[100];
	
	char  *p1,*p2;
	char  uart_data[1024] = {0};
	char *rev = NULL;
	cJSON *uartJson,*getVValue;
#if 0		
	for(i=0;i<UART1_RX_LEN;i++)
	{
		printf("%02x ",UART1_RX_BUFFER[i]);
	}
#endif 
	if((UART1_RX_BUFFER[0] == '{')&&(Flag_InitStatus == SYSTEM_INIT))
	{
		printf("\r\ninto serial mode!\r\n");
		Flag_InitStatus = MAC_INIT;		
		memset(UART1_RX_BUFFER,0,UARTBUF_MAX_LEN);
		UART1_RX_LEN = 0;
	}
//	if(strstr(UART1_RX_BUFFER,"serial") != NULL)
//	{
//		printf("\r\ninto serial mode!\r\n");
//		Flag_InitStatus = MAC_INIT;
//	}
	if((UART1_RX_LEN > 0)&&(Flag_InitStatus == MAC_INIT))
	{
		p1 = strchr(UART1_RX_BUFFER, '{');
        p2 = strrchr(UART1_RX_BUFFER, '}');
        
        if( (p1 != NULL)&&(p2 != NULL) )
        {
            memset(uart_data,0,1024);
            memcpy (uart_data,p1,p2-p1+1);
//            if(Flag_COMDebug == 1)
//                printf("uart receive data:%s \r\n",uart_data);
			//�����дģʽ
//			if(strstr(uart_data,"serial") != NULL)
//			{
//				printf("\r\ninto serial mode!\r\n");
//				Flag_InitStatus = MAC_INIT;
//			}
			//��ȡ
			if(strstr(uart_data,"read:andlink") != NULL)  //��ȡAndlinkЭ���豸������Ϣ
			{
				printf("\r\nandlink data:\r\n");
				printf("Andlink_GW_Info.flag:%d\r\n",Andlink_GW_Info.flag);
				printf("Andlink_GW_Info.andlinkToken:%s\r\n",Andlink_GW_Info.andlinkToken);
				printf("Andlink_GW_Info.deviceID:%s\r\n",Andlink_GW_Info.deviceID);
				printf("Andlink_GW_Info.deviceToken:%s\r\n",Andlink_GW_Info.deviceToken);
				printf("Andlink_GW_Info.dmToken:%s\r\n",Andlink_GW_Info.dmToken);
				printf("Andlink_GW_Info.gwToken:%s\r\n",Andlink_GW_Info.gwToken);
				printf("Andlink_GW_Info.userId:%d\r\n",Andlink_GW_Info.userId);
			}
			if(strstr(uart_data,"read:ssid") != NULL)  //��ȡ�����wifi��������Ϣ
			{
				printf("\r\nssid data:\r\n");
				printf("ssid :%s\r\n",Router_Info.SSID);
				printf("password :%s\r\n",Router_Info.password);
				printf("user_key :%s\r\n",Router_Info.user_key);
				printf("gwAddress2 :%s\r\n",Router_Info.gwAddress2);
				printf("gwAddress :%s\r\n",Router_Info.gwAddress);
				printf("flag :%d\r\n",Router_Info.flag);
			}
			//д��
			if(strstr(uart_data,"write") != NULL)
			{
				uartJson = cJSON_Parse(uart_data);  //�����ַ���
				if(strstr(uart_data,"ssid") != NULL)
				{
					getVValue = cJSON_GetObjectItem(uartJson, "name");	
					strcpy(Router_Info.SSID ,getVValue->valuestring);
					printf("name:%s \r\n",Router_Info.SSID);
					getVValue = cJSON_GetObjectItem(uartJson, "password");	
					strcpy(Router_Info.password ,getVValue->valuestring);
					printf("password:%s \r\n",Router_Info.password);
					getVValue = cJSON_GetObjectItem(uartJson, "user_key");	
					strcpy(Router_Info.user_key ,getVValue->valuestring);
					printf("user_key:%s \r\n",Router_Info.user_key);
					getVValue = cJSON_GetObjectItem(uartJson, "gwAddress2");	
					strcpy(Router_Info.gwAddress2 ,getVValue->valuestring);
					printf("gwAddress2:%s \r\n",Router_Info.gwAddress2);
					getVValue = cJSON_GetObjectItem(uartJson, "gwAddress");	
					strcpy(Router_Info.gwAddress ,getVValue->valuestring);
					printf("gwAddress:%s \r\n",Router_Info.gwAddress);
					Router_Info.flag =  Flag_FirstRun; 
					SaveRouterNameToFlash();  //����
					printf("����������Ϣ��flash\r\n");
				}
				if(strstr(uart_data,"andlink") != NULL)
				{
					printf("rev uart_data:%s\r\n",uart_data);
					Andlink_GW_Info.flag =  Flag_FirstRun; 
					getVValue = cJSON_GetObjectItem(uartJson, "andlinkToken");	
					strcpy(Andlink_GW_Info.andlinkToken ,getVValue->valuestring);
					printf("andlinkToken��%s \r\n",Andlink_GW_Info.andlinkToken);
					getVValue = cJSON_GetObjectItem(uartJson, "deviceID");	
					strcpy(Andlink_GW_Info.deviceID ,getVValue->valuestring);
					printf("deviceID:%s \r\n",Andlink_GW_Info.deviceID);
					getVValue = cJSON_GetObjectItem(uartJson, "deviceToken");	
					strcpy(Andlink_GW_Info.deviceToken ,getVValue->valuestring);
					printf("deviceToken:%s \r\n",Andlink_GW_Info.deviceToken);
					getVValue = cJSON_GetObjectItem(uartJson, "dmToken");	
					strcpy(Andlink_GW_Info.dmToken ,getVValue->valuestring);
					printf("dmToken:%s \r\n",Andlink_GW_Info.dmToken);
					getVValue = cJSON_GetObjectItem(uartJson, "gwToken");	
					strcpy(Andlink_GW_Info.gwToken ,getVValue->valuestring);
					printf("gwToken�� %s\r\n",Andlink_GW_Info.gwToken);
					getVValue = cJSON_GetObjectItem(uartJson, "userId");	
					Andlink_GW_Info.userId = getVValue->valueint;
					SaveAndlinkinfoToFlash();
					printf("����link��Ϣ��flash\r\n");
				}
			}
			memset(UART1_RX_BUFFER,0,UARTBUF_MAX_LEN);
			UART1_RX_LEN = 0;
			cJSON_Delete(uartJson);
			cJSON_Delete(getVValue);
		}
	}
	
	for(i=0;i<UART1_RX_LEN;i++)
	{
		if(UART1_RX_BUFFER[i] == CMD_START)
		{
			delay_ms(10);
			order_data_len = (UART1_RX_BUFFER[i+2]&0x7F)+5;
			//printf("����ָ���:%d\r\n",order_data_len);
			if((UART1_RX_BUFFER[i+order_data_len-1] == CMD_LF2 )&&(UART1_RX_BUFFER[i+order_data_len-2] == CMD_LF1 ))  //a complete command
			{
				for(j=0;j<order_data_len;j++)
				{
					order_data[j] = UART1_RX_BUFFER[i+j];
				}
				if(UART1_RX_LEN == (i+order_data_len))
				{
					memset(UART1_RX_BUFFER,0,UARTBUF_MAX_LEN);
					UART1_RX_LEN = 0;
				}
				else
				{
					memset(UART1_RX_BUFFER,0,i+order_data_len);
					for(j=0;j<UART1_RX_LEN-order_data_len-i;j++)
					{
						UART1_RX_BUFFER[j] = UART1_RX_BUFFER[i+order_data_len+j];
						UART1_RX_BUFFER[i+order_data_len+j] = 0;
					}
					UART1_RX_LEN = UART1_RX_LEN - order_data_len - i;
				}
				dealorder=1;  //parse the order
			}
			else  //not a complete command
			{
				if(i>0)
				{
					memset(UART1_RX_BUFFER,0,i);
					for(j=0;j<UART1_RX_LEN-i;j++)
					{
						UART1_RX_BUFFER[j] = UART1_RX_BUFFER[i+j];
						UART1_RX_BUFFER[i+j] = 0;
					}
					UART1_RX_LEN = UART1_RX_LEN  - i;
				}
			}
			
		}
	}
	if(dealorder == 1)
	{
//		for(i=0;i<order_data_len;i++)
//		{
//			printf("%02x ",order_data[i]);
//		}
		dealorder = 0;
		switch( order_data[3])
		{
		 case CMD_DEBUG:     //��ӡ������־
			 if(order_data[4] == 0x01 )
			 {
					Flag_COMDebug = 1;
				    flashsize = (uint16_t)( *(__IO uint32_t*)MCUFLASHSIZE_ADDRESS&0x0000FFFF);  //оƬflash��С
					for(i=0;i<3;i++)
					{
						mcuid[i] = *(__IO uint32_t*)(MCUID_ADDRESS+i*4);  //�ڲ�оƬ���
					}
				    printf("\r\n******************************************************************************\r\n"); 								
					printf("	MCU:N32G452CCL7\r\n");
					printf("	MCU Flash:%d kB\r\n",flashsize);
					printf("	MCU RAM:48 kB\r\n");   
					printf("	MCU ID:%08x%08x%08x \r\n",mcuid[0],mcuid[1],mcuid[2]); 
					printf("	HardVer:V%d.%d.%d\r\n",HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER);
					printf("	SoftVer:V%d.%d.%d\r\n",SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER);
					printf("	Soft release time:%s \r\n",RELEASE_TIME);
					printf("	Soft build time is:%s %s\r\n", __DATE__, __TIME__);
					printf("	MAC:%s \r\n",Device_Info.MAC_ID);
                    printf("	CMEI:%s \r\n",Device_Info.CMCC_CMEI);
					printf("	SN:%s \r\n",Device_Info.CMCC_SN);
					printf("	manuDate:%s \r\n",Device_Info.manuDate);
					printf("	Router name:%s,PWD:%s\r\n",Router_Info.SSID,Router_Info.password);
					printf("******************************************************************************\r\n");
			 }
			 else
					Flag_COMDebug = 0;	 
		 break;

		 //24 01 0e 22 41 45 38 44 34 38 35 35 38 36 37 35 ff 69 42
		 case CMD_SETMAC:      //�����豸MAC
			Device_Info.MAC_LEN = order_data_len-7;
			for(i=0;i<Device_Info.MAC_LEN;i++)
			{
				Device_Info.MAC_ID[i] = order_data[4+i];
			}
			Device_Info.MAC_ID[Device_Info.MAC_LEN] = 0x00;            
//			Res = SaveMACToFlash();//д���������ں�һ�𱣴�
//			if(Res == 0x00)
//			{
//				COMRetuenOneByte(DEBUG_UART,CMD_SETMAC,0x00);
//			}
//			else   
//			 {					 
				 Flag_ErrInfo &= ~ERROR_N0_MAC;
				 COMRetuenOneByte(DEBUG_UART,CMD_SETMAC,0x01);
//			 }
			

		 break;			 	 
			 
		 case CMD_READMAC:   //��ȡ�豸MAC
			SendDeviceMacToUart(DEBUG_UART);
					
		 break;
         
        case CMD_SETCMEI:
			len = order_data_len-7;
			for(i=0;i<len;i++)
			{
				Device_Info.CMCC_CMEI[i] = order_data[4+i];
			}
			Device_Info.CMCC_CMEI[len] = 0x00;
			
//			Res = SaveMACToFlash();
//			if(Res == 0x00)
//			{
//				COMRetuenOneByte(DEBUG_UART,CMD_SETCMEI,0x00);
//			}
//			else   
//			 {					 
				 Flag_ErrInfo &= ~ERROR_N0_MAC;
				 COMRetuenOneByte(DEBUG_UART,CMD_SETCMEI,0x01);
//			 }
         
         break;
         
		case CMD_SETMANUDATE:  //�����豸�������� ,���20230827����
             len = order_data_len-7;
			for(i=0;i<len;i++) 
			{
				Device_Info.manuDate[i] = order_data[4+i];
			}
			Device_Info.manuDate[len] = 0x00;            
			Res = SaveMACToFlash();
			if(Res == 0x00)
			{
				COMRetuenOneByte(DEBUG_UART,CMD_SETMANUDATE,0x00);
			}
			else   
			 {
				 Flag_ErrInfo &= ~ERROR_N0_MAC;
				 COMRetuenOneByte(DEBUG_UART,CMD_SETMANUDATE,0x01);
			 }
         break;
		 
		case CMD_SETSN:      //�����豸SN,20230916����
			len = order_data_len-7;
			for(i=0;i<len;i++)
			{
				Device_Info.CMCC_SN[i] = order_data[4+i];
			}
			Device_Info.CMCC_SN[len] = 0x00;            				 
			Flag_ErrInfo &= ~ERROR_N0_MAC;
			COMRetuenOneByte(DEBUG_UART,CMD_SETSN,0x01);
		 break;	
			
         case CMD_READCMEI:
             SendCMEIToUart(DEBUG_UART);
         break;

		 
		 case CMD_READVER:  //��ȡ�豸�汾��
			sprintf(SoftVer,"HardVer:V%d.%d.%d\r\nSoftVer:V%d.%d.%d\r\nSoft release time:%s\r\n",HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER,
							SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER,RELEASE_TIME);
			SendDeviceVerInfoToUart(DEBUG_UART,SoftVer);
		 break;
		 
		case CMD_DELFLASHDATA:          //ɾ��flash����
			if(order_data[4] == CMD_DELSAVENUM )
			{


			}			
			if(order_data[4] == CMD_DELSERVERIP )
			{
				Flag_InitStatus = WIRELESS_INIT;  //���Խ�������ģ���ʼ��
				Flag_WIFIInitStep = WIFI_INIT_STEP1;
				WiFi_InitTime = 0;
				LinkStep = GETIP2;
				Flag_PowerOn = 1;
				
			}
		break;

          
		case CMD_REQMOUDLE_INFO:   //��ѯ�豸״̬
			if(order_data[4] == MOUDLE_STATUS_RUNTIME )   //�豸������ʱ��
			{
				printf("\r\nTotal run time is:%d day %d Hour %d Min %d Sec!\r\n",TimerSim.Day,TimerSim.Hour,TimerSim.Min,TimerSim.Sec);
		
			}
			if(order_data[4] == MOUDLE_STATUS_ROUTERSSID )   //wifiģ�����ӵ�·��������
			{
//				if(WIFI_Req_STASSID()==WIFI_SUCCESS)
				{							 

					printf("Connected the WiFi:%s\r\n",RouterName_InWIFI);

				}					
			}
			if(order_data[4] == MOUDLE_STATUS_CONNECTIP )   //wifiģ�����ӵķ�����
			{
				printf("IP2:%s,Port2:%s",IP2,Port2);
			}
			if(order_data[4] == MOUDLE_DEL_ROUTERNAME )   //ɾ���豸�ڱ����WiFi�˺���Ϣ
			{
				STMFLASH_SectorErase(FLASH_WIFIInfoAddress);  //ɾ��WiFi��Ϣ	
				printf("Delete WiFi info\r\n");
				NVIC_SystemReset();
			}
			if((order_data[4] == MOUDLE_DEL_MAC )||(order_data[4] == MOUDLE_DEL_CMEI))   //ɾ���豸�ڱ����mac��Ϣ��cmei��Ϣ
			{
				STMFlashErase(FLASH_EquipmentInfoAddress,1);  //ɾ��MAC��Ϣ
				STMFLASH_SectorErase(FLASH_WIFIInfoAddress);  //ɾ��WiFi��Ϣ	
				printf("Delete MAC��CMEI��SN��DATE��WIFI\r\n");
				NVIC_SystemReset();
			}

		break;
			
		case SET_ROUTER_NAME:     //����wifi����
			Router_NameLen=order_data[4];
			Router_PWDLen =order_data[5]; 
			for(i=0;i<Router_NameLen;i++)
			{
				Router_Name[i]=order_data[6+i];
			}
			for(i=0;i<Router_PWDLen;i++)
			{
				Router_PWD[i]=order_data[6+Router_NameLen+i];
			}
			Router_Name[Router_NameLen]= '\0';
			Router_PWD[Router_PWDLen]= '\0';
			SaveRouterNameToFlash();
							 
			printf("\r\nWiFi name len:%d,Name:%s\r\n",Router_NameLen,Router_Name);
			printf("WiFi pwd len:%d,pwd:%s\r\n",Router_PWDLen, Router_PWD);	
			
		 break;
		 
		 default :
			 
		 break;
		}
	}	 
}


/****************************************************************************
*	�� �� ��:Server_Order_Dispose
*	����˵��: ������ָ�������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void Server_Order_Dispose(uint8_t *dat)
{
	
	uint8_t receivetime[6];
    uint16_t  i ,j;
	uint16_t order_data_len = 0;
    uint8_t order_data[UARTBUF_MAX_LEN];
	uint8_t dealorder = 0;
	uint16_t num = 0;
	uint8_t jiaoyan = 0;
	uint8_t senddata[10];
	
	
	for(i=0;i<WIFI_RX_LEN;i++)
	{
		if(WIFI_RX_BUFFER[i] == CMD_START)
		{
			delay_ms(20);
			order_data_len = (WIFI_RX_BUFFER[i+2]&0x7F)+5;
			
			if(order_data_len>100)
			{
				delay_ms(50);
			}
			if((WIFI_RX_BUFFER[i+order_data_len-1] == CMD_LF2 )&&(WIFI_RX_BUFFER[i+order_data_len-2] == CMD_LF1 ))  //a complete command
			{

				for(j=0;j<order_data_len;j++)
				{
					order_data[j] = WIFI_RX_BUFFER[i+j];
				}
				if(WIFI_RX_LEN == (i+order_data_len))
				{
					memset(WIFI_RX_BUFFER,0,UARTBUF_MAX_LEN);
					WIFI_RX_LEN = 0;
				}
				else
				{
					memset(WIFI_RX_BUFFER,0,i+order_data_len);
					for(j=0;j<WIFI_RX_LEN-order_data_len-i;j++)
					{
						WIFI_RX_BUFFER[j] = WIFI_RX_BUFFER[i+order_data_len+j];
						WIFI_RX_BUFFER[i+order_data_len+j] = 0;
					}
					WIFI_RX_LEN = WIFI_RX_LEN - order_data_len - i;
				}
				dealorder=1;  //parse the order
				WIFI_Data_Receive_Time = 0;
			}
			else  //not a complete command
			{
				if(i>0)
				{
					memset(WIFI_RX_BUFFER,0,i);
					for(j=0;j<WIFI_RX_LEN-i;j++)
					{
						WIFI_RX_BUFFER[j] = WIFI_RX_BUFFER[i+j];
						WIFI_RX_BUFFER[i+j] = 0;
					}
					WIFI_RX_LEN = WIFI_RX_LEN  - i;
				}
			}
			
		}
	}
	if(dealorder == 1)
	{

		//---------------����Ϊ�Է��������ݵĽ���--------------------------------------------------------		 		 	 
		if((order_data[1]==TypeID_WIFI)&&(order_data[3]==SERVER_ABNORMAL_MESSAGE))   //���������ش���δ�����û�
		{
			if((order_data[2]== 0x84 )&&(order_data[5]== BINDING_USERS_NO))
			{
				Flag_Binding_Users = BINDING_USERS_NO;
				if(Flag_No_Binding_Users_Time == 0)  //δ�����û���ʱ��־
				{
					Flag_No_Binding_Users_Time = 1;
					No_Binding_Users_Time = 0;						 
				}
				if(Flag_COMDebug == 1)
					printf("The device does not binding to users!\r\n");   			 
			}
			if((order_data[2]== 0x84 )&&(order_data[5]== BINDING_USERS_YES))
			{
				Flag_Binding_Users = BINDING_USERS_YES;
				Flag_No_Binding_Users_Time = 0;			  
//				if(gPeopleFlag == TRUE)
				if((RealTime[3] >= 9)&&(RealTime[3] <= 17)) //9~18��3��1֡������10��һ֡
					SleepData_SendTime = SLEEPDATA_SENDTIME_3S; 
				else
					SleepData_SendTime = SLEEPDATA_SENDTIME_10S; 
				
				if(Flag_COMDebug == 1)
					printf("The device is  binding to users!\r\n");
			}					 
		}
		if((order_data[1]==TypeID_WIFI)&&(order_data[3]==REQ_SERVER_TIME))//���������ظ��µ�ʱ��
		{		
			//test code  220526  ÿ10��ʵʱ���ݻ�����һ��ʱ�䣬�Ѵ˵�����������
			HeartBeat = 0;
			printf("������������\r\n");
			for(j=0;j<order_data_len;j++)
			{
				printf("%x ",order_data[j]);
			}
			for(i=0;i<6;i++)  //��ȡ������ʱ��
			{
				receivetime[i] = (order_data[4+i*2]&0x7F-0x30)*10+(order_data[5+i*2]&0x7F-0x30); //��ASCII�ַ��������ֽڵ�ʱ��ת��Ϊ1���ֽڵ�ʱ��		 
			}
			if((receivetime[0]>0)&&(receivetime[0]<99)&&(receivetime[1]>0)&&(receivetime[1]<13)&&(receivetime[2]>0)&&(receivetime[2]<32))
			{
				if((receivetime[3]>=0)&&(receivetime[3]<60)&&(receivetime[4]>=0)&&(receivetime[4]<60)&&(receivetime[5]>=0)&&(receivetime[5]<60))
				{
					for(i=0;i<6;i++)
					{
						RealTime[i] = receivetime[i];
					}
					Flag_TimeAdj = 3;
					if(Flag_COMDebug == 1)
					{					
//						printf("������Ӧ������:%x %x %x %x %x %x %x %x %x %x %x %x %x %x %x \r\n",order_data[0],order_data[1],order_data[2],order_data[3],order_data[4],order_data[5],order_data[6],order_data[7],order_data[8],order_data[9]
//						,order_data[10],order_data[11],order_data[12],order_data[13],order_data[14]);
						printf("Renew Server time is:%d-%d-%d %d:%d:%d\r\n",RealTime[0],RealTime[1],RealTime[2],RealTime[3],RealTime[4],RealTime[5]);
					}							
				}
			}
		}
//		if((order_data[1]==TypeID_WIFI)&&(order_data[3]==DEL_DEVICE_DATA))// ����豸  24 02 00 07
//		{
//			printf("����豸\r\n");
//			STMFLASH_SectorErase(FLASH_ServerInfoAddress);  //ɾ��IP��Ϣ
//			STMFLASH_SectorErase(FLASH_VerifyInfoAddress);  //ɾ��token��Ϣ
//			STMFLASH_SectorErase(FLASH_WIFIInfoAddress);
//			STMFLASH_SectorErase(FLASH_AndLinkInfoAddress);
//			NVIC_SystemReset();
//		}
		if((order_data[1]== TypeID_WIFI)&&(order_data[3]== SERVER_ABNORMAL_MESSAGE)) //MAC��֤����
		{
			if(order_data[4] == SERVER_CHECK_MAC_ERR)
			{
				if(Flag_COMDebug == 1)
					printf("Server Return MAC Verify Error\r\n");
				Flag_StepStatus = STEP_SEND;
				LinkStep = CONNECTIP1;	
				Flag_LED_Status = LED_SERVER_LINK;
//				Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
				STMFLASH_SectorErase(FLASH_ServerInfoAddress);  //ɾ��IP��Ϣ
				STMFLASH_SectorErase(FLASH_VerifyInfoAddress);  //ɾ��token��Ϣ
				Set_StatistStartTime();
			}								 
		}
		if((order_data[0]== CMD_START)&&(order_data[1]== TypeID_WIFI)&&(order_data[3]== SEND_STATISTICS_SLEEPDTAT)) //��Ӧ���͵�ͳ������
		{
			if((order_data[4] == 0x81)&&(Flag_SleepDataBuffer_Save != Flag_SleepDataBuffer_Send))   //���յ���ȷ��ͳ������
			{
				if(Flag_COMDebug == 1)
				{
					printf("Server Receive Right Statistics Data:%d!\r\n",Flag_SleepDataBuffer_Send);
				}
				Flag_CanSendStatistData = 1;
				CanSendStatistTime = 0;					
				Flag_SleepDataBuffer_Send++;			
				if(Flag_SleepDataBuffer_Send == Flag_SleepDataBuffer_Save)
				{
					Flag_SleepDataBuffer_Send = 0;
					Flag_SleepDataBuffer_Save = 0;
					Flag_SavepPos = 0;
					Flag_CanSendStatistData = 0;
					for(i=0;i<SLEEPDTATABUF;i++)
					{
						for(j=0;j<40;j++)
							Buffer_SleepData[i][j] = 0;
					}
				} 
				if(Flag_SleepDataBuffer_Send ==SLEEPDTATABUF )
				{
					Flag_SleepDataBuffer_Send = 0;
				}
			}	
			if(order_data[4] == 0x80)   //���յ������ͳ������
			{
				if(Flag_COMDebug == 1)
				{
					printf("Server Receive Error Statistics Data:%d,!Resend\r\n",Flag_SleepDataBuffer_Send);
				}
				Flag_CanSendStatistData = 1;
				CanSendStatistTime = 0;						
			}
		}
		#ifdef ENABLE_SENDPRESSSERSONSTATUS
		if((order_data[1]== TypeID_WIFI)&&(order_data[3]== CMD_PRESSSENSER)) //ѹ��������״̬����
		{
			if(order_data[4] == 0x81)
			{
				Flag_SendPresensorStatus = 0;
				SendPresensorStatus_Time = 0;
				if(Flag_COMDebug == 1)
					printf("Server Received pressure sensor status\r\n");
			}								 
		}
		#endif
		ClearUSARTBUF(WIFI_USART);		 
	}	
}


/****************************************************************************
*	�� �� ��: Power_ON
*	����˵��: �豸��������ʼ��������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void Power_ON(void)
{	 		
	uint8_t i,j;
	uint8_t dat = 0;

//--------------------------����������ʼ��--------------------------------		
	uint8_t Time_RM = 0;
	uint8_t send_data[5];
	uint32_t ADC_SampleData[16];

	Flag_BT_Linkstatus = BT_NoCONNECT;  
	Flag_InitStatus = SYSTEM_INIT;
	Flag_LED_Status = 0;
	Flag_ErrInfo = NO_ERROR;
	Flag_PowerOn = 1;
	GetSleepDataTimeCount = 0;
	Flag_Reset_RouterSSID=0; 
	Flag_Binding_Users = BINDING_USERS_YES;
	Flag_No_Binding_Users_Time =0; //δ�����û���ʱ��־����

	Flag_Send_GPRS_Position = 0;
	Flag_SendDataAbnormal = NO_ERROR;
	Flag_TimeAdj = 0;
	Flag_LED_Status=0;
	WIFI_ConnetTime =0;
	Flag_SleepData_SendOver = 0;	
	Flag_WIFIInitStep = 0;

	ClearUSARTBUF(DEBUG_UART);
//	for(i=0;i<ECG_COMPARE_TIMES;i++)
//	{
//		ECG_MAX[i] = STANDARD_VOLTAGE;
//		ECG_MIN[i] = STANDARD_VOLTAGE;
//		CHGECG_MAX[i] = STANDARD_VOLTAGE;
//		CHGECG_MIN[i] = STANDARD_VOLTAGE;
//	}
//	ECG_COMPARE_COUNT = 0;
//	Flag_ADC_ADJ = 0;
//	ADC_COUNT = 0;
//	CHGADC_COUNT = 0;
	LinkIPCount = 0;
//	Flag_SendAMPCHGToServer = 0;
	Flag_SleepDataBuffer_Save = 0;
	Flag_SleepDataBuffer_Send = 0;
	Flag_DataSendMode =WIFI_DATASEND_ATMODE;   //ATģʽ
	SleepData_SendTime = SLEEPDATA_SENDTIME_3S;
	SendLinkStatus_Time = 0;
	Flag_SendLinkStatus = 0;
	APP_Receive_Right = 0;
	BLE_ReceiveDataTime = 0;

	Flag_WiFiSmartConfig = 0; 
	Status_ExtSensorIn = EXTSENSOR_ISOUT;      //ѹ������
	Status_ExtSensorOnbed = EXTSENSOR_PEOPLEOFFBED; 
	ExtSensor_OnbedStatus_Count = 0;
	OnbedStatus_CountTimer = 0;
	LastOnbedStatus = 0;
	Flag_SendPresensorStatus = 0; 
	 
	for(i=0;i<SLEEPDTATABUF;i++)
	{
		for(j=0;j<40;j++)
			Buffer_SleepData[i][j] = 0;
	}	
	TimerSim.Msec = 0;   //ʱ���ʼ��
	TimerSim.Sec = 0;
	TimerSim.Min = 0;
	TimerSim.Hour = 0;
	TimerSim.Day = 0;
		
	
//--------------------------������ģ������--------------------------------
//	  HSI_SetSysClock(RCC_PLLMul_16);  //�ڲ������ʼ����ϵͳʱ��64M
//	SysTick_Init();
	
	DataInitial();					//�㷨������ʼ���������㷨��

	RCC_Configuration();

  	/* NVIC Configuration */
  	NVIC_Configuration(); 
	
  	/* GPIO Configuration */
  	GPIO_Configuration();

	/* Timer Configuration */
	Timer_Configuration();   
	
    /* USART Configuration */
	USART_Configuration();

	/* DMA ADC Configuration */
	//ѹ��
	DMA_ADC2_Configuration();
	//ѹ��
	DMA_ADC1_Configuration();
	
	LED_GPIO_Config();

	WIFI_GPIO_CONFIG();

}

/**
 * @brief  Main program
 */
int main(void)
{	
	char err_code;
	int errCnt = 0;
    
	uint16_t i,j;	 
     unsigned char *dataPtr = NULL;
    
	uint32_t sFLASH_ID = 0;	
    
	Flag_COMDebug = 1;	 //���Դ�

    /* System Clocks Configuration */
	SetSysClockToPLL(96000000, SYSCLK_PLLSRC_HSI);
	RCC_EnableClockSecuritySystem(ENABLE);		

	//-----------------------------------------------------	
	Power_ON();              //������ģ���ʼ��
	delay_ms(500);

 #if 0
    STMFlashErase(FLASH_WIFIInfoAddress,1);  //ɾ��WiFi��Ϣ
	STMFlashErase(FLASH_EquipmentInfoAddress,1);//ɾ��MAC��Ϣ
    STMFlashErase(FLASH_AndLinkInfoAddress,1);
#endif

	ReadMACFromFlash();     //��ȡ�豸MAC 
    ReadCMEIFromFlash();    //��ȡ�豸CMEI
	ReadRouterNameFromFlash(); //��ȡWiFi����
	
	printf("\r\n******************************************************************************\r\n"); 
	printf("	HardVer:V%d.%d.%d\r\n",HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER);
	printf("	SoftVer:V%d.%d.%d\r\n",SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER);
	printf("	Soft release time:%s \r\n",RELEASE_TIME);
	printf("	Soft build time is:%s %s\r\n", __DATE__, __TIME__);
	printf("	MAC:%s \r\n",Device_Info.MAC_ID);
    printf("	CMEI:%s \r\n",Device_Info.CMCC_CMEI);
	printf("	SN:%s \r\n",Device_Info.CMCC_SN);
	printf("	manuDate:%s \r\n",Device_Info.manuDate);
	printf("	Router name:%s,PWD:%s\r\n",Router_Info.SSID,Router_Info.password);
	printf("******************************************************************************\r\n");
    
	SystemReset_CheckStatus();   
	if((Flag_ErrInfo&ERROR_NO_ROUTERNAME) ==ERROR_NO_ROUTERNAME) //��WiFi�˺���Ϣ������Ҫ����
	{
      #ifdef  Enable_ESP8266_Config_AP
          Flag_WiFiAPConfig = 1;
       #endif
	}
    
	if(((Flag_ErrInfo&ERROR_N0_MAC) !=ERROR_N0_MAC)&&((Flag_ErrInfo&ERROR_NO_CMEI) !=ERROR_NO_CMEI))   //�����Mac���ʼ��wifiģ��
	{
		//test code!!!
		if(Flag_COMDebug == 1)
			printf("������д��ڶ�ȡ��д�룬����3���ڷ��� {serial} \r\n");
		delay_ms(200);
		printf("3...\r\n");
		delay_ms(1000);
		printf("2...\r\n");
		delay_ms(1000);
		printf("1...\r\n");
		delay_ms(1000);
		COMProcessCmd();
		
		if(Flag_InitStatus != MAC_INIT)
		{
			Flag_InitStatus = WIRELESS_INIT;  //���Խ�������ģ���ʼ��
			Flag_WIFIInitStep = WIFI_INIT_STEP1;
			WiFi_InitTime = 0;
			WIFI_EN(1);
			delay_ms(10);
			if(Flag_COMDebug == 1)
				printf("WIFI init\r\n");
		}
	}
	else
	{
        Flag_COMDebug = 0;
		printf("MAC or CMEI NULL\r\n");	
	}
					
	IWDG_Config(IWDG_PRESCALER_DIV64 ,1250);
    
	
    while (1)
    {
		
/*****************************wifiģ���ʼ��***********************************************/
#if 1		
		if(Flag_InitStatus == WIRELESS_INIT)
		{		
			Flag_LED_Status = LED_WIRELEE_INIT; 
            if(Flag_COMDebug == 1)            
                printf("start wifi init...\r\n");
			err_code=WIFI_INIT();	
			if(err_code == WIFI_INIT_STEP5)   //·����������
			{
                if(Flag_COMDebug == 1)
                    printf("·����������\r\n");
				LinkStep = ANDLINK_ONLINE;
				Flag_StepStatus = STEP_SEND;
				Flag_InitStatus = LINK_SERVER; //����ģ���ʼ����ɣ����Խ�������������֤
				Flag_LED_Status = LED_SERVER_LINK;	
				LinkIPCount = 0;			 
			}      							
		}
#endif
		if((WIFI_ConnetTime >600)&&(LinkStep != SENDSLEEPDATA)) //���豸10����δ�����Ϸ��������������ϵ�wifiģ��
		{
			WIFI_ConnetTime = 0;				 
			Flag_Start_Mode = START_WIFI_RESTART;  //wifiģ�������ϵ�
			RePowerOn_WIFI();			 
		}     		
/*****************************����������ͨѶ***********************************************/
		if(Flag_InitStatus == LINK_SERVER)
		{				
			if(LinkStep != SENDSLEEPDATA)
			{
				LinkServerVerifyStep(LinkStep);   //��������
			}
		}
		if(Flag_InitStatus == CONTINUE_SENDDATA)
	    {
			//-------------------------------��ѯ����״̬--------------------------------------------------
			if((Time_NetworkInquire >= GETNETWORKSTATUSTIME)&&(LinkStep == SENDSLEEPDATA))
			{
				Time_NetworkInquire = 0;								

				err_code = WIFI_Query_STA_RSSI();
				if(err_code == WIFI_NOCONNECT)   //wifiδ����
				{
					LinkStep = ANDLINK_MQTT;   
					Flag_StepStatus = STEP_SEND;
					Flag_InitStatus = LINK_SERVER;
					Flag_LED_Status = LED_SERVER_LINK;					 									 
					Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����											
					Flag_Send_GPRS_Position = 0;
					LinkIPCount = 0;
					Link_Time = 0;
					WIFI_ConnetTime = 0;										
					if(Flag_COMDebug == 1)
						printf("Reconnect Server1!\r\n");
				}
				else  //wifi����
				{
					err_code=WIFI_Query_TCPStatus();
					if(err_code == WIFI_TCP_NOCONNECT)  //���δ����
					{	
						LinkStep = ANDLINK_MQTT; 
						Flag_StepStatus = STEP_SEND;
						Flag_InitStatus = LINK_SERVER;
						Flag_LED_Status = LED_SERVER_LINK;					 									 
						Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����											
						Flag_Send_GPRS_Position = 0;
						LinkIPCount = 0;
						Link_Time = 0;
						WIFI_ConnetTime = 0;										
						if(Flag_COMDebug == 1)
							printf("Reconnect Server2\r\n");         							 
					}
				}
			}
           if(Flag_ReportAndlinkManagedata == 1) //ÿ������12�㿪ʼ��ʱ���ƶ��������ϱ����ݣ�ʱ���ɸ���(it.c�ļ��޸ģ�������ܿ�����ʱ��
           {
               Flag_ReportAndlinkManagedata = 0;
               TerminalManageData_OntimeReport();
           }
		}
	//-------------����ʵʱ����-------------------------------------------------------------------
		if((GetSleepDataTimeCount >= SleepData_SendTime) && (Flag_PowerOn == 0))  //����ʵʱ����
		{
			SendRealTimeSleepData();				//��������	
			GetSleepDataTimeCount=0;			
		}
   
/*****************************ָ���***********************************************/				
		
		if((WIFI_RX_LEN > 0)&&(LinkStep == SENDSLEEPDATA))   //WIFIģ�鷢�͵����ݴ���
		{		
              dataPtr = ESP8266_GetIPD(10);
              if(dataPtr != NULL)
                  Andlink_MQTT_RevPro(dataPtr);//��Ҫ�ڸú����д�������������ָ��
         
		}
		if(UART1_RX_LEN > 0)//���Դ�������
		{
			COMProcessCmd();
		}
/****************************************************************************/	
			
	}//end
}




/**
 * @brief  Configures the different system clocks.
 */
void RCC_Configuration(void)
{
    /* PCLK1 = HCLK/4 */
    //RCC_ConfigPclk1(RCC_HCLK_DIV4);

    /* TIM2 clock enable */
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM2, ENABLE);

    /* GPIOC clock enable */
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
	
	/* Enable GPIO clock */
    RCC_EnableAPB2PeriphClk(USART_DEBUG_GPIO_CLK | USART_WIFI_GPIO_CLK | RCC_APB2_PERIPH_AFIO, ENABLE);
	
    /* Enable USART_DEBUG and USART_WIFI Clock */
    USART_DEBUG_APBxClkCmd(USART_DEBUG_CLK, ENABLE);
    USART_WIFI_APBxClkCmd(USART_WIFI_CLK, ENABLE);

	//ADC DMA
	/* Enable peripheral clocks ------------------------------------------------*/
    /* Enable DMA1 and DMA2 clocks */
    RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_DMA1 | RCC_AHB_PERIPH_DMA2, ENABLE);
    /* Enable GPIOC clocks */
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    /* Enable ADC1, ADC2 clocks */
    RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_ADC2,ENABLE);
	RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_ADC1,ENABLE);
    /* RCC_ADCHCLK_DIV16*/
    ADC_ConfigClk(ADC_CTRL3_CKMOD_AHB,RCC_ADCHCLK_DIV16);

}

/**
 * @brief  Configure the GPIO Pins.
 */
void GPIO_Configuration(void)
{
    GPIO_InitType GPIO_InitStructure;

	//JTAG���Ÿ���ΪGPIO
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO, ENABLE);

	GPIO_ConfigPinRemap(GPIO_RMP_SW_JTAG_SW_ENABLE, ENABLE);		// ������ΪGPIO
	GPIO_ConfigPinRemap(GPIO_RMP3_UART5, ENABLE);		// ������ΪGPIO

    /* Configure USART_DEBUG Rx as input floating */
    GPIO_InitStructure.Pin       = USART_DEBUG_RxPin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitPeripheral(USART_DEBUG_GPIO, &GPIO_InitStructure);

    /* Configure USART_WIFI Rx as input floating */
    GPIO_InitStructure.Pin = USART_WIFI_RxPin;
    GPIO_InitPeripheral(USART_WIFI_GPIO, &GPIO_InitStructure);

    /* Configure USART_DEBUG Tx as alternate function push-pull */
    GPIO_InitStructure.Pin        = USART_DEBUG_TxPin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitPeripheral(USART_DEBUG_GPIO, &GPIO_InitStructure);

    /* Configure USART_WIFI Tx as alternate function push-pull */
    GPIO_InitStructure.Pin = USART_WIFI_TxPin;
    GPIO_InitPeripheral(USART_WIFI_GPIO, &GPIO_InitStructure);
	
	//ADC
    /* Configure PA1 PA2 as analog inputs */
    GPIO_InitStructure.Pin       = GPIO_PIN_4 | GPIO_PIN_3;//ԭPA5��ΪPA3
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitPeripheral(GPIOA, &GPIO_InitStructure);
		
}

/**
 * @brief  Configure the nested vectored interrupt controller.
 */
void NVIC_Configuration(void)
{
    NVIC_InitType NVIC_InitStructure;
	
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

    /* Enable the TIM2 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel                   = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the USART1 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel            = USART_DEBUG_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd         = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the USART_WIFI Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel            = USART_WIFI_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd         = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

}

void Timer_Configuration(void){
 /* ---------------------------------------------------------------
    TIM2 Configuration: Output Compare Timing Mode:
    TIM2 counter clock at 6 MHz
    CC1 update rate = TIM2 counter clock / CCR1_Val = 146.48 Hz
    CC2 update rate = TIM2 counter clock / CCR2_Val = 219.7 Hz
    CC3 update rate = TIM2 counter clock / CCR3_Val = 439.4 Hz
    CC4 update rate = TIM2 counter clock / CCR4_Val = 878.9 Hz
    --------------------------------------------------------------- */

    /* Compute the prescaler value */
    PrescalerValue = (uint16_t)(SystemCoreClock / 12000000) - 1;

    /* Time base configuration */
    TIM_TimeBaseStructure.Period    = 65535;
    TIM_TimeBaseStructure.Prescaler = 0;
    TIM_TimeBaseStructure.ClkDiv    = 0;
    TIM_TimeBaseStructure.CntMode   = TIM_CNT_MODE_UP;

    TIM_InitTimeBase(TIM2, &TIM_TimeBaseStructure);

    /* Prescaler configuration */
    TIM_ConfigPrescaler(TIM2, PrescalerValue, TIM_PSC_RELOAD_MODE_IMMEDIATE);

    /* Output Compare Timing Mode configuration: Channel1 */

    TIM_OCInitStructure.OcMode      = TIM_OCMODE_TIMING;
    TIM_OCInitStructure.OutputState = TIM_OUTPUT_STATE_ENABLE;
    TIM_OCInitStructure.Pulse       = MY_CCR_Val;
    TIM_OCInitStructure.OcPolarity  = TIM_OC_POLARITY_HIGH;

    TIM_InitOc1(TIM2, &TIM_OCInitStructure);

    TIM_ConfigOc1Preload(TIM2, TIM_OC_PRE_LOAD_DISABLE);

    /* TIM IT enable */
    TIM_ConfigInt(TIM2, TIM_INT_CC1, ENABLE);

    /* TIM2 enable counter */
    TIM_Enable(TIM2, ENABLE);
}

void USART_Configuration(void){

	/* USART_DEBUG and USARTz configuration ------------------------------------------------------*/
	USART_InitStructure.BaudRate			= 115200;
	USART_InitStructure.WordLength			= USART_WL_8B;
	USART_InitStructure.StopBits			= USART_STPB_1;
	USART_InitStructure.Parity				= USART_PE_NO;
	USART_InitStructure.HardwareFlowControl = USART_HFCTRL_NONE;
	USART_InitStructure.Mode				= USART_MODE_RX | USART_MODE_TX;

	/* Configure USART_DEBUG and USARTz */
	USART_Init(USART_DEBUG, &USART_InitStructure);
	USART_Init(USART_WIFI, &USART_InitStructure);

	/* Enable USART_DEBUG Receive interrupts */
	USART_ConfigInt(USART_DEBUG, USART_INT_RXDNE, ENABLE);
	
    /* Enable the USARTz Receive Interrupt */
    USART_ConfigInt(USART_WIFI, USART_INT_RXDNE, ENABLE);
	
	//DMA
	//UART5_DMA_Config();

	//USART_EnableDMA(USART_WIFI,USART_DMAREQ_RX, ENABLE);

	/* Enable the USART_DEBUG and USARTz */
	USART_Enable(USART_DEBUG, ENABLE);
	USART_Enable(USART_WIFI, ENABLE); 


}

//ѹ��
void DMA_ADC1_Configuration(void){
    /* DMA1 channel1 configuration ----------------------------------------------*/
    DMA_DeInit(DMA1_CH1);
    DMA_InitStructure.PeriphAddr     = (uint32_t)&ADC1->DAT;
    DMA_InitStructure.MemAddr        = (uint32_t)ADC1_ConvertedValue;
    DMA_InitStructure.Direction      = DMA_DIR_PERIPH_SRC;
    DMA_InitStructure.BufSize        = 1;
    DMA_InitStructure.PeriphInc      = DMA_PERIPH_INC_DISABLE;
    DMA_InitStructure.DMA_MemoryInc  = DMA_MEM_INC_ENABLE;
    DMA_InitStructure.PeriphDataSize = DMA_PERIPH_DATA_SIZE_WORD;
    DMA_InitStructure.MemDataSize    = DMA_MemoryDataSize_Word;
    DMA_InitStructure.CircularMode   = DMA_MODE_CIRCULAR;
    DMA_InitStructure.Priority       = DMA_PRIORITY_HIGH;
    DMA_InitStructure.Mem2Mem        = DMA_M2M_DISABLE;
    DMA_Init(DMA1_CH1, &DMA_InitStructure);
    /* Enable DMA1 Channel1 */
    DMA_EnableChannel(DMA1_CH1, ENABLE);

    /* ADC2 configuration ------------------------------------------------------*/
    ADC_InitStructure.WorkMode       = ADC_WORKMODE_REG_SIMULT;
    ADC_InitStructure.MultiChEn      = ENABLE;
    ADC_InitStructure.ContinueConvEn = ENABLE;
    ADC_InitStructure.ExtTrigSelect  = ADC_EXT_TRIGCONV_NONE;
    ADC_InitStructure.DatAlign       = ADC_DAT_ALIGN_R;
    ADC_InitStructure.ChsNumber      = 1;
    ADC_Init(ADC1, &ADC_InitStructure);
    /* ADC2 regular channels configuration */
    ADC_ConfigRegularChannel(ADC1, ADC1_Channel_04_PA3, 1, ADC_SAMP_TIME_239CYCLES5);

    /* Enable ADC2 external trigger conversion */
    ADC_EnableExternalTrigConv(ADC1, ENABLE);

//    /* Enable Vrefint channel17 */
    ADC_EnableTempSensorVrefint(ENABLE);

    /* Enable ADC1 */
    ADC_Enable(ADC1, ENABLE);
	ADC_EnableDMA(ADC1, ENABLE);
    /*Check ADC Ready*/
    while(ADC_GetFlagStatusNew(ADC1,ADC_FLAG_RDY) == RESET)
        ;
    /* Start ADC2 calibration */
    ADC_StartCalibration(ADC1);
    /* Check the end of ADC2 calibration */
    while (ADC_GetCalibrationStatus(ADC1))
        ;

 	ADC_EnableSoftwareStartConv(ADC1, ENABLE);

    /* Test on DMA1 channel1 transfer complete flag */
    while (!DMA_GetFlagStatus(DMA1_FLAG_TC1, DMA1))
        ;
    /* Clear DMA1 channel1 transfer complete flag */
    DMA_ClearFlag(DMA1_FLAG_TC1, DMA1);
}


//ѹ��
void DMA_ADC2_Configuration(void){
    /* DMA1 channel1 configuration ----------------------------------------------*/
    DMA_DeInit(DMA1_CH8);
    DMA_InitStructure.PeriphAddr     = (uint32_t)&ADC2->DAT;
    DMA_InitStructure.MemAddr        = (uint32_t)ADC2_ConvertedValue;
    DMA_InitStructure.Direction      = DMA_DIR_PERIPH_SRC;
    DMA_InitStructure.BufSize        = 1;
    DMA_InitStructure.PeriphInc      = DMA_PERIPH_INC_DISABLE;
    DMA_InitStructure.DMA_MemoryInc  = DMA_MEM_INC_ENABLE;
    DMA_InitStructure.PeriphDataSize = DMA_PERIPH_DATA_SIZE_WORD;
    DMA_InitStructure.MemDataSize    = DMA_MemoryDataSize_Word;
    DMA_InitStructure.CircularMode   = DMA_MODE_CIRCULAR;
    DMA_InitStructure.Priority       = DMA_PRIORITY_HIGH;
    DMA_InitStructure.Mem2Mem        = DMA_M2M_DISABLE;
    DMA_Init(DMA1_CH8, &DMA_InitStructure);
    /* Enable DMA1 Channel1 */
    DMA_EnableChannel(DMA1_CH8, ENABLE);

    /* ADC2 configuration ------------------------------------------------------*/
    ADC_InitStructure.WorkMode       = ADC_WORKMODE_REG_SIMULT;
    ADC_InitStructure.MultiChEn      = ENABLE;
    ADC_InitStructure.ContinueConvEn = ENABLE;
    ADC_InitStructure.ExtTrigSelect  = ADC_EXT_TRIGCONV_NONE;
    ADC_InitStructure.DatAlign       = ADC_DAT_ALIGN_R;
    ADC_InitStructure.ChsNumber      = 1;
    ADC_Init(ADC2, &ADC_InitStructure);
    /* ADC2 regular channels configuration */
    ADC_ConfigRegularChannel(ADC2, ADC2_Channel_01_PA4, 1, ADC_SAMP_TIME_239CYCLES5);
    //ADC_ConfigRegularChannel(ADC2, ADC2_Channel_02_PA5, 2, ADC_SAMP_TIME_239CYCLES5);
    /* Enable ADC2 external trigger conversion */
    ADC_EnableExternalTrigConv(ADC2, ENABLE);

//    /* Enable Vrefint channel17 */
    ADC_EnableTempSensorVrefint(ENABLE);

    /* Enable ADC2 */
    ADC_Enable(ADC2, ENABLE);
	ADC_EnableDMA(ADC2, ENABLE);
    /*Check ADC Ready*/
    while(ADC_GetFlagStatusNew(ADC2,ADC_FLAG_RDY) == RESET)
        ;
    /* Start ADC2 calibration */
    ADC_StartCalibration(ADC2);
    /* Check the end of ADC2 calibration */
    while (ADC_GetCalibrationStatus(ADC2))
        ;

	ADC_EnableSoftwareStartConv(ADC2, ENABLE);

    /* Test on DMA1 channel1 transfer complete flag */
    while (!DMA_GetFlagStatus(DMA1_FLAG_TC8, DMA1))
        ;
    /* Clear DMA1 channel1 transfer complete flag */
    DMA_ClearFlag(DMA1_FLAG_TC8, DMA1);
}


void SetSysClockToPLL(uint32_t freq, uint8_t src)
{
    uint32_t pllsrc = (src == SYSCLK_PLLSRC_HSI ? RCC_PLL_SRC_HSI_DIV2 : RCC_PLL_SRC_HSE_DIV2);
    uint32_t pllmul;
    uint32_t latency;
    uint32_t pclk1div, pclk2div;

    if (HSE_VALUE != 8000000)
    {
        /* HSE_VALUE == 8000000 is needed in this project! */
        while (1)
            ;
    }

    /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration
     * -----------------------------*/
    /* RCC system reset(for debug purpose) */
    RCC_DeInit();

    if (src == SYSCLK_PLLSRC_HSE)
    {
        /* Enable HSE */
        RCC_ConfigHse(RCC_HSE_ENABLE);

        /* Wait till HSE is ready */
        HSEStartUpStatus = RCC_WaitHseStable();

        if (HSEStartUpStatus != SUCCESS)
        {
            /* If HSE fails to start-up, the application will have wrong clock
               configuration. User can add here some code to deal with this
               error */

            /* Go to infinite loop */
            while (1)
                ;
        }
    }

    switch (freq)
    {
    case 24000000:
        latency  = FLASH_LATENCY_0;
        pllmul   = RCC_PLL_MUL_6;
        pclk1div = RCC_HCLK_DIV1;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 36000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_9;
        pclk1div = RCC_HCLK_DIV1;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 48000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_12;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 56000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_14;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 72000000:
        latency  = FLASH_LATENCY_2;
        pllmul   = RCC_PLL_MUL_18;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 96000000:
        latency  = FLASH_LATENCY_2;
        pllmul   = RCC_PLL_MUL_24;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    case 128000000:
        latency  = FLASH_LATENCY_3;
        pllmul   = RCC_PLL_MUL_32;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    case 144000000:
        /* must use HSE as PLL source */
        latency  = FLASH_LATENCY_4;
        pllsrc   = RCC_PLL_SRC_HSE_DIV1;
        pllmul   = RCC_PLL_MUL_18;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    default:
        while (1)
            ;
    }

    FLASH_SetLatency(latency);

    /* HCLK = SYSCLK */
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);

    /* PCLK2 = HCLK */
    RCC_ConfigPclk2(pclk2div);

    /* PCLK1 = HCLK */
    RCC_ConfigPclk1(pclk1div);

    RCC_ConfigPll(pllsrc, pllmul);

    /* Enable PLL */
    RCC_EnablePll(ENABLE);

    /* Wait till PLL is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_PLLRD) == RESET)
        ;

    /* Select PLL as system clock source */
    RCC_ConfigSysclk(RCC_SYSCLK_SRC_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while (RCC_GetSysclkSrc() != 0x08)
        ;
}


/**
 * @brief  Configures LED GPIO.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedInit(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_InitType GPIO_InitStructure;

    /* Check the parameters */
    assert_param(IS_GPIO_ALL_PERIPH(GPIOx));


    /* Enable the GPIO Clock */
    if (GPIOx == GPIOA)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
    }
    else if (GPIOx == GPIOB)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
    }
    else if (GPIOx == GPIOC)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    }
    else if (GPIOx == GPIOD)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOD, ENABLE);
    }
    else if (GPIOx == GPIOE)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOE, ENABLE);
    }
    else if (GPIOx == GPIOF)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOF, ENABLE);
    }
    else
    {
        if (GPIOx == GPIOG)
        {
            RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOG, ENABLE);
        }
    }

    /* Configure the GPIO pin */
    if (Pin <= GPIO_PIN_ALL)
    {
        GPIO_InitStructure.Pin        = Pin;
        GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitPeripheral(GPIOx, &GPIO_InitStructure);
    }
}

typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;
/**
 * @brief  Compares two buffers.
 * @param  pBuffer1, pBuffer2: buffers to be compared.
 * @param BufferLength buffer's length
 * @return PASSED: pBuffer1 identical to pBuffer2
 *         FAILED: pBuffer1 differs from pBuffer2
 */
TestStatus Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength)
{
    while (BufferLength--)
    {
        if (*pBuffer1 != *pBuffer2)
        {
            return FAILED;
        }

        pBuffer1++;
        pBuffer2++;
    }

    return PASSED;
}

/* retarget the C library printf function to the USART */
int fputc(int ch, FILE* f)
{
    USART_SendData(USART1, (uint8_t)ch);
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXDE) == RESET)
        ;

    return (ch);
}


#ifdef USE_FULL_ASSERT

/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param file pointer to the source file name
 * @param line assert_param error line source number
 */
void assert_failed(const uint8_t* expr, const uint8_t* file, uint32_t line)
{
    /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

    while (1)
    {
    }
}

#endif

/**
 * @}
 */

/**
 * @}
 */
