/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/

/**
 * @file n32g45x_it.c
 * @author Nations
 * @version v1.0.0
 *
 * @copyright Copyright (c) 2019, Nations Technologies Inc. All rights reserved.
 */
#include "n32g45x_it.h"
#include "main.h"
#include <BERpara.h>
#include <stdio.h>
#include "Parameter.h"
#include "USART.h"
#include "SysTick.h"
#include "ADC.h"
#include "Fun.h"

/** @addtogroup N32G45X_StdPeriph_Template
 * @{
 */

uint16_t capture = 0;
extern __IO uint16_t CCR1_Val;
extern __IO uint16_t CCR2_Val;
extern __IO uint16_t CCR3_Val;
extern __IO uint16_t CCR4_Val;
extern __IO uint16_t MY_CCR_Val;


extern void SYSCLKConfig_STOP(void);
extern void TimingDelay_Decrement(void);
extern void Time_Control(void);
extern void  Key_Handle(void);
extern void Set_MP3Player_Silence(void);
void Analysis_USART3_Order(void);

void timer1sProcess();
void timer20msProcess();


extern uint8_t indexWave[];

extern char  UART3_Rx_Buf[1000];

/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
 * @brief  This function handles NMI exception.
 */
void NMI_Handler(void)
{
}

/**
 * @brief  This function handles Hard Fault exception.
 */
void HardFault_Handler(void)
{
    /* Go to infinite loop when Hard Fault exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles Memory Manage exception.
 */
void MemManage_Handler(void)
{
    /* Go to infinite loop when Memory Manage exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles Bus Fault exception.
 */
void BusFault_Handler(void)
{
    /* Go to infinite loop when Bus Fault exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles Usage Fault exception.
 */
void UsageFault_Handler(void)
{
    /* Go to infinite loop when Usage Fault exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles SVCall exception.
 */
void SVC_Handler(void)
{
}

/**
 * @brief  This function handles Debug Monitor exception.
 */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
	//printf("systick..\r\n");
	TimingDelay_Decrement();
}

/******************************************************************************/
/*                 N32G45X Peripherals Interrupt Handlers                     */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_n32g45x.s).                                                 */
/******************************************************************************/

/**
 * @brief  This function handles TIM2 global interrupt request.
 */
int cnt = 0;
int AG_cnt = 0;
const int FRE = 100;
const int AG_FRE = 2;//20ms的计数
int COUNT = 0;
void TIM2_IRQHandler(void)
{
    if (TIM_GetIntStatus(TIM2, TIM_INT_CC1) != RESET)
    {
        TIM_ClrIntPendingBit(TIM2, TIM_INT_CC1);
        capture = TIM_GetCap1(TIM2);

		TIM_SetCmp1(TIM2, capture + MY_CCR_Val);

		//1s标记
		cnt++; 
		if(cnt == FRE){
			//1秒
			timer1sProcess();
		}
		cnt = cnt % FRE;	

		//20ms标记
		AG_cnt++;
		if(AG_cnt == AG_FRE)
		{
			//打印adc1 adc3的采样值
			//printf("get adc1_ch1..%d...%d\r\n",ADC1_ConvertedValue, ADC3_ConvertedValue);
			timer20msProcess();
		}
		AG_cnt = AG_cnt % AG_FRE;
    }
}


/**
 * @brief  This function handles USART_DEBUG global interrupt request.
 */
u8 a[20]  = {0};
void USART_DEBUG_IRQHandler(void)
{

    if (USART_GetIntStatus(USART1, USART_INT_RXDNE) != RESET)
    {
        /* Read one byte from the receive data register */
		
		 UART1_RX_BUFFER[UART1_RX_LEN++] = USART_ReceiveData(USART1);
		if(UART1_RX_LEN >= UARTBUF_MAX_LEN)
		{
			UART1_RX_LEN = 0;	
		}	 
    }

}

/**
 * @brief  This function handles USARTz global interrupt request.
 */
void UART5_IRQHandler(void)
{

    if (USART_GetIntStatus(USART_WIFI, USART_INT_RXDNE) != RESET)
    {

		WIFI_RX_BUFFER[WIFI_RX_LEN++]=USART_ReceiveData(USART_WIFI);
		if(WIFI_RX_LEN >= WIFI_RX_BUFFER_LEN)
		{
			WIFI_RX_LEN = 0;	
		}
        
		USART_ClrIntPendingBit(USART_WIFI,USART_INT_RXDNE);

    } 
}


/**
 * 1s调用一次
*/
void timer1sProcess(){
	uint8_t i =0;
 
//	printf("1s....\r\n");
//		getSmapleData();
//		printf("transmitData:%6d,%6d,%6d,%6d,%6d,%6d,%6d,%6d\r\n",transmitData[0],transmitData[1],transmitData[2],transmitData[3],transmitData[4],transmitData[5],transmitData[6],transmitData[7]); //test code
	
	delaytime++;
	delaytime1++;
	Link_Time++;
	WiFi_Time++;  //WiFi模块等待时间
	GetSleepDataTimeCount++;				
	Command_SendCount = 0;
	SleepDataBuffer_SendTime++;
	IWDG_Feed();
	HeartBeat++;   //test code  220526
	RenewRealTime();	
	if((HeartBeat >= 240)&&(Flag_WiFiAPConfig !=1))   //test code!!! 
	{
		printf("WiFi device reset! heartbeat overtime!\r\n");
		NVIC_SystemReset();//复位 
	}
	if(Flag_TimeAdj != 0)
	{
		Adj_Time++;
		if( Adj_Time == 60)
		{
			Adj_Time = 0;
			if(Flag_TimeAdj == 2)
				Flag_TimeAdj = 1;
			if(Flag_TimeAdj == 3)
				Flag_TimeAdj = 0; 					
		}			
	}
	if(Flag_SendLinkStatus == 1)
	{
		SendLinkStatus_Time++;
	}
	if(APP_Receive_Right == 1)   //指令字符串接收时间
	{
		BLE_ReceiveDataTime++;
	}			 
	if(LinkStep != SENDSLEEPDATA)
	{
		WifiUnconnectTime++;   //lqs add 220511
		//3分钟未联网，进行设备复位(配网中不复位)    lqs add 220511
		if(Flag_LED_Status == LED_WIFI_CONFIG)
			WifiUnconnectTime = 0;
		if((LinkStep != SENDSLEEPDATA)&&(WifiUnconnectTime >= 180)&&(Flag_WiFiAPConfig !=1))
		{
			printf("WiFi device reset!\r\n");
			NVIC_SystemReset();//复位  test code！
		}
		
		
//		if(Flag_COMDebug == 1)
//			printf("WifiUnconnectTime = %d s\r\n",WifiUnconnectTime);
		
		WIFI_ConnetTime++;
		if(WIFI_ConnetTime%60==0)
		{
			
//			if(Flag_COMDebug == 1)
//				printf("WIFI_ConnetTime = %d s\r\n",WIFI_ConnetTime); 
		}			
	}
	else
		WifiUnconnectTime = 0;
	
	if(Flag_InitStatus == WIRELESS_INIT)
	{
		WiFi_InitTime++;
	}
	if(Flag_CanSendStatistData == 2)
	{
		CanSendStatistTime++;
		if(CanSendStatistTime == 10)
		{
			CanSendStatistTime = 0;
			Flag_CanSendStatistData = 1;
		}
	}
	if(Flag_ADC_ADJ == 1)
	{
		ADC_AdjTime++;
	}
	if(Flag_InitStatus == CONTINUE_SENDDATA)
	{
		Time_NetworkInquire++;
	}
	
	#ifdef ENABLE_SENDPRESSSERSONSTATUS
	if(Flag_SendPresensorStatus == 1)  //发送压力状态
	{
		SendPresensorStatus_Time++;
	}
	#endif
	//-----------------脱离监测时，5min后数据发送时间间隔加长-----------					
	if(gPeopleFlag == TRUE)   //人员在线，清除计时，数据发送时间3s
	{
		if(Flag_Binding_Users == BINDING_USERS_YES)
		{
			if((RealTime[3] >= 9)&&(RealTime[3] <= 17)) //9~18点3秒1帧、其余10秒一帧
				SleepData_SendTime = SLEEPDATA_SENDTIME_3S; 
			else
				SleepData_SendTime = SLEEPDATA_SENDTIME_10S; 
		}
		Monitor_Offline_Time = 0;
	}
	if((gPeopleFlag == FALSE )&&(Monitor_Offline_Time >SLEEPDATA_CHANGETIME))
	{
		SleepData_SendTime = SLEEPDATA_SENDTIME_10S;
		Monitor_Offline_Time = SLEEPDATA_CHANGETIME;
	}		
	if((gPeopleFlag == FALSE)&&(Flag_PowerOn == 0))        //无人员并与服务器连接成功则开始计时，张炜2017525增加
	{
		Monitor_Offline_Time++;
	}	
	if(Flag_No_Binding_Users_Time == 1)  //未关联用户计时，张炜2017525增加
	{
		No_Binding_Users_Time++;
		if(No_Binding_Users_Time >= SLEEPDATA_CHANGETIME)
		{
			No_Binding_Users_Time = SLEEPDATA_CHANGETIME;
			SleepData_SendTime = SLEEPDATA_SENDTIME_10S;
		}
	}
	
	//---------------中午12点开始新的统计-------------------------------	
	if((RealTime[3] ==18)&&(RealTime[4] ==22)&&(RealTime[5] ==0)&&(LinkStep == SENDSLEEPDATA)) //定时终端管理数据上报
    {
        Flag_ReportAndlinkManagedata = 1;
    }
//	if((RealTime[3] ==12)&&(RealTime[4] ==0)&&(RealTime[5] ==0)&&(Flag_PowerOn == 0)&&(LinkStep != SENDSLEEPDATA))      //每天中午12点统计一次数据
//	{
//        
//		Statist_NextDayStart();
//	}
		
}

/**
 * 20ms调用一次
*/

void timer20msProcess(){
	LedFlash+=20;										//控制灯的闪烁
		
//	if(Flag_LED_Status > 0)	
		LED_Status();
	
	if(Flag_PowerOn == 0)
	 {
		OnbedStatus_CountTimer++;
		 SleepDataCalculate();
	 }
}


/**
 * @}
 */
