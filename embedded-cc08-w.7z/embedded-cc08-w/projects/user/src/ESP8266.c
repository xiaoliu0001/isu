/******************************************************************************
 * @file     ESP8266.c
 * @brief   WiFiͨѶ����
 * @version  v1.1
 * @date     2023.05
 * @note
 * Copyright (C)  
 *
 * @par      ���201810
 *    V1.0    ESP8266 WiFiģ��ͨѶ����
 *    V 1.1   ����ESP8266_GetIPDd�Ⱥ���
*******************************************************************************/


#include "ESP8266.h"
#include "Delay.h"

#include "cJSON.h"
#include "coap_client.h"
#include "MobileAndlink.h"

#define htons(n) 				(((n & 0xff) << 8) | ((n & 0xff00) >> 8))
#define htonl(n) 				(((n & 0xff) << 24) | ((n & 0xff00) << 8) | ((n & 0xff0000UL) >> 8) | ((n & 0xff000000UL) >> 24))
#define ntohs(n) 				htons(n)
#define ntohl(n) 				htonl(n)

uint8_t Flag_MuxLink = 0;
uint8_t MuxLink_ID = 0;  //��·���ӵ�id����Χ0-4
uint8_t AP_Channel=0;          //AP���ӵ��ŵ�
static uint8_t WiFiSmartConfig = 0;
char cmd[100]="";
uint16_t esp8266_cntPre = 0;
int Local_IP[4];
Router_Para Router_Info;

/****************************************************************************
*	�� �� ��: WIFI_GPIO_CONFIG
*	����˵��: ����ģ��IO����
*	��    �Σ�
*	�� �� ֵ:
* ˵    ����
*****************************************************************************/
void WIFI_GPIO_CONFIG(void)
{
   GPIO_InitType GPIO_InitStructure;
	
	RCC_EnableAPB2PeriphClk(WIFI_POWER_GPIO_CLK, ENABLE); 				 							   
	GPIO_InitStructure.Pin = WIFI_POWER_PIN ;	   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_InitPeripheral(WIFI_POWER_GPIO_PORT, &GPIO_InitStructure);
	
	RCC_EnableAPB2PeriphClk(WIFI_EN_GPIO_CLK, ENABLE); 				 							   
	GPIO_InitStructure.Pin = WIFI_EN_PIN ;	   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_InitPeripheral(WIFI_EN_GPIO_PORT, &GPIO_InitStructure);
			

    WIFI_EN(0);
    delay_ms(500);
    WIFI_POWER(1);
    WIFI_EN(1);
}
/****************************************************************************
*	�� �� ��: WIFI_INIT
*	����˵��: ����ģ���ʼ��
*	��    �Σ�
*	�� �� ֵ:���س�ʼ����ɵĲ���
* ˵    ����
*****************************************************************************/
char WIFI_INIT(void)
{
	 uint8_t buf[5];

//-------����ATָ��ģʽ---------------------------------
	if(Flag_WIFIInitStep == WIFI_INIT_STEP1)
	{	
        if(Flag_COMDebug==1)
            printf("Flag_WIFIInitStep...%d\r\n",Flag_WIFIInitStep);        
		if(WIFI_Open_cmdMode()==WIFI_SUCCESS)
		{
			if(Flag_PowerOn == 1)
				Flag_WIFIInitStep = WIFI_INIT_STEP2;
			else
				Flag_WIFIInitStep = WIFI_INIT_STEP3;
		}
		else     //ATָ��ģʽ�޷����룬��λģ��
		{
			if(WiFi_InitTime>=NETWORKLINK_TIMEOUT_30S)
			{

				//WIFI_POWER(0);
				WIFI_EN(0);
				delay_ms(5000);
				WIFI_POWER(1);
				WIFI_EN(1);
				delay_ms(500);	
				//Flag_DataSendMode = WIFI_DATASEND_ATMODE;   //ATģʽ
				WiFi_InitTime = 0;
			}
				delay_ms(2000);				 
				return WIFI_INIT_STEP1;
		} 
	}	 
//-------wifiģ������---------------------------------
	if(Flag_WIFIInitStep == WIFI_INIT_STEP2)
	{
        if(Flag_COMDebug==1)
            printf("Flag_WIFIInitStep...%d\r\n",Flag_WIFIInitStep);    
        
        #ifdef Enable_ESP8266_Config_AP
            if(WIFI_Set_Mode(WIFIMODE_STA) != WIFI_SUCCESS)
            {
                WIFI_Reset();
                delay_ms(500);
                Flag_WIFIInitStep = WIFI_INIT_STEP1;
                return  WIFI_INIT_STEP1;
            }        
//           if((ESP8266_SerchAP(TESTROUTERNAME) ==0) ||(Flag_WiFiAPConfig == 1))  // ɨ���Ƿ���ָ�����Ƶ�WiFi
           if((ESP8266_SerchAP(Router_Info.SSID) ==0) ||(Flag_WiFiAPConfig == 1))    ////��������ڣ������AP����ģʽ 
           {
               Flag_WiFiAPConfig =1;
               if(ESP8266_SoftAPConfig() ==1)  //�����ɹ�
               {                 
                   if(ReadAndlinkinfoFromFlash() == 1)
                   {
                        WIFI_Set_TCPConnectIP(URL_GETAHOST_IP,URL_GETAHOST_PORT);
                       Andlink_DeviceRegist();
                        BroadcastRegistResultByCoap();  
                   }
                   Flag_WiFiAPConfig = 0;
                  Flag_WIFIInitStep = WIFI_INIT_STEP4;
				  WiFi_InitTime = 0;
				  Flag_LED_Status = LED_WIRELEE_INIT; 
               }
               else //ʧ�������½�������
              {
                   WIFI_Reset();
				   delay_ms(500);
                   Flag_WIFIInitStep = WIFI_INIT_STEP1;
				   return  WIFI_INIT_STEP1;
               }
       
           }
           else  //������������Ӹ�WiFi
           {
                WIFI_Query_Ver();
                WIFI_Set_ATE(0);  //�ر�ָ�����
                WIFI_OpenDHCP();
                          
                WIFI_Set_MUXLINK(0);  //������
               Flag_WIFIInitStep = WIFI_INIT_STEP3;
           }
        #endif        
        
        
        #ifdef  Enable_ESP8266_Config_Smart
		if(WIFI_Set_Mode(WIFIMODE_STA) != WIFI_SUCCESS)
		{
			WIFI_Reset();
			delay_ms(500);
			Flag_WIFIInitStep = WIFI_INIT_STEP1;
			return  WIFI_INIT_STEP1;
		}
        WIFI_Query_Ver();
		WIFI_Set_ATE(0);  //�ر�ָ�����
		WIFI_OpenDHCP();
                  
		WIFI_Set_MUXLINK(0);  //������
        
		if(Flag_WiFiSmartConfig ==1)  //��WiFi���棬��������������
		{
			if(WiFi_SmartConfig() == WIFI_SUCCESS)  //����
			{			
				Flag_WIFIInitStep = WIFI_INIT_STEP4;
				WiFi_InitTime = 0;
				Flag_WiFiSmartConfig = 0;
				Flag_LED_Status = LED_WIRELEE_INIT; 
			}
			else
			{
				WiFiSmartConfig++;
				if(WiFiSmartConfig>4)
				{
					WiFiSmartConfig = 0;
					Flag_WiFiSmartConfig = 0;
					//WIFI_POWER(0);
					WIFI_EN(0);
					delay_ms(5000);
					WIFI_POWER(1);
					WIFI_EN(1);
					delay_ms(500);
					if(Flag_COMDebug == 1)
					{
						printf("Smart config time out,reconnected\r\n");
					}
				}
				else
				{
					WIFI_Reset();
					delay_ms(500);
				}
				Flag_WIFIInitStep = WIFI_INIT_STEP1;
				return  WIFI_INIT_STEP1;
			}
		}
		else
		{
			Flag_WIFIInitStep = WIFI_INIT_STEP3;
		}
        #endif
	}
//-------·��������״̬---------------------------------	 
	if(Flag_WIFIInitStep == WIFI_INIT_STEP3)
	{
         if(Flag_COMDebug==1)
            printf("Flag_WIFIInitStep...%d\r\n",Flag_WIFIInitStep);     
		if(WIFI_Set_STASSID(Router_Info.SSID,Router_Info.password)== WIFI_SUCCESS)
//		if(WIFI_Set_STASSID(TESTROUTERNAME,TESTROUTERPWD)== WIFI_SUCCESS)
		{
            if(Flag_COMDebug == 1)
            {
                printf("WiFi connected to :%s \r\n",TESTROUTERNAME);
            }
                
			//if(Flag_Reset_RouterSSID ==1)
			//{
			//	buf[0] = SET_ROUTER_NAME;
			//	buf[1] = MODULESTATUS_LINKSERVER;			 
//				APP_Send_Order(buf,2);	
			//}
			Flag_WIFIInitStep = WIFI_INIT_STEP4;	     
		}
		else
		{					
			delay_ms(1000);
			//printf("WiFi_InitTime=%d s\r\n",WiFi_InitTime);
			if(WiFi_InitTime>=NETWORKLINK_TIMEOUT_30S)
			{
				if(Flag_COMDebug == 1)
				{
					printf("WiFi connect time out:%d s\r\n",WiFi_InitTime);
				}
				WiFi_InitTime = 0;
				//WIFI_POWER(0);
				WIFI_EN(0);
				delay_ms(5000);
				WIFI_POWER(1);
				WIFI_EN(1);
				delay_ms(500);
				if(Flag_PowerOn == 1)
				{
					Flag_WiFiSmartConfig = 1;  //��������wifi
					WiFiSmartConfig = 0;	
                    
					if(Flag_COMDebug == 1)
					{
						printf("RePower and start smart config\r\n");
					}
				}
				Flag_WIFIInitStep = WIFI_INIT_STEP1;
				
				memset(&(Router_Info.SSID),0,sizeof(Router_Info.SSID));
				memset(&(Router_Info.password),0,sizeof(Router_Info.password));
				Flag_WiFiAPConfig =1;
				
				return  WIFI_INIT_STEP1;
			}
			else
			{
				return  WIFI_INIT_STEP3;
			}
		}					
	}
	if(Flag_WIFIInitStep == WIFI_INIT_STEP4)
	{
        if(Flag_COMDebug==1)
            printf("Flag_WIFIInitStep...%d\r\n",Flag_WIFIInitStep);     
		WIFI_Query_STA_RSSI();
        
        if(ReadAndlinkinfoFromFlash() == 0)  //�����ע�᷵����Ϣ��������豸ע��
        {
            WIFI_Set_TCPConnectIP(URL_GETAHOST_IP,URL_GETAHOST_PORT);
            if (Andlink_DeviceRegist()==0) //ע�᲻�ɹ�����Ҫ����ע��
            {
                return WIFI_INIT_STEP4;
            }
            BroadcastRegistResultByCoap();  //ע�����ɹ��㲥����һ����Ҫ,coapָ����Ҫ�ر�TCP���ӣ�����UDP���ӣ��ʸ�ָ��֮����Ҫ��������TCP����
			BroadcastAccessInNetworkByCoap();
        }
   
		Flag_WIFIInitStep = WIFI_INIT_STEP5;
		return WIFI_INIT_STEP5;
	}
}

/****************************************************************************
*	�� �� ��: WIFI_Open_cmdMode
*	����˵��: enter AT command mode from easytxrx mode
*	��    �Σ�
*	�� �� ֵ: 0��ʾ�ɹ�
* ˵    ����
*****************************************************************************/
char WIFI_Open_cmdMode(void)
{  
	 *cmd='\0';

	sprintf(cmd, "AT+CIPMODE?\r\n");	
	//WIFI_USART_Send(cmd, strlen(cmd));
	UART5_SendString(cmd);
	ClearUSARTBUF(WIFI_USART);
	WiFi_Time =0;
	if(Flag_COMDebug == 1)
	{
		printf("Set WiFi in AT mode\r\n");
	}
	delay_ms(50);
	
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"+CIPMODE:0")!=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("WiFi has in AT mode\r\n");
			}
			return  WIFI_SUCCESS;
		}
		if(strstr(WIFI_RX_BUFFER,"+CIPMODE:1")!=NULL)
		{
			sprintf(cmd, "AT+CIPMODE=0\r\n");	
			WIFI_USART_Send(cmd, strlen(cmd));
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("WiFi not in AT mode\r\n");
			}
			return  WIFI_FAIL;
		}
		if(WiFi_Time > WIFI_3S_TIMEOUT )
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set WiFi in AT mode time out:%s\r\n",WIFI_RX_BUFFER);
			}
			ClearUSARTBUF(WIFI_USART);
			return  WIFI_FAIL;
		}
	}

						
}
/****************************************************************************
*	�� �� ��: WIFI_Query_STA_RSSI
*	����˵��: ��ѯSTAģʽ��rssi���������ź�ǿ��
*	��    �Σ�
*	�� �� ֵ: �����ź�ǿ������
* 	˵    ������ѯSTA����״̬��AP�ź�ǿ��
*	+CWJAP_CUR:"zangwii2008","14:cf:92:bb:03:df",6,-42
*
*	OK
*****************************************************************************/
char WIFI_Query_STA_RSSI(void)
{
	char stringbuf1[20]={0};
	int csq= 0;
	
	delay_ms(10); 
	ClearUSARTBUF(WIFI_USART);
	WIFI_Query_rssi();
	WiFi_Time =0;
	delay_ms(10);	
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"+CWJAP_CUR:") !=NULL)   //���ص�ǰ���ӵ�AP��Ϣ
		{
			sscanf(WIFI_RX_BUFFER,"%*[^:]: %*[^,],%*[^,],%d,%d\r\n%s",&AP_Channel,&csq,stringbuf1)	;								
			CSQNual = 113+ csq;
			CSQNual /= 2;
			if(Flag_COMDebug == 1)
			{
				printf("csq:%d apch:%d \r\n",CSQNual,AP_Channel);
			}
			return WIFI_CONNECT;
		}
		if((strstr(WIFI_RX_BUFFER,"No AP")) !=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			return WIFI_NOCONNECT;
		}
		if(WiFi_Time>WIFI_3S_TIMEOUT) 
		{
			if(Flag_COMDebug == 1)
			{
				printf("Read rssi Time OUT:%s\r\n",WIFI_RX_BUFFER);
			}
			ClearUSARTBUF(WIFI_USART);
			return WIFI_FAIL ;
		}	
		if(strstr(WIFI_RX_BUFFER,"ERROR") != NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			WIFI_Query_rssi();
			delay_ms(10);	
		}
	}
	
}

/****************************************************************************
*	�� �� ��: WIFI_Set_Mode
*	����˵��: ���ù���ģʽ
*	��    �Σ�mode  ����ģʽ
*	�� �� ֵ: 
* 	˵    ��������Ĭ�ϵĹ���ģʽ
*****************************************************************************/
char WIFI_Set_Mode(uint8_t mode)
{
	uint8_t count=0;
	
	char modebuf[20] = "";
	*cmd='\0';
	if(Flag_COMDebug == 1)
	  {
		  printf("Set wifi mode:%d\r\n",mode);
	  }	
			  
//	sprintf(cmd, "AT+CWMODE?\r\n");
//	sprintf(modebuf, "+CWMODE:%d\r\n",mode);
//	WIFI_USART_Send(cmd, strlen(cmd));
//	ClearUSARTBUF(WIFI_USART);
//	delay_ms(10);
//	WiFi_Time = 0;
//	while(1)
//	{
//		 if(strstr(WIFI_RX_BUFFER,modebuf) != NULL)  //�Ѿ��Ǹù���ģʽ����ֱ�ӷ��أ�������������
//		 {
//			  if(Flag_COMDebug == 1)
//			  {
//					printf("WIFI has in this mode\r\n");
//			  }					
//			  return WIFI_SUCCESS ;
//		 }
//		 else
//		 {
//			  break;
//		 }
//		 if(WiFi_Time>WIFI_3S_TIMEOUT)
//		 {
//			 if(Flag_COMDebug == 1)
//			 {
//				 printf("Inquire wifi mode time out");
//			 }
//			 break;
//		 }
//	}
	sprintf(cmd, "AT+CWMODE=%d\r\n",mode);
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delay_ms(200);
	WiFi_Time = 0;
	count = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"OK") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set WIFI  mode Successed\r\n");
			}
			delay_ms(100);
			WIFI_Reset();
			delay_ms(2000);
			WIFI_Open_cmdMode();
			return WIFI_SUCCESS ;
		}
		else
		{
			WIFI_USART_Send(cmd, strlen(cmd));
			ClearUSARTBUF(WIFI_USART);
			delay_ms(200);
			count++;
		}
		if((count>5)||(WiFi_Time>WIFI_5S_TIMEOUT))
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set WIFI  mode time out\r\n");
			}
			return WIFI_FAIL ;
		}
	}
		
}
/****************************************************************************
*	�� �� ��: WIFI_Set_STASSID
*	����˵��: ����STAģʽ���ӵ�·����ssid������
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*	AT+CWJAP="zangwii2008","zw853429"
*
*	WIFI CONNECTED
*	WIFI GOT IP
*
*	OK
*	AT+CWJAP_DEF="zangwii2008","zw853429"
*
*	WIFI DISCONNECT
*	WIFI CONNECTED
*	WIFI GOT IP

*	OK
*****************************************************************************/
char WIFI_Set_STASSID(char *stassid,char *stapwd)
{
	//char cmd[100]="";
	*cmd='\0';
	sprintf(cmd,"AT+CWJAP_CUR=\"%s\",\"%s\"\r\n",stassid,stapwd);
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delay_ms(100);
	delaytime = 0;
	if(Flag_COMDebug == 1)
	{
		printf("Connect to wifi:%s,%s\r\n",stassid,stapwd);
		printf("AT+CWJAP_CUR=\"%s\",\"%s\"\r\n",stassid,stapwd);
	}
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"OK") != NULL)
		{				  				
			if(Flag_COMDebug == 1)
			{
				printf("Set ssid  Successed\r\n");
			}
			return WIFI_SUCCESS ;
		}
		if(strstr(WIFI_RX_BUFFER,"+CWJAP=1") != NULL)  //�������ӳ�ʱ
		{
			if(Flag_COMDebug == 1)
			{
				printf("Link time out!\r\n");
			}
			return WIFI_FAIL ;
		}
		if(strstr(WIFI_RX_BUFFER,"+CWJAP=2") != NULL)//�����������
		{
			if(Flag_COMDebug == 1)
			{
				printf("STA password error:%s\r\n",stapwd);
			}
			return WIFI_FAIL ;
		}
		if(strstr(WIFI_RX_BUFFER,"+CWJAP=3") != NULL)//�����Ҳ���AP
		{
			if(Flag_COMDebug == 1)
			{
				printf("Can't find AP:%s\r\n",stassid);
			}
			return WIFI_FAIL ;
		}
		if(strstr(WIFI_RX_BUFFER,"+CWJAP=4") != NULL)//��������ʧ��
		{
			if(Flag_COMDebug == 1)
			{
				printf("Link AP failed:%s\r\n",stassid);
			}
			return WIFI_FAIL ;
		}
		if(delaytime>WIFI_10S_TIMEOUT)
		{			 
			if(Flag_COMDebug == 1)
			{
				printf("Set ssid  failed\r\n");
			}
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Req_STASSID
*	����˵��: ��ѯwifiģ�����ӵ�·�������ƺ�����
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_Req_STASSID(void)
{
	//char cmd[20]="";
	char *pstr=NULL;
	uint8_t len=0;
	uint8_t i=0;
//	char buf[50];
	*cmd='\0';
	WIFI_Open_cmdMode();
	delay_ms (10);
	sprintf(cmd,"AT+CWJAP_CUR?\r\n");
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delaytime = 0;
	while(1)
	{			
		pstr = strstr(WIFI_RX_BUFFER,"AT+CWJAP_CUR:");
		if(pstr != NULL)
		{
			delay_ms (10);
			memcpy(RouterName_InWIFI,0x00,75);
			for(i=0;i<WIFI_RX_LEN-15;i++)
			{
				RouterName_InWIFI[i]=pstr[i+13];
			}
			ClearUSARTBUF(WIFI_USART);
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_5S_TIMEOUT)
		{			 
			if(Flag_COMDebug == 1)
			{
				printf("Req ssid  failed\r\n");
			}
			return WIFI_FAIL ;
		}
	}
	
	
}
/****************************************************************************
*	�� �� ��: WIFI_Set_TCPConnectIP
*	����˵��: ����ip�Ͷ˿ں�
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_Set_TCPConnectIP(char *ip,char *port)
{
	//char cmd[100]= "";
	*cmd='\0';
    
    if(Flag_MuxLink == MUXLINK_MULTI)
    {
        sprintf(cmd,"AT+CIPSTART=%d,\"TCP\",\"%s\",%s\r\n",MuxLink_ID,ip,port);
    }
    else
    {
        sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",ip,port);
    }
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delay_ms(50);
	WiFi_Time = 0;
	if(Flag_COMDebug == 1)
	{
		printf("\r\n%s",cmd);
	}
	while(1)
	{
		if((strstr(WIFI_RX_BUFFER,"CONNECT") != NULL)&&(strstr(WIFI_RX_BUFFER,"OK") != NULL))
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set IP successed\r\n");
			}        					
			return WIFI_SUCCESS ;
		}
		if(strstr(WIFI_RX_BUFFER,"ERROR") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set IP failed\r\n");
			}        					
			return WIFI_FAIL ;
		}
		if(strstr(WIFI_RX_BUFFER,"ALREAY CONNECT") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("IP has connect\r\n");
			}        					
			return WIFI_SUCCESS ;
		}
		if(WiFi_Time>WIFI_20S_TIMEOUT)
		{	       				 
			if(Flag_COMDebug == 1)
			{
				printf("Set IP failed��%s\r\n",WIFI_RX_BUFFER);
			}
			return WIFI_FAIL ;
		}
	}
	
}
/****************************************************************************
*	�� �� ��: WIFI_Close_TCPConnect
*	����˵��: �ر�TCP����
*	��    �Σ�linkID ���Ӻţ�Ϊ5ʱ�ر���������
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_Close_TCPConnect(uint8_t linkID)
{
	//char cmd[30]="";
	*cmd='\0';
	ClearUSARTBUF(WIFI_USART);
    if(Flag_MuxLink == MUXLINK_MULTI)
    {
        sprintf(cmd, "AT+CIPCLOSE=%d\r\n",linkID);
    }
    else
    {
       sprintf(cmd, "AT+CIPCLOSE\r\n"); 
    }
	WIFI_USART_Send(cmd, strlen(cmd));
	delaytime = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"OK") != NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(strstr(WIFI_RX_BUFFER,"ERROR") != NULL)
		{
			return WIFI_FAIL ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{
			return WIFI_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Reset
*	����˵��: reset module
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void WIFI_Reset(void)
{	 
	//char cmd[30]="";
	*cmd='\0';
	ClearUSARTBUF(WIFI_USART);
	sprintf(cmd, "AT+RST\r\n");
	WIFI_USART_Send(cmd, strlen(cmd));
	delaytime = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"ERROR") != NULL)
		{
			WIFI_USART_Send(cmd, strlen(cmd));
			ClearUSARTBUF(WIFI_USART);
		}
		if(strstr(WIFI_RX_BUFFER,"OK") != NULL)
		{
			//Flag_DataSendMode = WIFI_DATASEND_ATMODE;   //ATģʽ
			return ;
		}
		if(delaytime>WIFI_5S_TIMEOUT)
		{
			return ;
		}
	}
	  
}
/****************************************************************************
*	�� �� ��: WIFI_Restore
*	����˵��: restore to factory mode
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void WIFI_Restore(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+RESTIRE\r\n");
    WIFI_USART_Send(cmd, strlen(cmd));
}

/****************************************************************************
*	�� �� ��: WIFI_OpenDHCP
*	����˵��: ����DHCP
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_OpenDHCP(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CWDHCP_DEF=1,1\r\n");
    WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delaytime = 0;
	while(1)
	{			
		if(strstr(WIFI_RX_BUFFER,"OK") != NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
	
}
/****************************************************************************
*	�� �� ��: WIFI_Query_constatus
*	����˵��: ��ѯSTA����״̬
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void WIFI_Query_STAStatus(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CIPSTATUS\r\n");
    WIFI_USART_Send(cmd, strlen(cmd));
	 
}

/****************************************************************************
*	�� �� ��: WIFI_Query_rssi
*	����˵��: ��ѯ��ǰ���ӵ��ź�ǿ��
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void WIFI_Query_rssi(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CWJAP_CUR?\r\n");
    WIFI_USART_Send(cmd, strlen(cmd));
}
/****************************************************************************
*	�� �� ��: WIFI_Query_rssi
*	����˵��: ��ѯ��ǰ���ӵ��ź�ǿ��
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void WIFI_Query_Ver(void)
{
    
     char  *p1,*p2;
    //char Ver[100]={0};
    
    *cmd='\0';
    sprintf(cmd, "AT+GMR\r\n");
    ClearUSARTBUF(WIFI_USART); 
    WIFI_USART_Send(cmd, strlen(cmd));
    delay_ms(10);
	delaytime = 0;
    while(1)
	{
        p1 = strstr(WIFI_RX_BUFFER, "AT version");
        p2 = strstr(WIFI_RX_BUFFER, "OK");
		if((p1!=NULL)&&(p2!=NULL))
		{
             //memcpy (Ver,p1,p2-p1); //Խ�����
			if(Flag_COMDebug == 1)
			{
				*p2 = '\0';
				printf("WiFiģ��汾��Ϣ:\r\n%s\r\n",p1);
			}            
			return  ;
		}

		if(delaytime>WIFI_1S_TIMEOUT)
		{			 
			return  ;
		}
	}
    
}
/****************************************************************************
*	�� �� ��: WIFI_Set_MUXLINK
*	����˵��: ���ö�����
*	��    �Σ�linknum ������
*	�� �� ֵ: 
* 	˵    ����0Ϊ�����ӣ�1Ϊ������
*****************************************************************************/
char WIFI_Set_MUXLINK(uint8_t linknum)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CIPMUX=%d\r\n",linknum);
    WIFI_USART_Send(cmd, strlen(cmd));
    if(linknum == 1)
    {
      Flag_MuxLink = MUXLINK_MULTI;  
    }
    else
    {
        Flag_MuxLink = MUXLINK_SINGLE;  
    }
	delay_ms(50);
	delaytime = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"OK")!=NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(strstr(WIFI_RX_BUFFER,"ERROR")!=NULL)
		{
			return WIFI_FAIL ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Set_ATE
*	����˵��: �����Ƿ���ָ�����
*	��    �Σ�status �Ƿ����
*	�� �� ֵ: 
* 	˵    ����0Ϊ�����ӣ�1Ϊ������
*****************************************************************************/
char WIFI_Set_ATE(uint8_t status)
{
    //char cmd[30]="";
	*cmd='\0';
	if(status == 1)
	{
		sprintf(cmd, "ATE1\r\n"); //��������
	}
	else
	{
		sprintf(cmd, "ATE0\r\n"); //�رջ���
	}
    WIFI_USART_Send(cmd, strlen(cmd));
	delay_ms(50);
	delaytime = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"OK")!=NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Query_tcpstatus
*	����˵��: query tcp status
*	��    �Σ�
*	�� �� ֵ: 0��ʾδ���ӣ�1��ʾ���ӣ�-1��ʾ����
* 	˵    ����
*****************************************************************************/
char WIFI_Query_TCPStatus(void)
{
	//char cmd[30]="";
	char *pstr;
	*cmd='\0';
	delay_ms(10);
	ClearUSARTBUF(WIFI_USART);
	WIFI_Query_STAStatus();
	delay_ms(50);
	WiFi_Time = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"STATUS:3")!=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("TCP has connected\r\n");
			}
			return WIFI_TCP_CONNECT;
		}	
		if(strstr(WIFI_RX_BUFFER,"STATUS:4")!=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("TCP has not connected!!!\r\n");
			}
			return WIFI_TCP_NOCONNECT;
		}
		if(strstr(WIFI_RX_BUFFER,"STATUS:5")!=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("WiFi has not connect!!\r\n");
			}
			return WIFI_NOCONNECT;
		}		
		if(WiFi_Time > WIFI_10S_TIMEOUT )
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("Read sta status time out:%s\r\n",WIFI_RX_BUFFER);
			}
			return WIFI_FAIL;			
		}

	}
}
/****************************************************************************
*	�� �� ��: WIFI_ConnectIPCompare
*	����˵��: �豸�����IP��wifi���ӵ�ip���бȽ�
*	��    �Σ�
*	�� �� ֵ:1��ʾ�ɹ�,0��ʾʧ�ܣ�-1��ʾһ������ʧ��
* 	˵    ����
*****************************************************************************/
char WIFI_ConnectIPCompare(void)
{
   //char cmd[30]="";
	char *pstr;
	*cmd='\0';
	sprintf(cmd, "AT+CIPSTATUS\r\n");	
	WIFI_USART_Send(cmd, strlen(cmd));

	ClearUSARTBUF(WIFI_USART);
	WIFI_Query_STAStatus();
	delay_ms(50);
	WiFi_Time = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"+CIPSTATUS")!=NULL)
		{
			delay_ms(50);
			 if( strstr(WIFI_RX_BUFFER,IP2) != NULL)
			 {
				  if(Flag_COMDebug == 1)
				  {
						printf("IP2 has connected\r\n");
				  }					
				  return WIFI_SUCCESS ;
			 }
			 else
			 {
				 if(Flag_COMDebug == 1)
				  {
						printf("Wifi connected error IP:%s\r\n",WIFI_RX_BUFFER);
				  }					
				  return WIFI_FAIL ;
			 }
		}				
		if(WiFi_Time > WIFI_5S_TIMEOUT )
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("Read sta status time out:%s\r\n",WIFI_RX_BUFFER);
			}
			return WIFI_FAIL;			
		}

	}
}
/****************************************************************************
*	�� �� ��: WIFI_SmartConfig
*	����˵��: ��������
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ���������������Ӻ󣬷��ص��������£�
*	AT+CWSTARTSMART=1
*	
*	OK
*	WIFI DISCONNECT
*	smartconfig type:ESPTOUCH
*	Smart get wifi info
*	ssid:iBreezee-DEV
*	password:dev201805
*	WIFI CONNECTED
*	WIFI GOT IP
*	smartconfig connected wifi
*****************************************************************************/
char WiFi_SmartConfig(void)
{
	char err = 0;
	char *pstr = NULL;
	char Flag_receivessid = 0;
	uint8_t Command_SendCount=0;
    
	Flag_LED_Status = LED_WIFI_CONFIG;
	
	if(Flag_COMDebug == 1)
	{
		printf("Start smart config!\r\n");
	}
	WiFi_Time = 0;		
	if(WIFI_Start_SmartConfig() == WIFI_SUCCESS)
	{
		ClearUSARTBUF(WIFI_USART);
        //printf("send msg to es8266 succeed\r\n");
        //printf("Flag_receivessid:%d\r\n",Flag_receivessid);
        printf("WiFi_SmartConfig:%s\r\n",WIFI_RX_BUFFER);
		while(1)
		{
			if((strstr(WIFI_RX_BUFFER,"Smart get wifi info") != NULL)&&(Flag_receivessid == 0))  //��ȡ��������Ϣ
			{
				        //printf("Smart get wifi info\r\n");

				delay_ms(50);
				pstr = strstr(WIFI_RX_BUFFER,"ssid:");
				pstr += 5;
				Router_NameLen = 0;
				while( *pstr != 0x0D)
				{
					Router_Name[Router_NameLen++] = *pstr;
					pstr++;
				}
				Router_Name[Router_NameLen] = '\0';
                //printf("Router_Name :%s\r\n",Router_Name);
				pstr = strstr(WIFI_RX_BUFFER,"password:");
				pstr += 9;
				Router_PWDLen = 0;
				while( *pstr != 0x0D)
				{
					Router_PWD[Router_PWDLen++] = *pstr;
					pstr++;
					
				}
				Router_PWD[Router_PWDLen] = '\0';
               //printf("Router_PWD :%s\r\n",Router_PWD);
				if(Flag_COMDebug == 1)
				{
					printf("Smart config info:Router_Name=%s;Router_PWD=%s\r\n",Router_Name,Router_PWD);
				}
				SaveRouterNameToFlash();
				Flag_receivessid = 1;
			}
			if((strstr(WIFI_RX_BUFFER,"WIFI GOT IP") != NULL)&&(Flag_receivessid == 1))
			{
                printf("WIFI GOT IP\r\n");
				delay_ms(500);
				Flag_receivessid = 0;
				ClearUSARTBUF(WIFI_USART);
				WIFI_Stop_SmartConfig();								
				return WIFI_SUCCESS;
			}
			if(WiFi_Time > WIFI_3MIN_TIMEOUT )  //test code  1min->3min
			{				
                printf("Smart config time out\r\n");
				printf("WiFi device reset!\r\n");
				NVIC_SystemReset();//��λ  test code��
				if(Flag_COMDebug == 1)
				{
					printf("Smart config time out:%s\r\n",WIFI_RX_BUFFER);
				}
				ClearUSARTBUF(WIFI_USART);
                
				return WIFI_FAIL;			
			}
		}
	}
	else
	{
		WIFI_Stop_SmartConfig();
		return WIFI_FAIL ;
	}
}
	
/****************************************************************************
*	�� �� ��: WIFI_Start_SmartConfig
*	����˵��: ��ʼsmartconfig
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*	�������ӵķ�ʽ�� 
*	0: ʹ�ð��ſ� AI-LINK ���� 
*	1: ʹ�� ESP-TOUCH ���� 
*	2: ʹ�� AIR-KISS ���� 
*   3�� ESP-TOUCH+AirKiss
*****************************************************************************/
char WIFI_Start_SmartConfig(void)
{
    //char cmd[30]="";
    //WIFI_Restore();//wifi�ָ���������
    //printf("clear 8266flash\r\n");
	*cmd='\0';
    sprintf(cmd, "AT+CWSTARTSMART=3\r\n");	//ʹ�� ESP-TOUCH+AirKiss ���� 
    WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delay_ms(50);
	WiFi_Time = 0;
	printf("AT+CWSTARTSMART=3\r\n");
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"OK") != NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Stop_SmartConfig
*	����˵��: ��ʼsmartconfig
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_Stop_SmartConfig(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CWSTOPSMART\r\n");	
    WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delay_ms(50);
	WiFi_Time = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"OK") != NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Send_data
*	����˵��: send data via socket
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
char WIFI_Send_data(uint8_t sock_fd, uint16_t send_len, uint8_t *buf)
{
    //char cmd[50]="";
	uint8_t count = 0;
	uint16_t  i,cnt = 0;
	*cmd='\0';
	ClearUSARTBUF(WIFI_USART);
    if(Flag_MuxLink == MUXLINK_MULTI)
    {
        sprintf(cmd,"AT+CIPSEND=%d,%d\r\n",MuxLink_ID,send_len);   
    }
    else
    {
        sprintf(cmd,"AT+CIPSEND=%d\r\n",send_len);   
    }
	WIFI_USART_Send(cmd,strlen(cmd));	  
	WiFi_Time = 0;
	count++;
	if(Flag_COMDebug == 1)
		printf("AT+CIPSEND=%d\r\n",send_len); 
	
	//ԭ����begin
	while(1)
	{
		delay_ms(5);
		if(strstr(WIFI_RX_BUFFER,">")!= NULL)
		{				 
			break;
		}

		if(WiFi_Time> WIFI_1S_TIMEOUT)
		{
			if(count>2)
			{
	//			if(Flag_COMDebug == 1)
	//			{
	//				printf("Send data to server failed\r\n");
	//			}
	//			return WIFI_FAIL ;
				break;
			}
			else
			{
				ClearUSARTBUF(WIFI_USART);
				sprintf(cmd,"AT+CIPSEND=%d\r\n",send_len);   
				WIFI_USART_Send(cmd,strlen(cmd));
				WiFi_Time = 0;
				count++;
			}
		}
	}
	//ԭ����end
	
	//test code begin 220525
//	for(i=0;i<600;i++)
//	{
//		cnt++;
//		delay_ms(5);
//		if(strstr(WIFI_RX_BUFFER,">")!= NULL)
//		{				 
//			break;
//		}

//		if(cnt> 200)
//		{
//			cnt = 0;
//			if(count>2)
//			{
//				break;
//			}
//			else
//			{
//				ClearUSARTBUF(WIFI_USART);
//				sprintf(cmd,"AT+CIPSEND=%d\r\n",send_len);   
//				WIFI_USART_Send(cmd,strlen(cmd));
//				WiFi_Time = 0;
//				count++;
//			}
//		}		
//	}
	//test code end 220525
	
	WIFI_USART_Send(buf,send_len);	
	WiFi_Time = 0;
	delay_ms(10);
	
	//test code begin 220525
//	for(i=0;i<600;i++)
//	{
//		delay_ms(5);
//		if(strstr(WIFI_RX_BUFFER,"SEND OK")!= NULL)
//		{
//			if(Flag_COMDebug == 1)
//			{
//				printf("Send data to server over\r\n");
//			}
//			return WIFI_SUCCESS ;
//		}
//		if(strstr(WIFI_RX_BUFFER,"ERROR") != NULL)
//		{
//			if(Flag_COMDebug == 1)
//			{
//				printf("TCP has not connect\r\n");
//			}
//			
//			return WIFI_TCP_NOCONNECT ;
//		}
//		if(i> 550)
//		{
//			if(Flag_COMDebug == 1)
//			{
//				printf("Send data to server failed\r\n");
//			}
//			return WIFI_FAIL ;
//		}
//	}	
	//test code end 220525
	
	//ԭ����begin
	while(1)
	{
		
		if(strstr(WIFI_RX_BUFFER,"SEND OK")!= NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("Send data to server over\r\n");
			}
			return WIFI_SUCCESS ;
		}
		if(strstr(WIFI_RX_BUFFER,"ERROR") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("TCP has not connect\r\n");
			}
			
			return WIFI_TCP_NOCONNECT ;
		}
		if(WiFi_Time> WIFI_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{
				printf("Send data to server failed\r\n");
			}
			return WIFI_FAIL ;
		}
	}	
	//ԭ����end
}

/****************************************************************************
*	�� �� ��: WIFI_USART_Send
*	����˵��: WiFi���ڷ�������
*	��    �Σ�tx_buf��Ҫ���͵�����  buflen���͵����ݳ���
*	�� �� ֵ: 
*   ˵    ����
*****************************************************************************/
void WIFI_USART_Send(char *tx_buf,uint16_t buflen)
{
    uint16_t i;
    uint32_t err_code;

	for (i=0; i<buflen; i++)
	{
		SendDataToUSART(WIFI_USART,tx_buf[i]);
        
	}  
}
/****************************************************************************
*	�� �� ��: ESP8266_WaitRecive
*	����˵��: �ȴ��������
*	��    �Σ���
*	�� �� ֵ: REV_OK-�������		REV_WAIT-���ճ�ʱδ���
*  ˵    ����ѭ�����ü���Ƿ�������
*           20230517����
*****************************************************************************/
char ESP8266_WaitRecive(void)
{

	if(WIFI_RX_LEN == 0) 							//������ռ���Ϊ0 ��˵��û�д��ڽ��������У�����ֱ����������������
		return REV_WAIT;
		
	if(WIFI_RX_LEN == esp8266_cntPre)				//�����һ�ε�ֵ�������ͬ����˵���������
	{
		WIFI_RX_LEN = 0;							//��0���ռ���
			
		return REV_OK;								//���ؽ�����ɱ�־
	}
		
	esp8266_cntPre = WIFI_RX_LEN;					//��Ϊ��ͬ
	
	return REV_WAIT;								//���ؽ���δ��ɱ�־

}
/****************************************************************************
*	�� �� ��: ESP8266_GetIPD
*	����˵��: ��ȡƽ̨���ص�����
*	��    �Σ��ȴ���ʱ��(����10ms)
*	�� �� ֵ: ƽ̨���ص�ԭʼ����
*  ˵    ����20230517����
*           ��ͬ�����豸���صĸ�ʽ��ͬ����Ҫȥ����
*			��ESP8266�ķ��ظ�ʽΪ	"+IPD,x:yyy"	x�������ݳ��ȣ�yyy����������
*****************************************************************************/
unsigned char *ESP8266_GetIPD(uint16_t timeOut)
{

	char *ptrIPD = NULL;
	
	do
	{
		if(ESP8266_WaitRecive() == REV_OK)								//����������
		{
//			printf("%s\r\n",WIFI_RX_BUFFER); //�������ʱʹ�ã�
            
			ptrIPD = strstr((char *)WIFI_RX_BUFFER, "+IPD,");				//������IPD��ͷ
			if(ptrIPD == NULL)											//���û�ҵ���������IPDͷ���ӳ٣�������Ҫ�ȴ�һ�ᣬ�����ᳬ���趨��ʱ��
			{
//				printf("\"IPD\" not found\r\n");
			}
			else
			{
				ptrIPD = strchr(ptrIPD, ':');							//�ҵ�':'
				if(ptrIPD != NULL)
				{
					ptrIPD++;
					return (unsigned char *)(ptrIPD);
				}
				else
					return NULL;
				
			}
		}
		
		delay_ms(10);
        timeOut--;//��ʱ�ȴ�
	} while(timeOut>0);
	
	return NULL;														//��ʱ��δ�ҵ������ؿ�ָ��

}
/****************************************************************************
*	�� �� ��: WIFI_Query_LocalIP
*	����˵��: ��ȡ����IP
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����ģ�鷵��,20230521����
*         +CIFSR:STAIP,"192.168.0.108"
*   +CIFSR:STAMAC,"24:d7:eb:c8:a1:72"
*****************************************************************************/
char WIFI_Query_LocalIP(void)
{
	//char cmd[30]="";
    char stringbuf1[30]={0};
	char *pstr;
	*cmd='\0';
	sprintf(cmd, "AT+CIFSR\r\n");	
	ClearUSARTBUF(WIFI_USART);
	WIFI_USART_Send(cmd, strlen(cmd));;
	delay_ms(10);
	WiFi_Time = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"+CIFSR:")!=NULL)
		{	          
            sscanf(WIFI_RX_BUFFER,"%*[^,],\"%d.%d.%d.%d\"\r\n%s",&Local_IP[0],&Local_IP[1],&Local_IP[2],&Local_IP[3],stringbuf1);            
			if(Flag_COMDebug == 1)
			{
				printf("Local ip:%d.%d.%d.%d\r\n",Local_IP[0],Local_IP[1],Local_IP[2],Local_IP[3]);
			}
            ClearUSARTBUF(WIFI_USART);
			return WIFI_TCP_CONNECT;
		}		
		if(WiFi_Time > WIFI_3S_TIMEOUT )
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("Read local ip time out:%s\r\n",WIFI_RX_BUFFER);
			}
			return WIFI_FAIL;			
		}
        delay_ms(10);
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Set_UDPConnect
*	����˵��: UDP����ip�Ͷ˿ں�
*	��    �Σ�
*	�� �� ֵ: 
*   ˵    ����20230521����
*****************************************************************************/
char WIFI_Set_UDPConnect(char *ip,char *port,char *localport)
{
	//char cmd[100]= "";
	*cmd='\0';
    
    if(Flag_MuxLink == MUXLINK_MULTI)
    {
        sprintf(cmd,"AT+CIPSTART=%d,\"UDP\",\"%s\",%s,%s,0\r\n",MuxLink_ID,ip,port,localport); //mode =0 ��ʾ������Զ��Ŀ��
    }
    else
    {
       sprintf(cmd,"AT+CIPSTART=\"UDP\",\"%s\",%s,%s,0\r\n",ip,port,localport); //mode =0 ��ʾ������Զ��Ŀ�� 
    }
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
     if(Flag_COMDebug == 1)
    {
        printf("UDP connect:%s",cmd);
    }   
	delay_ms(10);
	WiFi_Time = 0;

	while(1)
	{
		if((strstr(WIFI_RX_BUFFER,"CONNECT") != NULL)&&(strstr(WIFI_RX_BUFFER,"OK") != NULL))
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set UDP IP successed\r\n");
			}        					
			return WIFI_SUCCESS ;
		}
		if(strstr(WIFI_RX_BUFFER,"ERROR") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set UDP IP failed\r\n");
			}        					
			return WIFI_FAIL ;
		}
		if(strstr(WIFI_RX_BUFFER,"ALREAY CONNECT") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("UDP IP has connect\r\n");
			}        					
			return WIFI_SUCCESS ;
		}
		if(WiFi_Time>WIFI_20S_TIMEOUT)
		{	       				 
			if(Flag_COMDebug == 1)
			{
				printf("Set UDP IP failed��%s\r\n",WIFI_RX_BUFFER);
			}
			return WIFI_FAIL ;
		}
        delay_ms(10);
	}
	
}
/****************************************************************************
*	�� �� ��: ESP8266_Cmd
*	����˵��: ��WF-ESP8266ģ�鷢��ATָ��
*	��    �Σ�cmd�������͵�ָ��
*         reply1��reply2���ڴ�����Ӧ��ΪNULL��������Ӧ������Ϊ���߼���ϵ
*         waittime���ȴ���Ӧ��ʱ��
*	�� �� ֵ:  1��ָ��ͳɹ�
*         0��ָ���ʧ��
*   ˵    ����
*****************************************************************************/
char ESP8266_Cmd ( char * cmd, char * reply1, char * reply2, uint8_t waittime )
{    

    ClearUSARTBUF(WIFI_USART);

    WIFI_USART_Send(cmd, strlen(cmd));
  
	if ( ( reply1 == NULL ) && ( reply2 == NULL) )                      //����Ҫ��������
		return 1;
	delay_ms(50);
    WiFi_Time = 0;
    
    while( 1 )
    {
        if ( ( reply1 != NULL ) && ( reply2 != NULL ) )
        {
            if((strstr ( WIFI_RX_BUFFER, reply1 )!=NULL)  &&  (strstr ( WIFI_RX_BUFFER, reply2 )!= NULL) )
            {
                 if(Flag_COMDebug == 1)
                    printf("ָ�%s ���ͳɹ�,����%s\r\n",cmd,WIFI_RX_BUFFER);
                return 1;
            }
        }       
       if ( ( reply1 != NULL ) && ( reply2 == NULL ) )
        {
            if(strstr ( WIFI_RX_BUFFER ,reply1 ) != NULL)
            {
                 if(Flag_COMDebug == 1)
                    printf("ָ�%s ���ͳɹ�\r\n",cmd);
                return 1;
            } 
        }        
        if ( ( reply1 == NULL ) && ( reply2 != NULL ) )
        {
            if(strstr ( WIFI_RX_BUFFER, reply2 )!= NULL )
            {
                 if(Flag_COMDebug == 1)
                    printf("ָ�%s ���ͳɹ�\r\n",cmd);
              return 1;  
            }                
        }
        if(WiFi_Time >= waittime)
        {
             if(Flag_COMDebug == 1)
                printf("ָ�%s ����ʧ��:%s\r\n",cmd,WIFI_RX_BUFFER);
            return 0;
        }
        delay_ms(10);

    }	
}
/****************************************************************************
*	�� �� ��: ESP8266_ListAP
*	����˵��: WF-ESP8266ģ���ѯ����AP
*	��    �Σ�pSSID��WiFi�����ַ���        pPassWord��WiFi�����ַ���
*	�� �� ֵ: 1��ѡ��ɹ�    0��ѡ��ʧ��
*   ˵    ����
*****************************************************************************/
char ESP8266_SerchAP ( char * pSSID )
{
    char cCmd [50];


	sprintf ( cCmd, "AT+CWLAP=\"%s\"\r\n", pSSID );
    if ( ESP8266_Cmd ( cCmd, "OK",pSSID, 5 ) )
    {
        if(Flag_COMDebug ==1)
        {
            printf("Exist the WiFi:%s \r\n",pSSID);  
        }
        return 1;
    }
    if(Flag_COMDebug ==1)
    {
        printf("No WiFi:%s \r\n",pSSID);  
    }
    return 0;
}
/****************************************************************************
*	�� �� ��: ESP8266_BuildAP
*	����˵��: WF-ESP8266ģ�鴴��WiFi�ȵ�
*	��    �Σ�pSSID��WiFi�����ַ���        pPassWord��WiFi�����ַ��� enunPsdMode��WiFi���ܷ�ʽ�����ַ���
*	�� �� ֵ: 1��ѡ��ɹ�    0��ѡ��ʧ��
*   ˵    ����
*****************************************************************************/
char ESP8266_BuildAP ( char * pSSID, char * pPassWord, ENUM_AP_PsdMode_TypeDef enunPsdMode )
{
	char cCmd [120];

    if(Flag_COMDebug ==1)
    {
        printf("Build ap:%s,%s \r\n",pSSID,pPassWord);  
    }
    
	sprintf ( cCmd, "AT+CWSAP=\"%s\",\"%s\",5,%d\r\n", pSSID, pPassWord,enunPsdMode ); //���Է��֣����ʹ�ü��ܷ�ʽ�����볤����Ҫ����8λ
	
	return ESP8266_Cmd ( cCmd, "OK", NULL, 5 );
	
}
/****************************************************************************
*	�� �� ��: ESP8266_OpenServer
*	����˵��: ESP8266ģ������serverģʽ
*	��    �Σ�mode = 1 Ϊ������0Ϊ�ر�
*	�� �� ֵ: 1�����óɹ�    0������ʧ��
*   ˵    ����
*****************************************************************************/
char ESP8266_OpenServer(char mode )
{
    char cCmd [120];

	sprintf ( cCmd, "AT+CIPSERVER=%d,%d\r\n", mode, AP_MODE_PORT);
	
	return ESP8266_Cmd ( cCmd, "OK", NULL, 5 );
}
/****************************************************************************
*	�� �� ��: ESP8266_SetSoftAPip
*	����˵��: ����ESP8266ģ��apģʽ�µ�ip
*	��    �Σ�
*	�� �� ֵ: 
*   ˵    ����
*****************************************************************************/
char ESP8266_SetSoftAPip(uint8_t *ip)
{
    char cCmd [120];

	sprintf ( cCmd, "AT+CIPAP=\"%s\"\r\n", ip);
	
	return ESP8266_Cmd ( cCmd, "OK", NULL, 5 );
    
}


/****************************************************************************
*	�� �� ��: Deal_SoftAPInfo
*	����˵��: ����app���͵�������Ϣ
*	��    �Σ�
*	�� �� ֵ: 
*   ˵    ����
*****************************************************************************/
//char  jsondata[300] = {0};
extern char  json_data[MAX_WIFIUART_LEN];
char Deal_SoftAPInfo(void)
{
	int length,androidorIOS = 0;
	char extracted[100];
	char *_start,*_end;
	printf("into Deal_SoftAPInfo\r\n");
	if(strstr(WIFI_RX_BUFFER, "extra") != NULL)
		androidorIOS = 1; //IOS
	else
		androidorIOS = 2; //android
		
	if(strstr(WIFI_RX_BUFFER, "password") != NULL)
	{
		_start = strstr(WIFI_RX_BUFFER, "password");
		if(androidorIOS == 1)
			_start += strlen("\"password\":\"");  
		else
			_start += strlen("\"password\"");  
		_start = strchr(_start, '"');  // ���ҵ�һ��˫����
		++_start;  // ����˫���ű���
//		if(androidorIOS == 1)
//		{
//			_end = strstr(_start, "\",");  //��", Ϊ��β�ж���Ȼû�ã���Ϊ���Դ�ת��
//			if (_end == NULL) {  
//				printf("No \", found.\n");  
//				return 0;  
//			}
//		}
//		else
//		{
//			_end = strstr(_start, "\"}");
//			if (_end == NULL) {  
//				printf("No \"} found.\n");  
//				return 0;  
//			}
//		}
		_end = strchr(_start, '"');    // ���ҵڶ���˫����
		length = _end-_start;  // �����Ӵ��ĳ���
		memcpy(Router_Info.password,_start,length);
		Router_Info.password[length] = '\0';
		printf("password:%s,lenth:%d\r\n",Router_Info.password,length);
	}
	else
        return 0;
	
	if(strstr(WIFI_RX_BUFFER, "SSID") != NULL)
	{
		_start = strstr(WIFI_RX_BUFFER, "SSID");
		if(androidorIOS == 1)
			_start += strlen("\"SSID\":\"");
		else
			_start += strlen("\"SSID\""); 
		_start = strchr(_start, '"');  // ���ҵ�һ��˫����
		++_start;  // ����˫���ű���
		_end = strchr(_start, '"');
		length = _end-_start;  // �����Ӵ��ĳ���
		memcpy(Router_Info.SSID,_start,length);
		Router_Info.SSID[length] = '\0';
		printf("SSID:%s,lenth:%d\r\n",Router_Info.SSID,length); 
	}
	else
        return 0;
	
	if(strstr(WIFI_RX_BUFFER, "gwAddress") != NULL)
	{
		_start = strstr(WIFI_RX_BUFFER, "gwAddress");
		if(androidorIOS == 1)
			_start += strlen("\"gwAddress\":\""); 
		else
			_start += strlen("\"gwAddress\""); 
		_start = strchr(_start, '"');  // ���ҵ�һ��˫����
		++_start;  // ����˫���ű���
		_end = strchr(_start, '"');
		length = _end-_start;  // �����Ӵ��ĳ���
		memcpy(Router_Info.gwAddress,_start,length);
		Router_Info.gwAddress[length] = '\0';
		printf("gwAddress:%s,lenth:%d\r\n",Router_Info.gwAddress,length); 
	}
	else
        return 0;
	
	if(strstr(WIFI_RX_BUFFER, "gwAddress2") != NULL)
	{
		_start = strstr(WIFI_RX_BUFFER, "gwAddress2");
		if(androidorIOS == 1)
			_start += strlen("\"gwAddress2\":\""); 
		else
			_start += strlen("\"gwAddress2\""); 
		_start = strchr(_start, '"');  // ���ҵ�һ��˫����
		++_start;  // ����˫���ű���
		_end = strchr(_start, '"');
		length = _end-_start;  // �����Ӵ��ĳ���
		memcpy(Router_Info.gwAddress2,_start,length);
		Router_Info.gwAddress2[length] = '\0';
		printf("gwAddress2:%s,lenth:%d\r\n",Router_Info.gwAddress2,length); 
	}
	else
        return 0;
	
	if(strstr(WIFI_RX_BUFFER, "user_key") != NULL)
	{
		_start = strstr(WIFI_RX_BUFFER, "user_key");
		if(androidorIOS == 1)
			_start += strlen("\"user_key\":\""); 
		else
			_start += strlen("\"user_key\""); 
		_start = strchr(_start, '"');  // ���ҵ�һ��˫����
		++_start;  // ����˫���ű���
		_end = strchr(_start, '"');
		length = _end-_start;  // �����Ӵ��ĳ���
		memcpy(Router_Info.user_key,_start,length);
		Router_Info.user_key[length] = '\0';
		printf("user_key:%s,lenth:%d\r\n",Router_Info.user_key,length); 
	}
	else
        return 0;
	
	RespQlikNetInfo();
	ClearUSARTBUF(WIFI_USART);
	return 1;
/*	
    char  *p1,*p2;
    
    cJSON *getvalue,*cgwvalue,*app_data;
    
//    p1 = strstr(WIFI_RX_BUFFER, "{\"CGW\":");
//    p2 = strrchr(p1, '}');
//    p3 = strrchr(p2, '}'); //�ڶ���
    
	printf("���յ�����\r\n"); 	
	//  ����ж���json�����ǻ�������������
	p1 = strchr(WIFI_RX_BUFFER, '{'); 
	p2 = strrchr(WIFI_RX_BUFFER, '}');
	
	if( (p1 != NULL)&&(p2 != NULL) )
	{
		memset(json_data,0,MAX_WIFIUART_LEN);
		memcpy (json_data,p1,p2-p1+1);
		if(Flag_COMDebug == 1)
			printf("json:%s \r\n",json_data); 
		app_data = cJSON_Parse(json_data);  //�����ַ���
        
        cgwvalue = cJSON_GetObjectItem(app_data, "CGW");
        
        getvalue = cJSON_GetObjectItem(cgwvalue, "gwAddress");	
        strcpy(Router_Info.gwAddress ,getvalue->valuestring);
        
        getvalue = cJSON_GetObjectItem(cgwvalue, "gwAddress2");	
        strcpy(Router_Info.gwAddress2 ,getvalue->valuestring);

        getvalue = cJSON_GetObjectItem(cgwvalue, "user_key");	
        strcpy(Router_Info.user_key ,getvalue->valuestring);

        getvalue = cJSON_GetObjectItem(app_data, "SSID");	
        strcpy(Router_Info.SSID ,getvalue->valuestring);

        getvalue = cJSON_GetObjectItem(app_data, "password");	
        strcpy(Router_Info.password ,getvalue->valuestring); 

        cJSON_Delete(app_data);
		if(Flag_COMDebug ==1)
        {
            printf("������Ϣ:\r\n");
            printf("gwAddress:%s\r\n",Router_Info.gwAddress);
            printf("gwAddress2:%s\r\n",Router_Info.gwAddress2);
            printf("user_key:%s\r\n",Router_Info.user_key);
            printf("SSID:%s\r\n",Router_Info.SSID);
            printf("password:%s\r\n",Router_Info.password);
        }
        
        RespQlikNetInfo();
        ClearUSARTBUF(WIFI_USART);
        
		return 1;
	}
	else
    {
        cJSON_Delete(app_data);
        return 0;
    }
*/
	//
//    if((p1 != NULL)&&(p3 != NULL)&&(strstr(p1,"SSID")!=NULL)&&(strstr(p1,"password")!=NULL))
//    {

//        memset(jsondata,0,300);
//        memcpy (jsondata,p1,p3-p1+1);
//        if(Flag_COMDebug ==1)
//        {
////            printf("������Ϣ:%s\r\n",WIFI_RX_BUFFER);
//            printf("����json��Ϣ:%s\r\n",jsondata);
//        }
//        
//        app_data = cJSON_Parse(jsondata);  //�����ַ���
//        
//        cgwvalue = cJSON_GetObjectItem(app_data, "CGW");
//        
//        getvalue = cJSON_GetObjectItem(cgwvalue, "gwAddress");	
//        strcpy(Router_Info.gwAddress ,getvalue->valuestring);
//        
//        getvalue = cJSON_GetObjectItem(cgwvalue, "gwAddress2");	
//        strcpy(Router_Info.gwAddress2 ,getvalue->valuestring);

//        getvalue = cJSON_GetObjectItem(cgwvalue, "user_key");	
//        strcpy(Router_Info.user_key ,getvalue->valuestring);

//        getvalue = cJSON_GetObjectItem(app_data, "SSID");	
//        strcpy(Router_Info.SSID ,getvalue->valuestring);

//        getvalue = cJSON_GetObjectItem(app_data, "password");	
//        strcpy(Router_Info.password ,getvalue->valuestring); 

//        cJSON_Delete(app_data);
////        
//        if(Flag_COMDebug ==1)
//        {
//            printf("������Ϣ:\r\n");
//            printf("gwAddress:%s\r\n",Router_Info.gwAddress);
//            printf("gwAddress2:%s\r\n",Router_Info.gwAddress2);
//            printf("user_key:%s\r\n",Router_Info.user_key);
//            printf("SSID:%s\r\n",Router_Info.SSID);
//            printf("password:%s\r\n",Router_Info.password);
//        }
//        
//        RespQlikNetInfo();
//        ClearUSARTBUF(WIFI_USART);
//        
//        return 1;
//    }
//    else
//    {
//        cJSON_Delete(app_data);
//        return 0;
//    }
}

//����app���͵���Ϣ����������������
char Deal_APPInfo(void)
{
    char  *p1,*p2;
    
	p1 = strchr(WIFI_RX_BUFFER, '{'); 
	p2 = strchr(WIFI_RX_BUFFER, '}');
	
	if( (p1 != NULL)&&(p2 != NULL) )
	{
		memset(json_data,0,MAX_WIFIUART_LEN);
		memcpy (json_data,p1,p2-p1+1);
		if(Flag_COMDebug == 1)
			printf("json:%s \r\n",json_data); 
		ClearUSARTBUF(WIFI_USART);
	}
	return 1;
}
/****************************************************************************
*	�� �� ��: ESP8266_SoftAPConfig
*	����˵��:ESP8266ģ��������softAP����ģʽ
*	��    �Σ�enumEnUnvarnishTx�������Ƿ������
*	�� �� ֵ: 1�����óɹ�    0������ʧ��
*   ˵    ����
*****************************************************************************/
char ESP8266_SoftAPConfig(void)
{
    char apname[30] ={0};
    static uint8_t SetSSIDFail_cnt = 0;

    Flag_LED_Status = LED_WIFI_CONFIG;
    if(Flag_COMDebug == 1)
    {
        printf("SoftAP ����ģʽ\r\n");
    }
	quickSSID:
    if(WIFI_Set_Mode(WIFIMODE_AP_STA) == WIFI_SUCCESS)
    {
        WIFI_Reset();
		delay_ms(500);
        if(WIFI_Open_cmdMode()==WIFI_SUCCESS)
        {           
            WIFI_Set_MUXLINK(1);  //����������            
            ESP8266_OpenServer(1); //����������
            ESP8266_SetSoftAPip("192.168.5.1");
            sprintf(apname,"%s-%s",AP_NAME,&Device_Info.MAC_ID[8]);
            ESP8266_BuildAP(apname,AP_PASSWD,OPEN);  
            ClearUSARTBUF(WIFI_USART);
            MuxLink_ID = 1;
            WIFI_Set_UDPConnect("192.168.5.255","5683","5683");
            WiFi_Time = 0;            
           while(1)
           {
			   printf("rev phone:%s \r\n",WIFI_RX_BUFFER); 
//               if((strstr(WIFI_RX_BUFFER,"+IPD,")!= NULL)&&(strstr(WIFI_RX_BUFFER,"SSID") != NULL) &&(strstr(WIFI_RX_BUFFER,"password") != NULL)) //�յ�APP���͵�������Ϣ
			   if(strstr(WIFI_RX_BUFFER,"password") != NULL)
               {
//                   delay_ms(50);
                   if(Deal_SoftAPInfo() ==1)
                   {
                       break;
                   }
               }
//			   if((strstr(WIFI_RX_BUFFER,"+IPD,")!= NULL)&&(strstr(WIFI_RX_BUFFER,"appVersion") != NULL)) //�յ�APP���͵�������Ϣ
//			   {
////					delay_ms(50);
//                   if(Deal_APPInfo() ==1)
//                   {
//                       break;
//                   }
//			   }
                if(WiFi_Time >= WIFI_15MIN_TIMEOUT)
                {
                    printf("������ʱ:%s\r\n",WIFI_RX_BUFFER);
					NVIC_SystemReset();//��λ 
                    return 0;
                }
				ClearUSARTBUF(WIFI_USART);
                delay_ms(1500);
           } 
          //APP����������Ϣ�ɹ�������·����
		   chongfupeiwang:
           WIFI_Close_TCPConnect(MuxLink_ID);
           WIFI_Set_Mode(WIFIMODE_STA);
            WIFI_Set_ATE(0);  //�ر�ָ�����
            WIFI_OpenDHCP();
            WIFI_Set_MUXLINK(0);  //������
           	if(WIFI_Set_STASSID(Router_Info.SSID,Router_Info.password)== WIFI_SUCCESS)
            {
                if(Flag_COMDebug == 1)
                {
                    printf("WiFi connected to :%s \r\n",Router_Info.SSID);
                }
                SaveRouterNameToFlash();
				SetSSIDFail_cnt = 0;
//                BroadcastAccessInNetworkByCoap();   //��һ����Ҫ�㲥coap
                return 1;
                            
             
            }
			else
			{
				SetSSIDFail_cnt++;
				if(SetSSIDFail_cnt < 2)
					goto chongfupeiwang;
				else
				{
					SetSSIDFail_cnt = 0;
					goto quickSSID;
				}
			}
				
        }
        else
        {
            return 0; 
        }
    }
    else
    {
        return 0;
    }
}
/****************************************************************************
*	�� �� ��: 
*	����˵��: ��ѯwlanMAC
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void strdel(char* s,char del_x)
{
	char *p;
	char *q;
	for(p=s,q=s;*p!='\0';p++)
 
		if(*p!=del_x)
			*q++=*p;
 
		*q=*p;
}

char WIFI_wlanMAC(char *SS)
{
    uint8_t i;
	char *cmdid = NULL;
	*cmd='\0';
    sprintf(cmd, "AT+CIPSTAMAC?\r\n");	
    WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delay_ms(50);
	WiFi_Time = 0;
	while(1)
	{
		if(strstr(WIFI_RX_BUFFER,"CIPSTAMAC") != NULL)
		{
			cmdid = strstr(WIFI_RX_BUFFER,"MAC");
			for(i=0;i<17;i++)
			{
				SS[i] = cmdid[i+5];
			}
			printf("WLAN MAC : %s \r\n",SS);
			strdel(SS,':');
			if(Flag_COMDebug == 1)
				printf("\r\nWLAN MAC : %s \r\n",SS);
//			free(cmdid);
			return WIFI_SUCCESS;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{
//			free(cmdid);
			return WIFI_FAIL ;
		}
	}
}


