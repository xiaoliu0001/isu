/******************************************************************************
 * @file     Timerstamp.h
 * @brief   ��ȡʱ���
 * @version  v1.0
 * @date     2023.05.31
 * @note
 * Copyright (C)  ��� 2023
 *
 * @par      
 *    V1.0    
*******************************************************************************/

#ifndef __TIMESTAMP_H__
#define __TIMESTAMP_H__

#include <stdio.h>
#include <stdint.h>

//typedef struct times
//{
//    int Year;
//    int Mon;
//    int Day;
//    int Hour;
//    int Min;
//    int Second;
//}Times;

#define  SECONDS_IN_A_MINUTE   60
#define  SECONDS_IN_AN_HOUR    60 * SECONDS_IN_A_MINUTE
#define  SECONDS_IN_A_DAY      24 * SECONDS_IN_AN_HOUR

#define  SECONDS_IN_A_COMMON_YEAR   365 * SECONDS_IN_A_DAY
#define  SECONDS_IN_A_LEAP_YEAR     366 * SECONDS_IN_A_DAY

//��1970-01-01 08��00��00 ��ʼ����
//����һ����ʼʱ��� 2000-01-01 00:00:00
#define  SPECIALTIMESTAMP       946656000

typedef struct
{
    int Year;
    int Mon;
    int Day;
    int Hour;
    int Min;
    int Second;
}Date;


uint64_t Date2timeStamp(Date standardTime);

#endif