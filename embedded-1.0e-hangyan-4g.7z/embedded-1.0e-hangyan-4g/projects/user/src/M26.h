#ifndef __M26_H
#define __M26_H
#include "Fun.h"
#include "Parameter.h"
#include "USART.h"
//#if _NEW_MODULE
#define GPRS_CQ_GPIO_PORT        		GPIOB
#define GPRS_CQ_GPIO_CLK                RCC_APB2_PERIPH_GPIOB
#define CHIR_PIN                    	GPIO_PIN_1
#define GPRS_CQ_PIN                    	GPIO_PIN_14	

#define CSTTY  "AT+CSTT="CMNET"\r\n"
//端口定义
#define LTE_PWRKEY_PIN                  GPIO_PIN_3                  //开机引脚   
#define LTE_PWRKEY_GPIO_PORT            GPIOB                      


#define LTE_RESETN_PIN                  GPIO_PIN_4             //复位引脚       
#define LTE_RESETN_GPIO_PORT            GPIOB                      


#define LTE_DTR_PIN                  GPIO_PIN_12             //复位引脚       
#define LTE_DTR_GPIO_PORT            GPIOB                

#define LTE_PWRKEY(a)	if (a)	\
					GPIO_SetBits(LTE_PWRKEY_GPIO_PORT,LTE_PWRKEY_PIN);\
					else		\
					GPIO_ResetBits(LTE_PWRKEY_GPIO_PORT,LTE_PWRKEY_PIN);
										
#define LTE_RESETN(a)	if (a)	\
					GPIO_SetBits(LTE_RESETN_GPIO_PORT,LTE_RESETN_PIN);\
					else		\
					GPIO_ResetBits(LTE_RESETN_GPIO_PORT,LTE_RESETN_PIN);
					
#define LTE_DTR(a)	if (a)	\
					GPIO_SetBits(LTE_DTR_GPIO_PORT,LTE_DTR_PIN);\
					else		\
					GPIO_ResetBits(LTE_DTR_GPIO_PORT,LTE_DTR_PIN);		

#define GPRS_POWER(a) if (a)	\
					GPIO_SetBits(GPRS_CQ_GPIO_PORT,GPRS_CQ_PIN);\
					else		\
					GPIO_ResetBits(GPRS_CQ_GPIO_PORT,GPRS_CQ_PIN);
//#endif
extern unsigned char SIMCard_IMEI[25];
extern uint8_t SIMCard_IMEI_Len;
extern unsigned char SIMCard_SN[25];
extern uint8_t SIMCard_SN_Len;					
extern unsigned char SIMCard_IMSI[20];
extern uint8_t SIMCard_IMSI_Len;
extern unsigned char SIMCard_ICCID[25];
extern uint8_t SIMCard_ICCID_Len;
extern char Device_ip[25];
extern uint8_t Device_ip_Len;
extern u8 Flag_Init_Step;    
extern uint16_t  Init_pauseTime ;    
char SLM750V_StartUP(void);					
uint8_t AT_CIICR_(void);
void Init_M26(u8 int_step);
uint8_t Set_Baund(void);
uint8_t Check_PIN(void);
uint8_t Wait_CREG(void);
uint8_t Wait_CGREG(void);
uint8_t AT_CGATT_Ctrl(void);
char LTE_Set_ConnectIP_MUX(void);
char Set_APN_Function(void);
char Get_LocalIP_Address(void);
char CheckLinkStatus(void);
char LTE_Select_Data_Sending_Mode(void);
uint8_t Set_Connext(void);
int8_t  Read_Card_IMSI(void);
int8_t  Read_Card_CCID(void);
int8_t  Read_Card_IMEI(void);
uint8_t InquireCSQ(void);
void GPRSSendData(unsigned char *p,unsigned int Len);
void GetGPRSPosition(void);
char MyCountChar(unsigned char *p,int pLen);
u8 GPRS_CloseSocket(void);
uint8_t Set_IPLink_Mode(uint8_t mode);
void GetBackServerIP(void);
void AnalysisBackServerIP(void);
void Connect_BackServer(void);
void Analysis_BackServer(void);
void GetBackServerToken2(void);
void AnalysisBackServerToken2(void);
void SendBackServerVerify(void);
u8 GPRS_Send_Data(char *data,uint16_t len);
char GPRS_Wait_Resp(char *expect_str, char timeout_sec);
void Send_AMPCHGData2Server(void);
uint8_t InquireTCPstat(void);
char LuatModule_PowerDown(void);

char MQTT_config(void);
char MQTT_TCP_connect(void);
char MQTT_session_conn(void);
char MQTT_SUB(void);
char MQTT_PUB(char *topic,char *data);
char MQTT_MSGGET_0(void);
char MQTT_Close(void);
char MQTT_Status(void);
char MQTT_REV_MODE(void);
#endif
