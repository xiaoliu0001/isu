/******************************************************************************
 * @file     Calculate.c
 * @brief   ADC数据处理
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par       严斌 2016
 *         张炜20170519  按V2.0通讯协议修改串口发送的数据格式
*******************************************************************************/
#include "Calculate.h"
#include <stdio.h>
#include <stdlib.h>
#include "BERpara.h"
#include <math.h>
#include "Parameter.h"
#include "USART.h"
#include "string.h"
#include "Flash.h"
#include "MobileAndlink.h"


const static int MAX_COUNT_NUM = 150;
const static int SAMPLE_NUM = 12;
const static int MAX_VALUE = 255;

//reapdata..max:679..min:.-781
static int sHrWaveBuf[MAX_COUNT_NUM];// 3秒,每秒4个点 ,
static int sRrWaveBuf[MAX_COUNT_NUM];// 3秒,每秒4个点 ,
static int sRrSampleWaveBuf[MAX_COUNT_NUM];// 采样后的波形，最大为255,
static int filterRrWave[SAMPLE_NUM];//取样后的波形
static int index = 0;


int getMax(int datas[],int srcIndex,int len);
int getMin(int datas[],int srcIndex,int len);
int getAverage(int datas[],int srcIndex,int len);
int getAbsAverage(int datas[],int srcIndex,int len);
int getUpOrDown(int datas[],int index ,int len);
void filter(int src[],int len,int interval,int* dest);
void putHrWaveData(int data);
void putRrWaveData(int data);
/****************************************************************************
*	函 数 名: getFilterWave
*	功能说明: 获取滤波后的波形数据
*	形    参：wave滤波后波形数据保存位置
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void getFilterWave(int* wave)
{
	int i;
	for(i = 0; i < SAMPLE_NUM;i++){
		*(wave + i ) = filterRrWave[i];
	}
}
/****************************************************************************
*	函 数 名: putWaveDataToBuf
*	功能说明: 将呼吸和心率波形数据放置到缓冲区中
*	形    参：hrWave心率波形数据   rrWave呼吸波形数据
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void putWaveDataToBuf(int org,int hrWave,int rrWave)
{
	putHrWaveData(hrWave);//把心率波形放到缓冲区
	putRrWaveData(rrWave);//把呼吸波形放到缓冲区
	index++;
	if(index > MAX_COUNT_NUM - 1){
		index = 0;
//		filter(sRrSampleWaveBuf,MAX_COUNT_NUM,SAMPLE_NUM,filterRrWave);
		filter(sRrWaveBuf,MAX_COUNT_NUM,SAMPLE_NUM,filterRrWave);
	}
}
/****************************************************************************
*	函 数 名: putHrWaveData
*	功能说明: 将心率波形数据放置到数组中
*	形    参：data波形数据
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void putHrWaveData(int data)
{
	sHrWaveBuf[index] = data;
}
/****************************************************************************
*	函 数 名: putHrWaveData
*	功能说明: 将呼吸波形数据放置到数组中
*	形    参：data波形数据
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void putRrWaveData(int data)
{
	sRrWaveBuf[index] = data;
//	data = data/4 + 128;//原始数据大概是在-255 ~ 255,需要压缩成 0~255
//	if(data < 0)
//		data = 0;
//	if(data > MAX_VALUE)
//		data = MAX_VALUE;
	//把一个点缩小成一个字节来存储,用于传输给客户端来画图 大小 0~255
//	sRrSampleWaveBuf[index] = data;
	
}
/****************************************************************************
*	函 数 名: filter
*	功能说明: 
*	形    参：data波形数据
*	返 回 值: 无
* 说    明：计算出组成这3秒波形的12个点
*****************************************************************************/
void filter(int src[],int len,int interval,int* dest){
	const int times = len/interval;
	int filtersIndex = 0;
	int tmp = 0;
	int i;
	int max = 0;
	int div = 2;

	max = getMax(src,0,len);
	div = max / 128 + 1;
	if(div > 896)
		div = 7;//128*7 = 896
	if( div < 2)
		div = 2;
	
	for(i = 0; i < times ;i++){
		if(getUpOrDown(src, i*interval, interval) == 1){
			//上升，取最高点
			tmp = getMax(src, i*interval, interval)/div;
		}else if(getUpOrDown(src, i*interval, interval) == 0){
			//下降,取最低点
			tmp = getMin(src, i*interval, interval)/div;
		}else{
			//趋势不变
			tmp = getAverage(src, i*interval, interval)/div;
		}
		tmp += 128;//基线是128
		if(tmp < 0){
			tmp = 0;
		}
		if(tmp > 255){
			tmp = 255;
		}
		*(dest+filtersIndex++) = tmp;
	}
}
/****************************************************************************
*	函 数 名: getMax
*	功能说明: 获取数组中最大值
*	形    参：
*	返 回 值: 最大值数据
* 说    明：
*****************************************************************************/
int getMax(int datas[],int srcIndex,int len){
	int max = datas[srcIndex++];
	int tmp = 0;
	len--;
	while(len-- > 0){
		tmp = datas[srcIndex++];
		if(tmp > max){
			max = tmp;
		}
	}
	return max;
}
/****************************************************************************
*	函 数 名: getMin
*	功能说明: 获取数组中最小值
*	形    参：
*	返 回 值: 最小值数据
* 说    明：
*****************************************************************************/
int getMin(int datas[],int srcIndex,int len){
	int min = datas[srcIndex++];
	int tmp = 0;
	len--;
	while(len-- > 0){
		tmp = datas[srcIndex++];
		if(tmp < min){
			min = tmp;
		}
	}
	return min;
}
/****************************************************************************
*	函 数 名:  getAverage
*	功能说明: 获取数组平均值
*	形    参：
*	返 回 值: 平均值数据
* 说    明：
*****************************************************************************/
int getAverage(int datas[],int srcIndex,int len){
	int sum = 0;
	int tmpLen = len;
	while(len-- > 0){
		sum += datas[srcIndex++];
	}
	return sum/tmpLen;
}
/****************************************************************************
*	函 数 名:  getAbsAverage
*	功能说明: 获取绝对值的平均值
*	形    参：
*	返 回 值:
* 说    明：
*****************************************************************************/
int getAbsAverage(int datas[],int srcIndex,int len){
	long sum = 0;
	int tmpLen = len;
	int tmp = 0;
	while(len-- > 0){
		tmp = abs(datas[srcIndex++]);
		sum += tmp;
//		printf("sum...%d..%d\n",sum,tmp);
	}
	return sum/tmpLen;
}
/****************************************************************************
*	函 数 名:  getUpOrDown
*	功能说明: 获取数据波形是上升还是下降
*	形    参：
*	返 回 值:
* 说    明：1：上升  0：下降  -1无效
*****************************************************************************/
int getUpOrDown(int datas[],int index ,int len){
	int sum = 0;
	int i;
	if(len < 2)
		return -1;
	for(i = 0; i < len;i++){
		sum += datas[index+i];
	}
	return (sum - datas[index]*len) > 0 ? 1:0;
}
/****************************************************************************
*	函 数 名:  isPeopleOnbed
*	功能说明:   是否有人
*	形    参：
*	返 回 值:
* 说    明：
*****************************************************************************/
unsigned char isPeopleOnbed()
{
	unsigned char flag = 0;
	
	return flag;
}
/****************************************************************************
*	函 数 名:  sendPackDataToUART1
*	功能说明:  通过串口1发送数据包
*	形    参：
*	返 回 值:
* 说    明：张炜20170522按新协议修改数据
*****************************************************************************/
void sendPackDataToUART1(void)
{
	unsigned char Dat[30]={0};
	int i = 0;
	
	SendDataToUSART(USART1,0x24);
	SendDataToUSART(USART1,0x01 );
	SendDataToUSART(USART1,0x0F);
  SendDataToUSART(USART1,READ_REALTIME_ADCDATA);
	SendDataToUSART(USART1,SampleData/100 );       //ADC采样数据
	SendDataToUSART(USART1,SampleData%100 );
	SendDataToUSART(USART1,(EcgData+1000)/100 );     //心率波形数据
	SendDataToUSART(USART1,(EcgData+1000)%100 );
	SendDataToUSART(USART1,(RespData+1000)/100 );     //呼吸数据
	SendDataToUSART(USART1,(RespData+1000)%100 ); 
	SendDataToUSART(USART1,gPulseRateHR );    //心率值
	SendDataToUSART(USART1,gPulseRateRR );    //呼吸值
	SendDataToUSART(USART1,gPowerHeart << 4 | gPowerBreath );    //心率和呼吸强度
	SendDataToUSART(USART1,(gPeopleFlag<<4)|gTurnFlag );     //状态
	SendDataToUSART(USART1,AngelPace );    //无线连接状态
	SendDataToUSART(USART1,(uint8_t)(ADC_AmpMultiple*10));  //放大倍数
  SendDataToUSART(USART1,gPowerSample << 4 | gPowerTurn ); //信号强度
	SendDataToUSART(USART1,0xFF );
	SendDatasToUSART(USART1,0x6942 );
	
}

#if 0
/****************************************************************************
*	函 数 名:  SendDeviceVerInfoToUart1
*	功能说明:  通过串口1发送设备版本信息
*	形    参：
*	返 回 值:
* 说    明：张炜20150519改
*****************************************************************************/
void SendDeviceVerInfoToUart1(char *str)
{
	uint8_t len;	
  len = strlen(str);	
	 SendDataToUSART(USART1,0x24);
	 SendDataToUSART(USART1,0x01 );
	 SendDataToUSART(USART1,len+2);
	 SendDataToUSART(USART1,READ_DEVICE_VER);
	 while(*str != '\0')
	 {
	    SendDataToUSART(USART1,*str++);
	 }
	 SendDataToUSART(USART1,0xFF );
	 SendDatasToUSART(USART1,0x6942 );
}


/****************************************************************************
*	函 数 名:  SendDeviceMacToUart1
*	功能说明:  通过串口1发送设备MAC
*	形    参：
*	返 回 值:
* 说    明：张炜20170522 按照新协议修改传输内容
*****************************************************************************/
void SendDeviceMacToUart1()
{
	U8 Dat[30]={0};
	int i = 0;
	
	 if(ReadMACFromFlash() == 0x01)
	 {
			 SendDataToUSART(USART1,0x24);
			 SendDataToUSART(USART1,0x01 );
			 SendDataToUSART(USART1,MAC_LEN+2);
			 SendDataToUSART(USART1,READ_DEVICE_MAC);
			 for(i=0;i<MAC_LEN;i++)
			 {
					SendDataToUSART(USART1,MAC_ID[i]);
			 }
			 SendDataToUSART(USART1,0xFF );
			 SendDatasToUSART(USART1,0x6942 );	
			
   }
	 else  //无设备编号，返回错误
		{
		   SendDataToUSART(USART1,0x24);
			 SendDataToUSART(USART1,0x01 );
			 SendDataToUSART(USART1,4);
			 SendDataToUSART(USART1,DEVICE_ABNORMAL_MESSAGE);
			 SendDataToUSART(USART1,0xFF);
			 SendDataToUSART(USART1,FLASH_No_MAC);
			 SendDataToUSART(USART1,0xFF );
			 SendDatasToUSART(USART1,0x6942 );
			
	  }
}
#endif

/****************************************************************************
*	函 数 名: COMRetuenOneByte
*	功能说明: 串口返回一个字节的数据
*	形    参：USARTx返回数据的串口号，cmd返回的指令data返回的数据
*	返 回 值: 
* 	说    明：
*****************************************************************************/
void COMRetuenOneByte(USART_Module* USARTx,uint8_t cmd,uint8_t data)
{
	 SendDataToUSART(USARTx,CMD_START);
	 SendDataToUSART(USARTx,0x01 );
	 SendDataToUSART(USARTx,3);
	 SendDataToUSART(USARTx,cmd);
	 SendDataToUSART(USARTx,data);
	 SendDataToUSART(USARTx,0xFF );
	 SendDataToUSART(USARTx,CMD_LF1 );
	 SendDataToUSART(USARTx,CMD_LF2 );
}
/****************************************************************************
*	函 数 名:  SendDeviceVerInfoToUart
*	功能说明:  通过串口发送设备版本信息
*	形    参：
*	返 回 值:
* 	说    明：
*****************************************************************************/
void SendDeviceVerInfoToUart(USART_Module* USARTx,char *str)
{
	uint8_t len;	

	len = strlen(str);	
	SendDataToUSART(USARTx,CMD_START);
	SendDataToUSART(USARTx,0x01 );
	SendDataToUSART(USARTx,len+2);
	SendDataToUSART(USARTx,CMD_READVER);
	while(*str != '\0')
	{
		SendDataToUSART(USARTx,*str++);
	}
	SendDataToUSART(USARTx,0xFF );
	SendDataToUSART(USARTx,CMD_LF1 );
	SendDataToUSART(USARTx,CMD_LF2 );
}
/****************************************************************************
*	函 数 名:  SendDeviceMacToUart
*	功能说明:  通过串口1发送设备MAC
*	形    参：
*	返 回 值:
* 	说    明：张炜20230530增加
*****************************************************************************/
void SendDeviceMacToUart(USART_Module* USARTx)
{
	int i = 0;

	if(ReadMACFromFlash() == 0x01)
	{
		SendDataToUSART(USARTx,CMD_START);
		SendDataToUSART(USARTx,0x01 );
		SendDataToUSART(USARTx,Device_Info.MAC_LEN+2);
		SendDataToUSART(USARTx,CMD_READMAC);
		for(i=0;i<Device_Info.MAC_LEN;i++)
		{
			SendDataToUSART(USARTx,Device_Info.MAC_ID[i]);
		}
		SendDataToUSART(USARTx,0xFF );
		SendDataToUSART(USARTx,CMD_LF1 );
		SendDataToUSART(USARTx,CMD_LF2 );	

	}
	else  //无设备编号，返回错误
	{
		SendDataToUSART(USARTx,CMD_START);
		SendDataToUSART(USARTx,0x01 );
		SendDataToUSART(USARTx,4);
		SendDataToUSART(USARTx,DEVICE_ABNORMAL_MESSAGE);
		SendDataToUSART(USARTx,0xFF);
		SendDataToUSART(USARTx,FLASH_No_MAC);
		SendDataToUSART(USARTx,0xFF );
		SendDataToUSART(USARTx,CMD_LF1 );
		SendDataToUSART(USARTx,CMD_LF2 );

	}
}
/****************************************************************************
*	函 数 名:  SendCMCCCMEIMacToUart
*	功能说明:  通过串口1发送设备cmei
*	形    参：
*	返 回 值:
* 	说    明：
*****************************************************************************/
void SendCMEIToUart(USART_Module* USARTx)
{
	int i = 0;

    ReadMACFromFlash();
    
	if(strncmp(Device_Info.CMCC_CMEI,CMEI_START,8) == 0)
	{
		SendDataToUSART(USARTx,CMD_START);
		SendDataToUSART(USARTx,0x01 );
		SendDataToUSART(USARTx,17);
		SendDataToUSART(USARTx,CMD_READCMEI);
		for(i=0;i<15;i++)
		{
			SendDataToUSART(USARTx,Device_Info.CMCC_CMEI[i]);
		}
		SendDataToUSART(USARTx,0xFF );
		SendDataToUSART(USARTx,CMD_LF1 );
		SendDataToUSART(USARTx,CMD_LF2 );	

	}
	else  //无cmei，返回错误
	{
		SendDataToUSART(USARTx,CMD_START);
		SendDataToUSART(USARTx,0x01 );
		SendDataToUSART(USARTx,4);
		SendDataToUSART(USARTx,DEVICE_ABNORMAL_MESSAGE);
		SendDataToUSART(USARTx,0xFF);
		SendDataToUSART(USARTx,FLASH_NO_CMEI);
		SendDataToUSART(USARTx,0xFF );
		SendDataToUSART(USARTx,CMD_LF1 );
		SendDataToUSART(USARTx,CMD_LF2 );

	}
}

//向SOS设备同步联网状态
void COMSynSOS_NetStatus(USART_Module* USARTx,uint8_t data1)
{
	SendDataToUSART(USARTx,0xab);
	SendDataToUSART(USARTx,0xba);
	SendDataToUSART(USARTx,8);
	SendDataToUSART(USARTx,0xa1);
	SendDataToUSART(USARTx,data1);
	SendDataToUSART(USARTx,0xcc);
	SendDataToUSART(USARTx,0xcd);
	SendDataToUSART(USARTx,0xdc);
}

//向SOS设备应答供电方式帧，直接回显
void COMRetuenSOS_POWER(USART_Module* USARTx,uint8_t data1,uint8_t data2)
{
	SendDataToUSART(USARTx,0xab);
	SendDataToUSART(USARTx,0xba);
	SendDataToUSART(USARTx,9);
	SendDataToUSART(USARTx,0xb2);
	SendDataToUSART(USARTx,data1);
	SendDataToUSART(USARTx,data2);
	SendDataToUSART(USARTx,0xcc);
	SendDataToUSART(USARTx,0xcd);
	SendDataToUSART(USARTx,0xdc);
}

//向SOS设备应答SOS事件的上报情况
void COMRetuenSOS_event(USART_Module* USARTx,uint8_t data1)
{
	SendDataToUSART(USARTx,0xab);
	SendDataToUSART(USARTx,0xba);
	SendDataToUSART(USARTx,8);
	SendDataToUSART(USARTx,0xb1);
	SendDataToUSART(USARTx,data1);
	SendDataToUSART(USARTx,0xcc);
	SendDataToUSART(USARTx,0xcd);
	SendDataToUSART(USARTx,0xdc);
}

//向SOS设备同步休眠情况
void COMSynSOS_SleepStatus(USART_Module* USARTx)
{
	SendDataToUSART(USARTx,0xab);
	SendDataToUSART(USARTx,0xba);
	SendDataToUSART(USARTx,7);
	SendDataToUSART(USARTx,0xa2);
	SendDataToUSART(USARTx,0xcc);
	SendDataToUSART(USARTx,0xcd);
	SendDataToUSART(USARTx,0xdc);
}

void COMSynSOS_SleepStatus_end(USART_Module* USARTx)
{
	SendDataToUSART(USARTx,0xab);
	SendDataToUSART(USARTx,0xba);
	SendDataToUSART(USARTx,7);
	SendDataToUSART(USARTx,0xa3);
	SendDataToUSART(USARTx,0xcc);
	SendDataToUSART(USARTx,0xcd);
	SendDataToUSART(USARTx,0xdc);
}

void COMSynSOS_test(USART_Module* USARTx)
{
	SendDataToUSART(USARTx,0xaa);
	SendDataToUSART(USARTx,0xbb);
	SendDataToUSART(USARTx,0xee);
	SendDataToUSART(USARTx,0xee);
}
/****************************************************************************
*	函 数 名:  getStatus
*	功能说明:  获取状态
*	形    参：
*	返 回 值:
* 说    明：
*****************************************************************************/
const static int HR_ONBED_BASE = 10,RR_ONBED_BASE = 10;
void getStatus(STATUS *status)
{
	int avrHr = 0,avrRr = 0,maxHr = 0,maxRr = 0;
	avrHr = getAbsAverage(sHrWaveBuf, 0, 150);//取最近的1s的数据来作分析
	avrRr = getAbsAverage(sRrWaveBuf, 0 , 150);//取最近的1s的数据来作分析
	maxHr = getMax(sHrWaveBuf, 0, 150);
	maxRr = getMax(sRrWaveBuf, 0, 150);

	if(maxHr < 50 ||(avrHr < 10 && avrRr < 10))
	{
		//不拿maxRr判断是因为可能是呼吸窒息
		status->isOnbed = 0;
	}else
	{
		status->isOnbed = 1;
	}
	if(Flag_COMDebug == 1)
		printf("avrhr..%d..avrRr..%d..maxHr..%d..maxRr..%d....isONbed...%d\r\n",avrHr,avrRr,maxHr,maxRr,status->isOnbed);
}
/****************************************************************************
*	函 数 名:  GetDataHead
*	功能说明:  获取数据包的数据头字节
*	形    参：
*	返 回 值:
* 说    明：张炜20170519加一个参数len，用于1~7个变化长度数据的数据头
*****************************************************************************/
unsigned char GetDataHead(unsigned char* datas,unsigned char len)
{
	uint8_t DH = 0x00;
	uint8_t i = 0;
	
	for(i=0;i<len;i++)
	{
		DH |= (*(datas+i)&0x80)>>(7-i);
	}
	return  DH;
}
