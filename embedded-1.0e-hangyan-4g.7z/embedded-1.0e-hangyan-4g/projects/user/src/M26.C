#include "m26.h"
#include "cJSON.h"
#include <stdlib.h>
#include "Fun.h"
#include "Parameter.h"
#include "string.h"
#include "Delay.h"
#include "USART.h"
#include "MobileAndlink.h"
#include "Mqttkit.h"
#include "Calculate.h"
#define SETBAUND        1
#define CHECKPIN        9
#define READCARD        2
#define CHECKCSQ        3
#define INIT_PAUSE      10
#define WAITREG         4
#define GPRSREG         5
#define CGATT           6
#define CONFIGCONNEXT   7

#define SETLINK_MODE    8
unsigned char SIMCard_IMEI[25];
uint8_t SIMCard_IMEI_Len=0;
uint8_t SIMCard_SN_Len=0;
unsigned char SIMCard_IMSI[20];
unsigned char SIMCard_SN[25]={0};
uint8_t SIMCard_IMSI_Len = 0;
unsigned char SIMCard_ICCID[25];
uint8_t SIMCard_ICCID_Len = 0;
char Device_ip[25];
uint8_t Device_ip_Len = 0;
uint16_t  Init_pauseTime =0 ; 
uint16_t  LTE_InitTime=0;  //LTE初始化时间
u8 Flag_Init_Step=1;
u8 GPRS_QIMUX(void);
uint8_t Set_ATE(uint8_t x);
char SLM750V_Query_VER(void);
char SLM750V_Query_MNOReg(void);
char SLM750V_Query_NetTyp(void);
char SLM750V_Query_APNstate(void);
char SLM750V_Query_Link(void);
char SLM750V_Close_Socket(void);
char SLM750V_Open_Socket(char *ipaddr,char *ipport);
char SLM750V_Send_Data(uint8_t *data,uint16_t len );


/****************************************************************************
*	函 数 名: SLM750V_GPIO_CONFIG
*	功能说明: 初始化SLM750的开机引脚和复位引脚
*	形    参：
*	返 回 值:
* 	说    明：
*****************************************************************************/
void SLM750V_GPIO_CONFIG(void)
{

	GPIO_InitType GPIO_InitStruct;

	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO, ENABLE);

	GPIO_ConfigPinRemap(GPIO_RMP_SW_JTAG_SW_ENABLE, ENABLE);		// 重新设为GPIO
	
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);	
    GPIO_InitStruct.Pin=LTE_PWRKEY_PIN|LTE_RESETN_PIN;
    GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_InitPeripheral(LTE_PWRKEY_GPIO_PORT, &GPIO_InitStruct);

	
	
	
	LTE_RESETN(1);
	LTE_PWRKEY(0);	
	
	
}
/****************************************************************************
*	函 数 名: LTE_StartUP
*	功能说明: LTE开机
*	形    参：
*	返 回 值:返回初始化完成的步骤
* 	说    明：
*****************************************************************************/
char SLM750V_StartUP(void)
{
	
	if(Flag_COMDebug == 1)
	{						
		printf("Start up LTE \r\n");
	}
		
	delay_ms(100);
	LTE_PWRKEY(0);
	delay_ms(500);//slm750  test code!!!
//    delay_ms(2000);//air720g  test code!!!
	LTE_PWRKEY(1);

	mytime = 0;
	LTE_RESETN(0);
    //delay_ms(450);//slm750
    delay_ms(60);//air720g
    //LTE_RESETN(1);
    //20211108 原来硬件拉低，先改为PB4拉低
    LTE_RESETN(0);
    RePowerOn_GPRS();
	if(Flag_COMDebug == 1)
		printf("LTE上电完成...\r\n");
}
void Init_M26(u8 int_step)
{
    char res1,res2;
    switch(int_step)
    {
        case 1:
            SLM750V_GPIO_CONFIG();//配置io
            SLM750V_StartUP();//上电开机
            Flag_Init_Step=2;
        break;
        case 2:
            if(Set_ATE(0))//ate
				if(Check_PIN())//查看SIM卡的状态
					if(Read_Card_IMSI())
						if(Read_Card_IMEI())//查看SIM卡的状态     
						{
							if(Read_Card_CCID())//获取卡编号
							{
								if(SLM750V_Query_MNOReg())//Write command forces an attempt to select and register the GSM/UMTS network operator
								{
									Flag_Init_Step=3;
								}
							}
						}
//			if(ReadAndlinkinfoFromFlash() == 1)
//			{
//				Andlink_DeviceRegist();
//				BroadcastRegistResultByCoap(); 
//				BroadcastAccessInNetworkByCoap();				
//			}
        break;
        case 3:
            if(InquireCSQ())//信号强度
                if(Wait_CREG())
					Flag_Init_Step=4;
        break;
        case 4:
			if(AT_CGATT_Ctrl() == 1)  //一直停留在此阶段，不进行高层业务
				Flag_Init_Step=5;
        break;
        case 5:
		if(LTE_Set_ConnectIP_MUX() == 1)
			if(LTE_Select_Data_Sending_Mode() ==1)
                Flag_Init_Step=6;
        break;
        case 6:
			if(Set_APN_Function() ==1)
				if(AT_CIICR_() == 1) 
					Flag_Init_Step=7;
//            delay_ms(1000);
        break;
        case 7:
			if(Get_LocalIP_Address() == 1)
				if(CheckLinkStatus() == 2)
				{
					Flag_init = WIRELESS_INIT_OK;
					Flag_Init_Step=8;
					if(Flag_COMDebug == 1)
						printf("PowerBatteryFlag:%d,SleepData_SendTime:%d\r\n",PowerBatteryFlag,SleepData_SendTime);
					#ifdef Demonstrate
					AngelPace = POWER_ON_NOTIFY;
					Connect_DM_Server();
					#else
					AngelPace = DM_CONFIG_Auto;
					#endif
//					if(PowerBatteryFlag == 1)  //电池供电
					if((SleepData_SendTime == CGATTime_10)&&(RealBatchIndex != 0))
					{
						PowerBatteryFlag = 1;  //test code!!! 程序会异常清零
					}
				}
//            delay_ms(1000);
        break;
        default:
            
        break;
    
    }

}
uint8_t Set_Baund(void)
{
	 char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+IPR=115200&W\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"OK")!=NULL)
        {
			if(Flag_COMDebug == 1)
				printf("set baund ok\r\n");
            return 1;
        }
        if(mytime >5)
        {
			if(Flag_COMDebug == 1)
				printf("set baund time out\r\n");
            return 0;
        }
    }
}
uint8_t Set_ATE(uint8_t x)
{
	char *pstr;
    char cmd[5]="";
	ClearUSART3BUF(); 
	mytime = 0;	
        
    sprintf(cmd,"ATE%d\r\n",x);
    UART3_SendString(cmd);
    while(1)
    {
        
        delay_ms(500);
        if(strstr(ucUar3tbuf,"OK")!=NULL)
        {
			if(Flag_COMDebug == 1)
				printf("%s OK\r\n",cmd);
			#ifdef SOS_1_0
			COMSynSOS_NetStatus(USART1,0);  //上电时向SOS发一条信息
			#endif
            return 1;
        }
        if(mytime >5)
        {
			if(Flag_COMDebug == 1)
				printf("set %s time out\r\n",cmd);
            return 0;
        }
    }
}
uint8_t Check_PIN(void)
{
	 char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+CPIN?\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"OK")!=NULL)
        {
			if(Flag_COMDebug == 1)
				printf("SIM Card is already\r\n");
            return 1;
        }
        if(mytime >5)
        {
			if(Flag_COMDebug == 1)
				printf("Read PIN time out:%s\r\n",ucUar3tbuf);
            return 0;
        }
    }
}
uint8_t Wait_CREG(void)
{
	 char *pstr;
    
    u8 cfg;
    u8 state;
    u8 lac[10]={0};
    u8 ci[10]={0};
	char stringbuf1[30]={0};//提取其他
    uint32_t t_lac,t_cid;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+CREG?\r\n");
        delay_ms(100);
        if((strstr(ucUar3tbuf,"+CREG:")!= NULL))  //提取位置信息
        {
			if(Flag_COMDebug == 1)
				printf("%s\r\n",ucUar3tbuf);
			sscanf(ucUar3tbuf,"%*[^:]: %d,%d,%s",&cfg,&state,stringbuf1);
//            sscanf(ucUar3tbuf,"%*[^:]: %d,%d,\"%[^\"]\",\"%[^\"]\"",&cfg,&state,lac,ci);						
			sscanf(lac,"%x",&t_lac);
            sscanf(ci,"%x",&t_cid);
            Position_LAC=t_lac;
            Position_CID=t_cid;
			if(Flag_COMDebug == 1)
				printf("lac: %x,cid: %x",t_lac,t_cid);
            if(state==1)
            {
				if(Flag_COMDebug == 1)
					printf("网络注册成功 \r\n");
                return 1;
            }
            else
            {
				if(Flag_COMDebug == 1)
					printf("网络未注册 \r\n");
                ClearUSART3BUF();
                UART3_SendString("AT+CREG?\r\n");
            }
        }
        if(mytime >5)
        {
			if(Flag_COMDebug == 1)
				printf("网络注册超时 \r\n");
            return 0;
        }
    }
}
uint8_t AT_CGATT_Ctrl(void)
{
	 char *pstr;
     u8 state;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+CGATT?\r\n");
        delay_ms(50);
        if((strstr(ucUar3tbuf,"+CGATT:")!= NULL))  //提取位置信息
        {
			if(Flag_COMDebug == 1)
				printf("%s\r\n",ucUar3tbuf);
            sscanf(ucUar3tbuf,"%*[^:]: %d",&state);
			if(state==1)
            {
				if(Flag_COMDebug == 1)
					printf("GPRS业务已经附着\r\n");
                return 1;
            }
			else
				return 0;
        }
        if(mytime >5)
        {
			if(Flag_COMDebug == 1)
				printf("GPRS附着失败");
            return 0;
        }
    }
}

char LTE_Set_ConnectIP_MUX(void)
{
	char stringbuf1[20]={0};
	char cmd[100]= "";
	
	ClearUSART3BUF();
	UART3_SendString("AT+CIPMUX=0\r\n");
	mytime = 0;
	while(1)
	{
		delay_ms(50);
        //printf("AT+CIPMUX=0:%s\r\n",LTEUART_RX_BUFFER);

		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
				printf("Set IP 为单链接\r\n");
			ClearUSART3BUF();
			return 1;
		}
		if(mytime>3)
		{		
			if(Flag_COMDebug == 1)
				printf("Set IP fail\r\n");
			ClearUSART3BUF();
			return 0;
		}
	}
}

char LTE_Select_Data_Sending_Mode(void)
{
	ClearUSART3BUF();
	UART3_SendString("AT+CIPQSEND=0\r\n");  //快发模式
	mytime = 0;
	while(1)
	{
		delay_ms(50);
        //printf("AT+CIPQSEND=0:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{		
			if(Flag_COMDebug == 1)			
				printf("Set_Data_Sending_Mode successed\r\n");
			ClearUSART3BUF();
			return 1;
		}
		if(mytime>3)
		{
            ClearUSART3BUF();
			if(Flag_COMDebug == 1)
				printf("Set_Data_Sending_Mode failed\r\n");
			return 0;
		}
	}
	
}

char Set_APN_Function(void)
{
    ClearUSART3BUF();	
    UART3_SendString("AT+CSTT\r\n");
    mytime = 0;
    while(1)
	{
        delay_ms(50);
        if(strstr(ucUar3tbuf,"OK")!= NULL) 
        {
            if(Flag_COMDebug == 1)
            {						
                printf("Ask APN Succeed\r\n");
            }
            return 1;
        }
        if(mytime>3)
		{
            ClearUSART3BUF();	
			if(Flag_COMDebug == 1)			
				printf("Ask APN failed:%s\r\n",ucUar3tbuf);
            return 0;
		}
    }
}

uint8_t AT_CIICR_(void)
{
	 char *pstr;
     u8 state;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+CIICR\r\n");
        delay_ms(500);
        if((strstr(ucUar3tbuf,"OK")!= NULL))  //提取位置信息
        {
			if(Flag_COMDebug == 1)
				printf("激活移动场景成功\r\n");
//            sscanf(ucUar3tbuf,"%*[^:]: %d",&state);
//            if(state==1)
//            printf("MT 附着 GPRS 业务");
            return 1;
        }
        if(mytime >5)
        {
			if(Flag_COMDebug == 1)
				printf("激活移动场景失败\r\n");
                
            return 0;
        }
    }
}
char Get_LocalIP_Address(void)
{
    ClearUSART3BUF();	
	UART3_SendString("AT+CIFSR\r\n");
	mytime = 0;
    while(1)
    {
        delay_ms(50);
        //printf("AT+CIFSR:%s\r\n",LTEUART_RX_BUFFER);
        if(strstr(ucUar3tbuf,".")!= NULL) 
        {
			if(Flag_COMDebug == 1)
				printf("Get_LocalIP_Address:%s\r\n",ucUar3tbuf);
			sscanf(ucUar3tbuf,"%s\r\n",&Device_ip);
			Device_ip_Len = strlen(Device_ip);
			Device_ip[Device_ip_Len]= '\0';					
			if(Flag_COMDebug == 1)
				printf("ip:%s\r\n",Device_ip);
            ClearUSART3BUF();
            return 1;
        }
        if(mytime>3)
		{
            ClearUSART3BUF();
			if(Flag_COMDebug == 1)
			{						
				printf("Get_LocalIP_Address failed:%s\r\n",ucUar3tbuf);
			}
            return 0;
		}
    }
}
char CheckLinkStatus(void)
{
	static u8 LTE_FAILD_COUNT=0;
    ClearUSART3BUF();	
	UART3_SendString("AT+CIPSTATUS\r\n");
	mytime = 0;
    while(1)
    {
        delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
				printf("AT+CIPSTATUS：%s\r\n",ucUar3tbuf);
			if (strstr(ucUar3tbuf,"CONNECT OK")!= NULL)
			{
				LTE_FAILD_COUNT=0;
				if(Flag_COMDebug == 1)
					printf("TCP CONNECT OK\r\n");
				ClearUSART3BUF();
				return 1;
			}
			else if(strstr(ucUar3tbuf,"IP STATUS")!= NULL) 
			{
				LTE_FAILD_COUNT=0;
				if(Flag_COMDebug == 1)
					printf("TCP IP STATUS\r\n");
				ClearUSART3BUF();
				return 2;
			}
			else if(strstr(ucUar3tbuf,"CLOS")!= NULL)
			{
				if(Flag_COMDebug == 1)
					printf("TCP NOCONNECT\r\n");
				ClearUSART3BUF();
				return 0;
			}
		}
        if(mytime>1)
		{
			LTE_FAILD_COUNT++;
            ClearUSART3BUF();
			UART3_SendString("AT+CIPSTATUS\r\n");
			mytime = 0;	
			if(Flag_COMDebug == 1)
				printf("链接状态异常:%s\r\n",ucUar3tbuf);
			ClearUSART3BUF();
		}
		if(LTE_FAILD_COUNT>=3)
		{
			LTE_FAILD_COUNT = 0;
			return 0;
		}
    }
}
uint8_t Set_Connext(void)
{
	 char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+QIFGCNT=0\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"OK")!=NULL)
        {
            return 1;
        }
        if(mytime >5)
        {
            return 0;
        }
    }
}
uint8_t InquireCSQ(void)
{
	 char *pstr;
//	u8 stringbuf1[20]={0}; 
    u8   Command_SendCount=0;
    ClearUSART3BUF(); 
  
	 mytime = 0;  
    while(1)
    {
        UART3_SendString("AT+CSQ\r\n");
        delay_ms(50);
        if(strstr(ucUar3tbuf,"+CSQ")!= NULL) 
		{
			sscanf(ucUar3tbuf,"%*[^:]: %d",&CSQNual);
			if(Flag_COMDebug == 1)
				printf("\r\nCSQ = %d\r\n",CSQNual);
			
			ClearUSART3BUF();
			if((CSQNual>0)&&(CSQNual<33))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+CSQ\r\n");
            mytime = 0;
			Command_SendCount++;
			delay_ms(50);
		}
        if((mytime >5)||(Command_SendCount>5))
        {
            return 0;
        }
    }
}
uint8_t InquireTCPstat(void)
{
	 char *pstr;
	u8 state[20]={0}; 
    u8 index =0;
    u8 mode[20]={0};
    u8 addr[20]={0}; 
    u8 port[20]={0};     
    u8   Command_SendCount=0;
    ClearUSART3BUF(); 
  
	 mytime = 0;  
    while(1)
    {
        UART3_SendString("AT+QISTAT\r\n");
        delay_ms(500);
        pstr=strstr(ucUar3tbuf,"CONNECT OK");
        if(pstr!= NULL) 
		{
//            printf("u3: %s\r\n",ucUar3tbuf);
//			sscanf(ucUar3tbuf,"%*[^:]: %s",state);
			if(Flag_COMDebug == 1)
				printf("\r\nSTATE = %s\r\n",pstr);
			
			ClearUSART3BUF();
			mytime = 0;
				return 1;
			
			
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+QISTAT\r\n");
            mytime = 0;
			Command_SendCount++;
			delay_ms(50);
		}
        if((mytime >5)||(Command_SendCount>3))
        {
            return 0;
        }
    }
}
uint8_t Wait_CGREG(void)
{
	 char *pstr;
    
    u8 cfg;
    u8 state;
    u8 lac[10]={0};
    u8 ci[10]={0};
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+CGREG?\r\n");
        delay_ms(500);
        if((strstr(ucUar3tbuf,"+CGREG:")!= NULL))  //提取位置信息
        {
			if(Flag_COMDebug == 1)
				printf("%s\r\n",ucUar3tbuf);
            sscanf(ucUar3tbuf,"%*[^:]: %d,%d,\"%[^\"]\",\"%[^\"]\"",&cfg,&state,lac,ci);						
			
            if(state==1)
            {
				if(Flag_COMDebug == 1)
					printf("GPRS网络注册成功 \r\n");
                return 1;
            }
            else
            {
				if(Flag_COMDebug == 1)
					printf("GPRS网络未注册 \r\n");
                ClearUSART3BUF();
                UART3_SendString("AT+CGREG?\r\n");
            }
        }
        if(mytime >5)
        {
			if(Flag_COMDebug == 1)
				printf("GPRS网络注册超时 \r\n");
            return 0;
        }
    }
}
int8_t  Read_Card_IMSI(void)
{
	 char *pstr;
	 uint8_t d[20];
	 uint8_t i =0;
	 delay_ms(100);
	 ClearUSART3BUF();
	 UART3_SendString("AT+CIMI\r\n");
	 mytime = 0;
	 delay_ms(100);
	 while(1)
	 {
         delay_ms(50);
//        if(strstr(ucUar3tbuf,"+CSQ")!=NULL)  //上一步骤中返回CSQ没有清理
//        {
//            ClearUSART3BUF();
//            UART3_SendString("AT+CIMI\r\n");
//            mytime = 0;
//            delay_ms(100);
//		}				
//		if((strstr(ucUar3tbuf,"OK")!=NULL)&&(strstr(ucUar3tbuf,"460")!=NULL))  //模块返回IMSI号
//		{
//            if(Flag_COMDebug == 1)
//            printf("%s",ucUar3tbuf);
//            pstr = strstr(ucUar3tbuf,"460");
//            CARD_ID[0] = 0x39;
//            ICCID_LEN = 1;			 
//            while(*pstr != 0x0D)
//            {
//                CARD_ID[ICCID_LEN++] = *pstr++;
//            }					 
//            CARD_ID[ICCID_LEN] = '\0';
//            if(Flag_COMDebug == 1)
//            printf("SIM CARD IMSI is:%s len is:%d\r\n",CARD_ID,ICCID_LEN);
//            ClearUSART3BUF();
//            return 1;
//		}
//        if(strstr(ucUar3tbuf,"NO SIM CARD")!=NULL)  //未插入SIM卡
//        {
//             if(Flag_COMDebug == 1)
//             {
//                 printf("%s",ucUar3tbuf);
//                 printf("No SIM Card! Please Check!\r\n");
//             }
//             return -1;
//        }
		if(strstr(ucUar3tbuf,"OK")!= NULL)
		{
			pstr = strstr(ucUar3tbuf,"460");
			//CARD_ID[0] = 0x39;
            ICCID_LEN = 0;
			SIMCard_IMSI_Len = 0;
			while(*pstr != 0x0D)
			{
				SIMCard_IMSI[SIMCard_IMSI_Len++] = *pstr++;
			}
			SIMCard_IMSI[SIMCard_IMSI_Len]= '\0';					
			if(Flag_COMDebug == 1)						
				printf("IMSI:%s\r\n",SIMCard_IMSI);
			
			 ClearUSART3BUF(); 
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CIMI\r\n");
			//Command_SendCount++;
			 ClearUSART3BUF(); 
			delay_ms(50);
		}
        if(mytime > 3)  //3s未回应，超时
        {
            if(Flag_COMDebug == 1)
            {
                printf("%s",ucUar3tbuf);
                printf("Read IMSI time out:%s\r\n",ucUar3tbuf);
            }
            ClearUSART3BUF();
            return 0;
        }
	 }
	
}
/****************************************************************************
*	函 数 名: Read_Card_CID
*	功能说明: 获取卡编号
*	形    参：id卡号保存的位置,len卡号长度
*	返 回 值: 返回1标识正确读取，返回-1表示没有插入卡，返回0表示读取失败
* 说    明：
*****************************************************************************/
int8_t  Read_Card_CCID(void)
{
    
	 char *pstr;
	 uint8_t d[20];
	 uint8_t i =0;
    char stringbuf1[30]={0};
    u8 Command_SendCount=0;
	 delay_ms(100);
	 ClearUSART3BUF();
	 UART3_SendString("AT+ICCID\r\n");
    
	  mytime = 0;
	 delay_ms(300);
	 while(1)
	 {
         delay_ms(50);
        if(strstr(ucUar3tbuf,"+CSQ")!=NULL)  //上一步骤中返回CSQ没有清理
		{
            ClearUSART3BUF();
            UART3_SendString("AT+ICCID\r\n");
            mytime = 0;
            delay_ms(300);
		}			

//		  if(strstr(ucUar3tbuf,"OK")!=NULL)  //模块返回CCID号
//			{
//				 if(Flag_COMDebug == 1)
//						printf("%s",ucUar3tbuf);				 
////				 ICCID_LEN = strcspn(ucUar3tbuf,"OK")-15;
//				 ICCID_LEN = 20;
//                 memcpy(CARD_ID,ucUar3tbuf+11,ICCID_LEN);
//				 CARD_ID[ICCID_LEN] = '\0';
//				 if(Flag_COMDebug == 1)
//						printf("SIM CARD CCID is:%s len is:%d\r\n",CARD_ID,ICCID_LEN);
//				 ClearUSART3BUF();
//				 return 1;
//			}
        if(strstr(ucUar3tbuf,"ICCID:")!= NULL)
		{
//			pstr = strstr(LTEUART_RX_BUFFER,"8986");
			sscanf(ucUar3tbuf,"%*[^:]: %s\r\n%s",&SIMCard_ICCID,stringbuf1);
			SIMCard_ICCID_Len = strlen(SIMCard_ICCID);
			SIMCard_ICCID[SIMCard_ICCID_Len]= '\0';					
			if(Flag_COMDebug == 1)						
				printf("ICCID:%s\r\n",SIMCard_ICCID);
			
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+QCCID\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}
			if(mytime >5)  //5s未回应，超时
			{
				if(Flag_COMDebug == 1)
						printf("Read CCID time out:%s\r\n",ucUar3tbuf);
				ClearUSART3BUF();
				return 0;
			}
	 }
	
}
int8_t  Read_Card_IMEI(void)
{
    
	 char *pstr;
	 uint8_t d[20];
	 uint8_t i =0;
    char stringbuf2[30]={0};
    char stringbuf1[30]={0};
    u8 Command_SendCount=0;
	 delay_ms(100);
	 ClearUSART3BUF();
	 UART3_SendString("AT+CGSN\r\n");
    
	  mytime = 0;
	 delay_ms(300);
	 while(1)
	 {
         delay_ms(50);

        if(strstr(ucUar3tbuf,"OK")!= NULL)
		{
//			pstr = strstr(LTEUART_RX_BUFFER,"8986");
			if(Flag_COMDebug == 1)
				printf("%s\r\n",ucUar3tbuf);
//			sscanf(ucUar3tbuf,"%s\r\n%s\r\n%s",&SIMCard_IMEI,&stringbuf2,stringbuf1);
//			SIMCard_IMEI_Len = strlen(SIMCard_IMEI);
//			SIMCard_IMEI[SIMCard_IMEI_Len]= '\0';					
//			if(Flag_COMDebug == 1)						
//				printf("IMEI:%s\r\n",SIMCard_IMEI);
			
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CGSN\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}
			if(mytime >5)  //5s未回应，超时
			{
				if(Flag_COMDebug == 1)
						printf("Read IMEI time out:%s\r\n",ucUar3tbuf);
				ClearUSART3BUF();
				return 0;
			}
	 }
	
}
void GPRSSendData(unsigned char *p,unsigned int Len)
{
	ClearUSART3BUF();
//	printf("SendData len:%d :%s\r\n",Len,p);
	UART3_SendString_YB(p,Len);
	UART3_SendLR();

}
u8 GPRS_Send_Data(char *data,uint16_t len)
{
    #if 1
    char *pstr;
    char cmd[20]="0";
    u8 waittime = 0;
    ClearUSART3BUF(); 
    
    sprintf(cmd,"AT+CIPSEND=%d\r\n",len);
    while(1)
    {
        UART3_SendString(cmd);//发送指令
        delay_ms(50);//延时50毫秒等待发送
        if(strstr(ucUar3tbuf,">")!=NULL)//判别接收的字符中有没有相应字符
        {
            mytime = 0;
            UART3_SendData(data,len);
			ClearUSART3BUF();
            while(1)
            {
                if(strstr(ucUar3tbuf,"SEND OK")!=NULL)
                {
//                    ClearUSART3BUF();
					if(Flag_COMDebug == 1)
						printf("发送成功 \r\n");
                    return 1;
                }
                if(mytime >3)
                {
					if(Flag_COMDebug == 1)
						printf("发送失败:%s\r\n",ucUar3tbuf);
                    return 0;
                }
            }
        }
        waittime++;
        if(waittime >60)
        {
//			if(Flag_COMDebug == 1)
				printf("发送失败\r\n");
            return 0;
        }
    }
    #else
    SLM750V_Send_Data(data,len);
    #endif
}

char GPRS_Wait_Resp(char *expect_str, char timeout_sec)
{
    mytime = 0;
    while (mytime < timeout_sec) {
        
        delay_ms(100);
        if (strstr(ucUar3tbuf, expect_str)) {
            log_trace("get exp[%s] \r\n", ucUar3tbuf);
            //ClearUSART3BUF();
            return 1;
        }
    }
    log_trace("timeout exp[%s] \r\n", expect_str);
    return 0;
}

void GetGPRSPosition(void)
{
	uint8_t i;
	char *ppos = NULL;
	unsigned char lacstring[5]={0};
	unsigned char cidstring[5]={0};
	unsigned char posstring[15]={0};
	int len = 0;
		
	  ClearUSART3BUF();
	  UART3_SendString("AT+CREG\r\n");
	  mytime = 0;
	  delay_ms_YB();
//	  printf("%s",ucUar3tbuf);
		while(1)
		{			
			ppos = strstr(ucUar3tbuf,"+CREG");
			if( ppos != NULL )
			{
				 memcpy(posstring,ppos+11,11);
				 if(Flag_COMDebug == 1)
						printf("grps位置为：%s ",posstring);
				 ppos = strstr(posstring,",");
				 memcpy(cidstring,ppos+1,5);
				 len = strlen(posstring)-strlen(cidstring);
				 memcpy(lacstring,posstring,len-1);				 
//				 printf("LAC string:%s  CID string:%s  \r\n",lacstring,cidstring);
				 Position_LAC = atoi(lacstring);			
				 Position_CID = atoi(cidstring);
         if(Flag_COMDebug == 1)				 
						printf("LAC 16data:0x%x  CID 16data:0x%x  \r\n",Position_LAC,Position_CID);
				 ClearUSART3BUF();
				 break;
			}
			if(mytime > 2)
			{
				 if(Flag_COMDebug == 1)
						printf("Get GPRS position error!\r\n");
				 ClearUSART3BUF();
				break;
			}
	 }

}
char MyCountChar(unsigned char *p,int pLen)
{
	int i=0;
	char icount=0;
	for(i=0;i<pLen;i++){
		if(p[i]=='.'){
			icount++;
		}
	}
	return icount;
}
u8 GPRS_QIMUX(void)
{

    char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+QIMUX=0\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"OK")!=NULL)
        {
            return 1;
        }
        if(mytime >5)
        {
            return 0;
        }
    }
}
/****************************************************************************
*	函 数 名: Set_IPLink_Mode
*	功能说明: 设置网络连接模式
*	形    参：0为IP连接，1为域名连接
*	返 回 值: 0为设置失败，1为设置成功
* 说    明：
*****************************************************************************/
uint8_t Set_IPLink_Mode(uint8_t mode)
{
	  char *pstr;
	  uint8_t count=0;
	 	ClearUSART3BUF(); 
	  mytime = 0;	 
	 while(1)
	 {
		   if(mode == 0)
			 {
					UART3_SendString("AT+QIDNSIP=0\r\n");
			 }
			 else
			 {
					UART3_SendString("AT+QIDNSIP=1\r\n");
			 }
			 count++;
			 delay_ms(300);
			 if(strstr(ucUar3tbuf,"OK")!=NULL)
			 {
				  return 1;
			 }
			 if(count >5)
			 {
				 return 0;
			 }
	 }
}
u8 GPRS_Query_TCPstate(void)
{
    char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+QISTAT\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"TCP CONNECTING")!=NULL)
        {
            return 1;
        }
        if(strstr(ucUar3tbuf,"CONNECT OK")!=NULL)
        {
            return 0;
        }
        if(strstr(ucUar3tbuf,"IP INITIAL")!=NULL)
        {
            return 0;
        }
        if(strstr(ucUar3tbuf,"IP START")!=NULL)
        {
            return 0;
        }
        if(strstr(ucUar3tbuf,"IP CONFIG")!=NULL)
        {
            return 0;
        }
        if(mytime >5)
        {
            return 0;
        }
    }
}
u8 GPRS_CloseSocket(void)
{
    #if 0
	 char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+QICLOSE\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"CLOSE OK")!=NULL)
        {
            printf("关闭连接成功\r\n");
            return 1;
        }
        if(mytime >5)
        {
            printf("关闭连接失败\r\n");
            return 0;
        }
    }
    #else
    SLM750V_Close_Socket();
    #endif
}
u8 GPRS_ConnectIP(char *ip,char *port)
{
    char stringbuf1[20]={0};
	char cmd[100]= "";
	u8 Socket;
	ClearUSART3BUF();;
	sprintf(cmd,"AT+QIOPEN=\"TCP\",\"%s\",%s\r\n",ip,port);  //
    UART3_SendString(cmd);
    mytime = 0;
    while(1)
    {
        delay_ms(50);
        if(strstr(ucUar3tbuf,"CONNECT")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set IP successed\r\n");
			}
			ClearUSART3BUF();
			return 1;
		}
//		if(strstr(ucUar3tbuf,"OK")!= NULL) 
//		{
//			sscanf(ucUar3tbuf,"%*[^:]: %d,%s",&Socket,stringbuf1);
//			if(Flag_COMDebug == 1)
//			{
//				printf("Set IP successed,Socket=%d\r\n",Socket);
//			}

//			ClearUSART3BUF();
//			return 1;
//		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set IP error:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
        if(mytime >5)
        {
            return 0;
        }
    
    }
    
}
void GetBackServerIP(void)
{
	 uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
	 uint8_t data_len=0;
	 SendData[data_len++] = CMD_START;
	 SendData[data_len++] = TypeID;
	 SendData[data_len++] = (12+2)|0x80;
	 SendData[data_len++] = REQ_SECOND_SERVER;
	 for(i=0;i<12 ;i++)
	 {
			SendData[data_len++]=MAC_IDstring[i];
	 }
	 for(i = 0;i< 12;i++)
	 {
			jiaoyan += MAC_IDstring[i];
	 }
	 jiaoyan +=REQ_SECOND_TOKEN;
	 SendData[data_len++] = jiaoyan|0x80 ;
	 SendData[data_len++] = CMD_LF1;
	 SendData[data_len++] = CMD_LF2;
     ClearUSART3BUF();
	 GPRS_Send_Data(SendData,data_len);
    							//发送完毕
    mytime = 0;										//开始计时超时
    memset(SendDataBuff, 0x00, sizeof(SendDataBuff));
    memset(IP2, 0x00, sizeof(IP2));
    memset(chanl2, 0x0, sizeof(chanl2));
     if(Flag_COMDebug == 1)
     {
         printf("Get IP2 from front server:");
         for(i=0;i<data_len;i++)
         {
             printf("%02x ",SendData[i]);
         }
         printf("\r\n");
     }
     SendDataStatus = OK;
}
void AnalysisBackServerIP(void)
{
	 char *pstr,*pstr1;
	 uint8_t len;
	 uint8_t i=0;
	 uint8_t ip[6];
	 char buf[100];
	 char err;
	 
//	 if(strstr(ucUar3tbuf,"+QIURC: \"recv\"") != NULL)   //收到服务器数据
//	 {
//	    delay_ms(100);	
		  pstr = strstr(ucUar3tbuf, "$");
		  pstr1 = strstr(ucUar3tbuf, "iB");
		  
		  if((pstr!=NULL)&&(pstr1!=NULL))
			{
				 if((pstr[1] == TypeID)&&(pstr[3] == REQ_SECOND_SERVER))
				{   
					memset(IP2,0X00,20);
					memset(chanl2,0X00,5);
					 for(i=0;i<6;i++)
					{
						 if(((pstr[4]<<(7-i))&0x80)==0x80)
						    ip[i]= pstr[5+i];
						 else
							  ip[i]= pstr[5+i]&0x7F;
					 }	
					 sprintf(IP2, "%d.%d.%d.%d", ip[0],ip[1],ip[2],ip[3]);
					 sprintf(chanl2, "%d", ip[4]*100+ip[5]);
					 //SaveIP2ToFlash();
					 if(Flag_COMDebug == 1)
						{						
							printf("IP2:%s\r\n", IP2);
							printf("Port2:%s\r\n", chanl2);
						}
					 AngelPace = GETBACKSERVERIPOK;
                    SendDataStatus = NO;
				}
				if((pstr[1]== TypeID)&&(pstr[3] ==SERVER_ABNORMAL_MESSAGE)) 
				 {
					 if(pstr[4] == SERVER_CHECK_MAC_ERR)  //MAC验证错误
					 {
							 if(Flag_COMDebug == 1)
							 {
									printf("Server Return MAC Verify Error!\r\n");
							 }
							 AngelPace = CONECTIP1;					//重新连接前置服务器
                            SendDataStatus = NO;
					 }	
				   		 
				 } 	 			 
			}		
	 //}
 if(mytime > GetDataTimerOut)
        {
					  if(Flag_COMDebug == 1)
							printf("Timer out!%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//重新连接前置服务器
            SendDataStatus = NO;
        }

}
void Connect_BackServer(void)
{
    char cmd[100]={0};
    //if((GPRS_or_WIFI == GPRS) && (AngelPace == CONECTIP1))
//    {
        GPRS_CloseSocket();
        //if(SendDataStatus != OK) 			//发送数据
//        {
            ClearUSART3BUF();
//            UART3_SendString_YB(IPstring, strlen(IPstring));
//            UART3_SendLR();
            //sprintf(cmd,"AT+QIOPEN=\"TCP\",\"%s\",\"%s\"\r\n",IP2,chanl2);  //
             sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",IP2,chanl2);
            UART3_SendString(cmd);
					  if(Flag_COMDebug == 1)
							printf("%s", cmd);
            SendDataStatus = OK;
            mytime = 0;
            while(1)
            {
                if(mytime>5)return;
                if((strstr(ucUar3tbuf, "OK") != NULL))					//是否返回指定字符串
                {
                              if(Flag_COMDebug == 1)
                                {
                                    printf("%s\r\n", ucUar3tbuf);
                                    printf("CMD Success!\r\n");
                                }
                    //AngelPace = CONECTIP1OK;							//链接服务器成功
                       AngelPace = CONECTIP2OK;
                    SendDataStatus = NO;
                                return;
                }
                if(strstr(ucUar3tbuf, "ERROR") != NULL || strstr(ucUar3tbuf, "error") != NULL) 		//返回error的话，进行三次重发数据，去除数据传输不稳定的影响
                {
                              if(Flag_COMDebug == 1)
                                    printf("%s\r\n", ucUar3tbuf);
                    SendDataStatus = NO;
                              return;
                }
                if(strstr(ucUar3tbuf, "CONNECT FAIL") != NULL)
                {
                    AngelPace = CONECTIP1;
                              if(Flag_COMDebug == 1)
                                    printf("%s\r\n", ucUar3tbuf);
                    SendDataStatus = NO;
                              return;
                }
            }
//        }
//    }
}
 void Analysis_BackServer(void)
 {
     if(GPRS_or_WIFI == GPRS)
    {
        if((strstr(ucUar3tbuf, "CONNECT") != NULL))					//是否返回指定字符串
        {
					  if(Flag_COMDebug == 1)
						{
							printf("%s\r\n", ucUar3tbuf);
							printf("CMD Success!\r\n");
						}
            //AngelPace = CONECTIP1OK;							//链接服务器成功
               AngelPace = CONECTIP2OK;
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "ERROR") != NULL || strstr(ucUar3tbuf, "error") != NULL) 		//返回error的话，进行三次重发数据，去除数据传输不稳定的影响
        {
					  if(Flag_COMDebug == 1)
							printf("%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "CONNECT FAIL") != NULL)
        {
            AngelPace = CONECTIP1;
					  if(Flag_COMDebug == 1)
							printf("%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        if(mytime > ConnetServerTimeOut) 						//超时
        {
					  if(Flag_COMDebug == 1)
							printf("Timer Out:%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "SHUT OK") != NULL)
        {
            delay_ms_YB();
					  if(Flag_COMDebug == 1)
							printf("%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        CheckSystemErrorContrl();								//模块出现异常情况
    }
 }     
/****************************************************************************
*	函 数 名: GetBackServerToken2
*	功能说明: 获取后置服务器token
*	形    参：无
*	返 回 值: 
* 	说    明：
*****************************************************************************/
void GetBackServerToken2(void)
{
   	 uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
     uint8_t    DATA[200]="";
     
	 uint16_t data_len=0;
	 SendData[data_len++] = CMD_START;
	 SendData[data_len++] = TypeID;
	 SendData[data_len++] = (12+2)|0X80;
	 SendData[data_len++] = REQ_SECOND_TOKEN;
	 for(i=0;i<12 ;i++)
	 {
			SendData[data_len++]=MAC_IDstring[i];
	 }
	 for(i = 0;i< 12;i++)
	 {
			jiaoyan += MAC_IDstring[i];
	 }
	 jiaoyan +=REQ_SECOND_TOKEN;
	 SendData[data_len++] = jiaoyan|0X80 ;
	 SendData[data_len++] = CMD_LF1;
	 SendData[data_len++] = CMD_LF2;
     ClearUSART3BUF();
     GPRS_Send_Data(SendData,data_len);
     							//发送完毕
     mytime = 0;										//开始计时超时
	  if(Flag_COMDebug == 1)
     {
         printf("Get TOKEN2 from front server:");
         for(i=0;i<data_len;i++)
         {
             printf("%02x ",SendData[i]);
         }
         printf("\r\n");
     }
     SendDataStatus = OK;
}	
/****************************************************************************
*	函 数 名: AnalysisBackServerToken2
*	功能说明: 分析后置服务器token
*	形    参：无
*	返 回 值: 
* 	说    明：
*****************************************************************************/
void AnalysisBackServerToken2(void)
{
	char *pstr,*pstr1;
	uint8_t len,i=0;
	char buf[100];
	char err;
    char retry=0;
	if(strstr(ucUar3tbuf,"SEND OK") != NULL)   //收到服务器数据
	{
		delay_ms(100);	
        
		pstr = strstr(ucUar3tbuf, "$");
		if(pstr!=NULL)
		{			
//            while(*pstr !='\0')
//             {
//                 printf("%02x ",*pstr++);
//             }
			if(Flag_COMDebug == 1)
			{
				printf("rec token data :%s\r\n",ucUar3tbuf);
				while(pstr[i]!='B')
					printf("%02x",pstr[i++]);
				printf("%02x\r\n",'B');
			}
            memset(Token2,0,sizeof(Token2));
			if((pstr[1] == TypeID)&&(pstr[3] == REQ_SECOND_TOKEN))
			{   												 	         
				TOKEN2_LEN = (pstr[2]&0x7F)-2;
						 for(i = 0;i< TOKEN2_LEN;i++)
								{
									Token2[i] = pstr[i+4];
								}
						 
				if(Flag_COMDebug == 1)
				{
					printf("Token2 is:%s\r\n",Token2);
				}
                ClearUSART3BUF();
				AngelPace = GETBACKSERVEROK;
                SendDataStatus = NO;
                //break;
			}
			if((pstr[1]== TypeID)&&(pstr[3] ==SERVER_ABNORMAL_MESSAGE)) 
			{
				if(pstr[4] == SERVER_CHECK_MAC_ERR)  //MAC验证错误
				{
					if(Flag_COMDebug == 1)
					{
						printf("Server Return MAC Verify Error!\r\n");
					}
                    ClearUSART3BUF();
					AngelPace = CONECTIP2OK;
                    mytime=0;
                    SendDataStatus = NO;
                   // break ;
				}	
							 
			} 	 			 
		}
        if(mytime > 5)
        {
           retry++;
            mytime=0;
            ClearUSART3BUF();
            GetBackServerToken2();
            if(retry>=3)
            {
					  if(Flag_COMDebug == 1)
							printf("Timer out!%s\r\n", ucUar3tbuf);
                    AngelPace = CONECTIP1;					//重新连接前置服务器
                    SendDataStatus = NO;
                      //break;
            }
        }		
	}

}
/****************************************************************************
*	函 数 名: SendBackServerVerify
*	功能说明: 获取后置服务器校验
*	形    参：无
*	返 回 值: 
* 	说    明：
*****************************************************************************/
void SendBackServerVerify(void)
{
	 uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
	 uint8_t len=0;
	 char buf[100];
	 unsigned char ucMd5data[30] = {0};
     unsigned char ucMd5string[40] = {0};
     unsigned char ucMd5string1[40] = {0};
	 uint16_t data_len=0;	 
	 sprintf(ucMd5data,"%s123456%s",MAC_IDstring,Token2);
     MDString(ucMd5data,ucMd5string);
	 HexToLowerStr(ucMd5string1,ucMd5string,16);
	 if(Flag_COMDebug == 1)
		{			
			printf("ucMd5data:%s\r\n",ucMd5data);					
			printf("ucMd5string1:%s\r\n",ucMd5string1);		
		}
				
	 SendData[data_len++] = CMD_START;
	 SendData[data_len++] = TypeID;
	 len = strlen(ucMd5string1);
	 	
	 SendData[data_len++]= (len+MAC_LEN+2)|0x80;
	 SendData[data_len++]=REQ_SECOND_VERIFY;
	 for(i=0;i<len ;i++)
	 {
			SendData[data_len++]=ucMd5string1[i];
	 }
	 for(i=0;i<MAC_LEN ;i++)
	 {
			SendData[data_len++]=MAC_IDstring[i];
	 } 
	 for(i = 0;i< len;i++)
		{
			jiaoyan += ucMd5string1[i];
		}								 
	 for(i = 0;i< MAC_LEN;i++)
		{
			jiaoyan += MAC_IDstring[i];
		}
	 jiaoyan +=REQ_SECOND_VERIFY;
	 SendData[data_len++] = jiaoyan|0x80 ;
	 SendData[data_len++] = CMD_LF1;
	 SendData[data_len++] = CMD_LF2;
	 ClearUSART3BUF();
		if(Flag_COMDebug == 1)
		{
			printf("Verify MD5:\r\n");
			for(i=0;i<data_len;i++)
				printf("%02x ",SendData[i]);
			 printf("\r\n");
		}
     if(GPRS_Send_Data(SendData,data_len))
     {
       // printf("发送成功\r\n");
     };
     SendDataStatus = OK;							//发送完毕
     mytime = 0;
	
	
}
void Send_AMPCHGData2Server(void)
{
    uint8_t dat[20];
	 uint8_t  i = 0;
	 dat[i++]=CMD_START;
    dat[i++]=TypeID;
    dat[i++]=0x8a;
    dat[i++]=AMP_CHG;
    
	 dat[i++]= (uint8_t)(ADC_AmpMultiple*10)|0x80;
    
	 dat[i++] = (SEND_ECG_MAX[0]/256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[0]%256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[1]/256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[1]%256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[2]/256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[2]%256)|0x80;
	 dat[i++] = (GetDataHead(&dat[4],7))|0x80;  //数据头
     dat[i++]=0xFF;
     dat[i++]=0x69;
     dat[i++]=0x42;
	 
    
	 GPRS_Send_Data(dat,i);
     delay_ms(10);
	 if(Flag_COMDebug == 1)
		 printf("Send Amplification Data:%f To Server!\r\n",ADC_AmpMultiple);
}
void Net_Work_Link_Sever(uint8_t step)
{

}
char SLM750V_Query_MNOReg(void)
{
    char *pstr =NULL;
     char Command_SendCount=0;
	char mode,format,act;
    char oper[18]={0};//提取其他
    act =0;
	ClearUSART3BUF();
	UART3_SendString("AT+COPS?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+COPS:")!= NULL)
		{
			if(Flag_COMDebug == 1)
				printf("%s\r\n",ucUar3tbuf);
			sscanf(ucUar3tbuf,"%*[^:]: %d,%d,\"%[^\"]\",%d",&mode,&format,oper,&act);
			if(Flag_COMDebug == 1)
				printf("%d,%d,%s,%d\r\n",mode,format,oper,act);
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+COPS?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(100);
		}	
		if((mytime>3)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Operator read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Query_NetTyp(void)
{
    char *pstr =NULL;
     char Command_SendCount=0;
	char stringbuf1[30]={0};//提取其他
	ClearUSART3BUF();
	UART3_SendString("AT+PSRAT?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+PSRAT:")!= NULL)
		{
			sscanf(ucUar3tbuf,"%*[^:]:%s",stringbuf1);
			if(Flag_COMDebug == 1)
				printf("NETTyp:%s\r\n",stringbuf1);
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+PSRAT?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}	
		if((mytime>3)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("NetTyp read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Query_APNstate(void)
{
    char *pstr =NULL;
	 char Command_SendCount=0;
    char cid;
    char pdp_typ[10]={0};
    char apn[10]={0};
    char pdp_addr[16]={0};
    char d_comp,h_comp,ipv4alloc,request_type;
   
	ClearUSART3BUF();
	UART3_SendString("AT+CGDCONT?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+CGDCONT")!= NULL)
		{
			if(Flag_COMDebug == 1)
				printf("%s\r\n",ucUar3tbuf);
//			sscanf(ucUar3tbuf,"%*[^:]:%d,\"%[^\"]\",\"%[^\"]\",\"%[^\"]\",%d,%d,%d,%d",&cid,pdp_typ,apn,pdp_addr,&d_comp,&h_comp,&ipv4alloc,&request_type);
//			printf("%d,%s\r\n",cid,apn);
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CGDCONT?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}	
		if((mytime>3)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("CGDCONT read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Query_Link(void)
{
    char state=0;
     char Command_SendCount=0;
    uint8_t ip[4]={0};
    ClearUSART3BUF(); 
	UART3_SendString("AT+MIPCALL=1\r\n");
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+MIPCALL:")!= NULL) 
		{
            sscanf(ucUar3tbuf,"%*[^:]:%d,%d.%d.%d.%d",&state,&ip[0],&ip[1],&ip[2],&ip[3]);
			if(Flag_COMDebug == 1)
			{
				printf("%s",ucUar3tbuf);						
				printf("Query LTE Link state success:\r\n state:%d  ip: %d.%d.%d.%d\r\n",state,ip[0],ip[1],ip[2],ip[3]);
			}
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+MIPCALL?\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>10)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Query Wireless Link state time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Close_Socket(void)
{
    char Command_SendCount=0;
    ClearUSART3BUF(); 
	UART3_SendString("AT+CIPCLOSE\r\n");
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"CLOSE OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Close a Socket successed:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+CIPCLOSE\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>10)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Close a Socket time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Open_Socket(char *ipaddr,char *ipport)
{
    char cmd[100]="";
    char Command_SendCount=0;
     ClearUSART3BUF(); 
    
   // UART3_SendString("AT+MIPOPEN=1,10002,\"112.74.59.250\",10002,0\r\n");
    //112.74.59.250\",10002
    
    
    sprintf(cmd,"AT+MIPOPEN=1,0,\"%s\",%s,0\r\n",ipaddr,ipport);
	UART3_SendString(cmd);
	if(Flag_COMDebug == 1)
		printf("%s",cmd);
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+MIPOPEN:1,1")!= NULL) 
		{
            
			if(Flag_COMDebug == 1)
			{						
				printf("Open a Socket successed:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString(cmd);
			Command_SendCount++;
			delay_ms(100);
		}
		if((mytime>10)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Open a Socket time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
    
} 
char SLM750V_Send_Data(uint8_t *data,uint16_t len )
{
//24 01 8e 03 39 31 43 32 36 42 33 30 36 31 44 45 ad 69 42
//24 11 8e 02 42 33 33 38 34 44 38 32 41 39 45 35 b9 69 42 
  //24 01 8e 03 39 31 43 32 36 42 33 30 36 31 44 45 ad 69 42
   // uint8_t data[19]={0x24 ,0x01 ,0x8e ,0x03 ,0x39 ,0x31 ,0x43 ,0x32 ,0x36 ,0x42 ,0x33 ,0x30 ,0x36 ,0x31 ,0x44 ,0x45 ,0xad ,0x69 ,0x42};
    char Command_SendCount=0; 
    char cmd[20]="";
    ClearUSART3BUF(); 
    
    sprintf(cmd,"AT+MIPTPS=3,1,3,%d\r\n",len);
	//UART3_SendString("AT+MIPSEND=1,\"24018e03393143323642333036314445ad6942\"\r\n");
    UART3_SendString(cmd);
	mytime = 0;
	delay_ms(100);
	while(1)
	{
		delay_ms(50);
        if(strstr(ucUar3tbuf,">")!= NULL)
        {	
            ClearUSART3BUF();  
            mytime=0;            
            UART3_SendData(data,len);
            //MYDMA_USART_Transmit(&UART3_Handler, buf, send_len);
            			
        }
		if(strstr(ucUar3tbuf,"+MIPOK")!= NULL) 
		{
            
			if(Flag_COMDebug == 1)
			{						
				//printf("Send data2mode successed\r\n",ucUar3tbuf);
			}
			//ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			//ClearUSART3BUF();
			//UART3_SendString("AT+MIPSEND=1,\"24018e03393143323642333036314445ad6942\"\r\n");
			Command_SendCount++;
			delay_ms(50);
            ClearUSART3BUF();
			return 0;
		}
		if((mytime>3))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Send data2mode time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}    
}
char SLM750V_Query_VER(void)
{
	ClearUSART3BUF(); 
	UART3_SendString("AT+SGSW\r\n");
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 1;
		}
        
		if(mytime>3)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Read versoin time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
		
	}

}

//模组关机
char LuatModule_PowerDown(void)
{
	ClearUSART3BUF(); 
	UART3_SendString("AT+CPOWD=1\r\n");
	mytime = 0;
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"NORMAL")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 1;
		}
        
		if(mytime>3)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("PowerDown time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
/*************************MQTT相关*******************************/

//  设置 MQTT  相关参数
char MQTT_config(void)
{
//	cJSON *postdata;
//	char *send_data= NULL;
	char cmd[500] = {0};
	char Topic[50] ;
	char Client_id[50];
	char send_data1[200];   
	
//	sprintf(send_id,"CMCC-4G-%s",MAC_IDstring);
//	postdata  = cJSON_CreateObject();
//    cJSON_AddStringToObject(postdata,"deviceId",send_id);  
//    cJSON_AddStringToObject(postdata,"eventType","Offline");
//	cJSON_AddStringToObject(postdata,"mac",MAC_IDstring);
//    cJSON_AddNumberToObject(postdata,"timestamp",1694670785); 
//	cJSON_AddStringToObject(postdata,"deviceType","4G"); 
//    send_data = cJSON_PrintUnformatted(postdata);
//	if(Flag_COMDebug == 1)
//		printf("send_data=%s \r\n",send_data); 
	
//    sprintf(send_data1,"eventType:%s","Offline");
//	sprintf(send_data1,"{\\22eventType\\22:\\22Offline\\22\\2C\\22mac\\22:\\22%s\\22}",
//		MAC_IDstring);
	sprintf(send_data1,"{\\22eventType\\22:\\22Offline\\22\\2C\\22deviceId\\22:\\22CMCC-591217-%s\\22\\2C\\22mac\\22:\\22%s\\22\\2C\\22timestamp\\22:\\22%d\\22\\2C\\22deviceType\\22:\\22%s\\22\\2C\\22master\\22:%d}",
		MAC_IDstring,MAC_IDstring,1694670785,"4G",DevNature_master);
	ClearUSART3BUF(); 
	sprintf(Topic,"/device/CMCC-%s-%s/upward", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
	sprintf(Client_id,"6bbb0be4-2420-4c28-971a-%s",MAC_IDstring);
	sprintf(cmd,"AT+MCONFIG=%s,%s,%s,0,0,%s,%s\r\n",Client_id,
	"sleepace","sleepace2022.",Topic,send_data1);
    UART3_SendString(cmd);
	if(Flag_COMDebug == 1)
		printf("MQTT_config:%s\r\n", cmd);
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
//			cJSON_Delete(postdata);
//			free(send_data);
			return 1;
		}
        
		if(mytime>3)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("MQTT_config time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
//			cJSON_Delete(postdata);
//			free(send_data);
			return 0;
		}
	}
}

//建立 TCP 
char MQTT_TCP_connect(void)
{
	char cmd[100] = {0};
	ClearUSART3BUF(); 
//	sprintf(cmd,"AT+MIPSTART=\"%s\",\"%s\"\r\n","124.71.11.151","1888");
	sprintf(cmd,"AT+MIPSTART=\"%s\",\"%s\"\r\n",URL_MQTT_IP,MQTT_HOST_PORT);
    UART3_SendString(cmd);
	if(Flag_COMDebug == 1)
		printf("MQTT_TCP_connect:%s\r\n", cmd);
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"CONNECT")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{
				printf("%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 1;
		}
        
		if(mytime>3)
		{
			if(Flag_COMDebug == 1)
			{
				printf("MQTT_TCP_connect time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}

//客户端向服务器请求会话连接
char MQTT_session_conn(void)
{
	ClearUSART3BUF(); 
    UART3_SendString("AT+MCONNECT=1,15\r\n");  //test code!!!
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"CONNACK OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 1;
		}
        
		if(mytime>3)
		{
			MQTT_Close();//先关闭MQTT再试
			if(Flag_COMDebug == 1)
			{						
				printf("MQTT_session_conn time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}

//订阅
char MQTT_SUB(void)
{
	char cmd[100] = {0};
	ClearUSART3BUF(); 
	sprintf(cmd,"AT+MSUB=/device/CMCC-591217-%s/downward,0\r\n",MAC_IDstring);
    UART3_SendString(cmd);
	if(Flag_COMDebug == 1)
		printf("MQTT_SUB:%s\r\n", cmd);
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"SUBACK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 1;
		}
        
		if(mytime>3)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("MQTT_SUB time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}

//关闭MQTT连接
char MQTT_Close(void)
{
	ClearUSART3BUF(); 
    UART3_SendString("AT+MDISCONNECT\r\n");
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
				printf("MQTT关闭成功：%s\r\n",ucUar3tbuf);
			ClearUSART3BUF();
			return 1;
		}
        if(strstr(ucUar3tbuf,"ERROR")!= NULL) 
		{
			if(Flag_COMDebug == 1)
				printf("MQTT关闭失败：%s\r\n",ucUar3tbuf);
			ClearUSART3BUF();
			return 0;
		}
		if(mytime>2)
		{
			if(Flag_COMDebug == 1)
				printf("MQTT_Close time out:%s\r\n",ucUar3tbuf);
			ClearUSART3BUF();
			return 0;
		}
	}
}

//设置自动接收信息
char MQTT_REV_MODE(void)
{
	ClearUSART3BUF(); 
    UART3_SendString("AT+MQTTMSGSET=0\r\n");  //主动上报
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
				printf("MQTT设置主动上报成功\r\n");
			ClearUSART3BUF();
			return 1;
		}
        if(strstr(ucUar3tbuf,"ERROR")!= NULL) 
		{
			if(Flag_COMDebug == 1)
				printf("MQTT设置主动上报失败\r\n");
			ClearUSART3BUF();
			return 0;
		}
		if(mytime>2)
		{
			if(Flag_COMDebug == 1)
				printf("MQTT_REV_MODE time out:%s\r\n",ucUar3tbuf);
			ClearUSART3BUF();
			return 0;
		}
	}
}

//查看MQTT连接状态
char MQTT_Status(void)
{
	uint8_t state = 0;
	ClearUSART3BUF(); 
    UART3_SendString("AT+MQTTSTATU\r\n");
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"MQTTSTATU")!= NULL) 
		{
			sscanf(ucUar3tbuf,"%*[^:]: %d",&state);
			if(state==1)
			{
				if(Flag_COMDebug == 1)
					printf("MQTT状态正常\r\n");
				return 1;
			}
			if(state==0)
			{
				if(Flag_COMDebug == 1)
					printf("MQTT状态离线\r\n");
				return 0;
			}
			if(state==2)
			{
				if(Flag_COMDebug == 1)
					printf("还没认证，需要发送 MCONNECT 命令\r\n");
				return 2;
			}
			ClearUSART3BUF();
			return 1;
		}
		if(mytime>2)
		{
			if(Flag_COMDebug == 1)
				printf("MQTT_Status time out:%s\r\n",ucUar3tbuf);
			ClearUSART3BUF();
			return 0;
		}
	}
}

//发布消息
char MQTT_PUB(char *topic,char *data)
{
	char cmd[1300];
	static uint8_t error_cnt = 0;
//	char sub_test[50] = "function:test";
	ClearUSART3BUF(); 
	sprintf(cmd,"AT+MPUB=%s,0,0,\"%s\"\r\n",topic,data);
    UART3_SendString(cmd);
	if(Flag_COMDebug == 1)
		printf("MQTT_content:%s\r\n", cmd);
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL)
		{
//			if(strstr(ucUar3tbuf,"CLOSED")!= NULL)
//			{
//				if(Flag_COMDebug == 1)
//					printf("连接关闭\r\n");
//				//重连  test code!!!
//				Flag_init = WIRELESS_INIT_OK;
//				Flag_Init_Step=8;
//				AngelPace = POWER_ON_NOTIFY;
//				ucConectFlag = 0;
//				return 0;
//			}
			if(Flag_COMDebug == 1)
			{
				printf("发布成功:%s\r\n",ucUar3tbuf);
			}
			ucConectFlag = 1;
			error_cnt = 0;
//			ClearUSART3BUF();
//			free(cmd);
			return 1;
		}
        if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			error_cnt++;
			if(error_cnt>=3)
			{
				error_cnt = 0;
				if(Flag_COMDebug == 1)
					printf("error_cnt is 3,reset\r\n");
                SaveSoftRebootFlagToFlash();
				NVIC_SystemReset();  //重启
				//重连
//				MQTT_Close();  //关闭MQTT
//				Flag_init = WIRELESS_INIT_OK;
//				Flag_Init_Step=8;
//				AngelPace = POWER_ON_NOTIFY;
//				ucConectFlag = 0;
			}
			if(Flag_COMDebug == 1)
				printf("未发布,重发:%s\r\n",ucUar3tbuf);
			return 0;
		}
		if(mytime>1)
		{
			ucConectFlag = 0;
			if(Flag_COMDebug == 1)
				printf("MQTT_PUB time out:%s\r\n",ucUar3tbuf);
			ClearUSART3BUF();
			return 0;
		}
	}
}


char MQTT_MSGGET_0(void)
{
	char *time = NULL;
	uint8_t num = 0,numBuf[12];
//	ClearUSART3BUF();
    // UART3_SendString("AT+MQTTMSGGET");
	mytime = 0;
		
	while(1)
	{
		delay_ms(800);
        UART3_SendString("AT+MQTTMSGGET");
        delay_ms(100);
		if(strstr(ucUar3tbuf,"MSUB")!= NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("已收到后台：%s\r\n",ucUar3tbuf);
			}
			
			if(strstr(ucUar3tbuf,"sync_time") != NULL)   //校时  
			{
				time = strstr(ucUar3tbuf,"extra");
				for(num=0;num<12;num++)
				{
					numBuf[num] = time[num+10] - 0x30;
				}
				for(num=0;num<6;num++)  //获取服务器时间
				{
					Timebuf[num] = (numBuf[num*2])*10+(numBuf[num*2+1]); //将ASCII字符的两个字节的时间转换为1个字节的时间		 
				}
				Heartbeat = 0;
				if(Flag_COMDebug == 1)
					printf("Renew Server time is:%d-%d-%d %d:%d:%d\r\n",Timebuf[0],Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5]);
			}
			if((strstr(ucUar3tbuf,"sos")!= NULL)||(strstr(ucUar3tbuf,"received")!= NULL))
			{
				if(Flag_COMDebug == 1)
					printf("后台已接收到SOS事件\r\n");
			}
			if(strstr(ucUar3tbuf,"test") != NULL)
			{
				if(Flag_COMDebug == 1)
					printf("只是测试 \r\n");
			}
			ClearUSART3BUF();
			return 1;
		}
        
		if(mytime>4)
		{
			if(Flag_COMDebug == 1)
			{
				printf("MQTT_MSGGET_0 time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
	

char MQTT_MSGGET_DM_report(void)
{
	char *time = NULL;
	uint8_t num = 0,numBuf[12];
//	ClearUSART3BUF();
    // UART3_SendString("AT+MQTTMSGGET");
	mytime = 0;
		
	while(1)
	{
		delay_ms(800);
        UART3_SendString("AT+MQTTMSGGET");
        delay_ms(100);
		if(strstr(ucUar3tbuf,"MSUB")!= NULL)
		{
			if(Flag_COMDebug == 1)
			{
				log_trace("dmreport respon: %s\r\n",ucUar3tbuf);
			}
			
			if(strstr(ucUar3tbuf,"sync_time") != NULL)   //校时  
			{
                // GPRS_Wait_Resp("}", 5);
                // resp_json = format_to_json(ucUar3tbuf);
                // if (resp_json) {
                //     item_json = cJSON_GetObjectItem(resp_json, "respCode");
                //     if (item_json && 0 != item_json->valueint) {
                //         log_trace("Andlink termina data report failed(dmReport) \r\n");
                //     } else {
                //         log_trace("Andlink termina data report success(dmReport) \r\n");
                //         res = 1;
                //     }
                //     cJSON_Delete(resp_json);
                // }
			}

			ClearUSART3BUF();
			return 1;
		}
        
		if(mytime>4)
		{
			if(Flag_COMDebug == 1)
			{
				printf("MQTT_MSGGET_DM_report time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
