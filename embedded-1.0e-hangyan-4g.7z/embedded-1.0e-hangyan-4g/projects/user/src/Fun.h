/******************************************************************************
 * @file     Fun.h
 * @brief   GPRS和WIFI连接
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par      严斌 2016
*******************************************************************************/
#ifndef __FUN_H_
#define __FUN_H_

#include <stdint.h>
#define _NEW_MODULE 1

#define KEY_INPUT_PORT GPIOA
#define KEY_INPUT_PIN  GPIO_PIN_10

//用电池时设备22:00~6:00之间设备不休眠，仅关闭模组
#define DEVICE_SLEEP_TIME_BEGIN  22
#define DEVICE_SLEEP_TIME_END    6

void GetToken1(void);
int GetIP1(void);
int GetToken2(int chanl);
void SleepDataSend(int chanl);
void StrToHex(unsigned char *pbDest, unsigned char *pbSrc, int nLen);
void HexToStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen);
void HexToLowerStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen);
void ConnectServertEST(void);
char Connect_DM_Server(void);
void ConnectFrontServer(void);
void ConnectFrontServerRcvCtr(void);

void GetFrontEndServerPw(void);
void GetFrontEndServerPwRcvCtr(void);

void GetBackEndServerIP(void);
void GetBackEndServerIPRcvCtr(void);

void ConnectBackServer(void);
void GetBackServerPw(void);
void PowerBatteryDeal(void);
void GetADCSampleData(void);
void SendSleepData(void);
void SendSleepDataRcvCtr(void);

void GetBackServerPwRece(unsigned char ucP);
void SendSleepDataRece(unsigned char *p);
char CheckSystemErrorContrl(void);
char SendSleepDataReally(void);
char SendSleepDataReallyRcvCtr(void);
char My_strstr(unsigned char *str1,unsigned char *str2);
void ADDTime(void);
void LedContrl(int csq,int Tcpstatues);
void Req_Users_Binding(void);  //张炜20170523增加，查询是否关联用户
void  Send_GPRSPosition(uint8_t st,int lac,int cid);
void GetServerTime(void);
void Send_DataUnusual(uint8_t flag_un,uint8_t unHr,uint8_t unRr);
void Send_SyncDataToServer(void);
void Send_CARD_IMSI(void);
void Send_CARD_ICCID(void);
void  RePowerOn_GPRS(void);
void  DealADCSampleData(void);
void  DealSmallADCSampleData(float status);
void CheckAmpADCData(void);
void Send_AMPCHGDataToServer(void);
void SleepDataCalculate(void);

char PowerBatteryDetermine(void);
char SendSleepDataBuff(void);
void  Set_StatistStartTime(void);
void Statist_SleepStatus(void);
void  Send_StatistStatusData(void);
void  Save_StatistStatusData(unsigned char *starttime,unsigned char *endtime,uint8_t status,uint8_t len,unsigned char *averavehr,unsigned char *averagerr);
void  Set_StatistEndTime(void);
void  Statist_NextDayStart(void);
void SendPressSenserStatus(uint8_t status);
void Check_ExtSensor_PeopleOnBed(void);
void IWDG_Config(uint8_t prv ,uint16_t rlv);	
void IWDG_Feed(void);
void DeviceIntoSleep(void);


char ReadMACFromFlash(void);	
char SaveMACToFlash(void);

#endif
