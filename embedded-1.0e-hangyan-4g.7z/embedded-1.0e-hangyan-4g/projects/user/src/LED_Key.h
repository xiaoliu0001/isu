/******************************************************************************
 * @file     LED_Key.C
 * @brief   按键以及LED配置
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par       严斌 2016
*******************************************************************************/

#ifndef __LED_KEY_H
#define __LED_KEY_H
#include "Fun.h"

#include "n32g45x.h"
#include "delay.h"
#include "USART.h"

#define LED_GPIO_PORT        		GPIOA
#define LED_GPIO_CLK                    RCC_APB2_PERIPH_GPIOA
#define LED2_PIN                         GPIO_PIN_15
#define LED3_PIN                         GPIO_PIN_14
#define LED4_PIN                         GPIO_PIN_13
#if _NEW_MODULE
#define LED5_PIN                         GPIO_PIN_9
#else
#define LED5_PIN                         GPIO_PIN_7
#endif



#define Toggle_LED             GPIO_WriteBit(LED_GPIO_PORT,LED2_PIN,1-(Bit_OperateType)(GPIO_ReadOutputDataBit(LED_GPIO_PORT,LED2_PIN)))
#define LED_ON                 GPIO_WriteBit(LED_GPIO_PORT,LED2_PIN,0);
#define LED_OFF                GPIO_WriteBit(LED_GPIO_PORT,LED2_PIN,1);
#define KEY_GPIO_CLK                   RCC_APB2_PERIPH_GPIOC
#define KEY_GPIO_PORT 			GPIOC
#define KEY_GPIO_PIN			GPIO_PIN_13


void LED_Init(void);
void delay_ms_YB(void);
void delay_ms_YB2(void);



#endif/*__LED_H*/


