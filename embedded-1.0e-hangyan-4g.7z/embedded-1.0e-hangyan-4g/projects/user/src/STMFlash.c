/******************************************************************************
 * @file     STMflash.c
 * @brief   存储程序
 * @version  V1.1
 * @date     2023
 * @note
 * Copyright (C)  
 *
 * @par     STM32 内部FLASH数据存储   张炜 2023
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Parameter.h"
#include "STMFlash.h"


uint32_t NbrOfPage1 = 0;			//记录写入多少页
uint32_t EraseCounter1 = 0x00; 	//记录要擦除多少页

 #define FLASH_SECTOR_SIZE   2048 // 扇区大小2KB  

/****************************************************************************
*	函 数 名: STMFLASH_BufferWrite
*	功能说明: STM32 内部flash数据写入
*	形    参：无
*	返 回 值: 无
* 	说    明：
*****************************************************************************/
void STMFLASH_BufferWrite(uint32_t *pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{
	uint16_t i = 0;
	uint32_t Address = 0x00;				//记录写入的地址
	
	FLASH_STS FLASHStatus = FLASH_COMPL; //记录每次擦除的结果
	
	FLASH_Unlock();// 解锁Flash
		
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);/* 清空所有标志位 */
	
	
    NbrOfPage1 = NumByteToWrite / FLASH_PAGE_SIZE;	/* 计算擦除的页数 */
	if(NumByteToWrite%FLASH_PAGE_SIZE !=0)
	{
		NbrOfPage1 += 1;
	}
    for(EraseCounter1 = 0; (EraseCounter1 < NbrOfPage1) && (FLASHStatus == FLASH_COMPL); EraseCounter1++)
    {
        if(FLASH_EraseOnePage(WriteAddr+ (FLASH_PAGE_SIZE * EraseCounter1)) != FLASH_COMPL) /* 擦除Flash */
        {
            FLASH_Lock(); /*擦除Flash出错，可写一些对应的处理*/
            printf("Clear Flash Fail!\r\n");
            return ;
        }
    }
    /*开始写入MAC数据***********/
     Address = WriteAddr;
    //printf("WriteAddr:0x%X NumByteToRead:%d \r\n", Address, NumByteToWrite);
	for(i = 0; i < NumByteToWrite; i++)
	{
		if (FLASH_ProgramWord(Address, pBuffer[i]) == FLASH_COMPL)
		{
			Address = Address + 4;		//DATA_32是unit32,占四个字节
		}
		else
		{
			FLASH_Lock(); //锁定Flash
			//printf("Write Flash Error!\r\n");
			return ;
		}
        //printf("---0x%x ", pBuffer[i] );
	} //printf("\r\n");

    FLASH_Lock(); //锁定Flash
}
/****************************************************************************
*	函 数 名: STMFLASH_BufferRead
*	功能说明: STM32 内部flash数据读取
*	形    参：无
*	返 回 值: 无
* 	说    明：注意读取的数据将字转换为字节
*****************************************************************************/
void STMFLASH_BufferRead(uint8_t *pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead)
{
	uint16_t i = 0;
	uint32_t Address = 0x00;				//记录写入的地址
	
	Address = ReadAddr;

    //printf("ReadAddr:0x%X NumByteToRead:%d \r\n", ReadAddr, NumByteToRead);
	for(i=0;i<NumByteToRead;i++)
	{
		pBuffer[i] = (uint8_t)((*(__IO uint32_t*) Address)&0x000000FF);
        //printf("0x%02x ", pBuffer[i] );
		Address += 4;
	}//printf("\r\n");

}
/****************************************************************************
*	函 数 名: STMFLASH_SectorErase
*	功能说明: STM32 内部flash扇区删除
*	形    参：SectorAddr扇区地址
*	返 回 值: 无
* 	说    明：擦除地址所在的扇区的数据
*****************************************************************************/
void STMFLASH_SectorErase(uint32_t SectorAddr)
{
	FLASH_STS FLASHStatus = FLASH_COMPL; //记录每次擦除的结果
	
	FLASH_Unlock();// 解锁Flash
		
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);/* 清空所有标志位 */
		
	if(FLASH_EraseOnePage(SectorAddr) != FLASH_COMPL) /* 擦除Flash */
	{		
		printf("Clear Flash Fail!\r\n");
	}
    
	FLASH_Lock(); /*擦除Flash出错，可写一些对应的处理*/
	
}
/****************************************************************************
*	函 数 名: STMFLASH_BufferWrite
*	功能说明: STM32 内部flash数据写入
*	形    参：addr:地址  count:块数量  
*	返 回 值: 无
* 	说    明：
*****************************************************************************/
flash_status_t STMFlashErase(uint32_t addr, uint8_t count)  
{  
  uint8_t i;  
  FLASH_Unlock(); 
  for(i = 0; i < count; ++i)  
  {  
    if(FLASH_EraseOnePage(addr + i * FLASH_PAGE_SIZE) != FLASH_COMPL)  
    {  
      return FLASH_FAILURE;  
    }  
  }  
   FLASH_Lock(); 
  return FLASH_SUCCESS;  
}  

uint32_t STMFlashWrite(uint32_t addr, uint8_t *buffer, uint32_t length)  
{  
  uint16_t i=0;
  uint32_t data = 0;  
  
  FLASH_Unlock();  
  
  for(i = 0; i < length; i += 4)  
  {  
    data = (*(buffer + i + 3) << 24) +(*(buffer + i + 2) << 16)+(*(buffer + i + 1) << 8)+ (*(buffer + i));  
    if(FLASH_ProgramWord((uint32_t)(addr + i), data) != FLASH_COMPL)  
    {  
      return i;  
    }  
  }  
    
  FLASH_Lock();  
  
  return length;  
} 

uint32_t STMFlashRead(uint32_t addr, uint8_t *buffer, uint32_t length)  
{  
  memcpy(buffer, (void *)addr, length);  
  
  return length;  
}  

/****************************************************************************
*	函 数 名: ReadUpFlagFromFlash
*	功能说明: 读flash中保存的连接记录
*	形    参：无
*	返 回 值: 返回1表示连接过，返回0表示未连接过
* 说    明：
*****************************************************************************/
char ReadUpFlagFromFlash(void)
{
	uint8_t dat[15];

	STMFLASH_BufferRead(dat, FLASH_VerifyInfoAddress, 15);
	if(dat[0] == Flag_FirstRun)
	{
		return 1;
	}
	if(dat[0] != Flag_FirstRun)
	{
		return 0;
	}
}

/****************************************************************************
*	函 数 名: SaveUpFlagToFlash
*	功能说明: 保存后置服务器的校验码到flash
*	形    参：无
*	返 回 值: 返回1表示正确读取，返回0表示第一次程序启动，未初始化
* 	说    明：保存IP和端口
*****************************************************************************/
char SaveUpFlagToFlash(void)
{
	uint32_t dat[15];
//	uint8_t i;

	dat[0] = (uint32_t)Flag_FirstRun;    
//	dat[1] = (uint32_t)(strlen(Token2));	  
//	for(i=0; i<dat[1] ;i++)
//	{
//		dat[i+2] = (uint32_t)Token2[i];
//	}		 
	STMFLASH_BufferWrite(dat,FLASH_VerifyInfoAddress, 15);	
}

/****************************************************************************
*	函 数 名: ReadUpFlagFromFlash
*	功能说明: 读flash中保存的连接记录
*	形    参：无
*	返 回 值: 返回1表示连接过，返回0表示未连接过
* 说    明：
*****************************************************************************/
char ReadSoftRebootFlagFromFlash(SOFT_REBOOT_INFO_T *info)
{
	// uint8_t dat[15];
    STMFlashRead(FLASH_SOFTREBOOTAddress, (uint8_t *)info, sizeof(SOFT_REBOOT_INFO_T));
	//STMFLASH_BufferRead(, FLASH_SOFTREBOOTAddress, sizeof(SOFT_REBOOT_INFO_T));
    
    // printf("0x%X \r\n", info->flag);
    // printf("0x%X \r\n", info->reserve[0]);
    // printf("0x%X \r\n", info->reserve[1]);
    // printf("0x%X \r\n", info->reserve[2]);
    // printf("0x%X \r\n", info->dm_report_count);
    
    return 0;
}


/****************************************************************************
*	函 数 名: SaveUpFlagToFlash
*	功能说明: 保存软重启标记
*	形    参：无
*	返 回 值: 返回1表示正确读取，返回0表示第一次程序启动，未初始化
* 	说    明：保存IP和端口
*****************************************************************************/
char SaveSoftRebootFlagToFlash(void)
{
	// uint32_t dat[15];

	// dat[0] = (uint32_t)Flag_SoftReboot;
    g_softboot_info.flag = Flag_SoftReboot;
    memset(g_softboot_info.reserve, 0, sizeof(g_softboot_info.reserve));
    g_softboot_info.dm_report_count = TerminalManage_cnt;
	printf("write dm_report_count=0x%X \r\n", g_softboot_info.dm_report_count);
    STMFlashErase(FLASH_SOFTREBOOTAddress, 1);
    STMFlashWrite ( FLASH_SOFTREBOOTAddress, (uint8_t *)&(g_softboot_info), sizeof(SOFT_REBOOT_INFO_T) );
	// STMFLASH_BufferWrite((uint32_t *)&g_softboot_info,FLASH_SOFTREBOOTAddress, sizeof(SOFT_REBOOT_INFO_T)/4);	
    
}

/****************************************************************************
*	函 数 名: SaveUpFlagToFlash
*	功能说明: 保存软重启标记
*	形    参：无
*	返 回 值: 返回1表示正确读取，返回0表示第一次程序启动，未初始化
* 	说    明：保存IP和端口
*****************************************************************************/
char ClearSoftRebootFlagToFlash(void)
{
    SOFT_REBOOT_INFO_T softboot_info = {0};
	memset(&softboot_info, 0, sizeof(SOFT_REBOOT_INFO_T));
	 
    STMFlashErase(FLASH_SOFTREBOOTAddress, 1);
    STMFlashWrite ( FLASH_SOFTREBOOTAddress, (uint8_t *)&(softboot_info), sizeof(SOFT_REBOOT_INFO_T) );
}


