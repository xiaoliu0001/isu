/******************************************************************************
 * @file     GPRS.c
 * @brief   GPRS通讯函数
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par      严斌 2016
*******************************************************************************/
#include "main.h"
#include "GPRS.h"
#include <stdlib.h>
#include "Fun.h"
#include "Parameter.h"
#include "string.h"
#include "Delay.h"

//const unsigned char *string = "AT+CIPSTART=0,\"TCP\",\"117.78.48.144\",6006";	//IP登录服务器
//const unsigned char *string = "AT+CIPSTART=\"TCP\",\"117.78.48.144\",6006";	//IP登录服务器
//const unsigned char *string = "AT+CIPSTART=\"TCP\",\"117.78.41.203\",6006";	//IP登录服务器
//unsigned char *IP_1 = "AT+CIPSTART=\"TCP\",\"117.78.41.203\",6006\r\n";	//IP登录服务器
const unsigned char *string = "AT+CIPSTART=\"TCP\",\"192.168.8.211\",502";	//测试服务器
unsigned char *IP_1 = "AT+CIPSTART=\"TCP\",\"192.168.8.211\",502\r\n";	//测试服务器




//const unsigned char *string2 = "AT+CIPSTART=1,\"TCP\",\"117.78.48.143\",6006";	//IP登录服务器


/*******************************************************************************
* 函数名 : InitGPRS
* 描述   : GPRS初始化
* 输入   : 
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
void InitGPRS(void)
{
	char ucstatu=0;
  int8_t res = 0;
	
	mytime=0;	

	Wait_CREG();
	while(1)          //获取SIM卡SIMI号
		{
			res = Read_Card_IMSI();
			if(res == 1)  //成功获取
			{
				Flag_Check_Status &= ~ERROR_NO_CARD;
				if(strcmp(CARD_ID,CARD_ID_Save) !=0)
					 Flag_CARD_ISCHANGE = CARD_HASCHANGE;
				else
					 Flag_CARD_ISCHANGE = CARD_NOCHANGE;
				break;
			}
		   if(res == -1)  //未插入卡
			{
				 Flag_Check_Status |= ERROR_NO_CARD;
				
				 break;
			}			
		}	
}
/*******************************************************************************
* 函数名 : Second_AT_Command
* 描述   : 发送AT指令函数
* 输入   : 发送数据的指针、发送等待时间(单位：S)
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
void Second_AT_Command(char *b,char *a,u8 wait_time)         
{
	u8 i;
	char *c;
	c = b;										//保存字符串地址到c
	ClearUSART3BUF(); 
  	i = 0;
	while(i == 0)                    
	{
		if(!Find(a)) 
		{
			if(Timer0_start == 0)
			{
				b = c;							//将字符串地址给b
				for (; *b!='\0';b++)
				{
					while(USART_GetFlagStatus(USART2, USART_FLAG_TC)==RESET);
					USART_SendData(USART2,*b);//UART2_SendData(*b);
				}
				UART2_SendLR();	
				Times = 0;
				shijian = wait_time;
				Timer0_start = 1;
		   }
    	}
 	  	else
		{
			i = 1;
			Timer0_start = 0;
		}
		printf("U2 Send!\r\n");
	}
	ClearUSART3BUF(); 
}

/*******************************************************************************
* 函数名 : Second_AT_Command_YB
* 描述   : 发送AT指令函数
* 输入   : 发送数据的指针、发送等待时间(单位：S)
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
char Second_AT_Command_YB(char *b,char *a,u8 wait_time)         
{
	u8 len=0;								//保存字符串地址到c

	ClearUSART3BUF(); 
	len = strlen(b);
	printf("len:%d\r\n",len);

	if(SendDataStatus != OK){			//发送数据
		UART3_SendString_YB(b,len);
		UART3_SendLR();
		printf("%s",b);
		SendDataStatus = OK;
		mytime = 0;
	}
	else{								//开始接收数据
		if(strstr(ucUar3tbuf,a)!=NULL){							//是否返回指定字符串
			printf("%s\r\n",b);
			printf("%s\r\n",ucUar3tbuf);
			printf("CMD Success!\r\n");
			AngelPace = CONECTIP1OK;							//链接服务器成功
			SendDataStatus = NO;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL || strstr(ucUar3tbuf,"error") != NULL){		//返回error的话，进行三次重发数据，去除数据传输不稳定的影响
			printf("%s\r\n",ucUar3tbuf);
			SendDataStatus = NO;
		}
		if(strstr(ucUar3tbuf,"CONNECT FAIL")!=NULL){
			printf("%s\r\n",ucUar3tbuf);
			SendDataStatus = NO;
		}
		if(mytime > wait_time){									//超时
			printf("Timer Out:%s\r\n",ucUar3tbuf);
			SendDataStatus = NO;
		}
	}
}

/*******************************************************************************
* 函数名 : Second_AT_Command_CIFSR
* 描述   : 发送AT指令函数
* 输入   : 发送数据的指针、发送等待时间(单位：S)
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
void Second_AT_Command_CIFSR(char *b,u8 wait_time)         
{
	u8 i,ii=0,len=0,count=0,ucerrorflag=0,ucerrorcount = 0;								//保存字符串地址到c
	//ClearUSART3BUF(); 
  	i = 0;
	len = strlen(b);
	printf("len:%d\r\n",len);
	while(1)                    
	{
		if(strstr(ucUar3tbuf,"ERROR") != NULL || strstr(ucUar3tbuf,"error") != NULL){
			printf("....%s\r\n",ucUar3tbuf);
			ucerrorflag = 1;
		}
		//if(ucUar2InterrFlag == 1){
		//	ucUar2InterrFlag = 0;
		//	printf("%s\r\n",ucUar2tbuf);
		//	break;
		//}
		if((strstr(ucUar3tbuf,".")!=NULL)&& (strlen(ucUar3tbuf)>=7))  //张炜20170524将'.'改为"."
		{
			printf("%s\r\n",b);
			printf("%s\r\n",ucUar3tbuf);
			printf("CMD Success!\r\n");
			break;
		}
	
		if(count == 0) 
		{	
			count = 1;
			UART3_SendString_YB(b,len);
			UART3_SendLR();	
			shijian = wait_time;
			mytime = 0;
			printf("U3 Send1!\r\n");
		 }
		if(mytime > shijian){
			printf("Timer Out:%s!\r\n",ucUar3tbuf);
			break;
		}
		if(ucerrorcount > 3){									//指令发送次数计数
			printf("%s\r\n",ucUar3tbuf);
			break;
		}
		
		if(ucerrorflag == 1){									//参数复位
			ucerrorflag = 0;
			ClearUSART3BUF();
			mytime= 0;
			count = 0;
			ucerrorcount++;
		}
		delay_ms_YB();
		i++;
		
	}
	ClearUSART3BUF(); 
}

/*******************************************************************************
* 函数名 : Second_AT_Command_CFUN
* 描述   : 发送AT指令函数
* 输入   : 发送数据的指针、发送等待时间(单位：S)
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
char Second_AT_Command_CFUN(char *b,char *a,u8 wait_time)         
{
	u8 i,ii=0,len=0,count=0,ucerrorflag=0,ucerrorcount = 0,ch=0;								//保存字符串地址到c
	//unsigned char *ATClose="AT+CIPCLOSE=1,1\r\n";
	unsigned char *ATClose="AT+CIPCLOSE=1\r\n";
	unsigned char CL=0;

	ClearUSART3BUF(); 
  	i = 0;
	len = strlen(b);
	printf("len:%d\r\n",len);
	while(1)                    
	{
		if(strstr(ucUar3tbuf,a)!=NULL){							//是否返回指定字符串
			delay_ms_YB();
			printf("CMD Success!%s  %s\r\n",b,ucUar3tbuf);
			if(strstr(ucUar3tbuf,"+CFUN: 0")!=NULL || strstr(ucUar3tbuf,"+CFUN: 4")!=NULL){
				CL = 1;
			}
			ch = 1;
			break;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL || strstr(ucUar3tbuf,"error") != NULL){		//返回error的话，进行三次重发数据，去除数据传输不稳定的影响
			printf("%s\r\n",ucUar3tbuf);
			ucerrorflag = 0;									//不需要撒三次

			ch = 1;
			break;
		}

		if(count == 0) 											//接收到结果之前，只发送一次指令
		{	
			count = 1;
			UART3_SendString_YB(b,len);
			//UART3_SendString(b);
			UART3_SendLR();	
			shijian = wait_time;
			mytime = 0;
			printf("U3 Send1!%s\r\n",b);
		 }
		if(mytime > shijian){									//超时
			printf("Timer Out:%s\r\n",ucUar3tbuf);
			ucerrorflag = 0;

			ch = 1;
			break;
		}

		if(ucerrorcount > 2){									//指令发送次数计数
			printf("%s\r\n",ucUar3tbuf);
			break;
		}
		
		if(ucerrorflag == 1){									//参数复位
			ucerrorflag = 0;
			ClearUSART3BUF();
			mytime= 0;
			count = 0;
			ucerrorcount++;
		}
		i++;
		
	}
	ClearUSART3BUF(); 
	if(CL == 1){
		Second_AT_Command_YB("AT+CFUN=1","OK",15);
	}
	return ch;
}



/*******************************************************************************
* 函数名 : Find
* 描述   : 判断缓存中是否含有指定的字符串
* 输入   : 
* 输出   : 
* 返回   : unsigned char:1 找到指定字符，0 未找到指定字符 
* 注意   : 
*******************************************************************************/

u8 Find(char *a)
{ 
	if(strstr(ucUar3tbuf,a)!=NULL)
	    return 1;
	else
		return 0;
}
/*******************************************************************************
* 函数名 : Wait_CREG
* 描述   : 等待模块注册成功
* 输入   : 
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
void Wait_CREG(void)
{
	u8 i;
	uint16_t k;
	i = 0;
	
	CREGTime = 0;
    while(i == 0)        			
	{		        
        //12*20=240ms
		if(gQuickFlashTimer < 12)
        {
			GPIO_SetBits(LED_GPIO_PORT,LED5_PIN);
		}
        else if(gQuickFlashTimer < 25)
        {
			if(gQuickFlashTimer == 12)
			{
				for(k=0;k<BufMAX;k++)      			
                {   
					if(ucUar3tbuf[k] == ':')
					{
						if((ucUar3tbuf[k+4] == '1')||(ucUar3tbuf[k+4] == '5'))//本地或者漫游网络
						{
							i = 1;
							if(Flag_COMDebug == 1)
								printf("Login OK:%s\r\n",ucUar3tbuf);
							ClearUSART3BUF();	
							GPIO_ResetBits(LED_GPIO_PORT,LED5_PIN);
						 	return;
						}
					}				
				}
				if(Flag_COMDebug == 1)
					printf("%s",ucUar3tbuf);
                ClearUSART3BUF();				
			}
			GPIO_ResetBits(LED_GPIO_PORT,LED5_PIN);
		}else if(gQuickFlashTimer >= 25)
        {
			gQuickFlashTimer = 0;
			ClearUSART3BUF();			
			UART3_SendString("AT+CREG?\r\n");
			//UART3_SendString("AT+CSQ\r\n");
		}
		
	    if(CREGTime >= 180)
        {		//3  //3分钟超时
			//CREGTime = 0;
			GPIO_ResetBits(GPRS_CQ_GPIO_PORT,GPRS_CQ_PIN);
			if(CREGTime >= 190)
            {
				CREGTime=0;
				GPRS_ConnetTime = 0;
				GPIO_SetBits(GPRS_CQ_GPIO_PORT,GPRS_CQ_PIN);
				if(Flag_COMDebug == 1)
					printf("System Begin!\r\n");
			}
	    }	
	}
}
/*******************************************************************************
* 函数名 : Set_ATE0
* 描述   : 取消回显
* 输入   : 
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
void Set_ATE0(void)
{
	Second_AT_Command_YB("ATE0","OK",ATTimer);								//取消回显		
}
/*******************************************************************************
* 函数名 : Connect_Server
* 描述   : GPRS连接服务器函数
* 输入   : 
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
void Connect_Server(const unsigned char *ucIP)
{
	char ucstatu=0;

	printf("Loading Begin!\r\n");
	ucstatu = Second_AT_Command_YB((char*)ucIP,"CONNECT  OK",ConectServerTimer);	//连接IP地址，链接之前必须有上面三个步骤，否则链接不上
	if(ucstatu == 1){
		AngelPace = CONECTIP1OK;												//链接成功
	}
	ClearUSART3BUF();
}
/*******************************************************************************
* 函数名 : Connect_Server2
* 描述   : GPRS连接服务器2函数
* 输入   : 通讯道
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/

void Connect_Server2(int chanl)
{
	unsigned char ucIP[50]={0};
	unsigned int TDNum=0;
	unsigned char len=0;

	Set_ATE0();
	
	ClearUSART3BUF();
	TDNum = atoi(chanl2);

	if(GPRS_or_WIFI == GPRS){
		//TDNum=6008;				//17-02-14   邋YB  test
		sprintf(ucIP,"AT+CIPSTART=\"TCP\",\"%s\",%d",IP2,TDNum);
		printf("TDNum:%d\r\n",TDNum);
		printf("ucIP:%s\r\n",ucIP);
		Second_AT_Command_YB((char*)ucIP,"CONNECT",20);
	}
	ClearUSART3BUF();
}

/*******************************************************************************
* 函数名 : Rec_Server_Data
* 描述   : 接收服务器数据函数
* 输入   : 
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
void Rec_Server_Data(void)
{
	char *ucIPD = NULL;

	//ucIPD = strstr(ucUar2tbuf,"+IPD");
	if(ucIPD!=NULL)   		//若缓存字符串中含有^SISR
	{	
		Heartbeat=0;	//清除心跳帧计数器
		Heart_beat=0;
		delay_ms(100);
		//if(strstr(Uart2_Buf,"onled")!=NULL)
		//{
		//	LED1_ON();
		//}
		//else if(strstr(Uart2_Buf,"offled")!=NULL)
		//{
		//	LED1_OFF();
		//}
		printf("收到新信息：\r\n");
		printf(ucUar2tbuf);
		ClearUSART3BUF();
		Heart_beat=1;//发送应答数据，告诉服务器收到数据		
	}
}
/*******************************************************************************
* 函数名 : Send_OK
* 描述   : 发送数据应答服务器的指令，该函数在有两功能
					1：接收到服务器的数据后，应答服务器
					2：服务器无下发数据时，每隔10秒发送一帧心跳，保持与服务器连接
* 输入   : 
* 输出   : 
* 返回   : 
* 注意   : 
*******************************************************************************/
void Send_OK(void)
{
	Second_AT_Command("AT+CIPSEND",">",2);
	Second_AT_Command("OK\32\0","SEND OK",8);;			//回复OK 
}

void GPRSSendData(unsigned char *p,unsigned int Len)
{
	ClearUSART3BUF();
//	printf("SendData len:%d :%s\r\n",Len,p);
	UART3_SendString_YB(p,Len);
	UART3_SendLR();

}

char GetConnectionStatus(int chanl)
{
	unsigned char ucCmddata[20]={0};

	sprintf(ucCmddata,"AT+CIPSTATUS=%d\r\n",chanl);
	ClearUSART3BUF();

	UART3_SendString(ucCmddata);
	mytime=0;
	while(1){
		if(mytime > 2){
			printf("Time Out!\r\n");
			return 1;
		}
		if(strstr(ucUar3tbuf,"CONNECTED")!=NULL){
			printf("CONNECTED!\r\n");
			return 0;
		}
		if(strstr(ucUar3tbuf,"CLOSED")!=NULL){
			printf("CLOSED!\r\n");
			return 1;
		}
	}
}
char MyCountChar(unsigned char *p,int pLen)
{
	int i=0;
	char icount=0;
	for(i=0;i<pLen;i++){
		if(p[i]=='.'){
			icount++;
		}
	}
	return icount;
}
char TCCencer(void)
{
	delay_ms_YB();
	ClearUSART3BUF();
	UART3_SendString("+++");
	mytime=0;
	while(1){
		if(mytime > 5){
			printf("Time Out!+++ Fail!%s\r\n",ucUar3tbuf);
			return 1;
		}
		if(strstr(ucUar3tbuf,"OK")!=NULL){
			printf("+++ OK!%s\r\n",ucUar3tbuf);
			return 0;
		}
		if(strstr(ucUar3tbuf,"CLOSED")!=NULL){
			printf("CLOSED!\r\n");
			return 1;
		}
	}
}
/****************************************************************************
*	函 数 名: GetGPRSPosition
*	功能说明: 获取GPRS定位数据
*	形    参：无
*	返 回 值: 无
* 说    明：张炜20170526,LAC 和CID表示位置，各用两个字节的数据表示
*****************************************************************************/
void GetGPRSPosition(void)
{
	  uint8_t i;
	  char *ppos = NULL;
    unsigned char lacstring[5]={0};
		unsigned char cidstring[5]={0};
	  unsigned char posstring[15]={0};
    int len = 0;
		
	  ClearUSART3BUF();
	  UART3_SendString("AT+CREG\r\n");
		mytime = 0;
	  delay_ms_YB();
//	  printf("%s",ucUar3tbuf);
		while(1)
		{			
			ppos = strstr(ucUar3tbuf,"+CREG");
			if( ppos != NULL )
			{
				 memcpy(posstring,ppos+11,11);
				 if(Flag_COMDebug == 1)
						printf("grps位置为：%s ",posstring);
				 ppos = strstr(posstring,",");
				 memcpy(cidstring,ppos+1,5);
				 len = strlen(posstring)-strlen(cidstring);
				 memcpy(lacstring,posstring,len-1);				 
//				 printf("LAC string:%s  CID string:%s  \r\n",lacstring,cidstring);
				 Position_LAC = atoi(lacstring);			
				 Position_CID = atoi(cidstring);
         if(Flag_COMDebug == 1)				 
						printf("LAC 16data:0x%x  CID 16data:0x%x  \r\n",Position_LAC,Position_CID);
				 ClearUSART3BUF();
				 break;
			}
			if(mytime > 2)
			{
				 if(Flag_COMDebug == 1)
						printf("Get GPRS position error!\r\n");
				 ClearUSART3BUF();
				break;
			}
	 }

}

/****************************************************************************
*	函 数 名: InquireCSQ
*	功能说明: 提取信号质量值
*	形    参：无
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void InquireCSQ(void)
{
	//Second_AT_Command_YB("AT+CSQ","OK",1);			//链接服务器之前，查询当前信号量如何
	u8 i,ii=0,len=0,count=0,ucerrorflag=0,ucerrorcount = 0,ch=0;								//保存字符串地址到c
	unsigned char b[]="AT+CSQ",a[]="OK";
	unsigned char csqstring[5]={0};
	char *pcsq;
    unsigned char readcsq = 0;
		
	
	ClearUSART3BUF(); 
  	i = 0;
	len = strlen(b);
	//printf("len:%d\r\n",len);
	while(1)                    
	{
		if(strstr(ucUar3tbuf,a)!=NULL)
		{							//是否返回指定字符串
//			printf("---------------%s\r\n",ucUar3tbuf);		
			if(strstr(ucUar3tbuf,"+CSQ") != NULL) 
			{ 
				pcsq = strstr(ucUar3tbuf,"+CSQ:");	
				memcpy(csqstring,pcsq+5,3);
				readcsq = atoi(csqstring);
				if((readcsq < 99)&&(readcsq > 0))
				{
					CSQNual = readcsq;
					if(Flag_COMDebug == 1)
						 printf("CSQ:%d\r\n---------------------\r\n",CSQNual);
					ClearUSART3BUF(); 
					break;
				}
				else
				{
					UART3_SendString_YB(b,len);
					UART3_SendLR();	
					mytime = 0;
					count++;
					memset(ucUar3tbuf,0x00,sizeof(ucUar3tbuf));
				}
		  }
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL || strstr(ucUar3tbuf,"error") != NULL){		//返回error的话，进行三次重发数据，去除数据传输不稳定的影响
			if(Flag_COMDebug == 1)
				printf("%s\r\n",ucUar3tbuf);
			break;
		}
		if(count == 0) 											//接收到结果之前，只发送一次指令
		{	
			count = 1;
			UART3_SendString_YB(b,len);
			UART3_SendLR();	
			mytime = 0;
			memset(ucUar3tbuf,0x00,sizeof(ucUar3tbuf));
		 }
		if((mytime > 2)||(count>5))
		{									//超时
			if(Flag_COMDebug == 1)
				printf("CSQ Timer Out:%s\r\n",ucUar3tbuf);
			break;
		}
	} 
	 
}
/****************************************************************************
*	函 数 名: AT_CGATT_Ctrl
*	功能说明: 获取联网状态
*	形    参：无
*	返 回 值: 返回1表示成功，其他表示CGATT后数值
* 说    明：
*****************************************************************************/
char AT_CGATT_Ctrl(void)
{
	u8 len=0,count=0;
	unsigned char b[]="AT+CGATT",a[]="+CGATT:1";

	ClearUSART3BUF(); 
	len = strlen(b);
	while(1)                    
	{
		if(strstr(ucUar3tbuf,a)!=NULL)
		{							//是否返回指定字符串
			if(Flag_COMDebug == 1)
				printf("-------------------\r\n%s\r\n",ucUar3tbuf);
			RegEnable = 1;
			ClearUSART3BUF();
			return 1;
		}
		else if(strstr(ucUar3tbuf,"ERROR") != NULL || strstr(ucUar3tbuf,"error") != NULL)
		{		//返回error的话，进行三次重发数据，去除数据传输不稳定的影响
			if(Flag_COMDebug == 1)
				printf("%s\r\n",ucUar3tbuf);
			
			SendDataStatus=NO;					//打开发送开关
			SendSleepDataStatus=NO;				//发送失败,需要重新组装数据
			ADCTimeCount = 0;					//计时清除
		 return -1;
		}
		else if(strstr(ucUar3tbuf,"+CGATT:0") != NULL)
		{
			if(Flag_COMDebug == 1)
				printf("%s\r\n",ucUar3tbuf);
			if(AngelPace == SendSleepDataR)
			{
			   Set_StatistStartTime();	
			   Flag_Start_Mode = START_NETWOEK_RECONNECT;  //网络关闭重连
			}
			AngelPace = GETBACKSERVEROK;
			SendDataStatus=NO;					//打开发送开关
			SendSleepDataStatus=NO;				//发送失败,需要重新组装数据
			ADCTimeCount = 0;					//计时清除
			RegEnable = 1;
      if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
		    SendSleepDataReally();				//唤醒数据
		  else
			  Send_SyncDataToServer();
			return 0;
		}
		else if((strstr(ucUar3tbuf,"+CGATT:3") != NULL)||((strstr(ucUar3tbuf,"+CGATT:2") != NULL)))
		{
			if(Flag_COMDebug == 1)
					printf("%s\r\n",ucUar3tbuf);
			if(AngelPace == SendSleepDataR)
			{
			   Set_StatistStartTime();	
				 Flag_Start_Mode = START_NETWOEK_RECONNECT;  //网络关闭重连
			}
			AngelPace = GETBACKSERVEROK;
			SendDataStatus=NO;					//打开发送开关
			SendSleepDataStatus=NO;				//发送失败,需要重新组装数据
			ADCTimeCount = 0;					//计时清除
			RegEnable = 1;
      if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
		     SendSleepDataReally();				//唤醒数据
		  else
			   Send_SyncDataToServer();
			return 2;
		}
		if(count == 0) 											//接收到结果之前，只发送一次指令
		{	
			count = 1;
			UART3_SendString(b);
			UART3_SendLR();	
			mytime = 0;
			//printf("U3 Send1!%s\r\n",b);
		}
		if(mytime > 2){									//超时
			if(Flag_COMDebug == 1)
				printf("CGATT Timer Out:%s\r\n",ucUar3tbuf);
			return -2;
		}
	}
}

/****************************************************************************
*	函 数 名: Read_Card_IMSI
*	功能说明: 获取国际移动台设备标识
*	形    参：id卡号保存的位置,len卡号长度
*	返 回 值: 返回1标识正确读取，返回-1表示没有插入卡，返回0表示读取失败
* 说    明：
*****************************************************************************/
int8_t  Read_Card_IMSI(void)
{
	 char *pstr;
	 uint8_t d[20];
	 uint8_t i =0;
	 delay_ms(100);
	 ClearUSART3BUF();
	 UART3_SendString("AT+CIMI\r\n");
	  mytime = 0;
	 delay_ms(100);
	 while(1)
	 {
      if(strstr(ucUar3tbuf,"+CSQ")!=NULL)  //上一步骤中返回CSQ没有清理
			{
         ClearUSART3BUF();
	       UART3_SendString("AT+CIMI\r\n");
	       mytime = 0;
	       delay_ms(100);
			}				
		  if((strstr(ucUar3tbuf,"OK")!=NULL)&&(strstr(ucUar3tbuf,"460")!=NULL))  //模块返回IMSI号
			{
				 if(Flag_COMDebug == 1)
				    printf("%s",ucUar3tbuf);
         pstr = strstr(ucUar3tbuf,"460");
				 CARD_ID[0] = 0x39;
				 CARD_ID_LEN = 1;			 
         while(*pstr != 0x0D)
				 {
           CARD_ID[CARD_ID_LEN++] = *pstr++;
				 }					 
				 CARD_ID[CARD_ID_LEN] = '\0';
				 if(Flag_COMDebug == 1)
				   printf("SIM CARD IMSI is:%s len is:%d\r\n",CARD_ID,CARD_ID_LEN);
				 ClearUSART3BUF();
				 return 1;
			}
			if(strstr(ucUar3tbuf,"NO SIM CARD")!=NULL)  //未插入SIM卡
			{
				 if(Flag_COMDebug == 1)
				 {
					 printf("%s",ucUar3tbuf);
					 printf("No SIM Card! Please Check!\r\n");
				 }
				 return -1;
			}
			if(mytime >5)  //5s未回应，超时
			{
				if(Flag_COMDebug == 1)
				{
					printf("%s",ucUar3tbuf);
					printf("Read IMSI time out:%s\r\n",ucUar3tbuf);
				}
				ClearUSART3BUF();
				return 0;
			}
	 }
	
}
