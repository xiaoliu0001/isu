
#include "USART.h"
#include <stdlib.h>
#include "string.h"
#include "Parameter.h"

#define USART_FLAG_TXE USART_FLAG_TXDE

/****************************************************************************
*	函 数 名: SendDataToUSART   SendDatasToUSART
*	功能说明: 重新编写串口发送char和int型数据函数，
*	形    参：无
*	返 回 值: 无
* 说    明：张炜20170519增加
*****************************************************************************/ 
void SendDataToUSART( USART_Module* USARTx,uint8_t ch)
{
	  while (USART_GetFlagStatus(USARTx, USART_FLAG_TXC) == RESET);  //等待发送完毕
  	USART_SendData(USARTx,ch);    
		while (USART_GetFlagStatus(USARTx, USART_FLAG_TXC) == RESET);  //等待发送完毕
}

void SendDatasToUSART( USART_Module* USARTx,uint16_t ch)
{
	  SendDataToUSART(USARTx,(uint8_t)(ch/256));
	  SendDataToUSART(USARTx,(uint8_t)(ch%256));
}
/****************************************************************************
*	函 数 名:UART1_SendString
*	功能说明: 串口1发送字符串，
*	形    参：S字符串
*	返 回 值: 无
* 说    明：字符串必须以\0结束
*****************************************************************************/	
void UART1_SendString(unsigned char* s)
{
	while(*s){
		
		USART_SendData(USART1 ,*s++);//发送当前字符
		while(USART_GetFlagStatus(USART1, USART_FLAG_TXC)==RESET); 
	}
}
/****************************************************************************
*	函 数 名: UART1_SendString_YB
*	功能说明: 串口1发送数组数据
*	形    参：S数组，count数组长度
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void UART1_SendString_YB(unsigned char* s,unsigned int count)
{
	int i=0;
	for(i=0;i<count;i++){
		
		USART_SendData(USART1 ,s[i]);//发送当前字符
		while(USART_GetFlagStatus(USART1, USART_FLAG_TXC)==RESET); 
	}
}
/****************************************************************************
*	函 数 名: UART3_SendString
*	功能说明: 串口3发送字符串，
*	形    参：S字符串
*	返 回 值: 无
* 说    明：字符串必须以\0结束
*****************************************************************************/
void UART3_SendString(unsigned char* s)
{
	//printf("send:[%s]\r\n",s);
	while(*s){
		
		USART_SendData(USART3 ,*s++);//发送当前字符
		while(USART_GetFlagStatus(USART3, USART_FLAG_TXC)==RESET); 
	}
}
void UART3_SendData(unsigned char* data,uint16_t len)
{
    int i=0;
	for(i=0;i<len;i++)
    {
		
		USART_SendData(USART3 ,*data++);//发送当前字符
		while(USART_GetFlagStatus(USART3, USART_FLAG_TXC)==RESET); 
	}
}
/****************************************************************************
*	函 数 名: UART3_SendString_YB
*	功能说明: 串口3发送数组数据
*	形    参：S数组，count数组长度
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void UART3_SendString_YB(unsigned char* s,unsigned int count)
{
	int i=0;
	//printf("send str_YB to usart3\r\n");
	for(i=0;i<count;i++){
		USART_SendData(USART3 ,s[i]);//发送当前字符
		while(USART_GetFlagStatus(USART3, USART_FLAG_TXC)==RESET); 
	}
}
/****************************************************************************
*	函 数 名: ComCpuRece
*	功能说明: 
*	形    参：ucusart    *Str
*	返 回 值: 
* 说    明：
*****************************************************************************/
uint8_t ComCpuRece(unsigned char ucusart,uint8_t *Str) 
{
	switch(ucusart){
		case MYUSRAT1:
			if (Recestop1==ReceEnd1) return 1;
			*Str=ucUar1tbuf[Recestop1];
			Recestop1++;
			if (Recestop1>=BufMAX) Recestop1=0;
			return 0;
		case MYUSRAT2:
			if (Recestop2==ReceEnd2) return 1;
			*Str=ucUar2tbuf[Recestop2];
			Recestop2++;
			if (Recestop2>=BufMAX) Recestop2=0;
			return 0;
		case MYUSRAT3:
			if (Recestop3==ReceEnd3) return 1;
			*Str=ucUar3tbuf[Recestop3];
			Recestop3++;
			if (Recestop3>=BufMAX) Recestop3=0;
			return 0;
	}
	return 0;
}
/****************************************************************************
*	函 数 名: ComCpuReceAtTime
*	功能说明: 
*	形    参：ucusart   *Str   length
*	返 回 值: 
* 说    明：
*****************************************************************************/
#define TimeOver	0x5000   //	时间参数要设大点
uint8_t ComCpuReceAtTime(unsigned char ucusart,uint8_t *Str,uint8_t length) 
{
	unsigned int  time;
	unsigned char temp;
	time=0;
	if (length==0) return 0;
	while(time++<TimeOver)
	{
		if (ComCpuRece(ucusart,&temp)==1) continue;
		time=0;
		*Str++=temp;
		length--;
		if (length==0) return 0;
	}
	return 1;
}
//将串中每两个字节压缩成一个字节，iLen之源串长度，原串长度要小于200
void CompressString(unsigned char *cpSrc,unsigned char *cpDes,unsigned int iLen)
{
	unsigned int  iLoop,i;
	unsigned char  cTmp1;
	unsigned char  cTmp2;
	unsigned char  cA;
	unsigned char  cB;

	for(iLoop=0,i=0;iLoop<iLen;i++)
	{
		cA=*(cpSrc+iLoop);
		cB=*(cpSrc+iLoop+1);
			
		if( (cA<=0x3F)&& (cA>=0x30) )
			cTmp1=cA-0x30;
		if( (cA<=0x46)&& (cA>=0x41) )
			cTmp1=cA-0x37;
		if( (cA<=0x66)&& (cA>=0x61) )
			cTmp1=cA-0x57;
			
		if( (cB<=0x3F)&& (cB>=0x30) )
			cTmp2=cB-0x30;
		if( (cB<=0x46)&& (cB>=0x41) )
			cTmp2=cB-0x37;
		if( (cB<=0x66)&& (cB>=0x61) )
			cTmp2=cB-0x57;
		
		cpDes[i]=cTmp1*16+cTmp2;
		iLoop=iLoop+2;
	}

}
/********************************************************************************************/
//将串中每个字节劈成两个字节，iLen之源串长度
void SplitString(unsigned char *cpSrc,unsigned char *cpDes,int iLen)
{
	unsigned char ucTmp;
	unsigned int  i,w;
	
	for(w=0;w<iLen;w++)
	{
		ucTmp=((*cpSrc)>>4);
		if(ucTmp>9)
			*cpDes=ucTmp+55;
		else
			*cpDes=ucTmp+0x30;
		
		cpDes++;
		ucTmp=(*cpSrc)%0x10;
		if(ucTmp>9)
			*cpDes=ucTmp+55;
		else
			*cpDes=ucTmp+0x30;
			
		cpDes++;
		cpSrc++;
	}

}
/****************************************************************************
*	函 数 名: ClearUSART3BUF
*	功能说明: 清除串口3缓存
*	形    参：无
*	返 回 值: 
* 说    明：
*****************************************************************************/
void ClearUSART3BUF(void)
{
	uint16_t i = 0;

	for(i=0;i<BufMAX;i++)
		  ucUar3tbuf[i] = 0;
	ucUar3InterrFlag=0;
  ReceEnd3=0;
}
/****************************************************************************
*	函 数 名: ClearUSART2BUF
*	功能说明: 清除串口2缓存
*	形    参：无
*	返 回 值: 
* 说    明：
*****************************************************************************/
void ClearUSART2BUF(void)
{
	memset(ucUar2tbuf,0x00,sizeof(ucUar2tbuf));
	ucUar2InterrFlag=0;
  ReceEnd2=0;
}
/****************************************************************************
*	函 数 名: PUTCHAR_PROTOTYPE
*	功能说明: 绑定printf输出到串口1
*	形    参：无
*	返 回 值: 
* 说    明：
*****************************************************************************/
#if 0
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART */
  USART_SendData(USART1, (uint8_t) ch);

  /* Loop until transmit data register is empty */
  while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET)
  {}

  return ch;
}
#endif