/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/

/**
 * @file main.c
 * @author Nations 
 * @version v1.0.1
 *
 * @copyright Copyright (c) 2019, Nations Technologies Inc. All rights reserved.
 */
#include "main.h"
#include <stdio.h>
#include <BERpara.h>
#include "Parameter.h"
#include "USART.h"
#include "Delay.h"
#include "Flash.h"
#include "Calculate.h"
#include "LED_Key.h"
#include "m26.h"
#include "Fun.h"
#include "string.h"
#include "MobileAndlink.h"
#include "STMFlash.h"


#define MCUID_ADDRESS          0x1FFFF7E8
#define MCUFLASHSIZE_ADDRESS   0x1FFFF7E0

/** @addtogroup TIM_TimeBase
 * @{
 */

TIM_TimeBaseInitType TIM_TimeBaseStructure;
OCInitType TIM_OCInitStructure;
ErrorStatus HSEStartUpStatus;

__IO uint16_t CCR1_Val  = 40961;
__IO uint16_t CCR2_Val  = 27309;
__IO uint16_t CCR3_Val  = 13654;
__IO uint16_t CCR4_Val  = 6826;
__IO uint16_t MY_CCR_Val  = 40060;
uint16_t PrescalerValue = 0;

USART_InitType USART_InitStructure;


ADC_InitType ADC_InitStructure;
DMA_InitType DMA_InitStructure;
__IO uint16_t ADC1_ConvertedValue = 0;
__IO uint16_t ADC3_ConvertedValue = 0;
//__IO uint16_t ADC1_ConvertedValue[2]={0};


#define TxBufferSize1 (countof(TxBuffer1) - 1)
#define TxBufferSize2 (countof(TxBuffer2) - 1)
#define RxBufferSize1 TxBufferSize2
#define RxBufferSize2 TxBufferSize1

#define countof(a) (sizeof(a) / sizeof(*(a)))

#define SYSTEMRESET_POWER       1   //电源复位
#define SYSTEMRESET_WATCHDOG    2   //看门狗复位
#define SYSTEMRESET_SOFT        3   //软件复位
#define SYSTEMRESET_UNKNOW      4   //不明原因复位 例如软件复位等

#define  START_POWERON            0X01     //电源重启
#define  START_NETWOEK_RECONNECT  0X02     //断网重连
#define  START_LTE_RESTART       0X03     //LTE模块上电重启
#define  START_SOFTRESET          0X04     //软件复位
#define  START_IWDGRESET          0X05     //看门狗复位
/****************软硬件版本信息,软件版本号后的时间为程序编译时间，张炜加********************/

USART_InitType USART_InitStructure;
uint8_t TxBuffer1[] = "USART Interrupt Example: USARTy -> USARTz using Interrupt";
uint8_t TxBuffer2[] = "USART Interrupt Example: USARTz -> USARTy using Interrupt";
uint8_t RxBuffer1[RxBufferSize1];
uint8_t RxBuffer2[RxBufferSize2];
__IO uint8_t TxCounter1         = 0x00;
__IO uint8_t TxCounter2         = 0x00;
__IO uint8_t RxCounter1         = 0x00;
__IO uint8_t RxCounter2         = 0x00;
uint8_t NbrOfDataToTransfer1    = TxBufferSize1;
uint8_t NbrOfDataToTransfer2    = TxBufferSize2;
uint8_t NbrOfDataToRead1        = RxBufferSize1;
uint8_t NbrOfDataToRead2        = RxBufferSize2;
__IO TestStatus TransferStatus1 = FAILED;
__IO TestStatus TransferStatus2 = FAILED;

volatile uint8_t mboot_flag=0;

volatile uint8_t unbind_flag=0; 
extern uint8_t press_cnt;

void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);
void Timer_Configuration(void);

void DMA_ADC_Configuration(void);
void InitParam(void);
volatile uint8_t receive_unbind_flag=0;

 char  *SoftVer = "Hardware:V5.0-20190523\r\nSoftware:V5.0.1<20190927>\r\n";  
 unsigned char sDebugMode = 0;
 u32 CpuID[3]={0};
 char is_softreset = 0;

void Get_CPU_ID(void)
   
{
//read CPU ID,stm32lxx,add+4
CpuID[0] = *(__IO u32 *)(0X1FFFF7AC);
CpuID[1] = *(__IO u32 *)(0X1FFFF7B0);
CpuID[2] = *(__IO u32 *)(0X1FFFF7B4);	
}


enum
{
    SYSCLK_PLLSRC_HSI,
    SYSCLK_PLLSRC_HSE,
};
void SetSysClockToPLL(uint32_t freq, uint8_t src)
{
    uint32_t pllsrc = (src == SYSCLK_PLLSRC_HSI ? RCC_PLL_SRC_HSI_DIV2 : RCC_PLL_SRC_HSE_DIV2);
    uint32_t pllmul;
    uint32_t latency;
    uint32_t pclk1div, pclk2div;

    if (HSE_VALUE != 8000000)
    {
        /* HSE_VALUE == 8000000 is needed in this project! */
        while (1)
            ;
    }

    /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration
     * -----------------------------*/
    /* RCC system reset(for debug purpose) */
    RCC_DeInit();

    if (src == SYSCLK_PLLSRC_HSE)
    {
        /* Enable HSE */
        RCC_ConfigHse(RCC_HSE_ENABLE);

        /* Wait till HSE is ready */
        HSEStartUpStatus = RCC_WaitHseStable();

        if (HSEStartUpStatus != SUCCESS)
        {
            /* If HSE fails to start-up, the application will have wrong clock
               configuration. User can add here some code to deal with this
               error */

            /* Go to infinite loop */
            while (1)
                ;
        }
    }

    switch (freq)
    {
    case 24000000:
        latency  = FLASH_LATENCY_0;
        pllmul   = RCC_PLL_MUL_6;
        pclk1div = RCC_HCLK_DIV1;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 36000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_9;
        pclk1div = RCC_HCLK_DIV1;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 48000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_12;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 56000000:
        latency  = FLASH_LATENCY_1;
        pllmul   = RCC_PLL_MUL_14;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 72000000:
        latency  = FLASH_LATENCY_2;
        pllmul   = RCC_PLL_MUL_18;
        pclk1div = RCC_HCLK_DIV2;
        pclk2div = RCC_HCLK_DIV1;
        break;
    case 96000000:
        latency  = FLASH_LATENCY_2;
        pllmul   = RCC_PLL_MUL_24;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    case 128000000:
        latency  = FLASH_LATENCY_3;
        pllmul   = RCC_PLL_MUL_32;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    case 144000000:
        /* must use HSE as PLL source */
        latency  = FLASH_LATENCY_4;
        pllsrc   = RCC_PLL_SRC_HSE_DIV1;
        pllmul   = RCC_PLL_MUL_18;
        pclk1div = RCC_HCLK_DIV4;
        pclk2div = RCC_HCLK_DIV2;
        break;
    default:
        while (1)
            ;
    }

    FLASH_SetLatency(latency);

    /* HCLK = SYSCLK */
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);

    /* PCLK2 = HCLK */
    RCC_ConfigPclk2(pclk2div);

    /* PCLK1 = HCLK */
    RCC_ConfigPclk1(pclk1div);

    RCC_ConfigPll(pllsrc, pllmul);

    /* Enable PLL */
    RCC_EnablePll(ENABLE);

    /* Wait till PLL is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_PLLRD) == RESET)
        ;

    /* Select PLL as system clock source */
    RCC_ConfigSysclk(RCC_SYSCLK_SRC_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while (RCC_GetSysclkSrc() != 0x08)
        ;
}

/**
 * @brief  Configures LED GPIO.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedInit(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_InitType GPIO_InitStructure;

    /* Check the parameters */
    assert_param(IS_GPIO_ALL_PERIPH(GPIOx));


    /* Enable the GPIO Clock */
    if (GPIOx == GPIOA)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
    }
    else if (GPIOx == GPIOB)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
    }
    else if (GPIOx == GPIOC)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    }
    else if (GPIOx == GPIOD)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOD, ENABLE);
    }
    else if (GPIOx == GPIOE)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOE, ENABLE);
    }
    else if (GPIOx == GPIOF)
    {
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOF, ENABLE);
    }
    else
    {
        if (GPIOx == GPIOG)
        {
            RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOG, ENABLE);
        }
    }

    /* Configure the GPIO pin */
    if (Pin <= GPIO_PIN_ALL)
    {
        GPIO_InitStructure.Pin        = Pin;
        GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitPeripheral(GPIOx, &GPIO_InitStructure);
    }
}
/**
 * @brief  Turns selected Led on.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedOn(GPIO_Module* GPIOx, uint16_t Pin)
{
        GPIOx->PBC = Pin;
}
/**
 * @brief  Turns selected Led Off.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedOff(GPIO_Module* GPIOx, uint16_t Pin)
{
	GPIOx->PBSC = Pin;
}
/**
 * @brief  Turns selected Led on or off.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be one of the following values:
 * 	@arg GPIO_PIN_0~GPIO_PIN_15: set related pin on
 *   	@arg (GPIO_PIN_0<<16)~(GPIO_PIN_15<<16): clear related pin off
 */
void LedOnOff(GPIO_Module* GPIOx, uint32_t Pin)
{
    GPIOx->PBSC = Pin;
}
/**
 * @brief  Toggles the selected Led.
 * @param GPIOx x can be A to G to select the GPIO port.
 * @param Pin This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void LedBlink(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIOx->POD ^= Pin;
}

/****************************************************************************
*	函 数 名:  SystemReset_CheckStatus
*	功能说明:  查找复位的原因
*	形    参：
*	返 回 值:
* 	说    明：电源复位、看门狗复位
*****************************************************************************/
void SystemReset_CheckStatus(void)
{

	if((RCC_GetFlagStatus(RCC_FLAG_IWDGRST) == SET)||(RCC_GetFlagStatus(RCC_FLAG_WWDGRST) == SET))
	{
		 //Flag_SystemReset = SYSTEMRESET_WATCHDOG;
		Flag_Start_Mode = START_IWDGRESET;  //看门狗复位重启
		 if(Flag_COMDebug == 1)
				printf("\r\n看门狗复位\r\n");
	}
	else if(RCC_GetFlagStatus(RCC_FLAG_LPWRRST) == SET)
	{
		 //Flag_SystemReset = SYSTEMRESET_POWER;
		Flag_Start_Mode = START_POWERON;  //上电重启
		 if(Flag_COMDebug == 1)
				printf("\r\n低电压复位\r\n");
	}
	else if((RCC_GetFlagStatus(RCC_FLAG_PORRST) == SET)||(RCC_GetFlagStatus(RCC_FLAG_PINRST) == SET))
	{
		 //Flag_SystemReset = SYSTEMRESET_POWER;
		Flag_Start_Mode = START_POWERON;  //上电重启
		 if(Flag_COMDebug == 1)
				printf("\r\n电源复位\r\n");
	}
	else if(RCC_GetFlagStatus(RCC_FLAG_SFTRST) == SET)
	{
		 //Flag_SystemReset = SYSTEMRESET_SOFT;
		Flag_Start_Mode = START_SOFTRESET;  //软件复位重启
		 if(Flag_COMDebug == 1)
				printf("\r\n软件复位\r\n");
	}
	else
	{
		 //Flag_SystemReset = SYSTEMRESET_UNKNOW ;
		Flag_Start_Mode = START_POWERON;  //上电重启
		 if(Flag_COMDebug == 1)
				printf("\r\n不明原因复位\r\n");
	}
		
	RCC_ClrFlag();
}


/****************************************************************************
*	函 数 名: LinkServer
*	功能说明: 连接服务器
*	形    参：
*	返 回 值: 
* 说    明：
*****************************************************************************/
volatile uint8_t first_power_flag=0;
void LinkServer(uint8_t AP)
{
	uint8_t i;
	char str[100];
	char *TTopic[] = {"/device/CMCC-591217-A2B3C4D5E618/downward"};
	static uint8_t DM_hreat_flag = 0;
	switch(AngelPace)
    {
        case SendSleepDataR:  //已联网，正常数据传输
            Flag_Register_OK = 1;
			Flag_LinkStatus = START_GPRS_LINKOK;
            break; 
		
		case DM_CONFIG_Auto:  //配置拉取--自注册
			Connect_DM_Server();
			#ifdef NOT_CMCC
			AngelPace = POWER_ON_NOTIFY;
			break;
			#endif
			if(Dm_getConfig_Auto())
			{
				delay_ms(500);
				if(HttpStageRevRespon()) 
					AngelPace = DM_CONFIG_Heart;
			}
			break;
		
		case DM_CONFIG_Heart: //配置拉取--心跳
			if(Dm_getConfig_Heart())
			{
				delay_ms(300);
				if(HttpStageRevRespon())
					AngelPace = DM_REGIST;
			}
			break;
		
		case DM_REGIST:       //自注册
			if(Dm_RegistReport())
			{
				delay_ms(300);
				HttpStageRevRespon();
				AngelPace = DM_HEART;
				DM_Heart_Time = 0;
			}
			break;
		
		case DM_HEART:        //心跳
			//如果是定时上报的情况不用再经过POWER_ON_NOTIFY状态，直接回到MQTT
			if(Dm_HeartReport())
			{
				DM_hreat_flag = 1;
				delay_ms(300);
				if(HttpStageRevRespon())
				{
					if(DM_Heart_Time > 5)  //定时心跳
					{
						GPRS_CloseSocket();  		//关闭TCP连接
						AngelPace = ANDLINK_MQTT;
					}
					else
					{
						AngelPace = POWER_ON_NOTIFY;
					}
				}
			}
			break;
		
		case POWER_ON_NOTIFY: //上电注册到isuke后台
			if(Power_on_notify())
			{
				delay_ms(300);
				//iSuke_MQTT_Time();
							
			
//				if(HttpStageRevRespon())
//				{
					GPRS_CloseSocket();  		//关闭TCP连接
					AngelPace = ANDLINK_MQTT;
//				}
			} else {
                // 失败关闭tcp连接再重连
                GPRS_CloseSocket();  		//关闭TCP连接
                delay_ms(300);
                Connect_DM_Server();
            }
			break;
		
		case ANDLINK_MQTT:   //MQTT连		
//			GPRS_CloseSocket(); 
		
			if(MQTT_config())
				if(MQTT_TCP_connect())
					if(MQTT_session_conn())
						if(MQTT_SUB())
						{
							if(Flag_COMDebug == 1)
								printf("PowerBatteryFlag:%d\r\n",PowerBatteryFlag);
							AngelPace = ONLINE_MQTT;
						}
             iSuke_MQTT_Time();  //获取时间

			break;
		
		case ONLINE_MQTT: 
			if(first_power_flag == 0)
			{
				first_power_flag=1;
				GPRS_CloseSocket();
				delay_ms(100);		
				Connect_DM_Server(); 
				delay_ms(200);
				Andlink_GetGWAddress();
				
                for (i = 0; i < 5; i ++) {
                    //设备注册
                    if (1 == Andlink_DeviceRegist()) {
                        break;
                    }
                    delay_ms(2000);
                }
                if (5 == i) {
                    log_trace("reboot \r\n");
                    SaveSoftRebootFlagToFlash();
                    delay_ms(1000);
                    NVIC_SystemReset(); //复位
                }

                delay_ms(200);
                for (i = 0; i < 5; i ++) {
                    //设备上线
                    if (1 == Andlink_DeviceOnline()) {
                        break;
                    }
                    delay_ms(2000);
                }
                if (5 == i) {
                    log_trace("reboot \r\n");
                    SaveSoftRebootFlagToFlash();
                    delay_ms(1000);
                    NVIC_SystemReset(); //复位
                }
				
                log_trace("Flag_Start_Mode:%d ReadUpFlagFromFlash:%d \r\n", Flag_Start_Mode, ReadUpFlagFromFlash());
                log_trace("Flag_Start_Mode:%d is_softreset:%d \r\n", Flag_Start_Mode, g_softboot_info.flag);
				if((g_softboot_info.flag != Flag_SoftReboot)||(ReadUpFlagFromFlash() == 0))  // 上电情况下再上报，看门狗复位不上报
				{
                    for (i = 0; i < 5; i ++) {
                        //终端管理数据上报 
                        if (1 == TerminalManageDataReport()) {
                            SaveUpFlagToFlash();
                            break;
                        }
                        delay_ms(2000);
                    }
                    if (5 == i) {
                        log_trace("reboot \r\n");
                        SaveSoftRebootFlagToFlash();
                        delay_ms(1000);
                        NVIC_SystemReset(); //复位
                    }
				}
				GPRS_CloseSocket();
                
			}

		    delay_ms(100);
            Andlink_MQTT_Link();	//MQTT连接	

			iSuke_MQTT_Mboot(); //MBOOT
		
		    sprintf(str,"/device/CMCC-%s-%s/downward", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
			TTopic[0] = str;
			printf("Subscribe Topic: %s\r\n", TTopic[0]);
			OneNet_Subscribe(TTopic,1);
		    Andlink_MQTT_Online();  //mqtt 上线通知
		
		    delay_ms(200);
		
			if(PowerBatteryFlag == 1)  //电池供电
				AngelPace = POWERERROR;
			else
				AngelPace = POWERNORMAL;
			break;
		
        case POWERERROR:   //电池供电
			AngelPace = SendSleepDataR; 
			Flag_PowerOn = 0; 
			if(LuatPowerOnWay == 1)
			{
				LuatPowerOnWay = 0;
				Luat_15min_SendFlag = 1;  //可以进行15min一发
			}
			else if(LuatPowerOnWay == 2)  //电池模式下收到SOS帧
			{
				iSuke_MQTT_Time();  //获取时间
				if((Timebuf[0]>22) && (Timebuf[1]<13) && (Timebuf[2]<32))  //日期正确
				{
					if(iSuke_MQTT_SOS(ucUar2tbuf[1]))
					{
						COMRetuenSOS_event(USART1,1);
						LuatPowerOnWay = 0;
						PowerBatteryDeal();  //模组关机
					}
					else
					{
						AngelPace = POWERERROR;  //重发
						COMRetuenSOS_event(USART1,0);
					}
				}
			}
            break;
			
		case POWERNORMAL:  //插电
			iSuke_MQTT_Time();  //获取时间
			if((Timebuf[0]>22) && (Timebuf[1]<13) && (Timebuf[2]<32))  //日期正确
			{
				if(DM_hreat_flag == 1)  //DM心跳
				{
					DM_hreat_flag = 0;
					for(i=0;i<6;i++)  //DM心跳的起始时间
						DMHeartTime[i] = Timebuf[i];
				}
				AngelPace = SendSleepDataR;
				Flag_PowerOn = 0;  
                
                if (g_softboot_info.flag == Flag_SoftReboot) {
                    log_trace("soft reboot update dm report count to %d \r\n", g_softboot_info.dm_report_count);
                    TerminalManage_cnt = g_softboot_info.dm_report_count;
                    g_softboot_info.flag = 0;
                }
			}
			break;
		
        case MACERROR:								//MAC不存在处理

            break;			
    }
}
//窗口看门狗配置
void WWDG_CONFIG(void)
{
	/* WWDG configuration */
    /* Enable WWDG clock */
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_WWDG, ENABLE);
    /* WWDG clock counter = (PCLK1(36MHz)/4096)/8 = 1099 Hz (~910 us)  */
    WWDG_SetPrescalerDiv(WWDG_PRESCALER_DIV8);
    /* Set Window value to 80; WWDG counter should be refreshed only when the counter
      is below 80 (and greater than 64) otherwise a reset will be generated */
    WWDG_SetWValue(80);
    /* Enable WWDG and set counter value to 127, WWDG timeout = ~910 us * 64 = 58.25 ms
       In this case the refresh window is: ~910 us * (127-80) = 42.77 ms < refresh window < ~910 us * 64 = 58.25ms */
    WWDG_Enable(127);
}

#if TOUCH_KEY
/**
 * @brief  Initializes the peripherals used by the KEY driver.
 */
void KEY_Init(void)
{ 
    GPIO_InitType GPIO_InitStructure;
 
    /*!< KEY, KEY0-KEY1 , KEY3 Periph clock enable */
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);

    GPIO_InitStructure.Pin  = GPIO_PIN_15;//KEY0-KEY1
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);
}

#endif

uint8_t KEY_Read_value(void)
{
    return GPIO_ReadInputDataBit(GPIOB,GPIO_PIN_15);
}




/**
 * @brief  Main program
 */
int main(void)
{
	uint16_t i,ADC_COUNT = 0;
    int Res;
    int have_sn = 0;

	InitParam();
		
    /* System Clocks Configuration */
//	SetSysClockToPLL(96000000, SYSCLK_PLLSRC_HSI);
	SetSysClockToPLL(36000000, SYSCLK_PLLSRC_HSI); //test code
	RCC_EnableClockSecuritySystem(ENABLE);
    RCC_Configuration();
    /* NVIC Configuration */
    NVIC_Configuration(); 
    /* GPIO Configuration */
    GPIO_Configuration();
	/* Timer Configuration */
	Timer_Configuration();
    /* USART Configuration */
	USART_Configuration();
	/* DMA ADC Configuration */
	DMA_ADC_Configuration();
	//LED
	LedInit(GPIOA, GPIO_PIN_15);
	LedInit(GPIOA, GPIO_PIN_2);
	DataInitial();
	delay_init();
	ClearUSART3BUF(); 
	SleepData_SendTime = CGATTime_3;	//开始默认发送时间间隔为3s		
//	delay_ms(500);
	LedOn(GPIOA, GPIO_PIN_15);
    #if TOUCH_KEY
    KEY_Init();
    #endif
    ReadSoftRebootFlagFromFlash(&g_softboot_info);
    ClearSoftRebootFlagToFlash();
	ReadMACFromFlash();

	if(Flag_COMDebug == 1)
	{
		printf("\r\n******************************************************************************\r\n"); 
		printf("%s",SoftVer);
        printf("Soft release time:%s \r\n",RELEASE_TIME);
		printf("Build time is:%s %s\r\n", __DATE__, __TIME__);
        printf("MAC:%s \r\n",Device_Info.MAC_ID);
        printf("CMEI:%s \r\n",Device_Info.CMCC_CMEI);
        printf("SN:%s \r\n",Device_Info.CMCC_SN);
        printf("manuDate:%s \r\n",Device_Info.manuDate);
		printf("******************************************************************************\r\n");
        log_trace("dm report count: %d \r\n", g_softboot_info.dm_report_count);
        log_trace("soft reboot flag: %d \r\n", g_softboot_info.flag);
		printf("System Init!\r\n");
	}
	SystemReset_CheckStatus();
	Get_CPU_ID();
	if(Flag_COMDebug == 1)
		printf("CPU_ID: %08X-%08X-%08X\r\n",CpuID[0],CpuID[1],CpuID[2]);
//	COMSynSOS_NetStatus(USART1,0);  //上电时向SOS发一条信息




	// ReadFlash();
	// CheckMac();
	
	if((Flag_Check_Status&ERROR_N0_MAC) !=ERROR_N0_MAC)
	{
		 
		Flag_init = MAC_INIT_OK;  //可以进行无线模块初始化
		Flag_start_time = 1;	
		ClearUSART3BUF();		
		delay_ms(500);	
		GPRS_ConnetTime =0;
        
        // 拷贝过去SIMCard_IMEI，因为之前很多地方都有用到，而现在改成读flash的内容到Device_Info
        strncpy(SIMCard_IMEI, Device_Info.CMCC_CMEI, sizeof(Device_Info.CMCC_CMEI));
        strncpy(MAC_IDstring, Device_Info.MAC_ID, sizeof(Device_Info.MAC_ID));
        strncpy(MAC_ID, Device_Info.MAC_ID, sizeof(Device_Info.MAC_ID));
        have_sn = 1;
	} else {
        //Flag_COMDebug = 0;
		printf("MAC or CMEI NULL\r\n");	
        have_sn = 0;
	}

//	WWDG_CONFIG();   //窗口看门狗配置
//	IWDG_Config(IWDG_PRESCALER_DIV64 ,1250);	 //看门狗	test code!!!

	while(1)
	{	
//------------------------压力传感器---------------------------------------------			
		if(Flag_PowerOn == 0)
		{
			Check_ExtSensor_PeopleOnBed(); //检查外部传感器在床状态
		}			
//-------------------------GPRS初始化--------------------------------------------		
		if(Flag_init == MAC_INIT_OK) 
		{
			if(GPRS_or_WIFI == GPRS)//GPRS初始化
			{
				Init_M26(Flag_Init_Step);				 
			}
		}		
		if(Flag_init == WIRELESS_INIT_OK)
		{
		//-----------------------无线连接数据处理-\----------------------------	 		  
			LinkServer(AngelPace);

		//-------------------------------60s查询一次信号状态---------------------------------
			//每10秒发一次联网状态给SOS
			if((ATCGATT_Count % 11 == 0) && (GPRS_or_WIFI == GPRS))
			{
				ATCGATT_Count++;
				#ifdef SOS_1_0
				if(ucConectFlag == 1)         //联网
				{
					COMSynSOS_NetStatus(USART1,1);
					if(Flag_COMDebug == 1)
						printf("to SOS:已联网 \r\n");
				}
				else
				{
					COMSynSOS_NetStatus(USART1,0);
					if(Flag_COMDebug == 1)
						printf("to SOS:未联网 \r\n");
				}
				#endif
			}
			if((ATCGATT_Count > 60) && (GPRS_or_WIFI == GPRS))
			{
				ATCGATT_Count = 0;
				if(AngelPace == SendSleepDataR)  //查询信号值
				{
					InquireCSQ();
					if(1 != MQTT_Status() || 1 != CheckLinkStatus()) 
					{
						MQTT_Close();  //关闭MQTT
                        GPRS_CloseSocket(); // 关闭 TCP 或 UDP 连接
						Flag_init = WIRELESS_INIT_OK;
						Flag_Init_Step=8;
						AngelPace = POWER_ON_NOTIFY;
						ucConectFlag = 0;
                        log_trace("mqtt or tcp disconnect, go to power on reconnect \r\n");
					}
				}
			}
			//-------------------------------如果从机超时则上报下线---------------------------------
			Slave_Manage_PutOut();
			//-------------------------------每24小时进行一次DM心跳上报---------------------------------
			if(mboot_flag ==1)
			{
				mboot_flag=0;
				MQTT_Mboot_Send(); //这个会上报dmReport，不知道为啥可能平台转发了
                //TerminalManageDataReport();
			}
			
            //printf("ADC_ConvertedValue[1]=%d press_cnt=%d\r\n", ADC_ConvertedValue[1], press_cnt);
			// if(ADC_ConvertedValue[1]>=0x400)
			// {
			// 	unbind_flag = 1;
			// }else{
			// 	unbind_flag = 0;
			// }
            
			//if(press_cnt >= 4)
            if (1 == unbind_flag)
			{
                
				press_cnt=0;//按压次数清零
//				press_flag=0;
				receive_unbind_flag=1;
//				STMFLASH_SectorErase(FLASH_ServerInfoAddress);  //删除IP信息
//				STMFLASH_SectorErase(FLASH_VerifyInfoAddress);  //删除token信息
//				STMFLASH_SectorErase(FLASH_WIFIInfoAddress);
//				STMFLASH_SectorErase(FLASH_AndLinkInfoAddress);
//				NVIC_SystemReset();
//				Connect_DM_Server();
//				delay_ms(100);
//				Andlink_DeviceOnline();  //设备上线
				// 20:00 ~ 8:00 不能解绑
                #define CAN_UNBIND_START_HOUR  (8)
                #define CAN_UNBIND_END_HOUR  (20)
				//if (CAN_UNBIND_END_HOUR > Timebuf[3] && CAN_UNBIND_START_HOUR <= Timebuf[3]) {
					receive_unbind_flag=1;
					isuke_UserUnbind();
					printf("key force unbind\r\n");
					printf("time[20%02d%02d%02d%02d%02d%02d] unbind ok\r\n", Timebuf[0], Timebuf[1], Timebuf[2], Timebuf[3], Timebuf[4], Timebuf[5]);
				//} else {
				//	printf("time[20%02d%02d%02d%02d%02d%02d] not support unbind \r\n", Timebuf[0], Timebuf[1], Timebuf[2], Timebuf[3], Timebuf[4], Timebuf[5]);
				//}
                
                delay_ms(2000);
                unbind_flag = 0;
                // 重新上线 不然解绑后杭研平台会显示离线
                first_power_flag = 0;
                AngelPace = ONLINE_MQTT;
			}
//			#ifndef Demonstrate
			#ifndef NOT_CMCC
			if((DM_Heart_Time >= 100)&&(AngelPace == SendSleepDataR)) 
			{
				if((DMHeartTime[3] == Timebuf[3])&&(DMHeartTime[4] == Timebuf[4])&&(DMHeartTime[0] != 0)) 
				{
					if(Flag_COMDebug == 1)
						printf("\r\nDM heart : %d,%d\r\n",DMHeartTime[3],DMHeartTime[4]);
					DM_Heart_Time = 6; 
					MQTT_Close();				//先关闭MQTT
					Connect_DM_Server();        //连上服务器
					AngelPace = DM_HEART;
				}
			}
			#endif
			//-----------------------------无线接收数据处理--------------------------------------------------
//				if((AngelPace == SendSleepDataR) && (GPRS_or_WIFI == GPRS))
//				{
//					SendSleepDataReallyRcvCtr();
//				}
			if((SleepData_SendTime == CGATTime_10)&&(PowerBatteryFlag == 0)&&((LuatPowerOnWay == 0)))  //未联网情况下收到电池供电，待校时后再进行低功耗操作
			{
				if((Timebuf[0]>22) && (Timebuf[1]<13) && (Timebuf[2]<32))  //日期正确
				{
					if(Flag_COMDebug == 1)
						printf("已校时，置位电池供电\r\n");
					PowerBatteryFlag = 1;
					PowerBatteryDeal();
				}
			}
			if(LuatPowerOnWay == 3)  //未联网时收到SOS信息
			{
				if((Timebuf[0]>22) && (Timebuf[1]<13) && (Timebuf[2]<32))  //日期正确
				{
					if(iSuke_MQTT_SOS(ucUar2tbuf[1]))
					{
						LuatPowerOnWay = 0;
						COMRetuenSOS_event(USART1,1);
					}
					else
					{
						COMRetuenSOS_event(USART1,0);
					}
				}
			}
			if((Flag_TimeAdj == 1)&&(AngelPace == SendSleepDataR)) //校准时间 5min 1次
			{
				if(PowerBatteryFlag == 0)  //插电供电
					iSuke_MQTT_Time();
				Flag_TimeAdj = 0;				
			}
		}

		//调用算法库进行计算
		if(Algorithm_TIMER_FLAG)
		{
				Algorithm_TIMER_FLAG = 0;
				if(Flag_PowerOn == 0)
				{
					 OnbedStatus_CountTimer++;
					 SleepDataCalculate();
				}	
		}
		//-----------------------------实时数据处理-------------------------
		if((AT_CGATT_Count >= SleepData_SendTime)&&(Flag_PowerOn == 0))  //发送实时数据
		{		  
			SendSleepDataReally();				//发送数据，发送到缓存里面
			AT_CGATT_Count=0;
//			GPIO_WriteBit(LED_GPIO_PORT,GPIO_PIN_2,1);
//			DeviceIntoSleep(); 
		}
		//-----------------------------打印串口信息处理--------------------------------------------------
		//if( ((ucUar2InterrFlag&0x8000)!=0) || ((ucUar1InterrFlag&0x8000)!=0))
        if (0 == have_sn)
		{
            // 注意：这里打开就会出现用适配器供电无法上线的问题，但是用usb打印工具供电就能正常
			COM1ProcessCmd();
		}
		//-------------------------如果SOS状态为none，则默认为插电供应------------------------------------------	
		if(SOSConnectFlag == 0)  //test code!!!
		{
			if(PowerBatteryFlag == 1)          //只调用一次,从关联SOS到失去联系
			{
				SleepData_SendTime = CGATTime_3;   //用插电时3s 1发
				if(Flag_COMDebug == 1)
					printf("SOS 失去联系，默认插电\r\n");
				Flag_PowerOn = 1;
				Battery_CntTime = 0;
				LuatPowerOnWay = 0;
				Flag_init = MAC_INIT_OK;//模组开机 
				Flag_Init_Step = 1;
				PowerBatteryFlag = 0; 
			}
		}		
	}	
}

void InitParam(void)
{
	int i ,j;
	//------------------变量初始化--------------------------------------	
	Times = 0;							//信号量计时清零
	AngelPace = CONECTIP1;
	Flag_No_Binding_Users_Time =0; //未关联用户计时标志清零
	Flag_Binding_Users = BINDING_USERS_YES;	
	gQuickFlashTimer = 0;
	SampleData = 0;
	Flag_Register_OK = 0;
	Monitor_Offline_Time = 0;
	Flag_Check_Status = NO_ERROR;
	Flag_Start_Mode = START_POWERON;  //上电重启
	Flag_LinkStatus = START_POWERON;
	Flag_Send_GPRS_Position = 0;
	ucUar1InterrFlag = 0;
	Flag_SendDataAbnormal = NO_ERROR;
	Flag_init = SYSTEM_INIT;
	Flag_TimeAdj = 0;	
	
	for(i=0;i<ECG_COMPARE_TIMES;i++)
	{
		ECG_MAX[i] = STANDARD_VOLTAGE;
		ECG_MIN[i] = STANDARD_VOLTAGE;
		CHGECG_MAX[i] = STANDARD_VOLTAGE;
		CHGECG_MIN[i] = STANDARD_VOLTAGE;
	}
	ECG_COMPARE_COUNT = 0;
	Flag_ADC_ADJ = 0;

	CHGADC_COUNT = 0;
	Last_gPeopleFlag  = 0;
	Flag_PowerOn = 1; 

	Flag_SleepDataBuffer_Save = 0;
	Flag_SleepDataBuffer_Send = 0;
	for(i=0;i<SLEEPDTATABUF;i++)
	{
		for(j=0;j<40;j++)
		   Buffer_SleepData[i][j] = 0;
	}

	Status_ExtSensorIn = EXTSENSOR_ISOUT;    
	Status_ExtSensorOnbed = EXTSENSOR_PEOPLEOFFBED; 
	ExtSensor_OnbedStatus_Count = 0;
	OnbedStatus_CountTimer = 0;
	LastOnbedStatus = 1;
	Flag_SendPresensorStatus = 1;//默认开启压阻状态发送 2019/4/23   BY DYP
    Flag_COMDebug = 1;     //默认串口不打印
}

/**
 * @brief  Configures the different system clocks.
 */
void RCC_Configuration(void)
{
    /* PCLK1 = HCLK/4 */
    //RCC_ConfigPclk1(RCC_HCLK_DIV4);

    /* TIM2 clock enable */
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM2, ENABLE);

    /* GPIOC clock enable */
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
	
	/* Enable GPIO clock */
    RCC_EnableAPB2PeriphClk(USARTy_GPIO_CLK | USART_4G_GPIO_CLK | RCC_APB2_PERIPH_AFIO, ENABLE);
	
    /* Enable USARTy and USART_4G Clock */
    USARTy_APBxClkCmd(USARTy_CLK, ENABLE);
    USART_4G_APBxClkCmd(USART_4G_CLK, ENABLE);

	//ADC DMA
		/* Enable peripheral clocks ------------------------------------------------*/
    /* Enable DMA1 and DMA2 clocks */
    RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_DMA1 | RCC_AHB_PERIPH_DMA2, ENABLE);
    /* Enable GPIOC clocks */
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    /* Enable ADC1, ADC2, ADC3 and ADC4 clocks */
    RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_ADC2,ENABLE);
    /* RCC_ADCHCLK_DIV16*/
    ADC_ConfigClk(ADC_CTRL3_CKMOD_AHB,RCC_ADCHCLK_DIV16);

}

/**
 * @brief  Configure the GPIO Pins.
 */
void GPIO_Configuration(void)
{
    GPIO_InitType GPIO_InitStructure;

	//JTAG引脚复用为GPIO
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO, ENABLE);

	GPIO_ConfigPinRemap(GPIO_RMP_SW_JTAG_SW_ENABLE, ENABLE);		// 重新设为GPIO

    /* Configure USARTy Rx as input floating */
    GPIO_InitStructure.Pin       = USARTy_RxPin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitPeripheral(USARTy_GPIO, &GPIO_InitStructure);

    /* Configure USART_4G Rx as input floating */
    GPIO_InitStructure.Pin = USART_4G_RxPin;
    GPIO_InitPeripheral(USART_4G_GPIO, &GPIO_InitStructure);

    /* Configure USARTy Tx as alternate function push-pull */
    GPIO_InitStructure.Pin        = USARTy_TxPin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitPeripheral(USARTy_GPIO, &GPIO_InitStructure);

    /* Configure USART_4G Tx as alternate function push-pull */
    GPIO_InitStructure.Pin = USART_4G_TxPin;
    GPIO_InitPeripheral(USART_4G_GPIO, &GPIO_InitStructure);
	
	//ADC
    /* Configure PA1 PA2 as analog inputs */
    GPIO_InitStructure.Pin       = GPIO_PIN_4 | GPIO_PIN_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitPeripheral(GPIOA, &GPIO_InitStructure);

//	//PB3 拉低电平
//	GPIO_InitStructure.Pin		  = GPIO_PIN_3;
//	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);
	
}

/**
 * @brief  Configure the nested vectored interrupt controller.
 */
void NVIC_Configuration(void)
{
    NVIC_InitType NVIC_InitStructure;
	
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

    /* Enable the TIM2 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel                   = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the USART1 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel            = USARTy_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd         = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* Enable the USART_4G Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel            = USART_4G_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd         = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

	//原项目移植，估计是FLASH的中断
 	//NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);

}

void Timer_Configuration(void){
 /* ---------------------------------------------------------------
    TIM2 Configuration: Output Compare Timing Mode:
    TIM2 counter clock at 6 MHz
    CC1 update rate = TIM2 counter clock / CCR1_Val = 146.48 Hz
    CC2 update rate = TIM2 counter clock / CCR2_Val = 219.7 Hz
    CC3 update rate = TIM2 counter clock / CCR3_Val = 439.4 Hz
    CC4 update rate = TIM2 counter clock / CCR4_Val = 878.9 Hz
    --------------------------------------------------------------- */

    /* Compute the prescaler value */
//    PrescalerValue = (uint16_t)(SystemCoreClock / 12000000) - 1;
	PrescalerValue = (uint16_t)(SystemCoreClock / 12900000) - 1;  //test code!!!

    /* Time base configuration */
    TIM_TimeBaseStructure.Period    = 65535;
    TIM_TimeBaseStructure.Prescaler = 0;
    TIM_TimeBaseStructure.ClkDiv    = 0;
    TIM_TimeBaseStructure.CntMode   = TIM_CNT_MODE_UP;

    TIM_InitTimeBase(TIM2, &TIM_TimeBaseStructure);

    /* Prescaler configuration */
    TIM_ConfigPrescaler(TIM2, PrescalerValue, TIM_PSC_RELOAD_MODE_IMMEDIATE);

    /* Output Compare Timing Mode configuration: Channel1 */

    TIM_OCInitStructure.OcMode      = TIM_OCMODE_TIMING;
    TIM_OCInitStructure.OutputState = TIM_OUTPUT_STATE_ENABLE;
    TIM_OCInitStructure.Pulse       = MY_CCR_Val;
    TIM_OCInitStructure.OcPolarity  = TIM_OC_POLARITY_HIGH;

    TIM_InitOc1(TIM2, &TIM_OCInitStructure);

    TIM_ConfigOc1Preload(TIM2, TIM_OC_PRE_LOAD_DISABLE);

    /* TIM IT enable */
    TIM_ConfigInt(TIM2, TIM_INT_CC1, ENABLE);

    /* TIM2 enable counter */
    TIM_Enable(TIM2, ENABLE);
}

void USART_Configuration(void){

	/* USARTy and USARTz configuration ------------------------------------------------------*/
	USART_InitStructure.BaudRate			= 115200;
	USART_InitStructure.WordLength			= USART_WL_8B;
	USART_InitStructure.StopBits			= USART_STPB_1;
	USART_InitStructure.Parity				= USART_PE_NO;
	USART_InitStructure.HardwareFlowControl = USART_HFCTRL_NONE;
	USART_InitStructure.Mode				= USART_MODE_RX | USART_MODE_TX;

	/* Configure USARTy and USARTz */
	USART_Init(USARTy, &USART_InitStructure);
	USART_Init(USART_4G, &USART_InitStructure);

	/* Enable USARTy Receive interrupts */
	USART_ConfigInt(USARTy, USART_INT_RXDNE, ENABLE);
	
	/* Enable USART 4G Receive interrupts */
	USART_ConfigInt(USART_4G, USART_INT_RXDNE, ENABLE);

	/* Enable the USARTy and USARTz */
	USART_Enable(USARTy, ENABLE);
	USART_Enable(USART_4G, ENABLE); 

}

void DMA_ADC_Configuration(void){
    /* DMA1 channel1 configuration ----------------------------------------------*/
    DMA_DeInit(DMA1_CH8);
    DMA_InitStructure.PeriphAddr     = (uint32_t)&ADC2->DAT;
    DMA_InitStructure.MemAddr        = (uint32_t)ADC_ConvertedValue;
    DMA_InitStructure.Direction      = DMA_DIR_PERIPH_SRC;
    DMA_InitStructure.BufSize        = 2;
    DMA_InitStructure.PeriphInc      = DMA_PERIPH_INC_DISABLE;
    DMA_InitStructure.DMA_MemoryInc  = DMA_MEM_INC_ENABLE;
    DMA_InitStructure.PeriphDataSize = DMA_PERIPH_DATA_SIZE_WORD;
    DMA_InitStructure.MemDataSize    = DMA_MemoryDataSize_Word;
    DMA_InitStructure.CircularMode   = DMA_MODE_CIRCULAR;
    DMA_InitStructure.Priority       = DMA_PRIORITY_HIGH;
    DMA_InitStructure.Mem2Mem        = DMA_M2M_DISABLE;
    DMA_Init(DMA1_CH8, &DMA_InitStructure);
    /* Enable DMA1 Channel1 */
    DMA_EnableChannel(DMA1_CH8, ENABLE);

    /* ADC2 configuration ------------------------------------------------------*/
    ADC_InitStructure.WorkMode       = ADC_WORKMODE_REG_SIMULT;
    ADC_InitStructure.MultiChEn      = ENABLE;
    ADC_InitStructure.ContinueConvEn = ENABLE;
    ADC_InitStructure.ExtTrigSelect  = ADC_EXT_TRIGCONV_NONE;
    ADC_InitStructure.DatAlign       = ADC_DAT_ALIGN_R;
    ADC_InitStructure.ChsNumber      = 2;
    ADC_Init(ADC2, &ADC_InitStructure);
    /* ADC2 regular channels configuration */
    ADC_ConfigRegularChannel(ADC2, ADC2_Channel_01_PA4, 1, ADC_SAMP_TIME_239CYCLES5);
    ADC_ConfigRegularChannel(ADC2, ADC2_Channel_02_PA5, 2, ADC_SAMP_TIME_239CYCLES5);
    /* Enable ADC2 external trigger conversion */
    ADC_EnableExternalTrigConv(ADC2, ENABLE);

//    /* Enable Vrefint channel17 */
    ADC_EnableTempSensorVrefint(ENABLE);

    /* Enable ADC2 */
    ADC_Enable(ADC2, ENABLE);
		ADC_EnableDMA(ADC2, ENABLE);
    /*Check ADC Ready*/
    while(ADC_GetFlagStatusNew(ADC2,ADC_FLAG_RDY) == RESET)
        ;
    /* Start ADC2 calibration */
    ADC_StartCalibration(ADC2);
    /* Check the end of ADC2 calibration */
    while (ADC_GetCalibrationStatus(ADC2))
        ;

		  ADC_EnableSoftwareStartConv(ADC2, ENABLE);

    /* Test on DMA1 channel1 transfer complete flag */
    while (!DMA_GetFlagStatus(DMA1_FLAG_TC8, DMA1))
        ;
    /* Clear DMA1 channel1 transfer complete flag */
    DMA_ClearFlag(DMA1_FLAG_TC8, DMA1);
}

/****************************************************************************
*	函 数 名: COM1ProcessCmd
*	功能说明: 串口1参数设置处理
*	形    参：无
*	返 回 值: 
* 说    明：
*****************************************************************************/
void COM1ProcessCmd(void)
{
	uint16_t i = 0, j = 0;
	uint8_t Res = 0;
	uint8_t STATUS[3];
	char D_MAC[20] = {0};
	uint8_t order_data_len = 0;
    uint8_t order_data[UARTBUF_MAX_LEN];
    uint8_t dealorder = 0;
    uint32_t mcuid[3];
    uint8_t len;
    uint8_t send_data[10];
	uint16_t flashsize = 0;
    
	if(0 < USART1_RX_LEN)
	{
        for(i=0;i<USART1_RX_LEN;i++)
        {
            if(ucUar1tbuf[i] == CMD_START)
            {
                delay_ms(10);
                order_data_len = (ucUar1tbuf[i+2]&0x7F)+5;
                //printf("串口指令长度:%d\r\n",order_data_len);
                if((ucUar1tbuf[i+order_data_len-1] == CMD_LF2 )&&(ucUar1tbuf[i+order_data_len-2] == CMD_LF1 ))  //a complete command
                {
                    for(j=0;j<order_data_len;j++)
                    {
                        order_data[j] = ucUar1tbuf[i+j];
                    }
                    if(USART1_RX_LEN == (i+order_data_len))
                    {
                        memset(ucUar1tbuf,0,UARTBUF_MAX_LEN);
                        USART1_RX_LEN = 0;
                    }
                    else
                    {
                        memset(ucUar1tbuf,0,i+order_data_len);
                        for(j=0;j<USART1_RX_LEN-order_data_len-i;j++)
                        {
                            ucUar1tbuf[j] = ucUar1tbuf[i+order_data_len+j];
                            ucUar1tbuf[i+order_data_len+j] = 0;
                        }
                        USART1_RX_LEN = USART1_RX_LEN - order_data_len - i;
                    }
                    dealorder=1;  //parse the order
                }
                else  //not a complete command
                {
                    if(i>0)
                    {
                        memset(ucUar1tbuf,0,i);
                        for(j=0;j<USART1_RX_LEN-i;j++)
                        {
                            ucUar1tbuf[j] = ucUar1tbuf[i+j];
                            ucUar1tbuf[i+j] = 0;
                        }
                        USART1_RX_LEN = USART1_RX_LEN  - i;
                    }
                }
                
            }
        }
        if(dealorder == 1)
        {
    //		for(i=0;i<order_data_len;i++)
    //		{
    //			printf("%02x ",order_data[i]);
    //		}
            dealorder = 0;
            switch( order_data[3])
            {
            case CMD_DEBUG:     //打印串口日志
                if(order_data[4] == 0x01 )
                {
                        Flag_COMDebug = 1;
                        flashsize = (uint16_t)( *(__IO uint32_t*)MCUFLASHSIZE_ADDRESS&0x0000FFFF);  //芯片flash大小
                        for(i=0;i<3;i++)
                        {
                            mcuid[i] = *(__IO uint32_t*)(MCUID_ADDRESS+i*4);  //内部芯片编号
                        }
                        printf("\r\n******************************************************************************\r\n"); 								
                        printf("	MCU:N32G452CCL7\r\n");
                        printf("	MCU Flash:%d kB\r\n",flashsize);
                        printf("	MCU RAM:48 kB\r\n");   
                        printf("	MCU ID:%08x%08x%08x \r\n",mcuid[0],mcuid[1],mcuid[2]); 
                        printf("	HardVer:V%d.%d.%d\r\n",HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER);
                        printf("	SoftVer:V%d.%d.%d\r\n",SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER);
                        printf("	Soft release time:%s \r\n",RELEASE_TIME);
                        printf("	Soft build time is:%s %s\r\n", __DATE__, __TIME__);
                        printf("	MAC:%s \r\n",Device_Info.MAC_ID);
                        printf("	CMEI:%s \r\n",Device_Info.CMCC_CMEI);
                        printf("	SN:%s \r\n",Device_Info.CMCC_SN);
                        printf("	manuDate:%s \r\n",Device_Info.manuDate);
                        //printf("	Router name:%s,PWD:%s\r\n",Router_Info.SSID,Router_Info.password);
                        printf("******************************************************************************\r\n");
                }
                else
                        Flag_COMDebug = 0;	 
            break;

            //24 01 0e 22 41 45 38 44 34 38 35 35 38 36 37 35 ff 69 42
            case CMD_SETMAC:      //设置设备MAC
                Device_Info.MAC_LEN = order_data_len-7;
                for(i=0;i<Device_Info.MAC_LEN;i++)
                {
                    Device_Info.MAC_ID[i] = order_data[4+i];
                }
                Device_Info.MAC_ID[Device_Info.MAC_LEN] = 0x00;            
    //			Res = SaveMACToFlash();//写入生产日期后一起保存
    //			if(Res == 0x00)
    //			{
    //				COMRetuenOneByte(DEBUG_UART,CMD_SETMAC,0x00);
    //			}
    //			else   
    //			 {					 
                    Flag_Check_Status &= ~ERROR_N0_MAC;
                    COMRetuenOneByte(USARTy, CMD_SETMAC, 0x01);
    //			 }
                

            break;			 	 
                
            case CMD_READMAC:   //读取设备MAC
                SendDeviceMacToUart(USARTy);
                        
            break;
            
            case CMD_SETCMEI:
                len = order_data_len-7;
                for(i=0;i<len;i++)
                {
                    Device_Info.CMCC_CMEI[i] = order_data[4+i];
                }
                Device_Info.CMCC_CMEI[len] = 0x00;
                
    //			Res = SaveMACToFlash();
    //			if(Res == 0x00)
    //			{
    //				COMRetuenOneByte(DEBUG_UART,CMD_SETCMEI,0x00);
    //			}
    //			else   
    //			 {					 
                    Flag_Check_Status &= ~ERROR_N0_MAC;
                    COMRetuenOneByte(USARTy, CMD_SETCMEI, 0x01);
    //			 }
            
            break;
            
            case CMD_SETMANUDATE:  //设置设备生产日期 ,张炜20230827增加
                len = order_data_len-7;
                for(i=0;i<len;i++) 
                {
                    Device_Info.manuDate[i] = order_data[4+i];
                }
                Device_Info.manuDate[len] = 0x00;            
                Res = SaveMACToFlash();
                if(Res == 0x00)
                {
                    COMRetuenOneByte(USARTy, CMD_SETMANUDATE, 0x00);
                }
                else   
                {
                    Flag_Check_Status &= ~ERROR_N0_MAC;
                    COMRetuenOneByte(USARTy, CMD_SETMANUDATE, 0x01);
                }
            break;
            
            case CMD_SETSN:      //设置设备SN,20230916增加
                len = order_data_len-7;
                for(i=0;i<len;i++)
                {
                    Device_Info.CMCC_SN[i] = order_data[4+i];
                }
                Device_Info.CMCC_SN[len] = 0x00;            				 
                Flag_Check_Status &= ~ERROR_N0_MAC;
                COMRetuenOneByte(USARTy, CMD_SETSN, 0x01);
            break;	
                
            case CMD_READCMEI:
                SendCMEIToUart(USARTy);
            break;

            
            case CMD_READVER:  //读取设备版本号
                //sprintf(SoftVer,"HardVer:V%d.%d.%d\r\nSoftVer:V%d.%d.%d\r\nSoft release time:%s\r\n",HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER,
                //                SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER,RELEASE_TIME);
                SendDeviceVerInfoToUart(USARTy, SoftVer);
            break;
            
            case CMD_DELFLASHDATA:          //删除flash数据

            break;

            
            case CMD_REQMOUDLE_INFO:   //查询设备状态
                if(order_data[4] == MOUDLE_STATUS_RUNTIME )   //设备总运行时间
                {
                    //printf("\r\nTotal run time is:%d day %d Hour %d Min %d Sec!\r\n",TimerSim.Day,TimerSim.Hour,TimerSim.Min,TimerSim.Sec);
            
                }
                if(order_data[4] == MOUDLE_STATUS_ROUTERSSID )   //wifi模块连接的路由器名称
                {
    //				if(WIFI_Req_STASSID()==WIFI_SUCCESS)
                    {							 

                        //printf("Connected the WiFi:%s\r\n",RouterName_InWIFI);

                    }					
                }
                if(order_data[4] == MOUDLE_STATUS_CONNECTIP )   //wifi模块连接的服务器
                {
                    //printf("IP2:%s,Port2:%s",IP2,Port2);
                }
                if(order_data[4] == MOUDLE_DEL_ROUTERNAME )   //删除设备内保存的WiFi账号信息
                {
                    STMFLASH_SectorErase(FLASH_WIFIInfoAddress);  //删除WiFi信息	
                    printf("Delete WiFi info\r\n");
                    NVIC_SystemReset();
                }
                if((order_data[4] == MOUDLE_DEL_MAC )||(order_data[4] == MOUDLE_DEL_CMEI))   //删除设备内保存的mac信息或cmei信息
                {
                    STMFlashErase(FLASH_EquipmentInfoAddress,1);  //删除MAC信息
                    STMFLASH_SectorErase(FLASH_WIFIInfoAddress);  //删除WiFi信息	
                    printf("Delete MAC、CMEI、SN、DATE、WIFI\r\n");
                    NVIC_SystemReset();
                }

            break;

            default :
                
            break;
            }
        }
	}
	 
	if((ucUar2InterrFlag&0x8000)!=0)
	{
		ucUar2InterrFlag = 0;
		if(Flag_COMDebug == 1)
			printf("receive ucUar2InterrFlag!\r\n");
		switch( ucUar2tbuf[0])
		{
			case UART_SOS_NETWORK: 
				break;
			
			case UART_SOS_SLEEP:  //SOS已经收到休眠帧
				COMSynSOS_SleepStatus_end(USART1);
				//可以正式进入休眠
				GPIO_WriteBit(LED_GPIO_PORT,GPIO_PIN_2,1);
				DeviceIntoSleep(); 
				break;
			
			case UART_SOS_EVENT:  //收到SOS事件
				SOS_Connect_Time = 0;
				SOSConnectFlag = 1;
				if((ucUar2tbuf[1] == 0)||(ucUar2tbuf[1] == 1))
				{
					for (i = 0; i < 6; i++) {
						sprintf(SlaveSOS_MAC + i * 2, "%02X", ucUar2tbuf[3+i]);  
					}
					if(Flag_COMDebug == 1)
						printf(" SOS device id:%s\r\n",SlaveSOS_MAC);
					//断网情况下需要重新联网
					if(PowerBatteryFlag == 1)   //电池情况下
					{
						Flag_PowerOn = 1;
						Battery_CntTime = 0;
						Flag_init = MAC_INIT_OK;//模组开机 
						Flag_Init_Step = 1;
						LuatPowerOnWay = 2;    //电池情况下，等联网完再上报，上报完关机
						if(Flag_COMDebug == 1)
							printf(" receive SOS event,power on first,LuatPowerOnWay = 2\r\n");
					}
					//需增加一些反复发送的措施
					if(PowerBatteryFlag == 0)   //供电情况下
					{
						//需判断日期是否正确  
						if((Timebuf[0]>22) && (Timebuf[1]<13) && (Timebuf[2]<32))  //日期正确
						{
							if(SOS_Report_Time >= 3)  //3秒内不重复发送SOS信息
							{
								SOS_Report_Time = 0;
								if(iSuke_MQTT_SOS(ucUar2tbuf[1]))
								{
									COMRetuenSOS_event(USART1,1);
								}
								else
								{
									LuatPowerOnWay = 3;  //未发送成功，再发
									COMRetuenSOS_event(USART1,0);
									if(Flag_COMDebug == 1)
										printf(" send fail,send again,LuatPowerOnWay = 3\r\n");
								}
							}
						}
						else
						{
							LuatPowerOnWay = 3;  //尚未联网，等联网完再上报
							if(Flag_COMDebug == 1)
								printf(" receive SOS event,networking first,LuatPowerOnWay = 3\r\n");
						}
							
					}
				}
				//服务器应答处理还需做，包括超时等
				break;

			case UART_SOS_POWER:  //SOS上报供电方式
				//记录供电方式，电池供电时需要切换
				//用作心跳
				SOS_Connect_Time = 0;
				SOSConnectFlag = 1;
				if(ucUar2tbuf[2] <= 100)  //电量
					SOS_Battery = ucUar2tbuf[2];
				//直接回显应答
				COMRetuenSOS_POWER(USART1,ucUar2tbuf[1],ucUar2tbuf[2]);
				
				if(LuatPowerOnWay != 0)   //SOS事件尚未处理完全， 先不处理供电问题
				{
					if(Flag_COMDebug == 1)
						printf(" SOS event donot deal done!\r\n");
					break;
				}
				
				if(ucUar2tbuf[1] == 0) 				   //插电
				{
					SleepData_SendTime = CGATTime_3;   //用插电时3s 1发
					if(PowerBatteryFlag == 1)
					{
						Flag_PowerOn = 1;
						Battery_CntTime = 0;
						Flag_init = MAC_INIT_OK;//模组开机 
						Flag_Init_Step = 1;
					}
					PowerBatteryFlag = 0; 
					if(Flag_COMDebug == 1)
						printf(" use electricity \r\n");
				}
				else if(ucUar2tbuf[1] == 1) 		   //电池
				{
					SleepData_SendTime = CGATTime_10;  //用电池时10s 1发
					if(PowerBatteryFlag == 0)  	    		   //避免反复调用
					{
						if((Timebuf[0]<23) || (Timebuf[1]>12) || (Timebuf[2]>31))  //日期错误
						{
							if(Flag_COMDebug == 1)
								printf(" date error, timing first \r\n");
							break;
						}
						else  //日期正确
						{
							PowerBatteryDeal();
						}
					}
					if(Flag_COMDebug == 1)
						printf(" use battery \r\n");
					PowerBatteryFlag = 1;
				}
				
				break;	
				
			case UART_SOS_10E_STATUS:  //1.0E在床数据
//				COMSynSOS_test(USART1);  //test code
				STATUS[0] = ucUar2tbuf[1];
				for (i = 0; i < 6; i++) {
					sprintf(D_MAC + i * 2, "%02X", ucUar2tbuf[2+i]);  
				}
				if(Flag_PowerOn == 0)
					Slave_Manage_PutIn(D_MAC,STATUS,Device_Onbed);
				
				break;
			
			case UART_SOS_10E_REAL:    //1.0E实时数据
//				COMSynSOS_test(USART1); //test code
				STATUS[0] = ucUar2tbuf[1];
				STATUS[1] = ucUar2tbuf[2];
				STATUS[2] = ucUar2tbuf[3];
				for (i = 0; i < 6; i++) {
					sprintf(D_MAC + i * 2, "%02X", ucUar2tbuf[4+i]);  
				}  
				if(Flag_PowerOn == 0)
					Slave_Manage_PutIn(D_MAC,STATUS,Device_Real);
				break;
				
			case UART_SOS_STATUS:      //SOS上报在线情况
				for (i = 0; i < 6; i++) {
					sprintf(D_MAC + i * 2, "%02X", ucUar2tbuf[3+i]);  
				}
				if(Flag_PowerOn == 0)
					Slave_Manage_PutIn(D_MAC,STATUS,Device_SOS);
				break;
		}
	}
}


/**
 * @brief  Compares two buffers.
 * @param  pBuffer1, pBuffer2: buffers to be compared.
 * @param BufferLength buffer's length
 * @return PASSED: pBuffer1 identical to pBuffer2
 *         FAILED: pBuffer1 differs from pBuffer2
 */
TestStatus Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength)
{
    while (BufferLength--)
    {
        if (*pBuffer1 != *pBuffer2)
        {
            return FAILED;
        }

        pBuffer1++;
        pBuffer2++;
    }

    return PASSED;
}

/* retarget the C library printf function to the USART */
int fputc(int ch, FILE* f)
{
    USART_SendData(USART1, (uint8_t)ch);
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXDE) == RESET)
        ;

    return (ch);
}


#ifdef USE_FULL_ASSERT

/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param file pointer to the source file name
 * @param line assert_param error line source number
 */
void assert_failed(const uint8_t* expr, const uint8_t* file, uint32_t line)
{
    /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

    while (1)
    {
    }
}

#endif

/**
 * @}
 */

/**
 * @}
 */
