/******************************************************************************
 * @file     STMflash.h
 * @brief   存储程序
 * @version  V1.1
 * @date     2023
 * @note
 * Copyright (C)  
 *
 * @par     STM32 内部FLASH数据存储   张炜 2023
*******************************************************************************/
#ifndef __STMFLASH_H_
#define __STMFLASH_H_

#include "n32g45x.h"
#include "Parameter.h"


/* Private define ------------------------------------------------------------*/
/* STM32大容量产品每页大小2KByte，中、小容量产品每页大小1KByte */
#if defined (STM32F10X_HD) || defined (STM32F10X_HD_VL) || defined (STM32F10X_CL) || defined (STM32F10X_XL)
  #define FLASH_PAGE_SIZE    ((uint16_t)0x800)	//2048
#else
  #define FLASH_PAGE_SIZE    ((uint16_t)0x400)	//1024
#endif

#define  FLASH_EquipmentInfoAddress       ((uint32_t)0x08032000)     //设备信息保存位置，设备MAC，CMEI
#define  FLASH_SOFTREBOOTAddress            ((uint32_t)0x08032800)    //WIFI模块连接的路由器名称和密码
#define  FLASH_ServerInfoAddress          ((uint32_t)0x08033000)     //保存服务器IP、服务器设置信息等  没用上
#define  FLASH_VerifyInfoAddress          ((uint32_t)0x08033800)    //设备上线过的标志位
#define  FLASH_AndLinkInfoAddress         ((uint32_t)0x08034000)     //保存移动Andlink协议设备连接信息
//-----------------------------------------------------------------------------------

typedef enum  
{   
  FLASH_FAILURE = 0,  
  FLASH_SUCCESS,  
} flash_status_t;  

void STMFLASH_BufferWrite(uint32_t *pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite);
void STMFLASH_BufferRead(uint8_t *pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead);
void STMFLASH_SectorErase(uint32_t SectorAddr);

uint32_t STMFlashWrite(uint32_t addr, uint8_t *buffer, uint32_t length);
uint32_t STMFlashRead(uint32_t addr, uint8_t *buffer, uint32_t length)  ;
flash_status_t STMFlashErase(uint32_t addr, uint8_t count)  ;
char ReadUpFlagFromFlash(void);
char SaveUpFlagToFlash(void);
char ReadSoftRebootFlagFromFlash(SOFT_REBOOT_INFO_T *info);
char SaveSoftRebootFlagToFlash(void);
char ClearSoftRebootFlagToFlash(void);
#endif

