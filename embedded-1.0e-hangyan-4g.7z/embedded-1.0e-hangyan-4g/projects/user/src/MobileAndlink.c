/******************************************************************************
 * @file     MobileAndlink.h
 * @brief   移动网关Ank-Link协议通信
 * @version  v1.0
 * @date     2023.05.19
 * @note
 * Copyright (C)  张炜 2023
 *
 * @par      
 *    V1.0    使用ESP8266 WiFi，
 *        协议MQTT ，Json， 移动And-link
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "MobileAndlink.h"
#include "m26.h"
#include "Timerstamp.h"
#include "Delay.h"
#include "STMFlash.h"
#include "Parameter.h"
#include "USART.h"
#include "coap_client.h"
#include "cJSON.h"

/*************************************************************************
	联网总体流程

一、移动相关流程（由苏仁服务器代为转发）http
1.配置拉取接口
2.注册上报接口
3.心跳上报接口

二、内部相关流程（直接发到苏仁服务器）
1.上电请求http
2.遗嘱、订阅、MBOOT等mqtt

三、常规时段
1.实时帧、校时帧等（内部）mqtt
2.心跳帧（移动）http
*************************************************************************/

//移动相关流程的定义
DM_fCONFIG fieldConfig_Auto;   //配置拉取阶段Json 自注册
DM_fCONFIG fieldConfig_Heart;  //配置拉取阶段Json 心跳
DM_rCONFIG ruleConfig;

//以下为MQTT连接相关定义
char devPubTopic[50] ;
char devPubTopic1[50] ;
Date RealTime2Data;
uint64_t TimeStamp = 0;
char  poststr[1024] = {0};
char  json_data[BufMAX] = {0};

Router_Para Router_Info;
MQTT_Para MQTT_Link_Info;

extern cJSON *format_to_json(char *str);

/****************************************************************************
*	函 数 名: HTTP_PostPkt
*	功能说明: 设置post包
*	形    参：无
*	返 回 值: 1 获取成功，0 失败
*   说    明：
*****************************************************************************/
void HTTP_PostPkt(char *postbuf,char *url,char *host,char *urlhead,char *sendstr)
{
    char str[50]={0};
    strcat(postbuf,"POST ");
    strcat(postbuf,url);
    strcat(postbuf," HTTP/1.1\r\n");
    sprintf(str,"Host:%s\r\n",host);   
    strcat(postbuf,str);
    strcat(postbuf,urlhead);
    sprintf(str,"Content-Length:%d\r\n",strlen(sendstr));
    strcat(postbuf,str);
    strcat(postbuf,"Connection: Keep-Alive\r\n\r\n");
    strcat(postbuf,sendstr);
    strcat(postbuf,"\r\n");
}


//移动流程一、配置拉取接口：自注册
char Dm_getConfig_Auto(void)
{
	cJSON *postdata;
    char *send_data= NULL;
	
	char enbuff[200]={0},result = 0; 
//	char  poststr[500] = {0};
	send_data=malloc(500);
	sprintf(enbuff,"isuke||CC08-G||A100008973||4.0.1||4.0.1||I||TY000015||%s||***||***||***||***",SIMCard_IMEI);
	postdata  = cJSON_CreateObject();
	cJSON_AddStringToObject(postdata,"endpoint",enbuff);
	cJSON_AddStringToObject(postdata,"configType","autoRegist");
	send_data = cJSON_PrintUnformatted(postdata);
	memset(poststr,0,1024);
	HTTP_PostPkt(poststr,URL_GETGWADDRESS1,URL_GETAHOST_IP,URL_HEADER,send_data); // 打包http post数据
	result = GPRS_Send_Data(poststr,strlen(poststr));
	if(Flag_COMDebug == 1)
	{
		printf("\r\n配置拉取接口 自注册:%s\r\n", poststr);
		printf("发送结果:%d\r\n", result);
	}
	memset(&fieldConfig_Auto,0,sizeof(fieldConfig_Auto));
	cJSON_Delete(postdata);
	free(send_data);
	return result;
}

//移动流程一、配置拉取接口：心跳
char Dm_getConfig_Heart(void)
{
	cJSON *postdata;
    char *send_data= NULL;
	
	char enbuff[200]={0},result = 0; 
//	char  poststr[500] = {0};
//	send_data=malloc(500);
	sprintf(enbuff,"isuke||CC08-G||A100008973||4.0.1||4.0.1||I||TY000015||%s||***||***||***||***",SIMCard_IMEI);
	postdata  = cJSON_CreateObject();
	cJSON_AddStringToObject(postdata,"endpoint",enbuff);
	cJSON_AddStringToObject(postdata,"configType","keepAlive");
	send_data = cJSON_PrintUnformatted(postdata);
	memset(poststr,0,1024);
	HTTP_PostPkt(poststr,URL_GETGWADDRESS1,URL_GETAHOST_IP,URL_HEADER,send_data); // 打包http post数据
	result = GPRS_Send_Data(poststr,strlen(poststr));
	if(Flag_COMDebug == 1)
	{
		printf("\r\n配置拉取接口 心跳:%s\r\n", poststr);
		printf("发送结果:%d\r\n", result);
	}
	memset(&fieldConfig_Heart,0,sizeof(fieldConfig_Heart));
	cJSON_Delete(postdata);
	free(send_data);
	return result;
}

//移动流程二、设备注册上报接口
/*	imei1、ip、apiVersion、appKey、platform、createTime、mac、softwareVer、netType、brand、model
	*/
char Dm_RegistReport(void)
{
    char *send_data2= NULL;
	
	char enbuff[200]={0},result = 0; 
	char  poststr[1000] = {0};
	cJSON *postdata2,*item;
	send_data2=malloc(500);
	sprintf(enbuff,"isuke||CC08-G||A100008973||4.0.1||4.0.1||I||TY000015||%s||***||***||***||***",SIMCard_IMEI);

	postdata2  = cJSON_CreateObject();
	cJSON_AddStringToObject(postdata2,"endpoint",enbuff);
	cJSON_AddItemToObject(postdata2,"deviceInfo",item = cJSON_CreateObject());
	//采集字段需要AES加密
	cJSON_AddStringToObject(item,"imei1",SIMCard_IMEI);
	cJSON_AddStringToObject(item,"ip",Device_ip);
	cJSON_AddStringToObject(item,"apiVersion","4.0.1");
	cJSON_AddStringToObject(item,"appKey","A100008973");
	cJSON_AddStringToObject(item,"platform","I");
	cJSON_AddStringToObject(item,"brand",DM_brand);
	cJSON_AddStringToObject(item,"model",DM_model);
	cJSON_AddStringToObject(item,"ipType","1");
	if(fieldConfig_Auto.f_imsi == true)
		cJSON_AddStringToObject(item,"imsi",SIMCard_IMSI);
	if(fieldConfig_Auto.f_mac == true)
		cJSON_AddStringToObject(item,"mac",MAC_IDstring);
	if(fieldConfig_Auto.f_sysVersion == true)
		cJSON_AddStringToObject(item,"sysVersion",DM_sysVersion);
	if(fieldConfig_Auto.f_softwareVer == true)
		cJSON_AddStringToObject(item,"softwareVer",DM_softwareVer);
	if(fieldConfig_Auto.f_softwareName == true)
		cJSON_AddStringToObject(item,"softwareName",DM_softwareName);
	if(fieldConfig_Auto.f_rom == true)
		cJSON_AddStringToObject(item,"rom","512K");
	if(fieldConfig_Auto.f_ram == true)
		cJSON_AddStringToObject(item,"ram","144K");
	if(fieldConfig_Auto.f_cpu == true)
		cJSON_AddStringToObject(item,"cpu","N32G452CCL7");
	if(fieldConfig_Auto.f_volte == true)
		cJSON_AddStringToObject(item,"volte","-1");
	if(fieldConfig_Auto.f_netType == true)
		cJSON_AddStringToObject(item,"netType","4G");
	if(fieldConfig_Auto.f_phoneNumber == true)
		cJSON_AddStringToObject(item,"phoneNumber","station");
	if(fieldConfig_Auto.f_routerMac == true)
		cJSON_AddStringToObject(item,"routerMac","***");
	if(fieldConfig_Auto.f_bluetoothMac == true)
		cJSON_AddStringToObject(item,"bluetoothMac","***");
	if(fieldConfig_Auto.f_sn == true)
		cJSON_AddStringToObject(item,"sn", Device_Info.CMCC_SN);
	if(fieldConfig_Auto.f_gpu == true)
		cJSON_AddStringToObject(item,"gpu","***");
	if(fieldConfig_Auto.f_board == true)
		cJSON_AddStringToObject(item,"board",DM_board);
	if(fieldConfig_Auto.f_resolution == true)
		cJSON_AddStringToObject(item,"resolution","***");
	if(fieldConfig_Auto.f_batteryCapacity == true)
		cJSON_AddStringToObject(item,"batteryCapacity","***");
	if(fieldConfig_Auto.f_screenSize == true)
		cJSON_AddStringToObject(item,"screenSize","***");
	if(fieldConfig_Auto.f_networkStatus == true)
		cJSON_AddStringToObject(item,"networkStatus","1");
	if(fieldConfig_Auto.f_wearingStatus == true)
		cJSON_AddStringToObject(item,"wearingStatus","-1");
	if(fieldConfig_Auto.f_appInfo == true)
		cJSON_AddStringToObject(item,"appInfo",DM_appInfo);
	if(fieldConfig_Auto.f_imsi2 == true)
		cJSON_AddStringToObject(item,"imsi2","***");
	send_data2 = cJSON_PrintUnformatted(postdata2);
	HTTP_PostPkt(poststr,URL_REGISTADDRESS2,URL_GETAHOST_IP,URL_HEADER,send_data2);
	result = GPRS_Send_Data(poststr,strlen(poststr));
	if(Flag_COMDebug == 1)
	{
		printf("设备注册上报接口 poststr:%s", poststr);
		printf("发送结果:%d\r\n", result);
		printf("mac:%d batteryCapacity:%d\r\n",fieldConfig_Auto.f_mac,fieldConfig_Auto.f_batteryCapacity);
	}
	cJSON_Delete(postdata2);
//	cJSON_Delete(item);
	free(send_data2);
	return result;
}

//移动流程三、设备心跳上报接口
char Dm_HeartReport(void)
{
	char *send_data2= NULL;
	
	char enbuff[200]={0},result = 0; 
	char  poststr[1000] = {0};
	cJSON *postdata2,*item;
	send_data2=malloc(500);
	sprintf(enbuff,"isuke||CC08-G||A100008973||4.0.1||4.0.1||I||TY000015||%s||***||***||***||***",SIMCard_IMEI);

	postdata2  = cJSON_CreateObject();
	cJSON_AddStringToObject(postdata2,"endpoint",enbuff);
	cJSON_AddItemToObject(postdata2,"deviceInfo",item = cJSON_CreateObject());
	//采集字段需要AES加密
	cJSON_AddStringToObject(item,"imei1",SIMCard_IMEI);
	cJSON_AddStringToObject(item,"ip",Device_ip);
	cJSON_AddStringToObject(item,"apiVersion","4.0.1");
	cJSON_AddStringToObject(item,"appKey","A100008973");
	cJSON_AddStringToObject(item,"platform","I");
	cJSON_AddStringToObject(item,"brand",DM_brand);
	cJSON_AddStringToObject(item,"model",DM_model);
	cJSON_AddStringToObject(item,"ipType","1");
	if(fieldConfig_Heart.f_imsi == true)
		cJSON_AddStringToObject(item,"imsi",SIMCard_IMSI);
	if(fieldConfig_Heart.f_mac == true)
		cJSON_AddStringToObject(item,"mac",MAC_IDstring);
	if(fieldConfig_Heart.f_sysVersion == true)
		cJSON_AddStringToObject(item,"sysVersion",DM_sysVersion);
	if(fieldConfig_Heart.f_softwareVer == true)
		cJSON_AddStringToObject(item,"softwareVer",DM_softwareVer);
	if(fieldConfig_Heart.f_softwareName == true)
		cJSON_AddStringToObject(item,"softwareName",DM_softwareName);
	if(fieldConfig_Heart.f_rom == true)
		cJSON_AddStringToObject(item,"rom","512K");
	if(fieldConfig_Heart.f_ram == true)
		cJSON_AddStringToObject(item,"ram","144K");
	if(fieldConfig_Heart.f_cpu == true)
		cJSON_AddStringToObject(item,"cpu","N32G452CCL7");
	if(fieldConfig_Heart.f_volte == true)
		cJSON_AddStringToObject(item,"volte","-1");
	if(fieldConfig_Heart.f_netType == true)
		cJSON_AddStringToObject(item,"netType","4G");
	if(fieldConfig_Heart.f_phoneNumber == true)
		cJSON_AddStringToObject(item,"phoneNumber","station");
	if(fieldConfig_Heart.f_routerMac == true)
		cJSON_AddStringToObject(item,"routerMac","***");
	if(fieldConfig_Heart.f_bluetoothMac == true)
		cJSON_AddStringToObject(item,"bluetoothMac","***");
	if(fieldConfig_Heart.f_sn == true)
		cJSON_AddStringToObject(item,"sn", Device_Info.CMCC_SN);
	if(fieldConfig_Heart.f_gpu == true)
		cJSON_AddStringToObject(item,"gpu","***");
	if(fieldConfig_Heart.f_board == true)
		cJSON_AddStringToObject(item,"board",DM_board);
	if(fieldConfig_Heart.f_resolution == true)
		cJSON_AddStringToObject(item,"resolution","***");
	if(fieldConfig_Heart.f_batteryCapacity == true)
		cJSON_AddStringToObject(item,"batteryCapacity","***");
	if(fieldConfig_Heart.f_screenSize == true)
		cJSON_AddStringToObject(item,"screenSize","***");
	if(fieldConfig_Heart.f_networkStatus == true)
		cJSON_AddStringToObject(item,"networkStatus","1");
	if(fieldConfig_Heart.f_wearingStatus == true)
		cJSON_AddStringToObject(item,"wearingStatus","-1");
	if(fieldConfig_Heart.f_appInfo == true)
		cJSON_AddStringToObject(item,"appInfo",DM_appInfo);
	if(fieldConfig_Heart.f_imsi2 == true)
		cJSON_AddStringToObject(item,"imsi2","***");
	send_data2 = cJSON_PrintUnformatted(postdata2);
	HTTP_PostPkt(poststr,URL_HEARTADDRESS3,URL_GETAHOST_IP,URL_HEADER,send_data2);
	result = GPRS_Send_Data(poststr,strlen(poststr));
	if(Flag_COMDebug == 1)
	{
		printf("设备心跳上报接口 poststr:%s", poststr);
		printf("发送结果:%d\r\n", result);
		printf("mac:%d batteryCapacity:%d\r\n",fieldConfig_Heart.f_mac,fieldConfig_Heart.f_batteryCapacity);
	}
	cJSON_Delete(postdata2);
//	cJSON_Delete(item);
	free(send_data2);
	return result;
}

//上电流程
char Power_on_notify(void)
{
	cJSON *postdata;
    char *send_data= NULL;
	char send_id[100]={0},result = 0; 
//	char  poststr[500] = {0};
	
	sprintf(send_id,"CMCC-591217-%s", Device_Info.MAC_ID);
    postdata  = cJSON_CreateObject();
    cJSON_AddStringToObject(postdata,"deviceId",send_id); 
	cJSON_AddStringToObject(postdata,"iccid",SIMCard_ICCID); 
	cJSON_AddStringToObject(postdata,"imei",SIMCard_IMEI);
//    cJSON_AddStringToObject(postdata,"imei",SIMCard_IMEI);	
    send_data = cJSON_PrintUnformatted(postdata);
    
//	ClearUSART3BUF(); 
	#ifdef Demonstrate
    HTTP_PostPkt(poststr,URL_demonstrate_ADDRESS,URL_demonstrate_IP,URL_HEADER,send_data); // 打包http post数据
	#else
	memset(poststr,0,1024);
	HTTP_PostPkt(poststr,URL_DEVICE_PWON_ADDRESS,URL_GETAHOST_IP,URL_HEADER,send_data);
	#endif
	
    result = GPRS_Send_Data(poststr,strlen(poststr));
	if(Flag_COMDebug == 1)
		printf("Power_on_notify poststr:%s", poststr);
	cJSON_Delete(postdata);
	free(send_data);
	return result;
}

//http阶段读取服务器应答
char HttpStageRevRespon(void)
{
	#if 0
	char  *p1,*p2;
	cJSON *server_data, *getvalue;
	char json_data_t[1024] = {0};
	char res = 0;
	
	p1 = strchr(ucUar3tbuf, '{');
    p2 = strrchr(ucUar3tbuf, '}');  
	if( (p1 != NULL)&&(p2 != NULL) )
	{
		memcpy(json_data_t,p1,p2-p1+1);
		if(Flag_COMDebug == 1)
			printf("http json:%s \r\n",json_data_t);  
            
        server_data = cJSON_Parse(json_data_t);  //解析字符串 
		getvalue = cJSON_GetObjectItem(server_data, "rspCode");
		
		if(strstr(getvalue->valuestring,"0000")!=NULL)
		{
			if(Flag_COMDebug == 1)
				printf("终端管理数据上报成功：\r\n");
			res =  1;
		}
		else
		{
			res =  0;
			if(Flag_COMDebug == 1)
				printf(" 终端管理数据上报失败!\r\n");
		}
		
		getvalue = cJSON_GetObjectItem(server_data, "mac");	
			   strcpy(fieldConfig_Auto.f_mac ,getvalue->valuestring);
		if(Flag_COMDebug == 1)
			printf(" mac:%s\r\n",fieldConfig_Auto.f_mac);
	}
	ClearUSART3BUF();
    cJSON_Delete(server_data);
//    cJSON_Delete(getvalue);
//	free(p1);
//	free(p2);
	return res;
	#else
	char res = 0;
	if(Flag_COMDebug == 1)
		printf("http json:%s \r\n",ucUar3tbuf); 
	if(strstr(ucUar3tbuf,"rspCode\":\"0000")!=NULL)
	{
		if(Flag_COMDebug == 1)
			printf("终端管理数据上报成功:%d\r\n",__LINE__);
		res =  1;
		
		if(AngelPace == DM_CONFIG_Auto)  //查询自注册
		{
			if(strstr(ucUar3tbuf,"imsi\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_imsi = true;
			else
				fieldConfig_Auto.f_imsi = false;
			
			if(strstr(ucUar3tbuf,"mac\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_mac = true;
			else
				fieldConfig_Auto.f_mac = false;
			
			if(strstr(ucUar3tbuf,"rom\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_rom = true;
			else
				fieldConfig_Auto.f_rom = false;
			
			if(strstr(ucUar3tbuf,"ram\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_ram = true;
			else
				fieldConfig_Auto.f_ram = false;
			
			if(strstr(ucUar3tbuf,"cpu\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_cpu = true;
			else
				fieldConfig_Auto.f_cpu = false;
			
			if(strstr(ucUar3tbuf,"sysVersion\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_sysVersion = true;
			else
				fieldConfig_Auto.f_sysVersion = false;
			
			if(strstr(ucUar3tbuf,"softwareVer\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_softwareVer = true;
			else
				fieldConfig_Auto.f_softwareVer = false;
			
			if(strstr(ucUar3tbuf,"softwareName\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_softwareName = true;
			else
				fieldConfig_Auto.f_softwareName = false;
			
			if(strstr(ucUar3tbuf,"volte\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_volte = true;
			else
				fieldConfig_Auto.f_volte = false;
			
			if(strstr(ucUar3tbuf,"netType\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_netType = true;
			else
				fieldConfig_Auto.f_netType = false;
			
			if(strstr(ucUar3tbuf,"phoneNumber\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_phoneNumber = true;
			else
				fieldConfig_Auto.f_phoneNumber = false;
			
			if(strstr(ucUar3tbuf,"routerMac\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_routerMac = true;
			else
				fieldConfig_Auto.f_routerMac = false;
			
			if(strstr(ucUar3tbuf,"bluetoothMac\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_bluetoothMac = true;
			else
				fieldConfig_Auto.f_bluetoothMac = false;
			
			if(strstr(ucUar3tbuf,"sn\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_sn = true;
			else
				fieldConfig_Auto.f_sn = false;
			
			if(strstr(ucUar3tbuf,"gpu\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_gpu = true;
			else
				fieldConfig_Auto.f_gpu = false;
			
			if(strstr(ucUar3tbuf,"board\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_board = true;
			else
				fieldConfig_Auto.f_board = false;
			
			if(strstr(ucUar3tbuf,"resolution\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_resolution = true;
			else
				fieldConfig_Auto.f_resolution = false;
			
			if(strstr(ucUar3tbuf,"batteryCapacity\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_batteryCapacity = true;
			else
				fieldConfig_Auto.f_batteryCapacity = false;
			
			if(strstr(ucUar3tbuf,"screenSize\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_screenSize = true;
			else
				fieldConfig_Auto.f_screenSize = false;
			
			if(strstr(ucUar3tbuf,"networkStatus\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_networkStatus = true;
			else
				fieldConfig_Auto.f_networkStatus = false;
			
			if(strstr(ucUar3tbuf,"wearingStatus\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_wearingStatus = true;
			else
				fieldConfig_Auto.f_wearingStatus = false;
			
			if(strstr(ucUar3tbuf,"appInfo\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_appInfo = true;
			else
				fieldConfig_Auto.f_appInfo = false;
			
			if(strstr(ucUar3tbuf,"imsi2\\\":\\\"Y") != NULL)
				fieldConfig_Auto.f_imsi2 = true;
			else
				fieldConfig_Auto.f_imsi2 = false;
			
			if(Flag_COMDebug == 1)
				printf("f_resolution:%d f_batteryCapacity:%d\r\n",fieldConfig_Auto.f_resolution,fieldConfig_Auto.f_batteryCapacity);
		}
		
		if(AngelPace == DM_CONFIG_Heart)  //查询心跳
		{
			if(strstr(ucUar3tbuf,"imsi\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_imsi = true;
			else
				fieldConfig_Heart.f_imsi = false;
			
			if(strstr(ucUar3tbuf,"mac\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_mac = true;
			else
				fieldConfig_Heart.f_mac = false;
			
			if(strstr(ucUar3tbuf,"rom\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_rom = true;
			else
				fieldConfig_Heart.f_rom = false;
			
			if(strstr(ucUar3tbuf,"ram\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_ram = true;
			else
				fieldConfig_Heart.f_ram = false;
			
			if(strstr(ucUar3tbuf,"cpu\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_cpu = true;
			else
				fieldConfig_Heart.f_cpu = false;
			
			if(strstr(ucUar3tbuf,"sysVersion\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_sysVersion = true;
			else
				fieldConfig_Heart.f_sysVersion = false;
			
			if(strstr(ucUar3tbuf,"softwareVer\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_softwareVer = true;
			else
				fieldConfig_Heart.f_softwareVer = false;
			
			if(strstr(ucUar3tbuf,"softwareName\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_softwareName = true;
			else
				fieldConfig_Heart.f_softwareName = false;
			
			if(strstr(ucUar3tbuf,"volte\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_volte = true;
			else
				fieldConfig_Heart.f_volte = false;
			
			if(strstr(ucUar3tbuf,"netType\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_netType = true;
			else
				fieldConfig_Heart.f_netType = false;
			
			if(strstr(ucUar3tbuf,"phoneNumber\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_phoneNumber = true;
			else
				fieldConfig_Heart.f_phoneNumber = false;
			
			if(strstr(ucUar3tbuf,"routerMac\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_routerMac = true;
			else
				fieldConfig_Heart.f_routerMac = false;
			
			if(strstr(ucUar3tbuf,"bluetoothMac\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_bluetoothMac = true;
			else
				fieldConfig_Heart.f_bluetoothMac = false;
			
			if(strstr(ucUar3tbuf,"sn\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_sn = true;
			else
				fieldConfig_Heart.f_sn = false;
			
			if(strstr(ucUar3tbuf,"gpu\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_gpu = true;
			else
				fieldConfig_Heart.f_gpu = false;
			
			if(strstr(ucUar3tbuf,"board\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_board = true;
			else
				fieldConfig_Heart.f_board = false;
			
			if(strstr(ucUar3tbuf,"resolution\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_resolution = true;
			else
				fieldConfig_Heart.f_resolution = false;
			
			if(strstr(ucUar3tbuf,"batteryCapacity\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_batteryCapacity = true;
			else
				fieldConfig_Heart.f_batteryCapacity = false;
			
			if(strstr(ucUar3tbuf,"screenSize\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_screenSize = true;
			else
				fieldConfig_Heart.f_screenSize = false;
			
			if(strstr(ucUar3tbuf,"networkStatus\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_networkStatus = true;
			else
				fieldConfig_Heart.f_networkStatus = false;
			
			if(strstr(ucUar3tbuf,"wearingStatus\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_wearingStatus = true;
			else
				fieldConfig_Heart.f_wearingStatus = false; 
			
			if(strstr(ucUar3tbuf,"appInfo\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_appInfo = true;
			else
				fieldConfig_Heart.f_appInfo = false;
			
			if(strstr(ucUar3tbuf,"imsi2\\\":\\\"Y") != NULL)
				fieldConfig_Heart.f_imsi2 = true;
			else
				fieldConfig_Heart.f_imsi2 = false;
			
			if(Flag_COMDebug == 1)
				printf("resolution:%d batteryCapacity:%d\r\n",fieldConfig_Heart.f_resolution,fieldConfig_Heart.f_batteryCapacity);
		}
	}
	if(strstr(ucUar3tbuf,"errorCode")!=NULL)
	{
		res =  0;
		if(Flag_COMDebug == 1)
			printf(" 终端管理数据上报失败!\r\n");
	}
	ClearUSART3BUF();
    return res;
	#endif
}
/****************************************************************************
*	函 数 名: 
*	功能说明: MQTT发送从机遗嘱帧
*	形    参：无
*	返 回 值: 
*****************************************************************************/
void Slave_MQTT_Will(char *MAC,char *device)
{
    char send_data1[200];   
	char real_time_str[] = "00000000000000";  // 实时时间
	sprintf(real_time_str, "20%02d%02d%02d%02d%02d%02d", Timebuf[0], Timebuf[1], Timebuf[2], Timebuf[3], Timebuf[4], Timebuf[5]);
    sprintf(send_data1,"{\\22eventType\\22:\\22Offline\\22,\\22deviceId\\22:\\22%s\\22,\\22mac\\22:\\22%s\\22,\\22timestamp\\22:\\22%s\\22,\\22deviceType\\22:\\22%s\\22,\\22master\\22:%d}",
		MAC,MAC,real_time_str,device,DevNature_slave);
	sprintf(devPubTopic,"/device/CMCC-%s-%s/upward", IOTDEVICETYPE, Device_Info.CMCC_CMEI);  //topic用主机的
//    MQTT_PUB(devPubTopic,send_data1);
	if(MQTT_PUB(devPubTopic,send_data1))   //发布成功
	{
		return;
	}
	else
	{
		MQTT_PUB(devPubTopic,send_data1);  //再发一次
	}
}
/****************************************************************************
*	函 数 名: 
*	功能说明: MQTT发送Mboot
*	形    参：无
*	返 回 值: 
*****************************************************************************/
void iSuke_MQTT_Mboot(void)
{
    char send_data1[200];   
    sprintf(send_data1,"{\\22eventType\\22:\\22MBoot\\22,\\22deviceId\\22:\\22CMCC-591217-%s\\22,\\22mac\\22:\\22%s\\22,\\22timestamp\\22:\\22%d\\22,\\22deviceType\\22:\\22%s\\22,\\22master\\22:%d}",
		MAC_IDstring,MAC_IDstring,1694670785,"4G",DevNature_master);
	sprintf(devPubTopic,"/device/CMCC-%s-%s/upward", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
//    MQTT_PUB(devPubTopic,send_data1);
	if(MQTT_PUB(devPubTopic,send_data1))   //发布成功
	{
		return;
	} 
	else
	{
		MQTT_PUB(devPubTopic,send_data1);  //再发一次
	}
    log_trace("isuke mqtt Mboot success \r\n");
}

/****************************************************************************
*	函 数 名: 
*	功能说明: MQTT定时发送Mboot(24h)
*	形    参：无
*	返 回 值: 
*****************************************************************************/
void MQTT_Mboot_Send(void)
{
    char send_data1[200];   
    sprintf(send_data1,"{\\22deviceId\\22:\\22CMCC-%s-%s\\22,\\22mac\\22:\\22%s\\22}",
		IOTDEVICETYPE, Device_Info.CMCC_CMEI,MAC_ID);
	sprintf(devPubTopic,"/device/CMCC-%s-%s/dmReport", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
//    MQTT_PUB(devPubTopic,send_data1);
	if(MQTT_PUB(devPubTopic,send_data1))   //发布成功
	{
        //MQTT_MSGGET_DM_report(); // 失败了后台会重传
		return;
	} 
	else
	{
		MQTT_PUB(devPubTopic,send_data1);  //再发一次
        //MQTT_MSGGET_DM_report(); // 失败了后台会重传
	}
}

/****************************************************************************
*	函 数 名: 
*	功能说明: MQTT发送从机上线Mboot
*	形    参：无
*	返 回 值: 
*****************************************************************************/
void Slave_MQTT_Mboot(char *MAC,char *device)
{
    char send_data1[200];   
	char real_time_str[] = "00000000000000";  // 实时时间
	sprintf(real_time_str, "20%02d%02d%02d%02d%02d%02d", Timebuf[0], Timebuf[1], Timebuf[2], Timebuf[3], Timebuf[4], Timebuf[5]);
    sprintf(send_data1,"{\\22eventType\\22:\\22MBoot\\22,\\22deviceId\\22:\\22%s\\22,\\22mac\\22:\\22%s\\22,\\22timestamp\\22:\\22%s\\22,\\22deviceType\\22:\\22%s\\22,\\22master\\22:%d}",
		MAC,MAC,real_time_str,device,DevNature_slave);
	sprintf(devPubTopic,"/device/CMCC-%s-%s/upward", IOTDEVICETYPE, Device_Info.CMCC_CMEI);  //topic用主机的
//    MQTT_PUB(devPubTopic,send_data1);
	if(MQTT_PUB(devPubTopic,send_data1))   //发布成功
	{
		return;
	}
	else
	{
		MQTT_PUB(devPubTopic,send_data1);  //再发一次
	}
}
/****************************************************************************
*	函 数 名: 
*	功能说明: MQTT请求校时
*	形    参：无
*	返 回 值: 
*****************************************************************************/
void iSuke_MQTT_Time(void)
{
	char send_status[10]; 
    char send_data11[100];   
    if(SOSConnectFlag == 1) 
		memcpy(send_status,"normal",sizeof("normal"));
	else  
		memcpy(send_status,"none",sizeof("none"));
	sprintf(send_data11,"{\\22function\\22:\\22sync_time\\22,\\22mac\\22:\\22%s\\22,\\22sos_status\\22:\\22%s\\22}",
		MAC_IDstring,send_status);
	sprintf(devPubTopic,"/device/CMCC-591217-%s/real",MAC_IDstring);
    if(MQTT_PUB(devPubTopic,send_data11))
		MQTT_MSGGET_0();
}
/****************************************************************************
*	函 数 名: 
*	功能说明: MQTT实时数据
*	形    参：无
*	返 回 值: 
*****************************************************************************/
void iSuke_MQTT_Data(void)
{
	char real_time_str[] = "00000000000000";  // 实时时间
	char send_data11[300];
	
	cJSON *postdata9;
    char res = 0;
    char *send_data9= NULL;
	
	if((Timebuf[0]<23) || (Timebuf[1]>12) || (Timebuf[2]>31))  //日期错误
	{
		if(Flag_COMDebug == 1)
			printf("日期错误，不发送1\r\n");
		return;
	}
	
	sprintf(real_time_str, "20%02d%02d%02d%02d%02d%02d", Timebuf[0], Timebuf[1], Timebuf[2], Timebuf[3], Timebuf[4], Timebuf[5]);
	sprintf(send_data11,"{\\22function\\22:\\22real_data\\22,\\22mac\\22:\\22%s\\22,\\22hr\\22:%d,\\22rr\\22:%d,\\22status\\22:%d,\\22csq\\22:%d,\\22time\\22:\\22%s\\22,\\22deviceType\\22:\\22%s\\22,\\22master\\22:%d}",
		MAC_IDstring,RT_Hr,RT_Rr,RT_Status,CSQNual,real_time_str,device_master,DevNature_master);

    //实时数据上传服务器	
	postdata9  = cJSON_CreateObject();
	cJSON_AddItemToObject(postdata9, "function", cJSON_CreateString("real_data"));
	cJSON_AddItemToObject(postdata9, "mac", cJSON_CreateString(MAC_ID));
	cJSON_AddItemToObject(postdata9, "hr", cJSON_CreateNumber(RT_Hr));
	cJSON_AddItemToObject(postdata9, "rr", cJSON_CreateNumber(RT_Rr));
	cJSON_AddItemToObject(postdata9, "status", cJSON_CreateNumber(RT_Status));
	cJSON_AddItemToObject(postdata9, "csq", cJSON_CreateNumber(CSQNual));
	cJSON_AddItemToObject(postdata9, "time", cJSON_CreateString(real_time_str));
	
//    sprintf(devPubTopic,"/device/CMCC-4G-%s/real",MAC_IDstring);
//	if(MQTT_PUB(devPubTopic,send_data11))   //发布成功
//	{
		send_data9 = cJSON_PrintUnformatted(postdata9);
//		if(Flag_COMDebug == 1)
//		printf("实时数据=%s \r\n",send_data9); 

		sprintf(devPubTopic1,"/device/CMCC-591217-%s/real",MAC_IDstring);   
		res = Andlink_Publish(devPubTopic1,send_data9);
		cJSON_Delete(postdata9);
		free(send_data9);
		return;
//	}
//	else
//	{
//		MQTT_PUB(devPubTopic,send_data11);  //再发一次
//		send_data9 = cJSON_PrintUnformatted(postdata9);
////		if(Flag_COMDebug == 1)
////		printf("实时数据=%s \r\n",send_data9); 

//		sprintf(devPubTopic1,"/device/%s/real",MY_DEVICEID);   
//		res = Andlink_Publish(devPubTopic1,send_data9);
//		cJSON_Delete(postdata9);
//		free(send_data9);
//	}
}

/****************************************************************************
*	函 数 名: Andlink_MQTT_DataReport
*	功能说明: MQTT数据上报
*	形    参：无
*	返 回 值: 
*   说    明：
*****************************************************************************/

void Andlink_MQTT_DataReport(void)
{
    cJSON *postdata,*xData;
    
    char *send_data= NULL;
    char deviceID[64] = {0};
    int ret = 0;
    static char data_report_failed = 0;
    
    snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
    
    RealTime2Data.Year = 2000+Timebuf[0];
    RealTime2Data.Mon = Timebuf[1];
    RealTime2Data.Day = Timebuf[2];
    RealTime2Data.Hour = Timebuf[3];
    RealTime2Data.Min =  Timebuf[4];
    RealTime2Data.Second = Timebuf[5]; 
    TimeStamp = Date2timeStamp(RealTime2Data);
    
    postdata  = cJSON_CreateObject();
    //cJSON_AddStringToObject(postdata,"deviceId",Andlink_GW_Info.deviceID);  
    cJSON_AddStringToObject(postdata,"deviceId",deviceID); 
    cJSON_AddStringToObject(postdata,"eventType","Inform"); //Inform：设备自发上报的状态和属性信息，包括事件和定时采集数据，可不带或扩展为具体的事件类型
    cJSON_AddNumberToObject(postdata,"timestamp",TimeStamp); 
    cJSON_AddStringToObject(postdata,"seqId", "DEV_00000001");
     cJSON_AddStringToObject(postdata,"deviceType", IOTDEVICETYPE);
    cJSON_AddItemToObject(postdata,"data",xData  = cJSON_CreateObject()); 
     cJSON_AddNumberToObject(xData,"bedStatus",gPeopleFlag); 
    cJSON_AddNumberToObject(xData,"heartRate",gPulseRateHR); 
    cJSON_AddNumberToObject(xData,"bretheRate",gPulseRateRR); 
    
    send_data = cJSON_PrintUnformatted(postdata);
    
    
    //sprintf(devPubTopic,"/device/%s/upward",Andlink_GW_Info.deviceID);
    sprintf(devPubTopic,"/device/%s/upward",deviceID);
    
    ret = Andlink_Publish(devPubTopic,send_data);
     cJSON_Delete(postdata);
//    if(Flag_COMDebug == 1)
//       log_trace("Andlink MQTT data report[%s] \r\n ", send_data);
      
    free(send_data);
    
    if (0 == ret) {
        log_trace("Andlink MQTT data report failed reconnect mqtt, data_report_failed:%d \r\n", data_report_failed);
        data_report_failed ++;
        if (5 < data_report_failed) {
            // data_report_failed = 0;
            // GPRS_CloseSocket();
            // AngelPace = POWER_ON_NOTIFY;
            ATCGATT_Count = 61;
        }
    } else {
        data_report_failed = 0;
    }
    
}

/****************************************************************************
*	函 数 名: 
*	功能说明: SOS事件
*	形    参：无
*	返 回 值: 
*****************************************************************************/
uint8_t iSuke_MQTT_SOS(uint8_t type)
{
    char real_time_str[] = "00000000000000";  // 实时时间
	char send_data11[200];
	char send_type[10];
	if((Timebuf[0]<23) || (Timebuf[1]>12) || (Timebuf[2]>31))  //日期错误
	{
		if(Flag_COMDebug == 1)
			printf("日期错误，不发送2\r\n");
		return 0;
	}
	if(type == 0) //语音
		memcpy(send_type,"voice",sizeof("voice"));
	else if(type == 1) //按键
		memcpy(send_type,"key",sizeof("key"));
	else if(type == 2) //夜间脱离监护
		memcpy(send_type,"away",sizeof("away"));
	
	sprintf(real_time_str, "20%02d%02d%02d%02d%02d%02d", Timebuf[0], Timebuf[1], Timebuf[2], Timebuf[3], Timebuf[4], Timebuf[5]);
	if(strstr(SlaveSOS_MAC,"CCCDDC") != NULL)  //MAC无效
	{
		sprintf(send_data11,"{\\22function\\22:\\22%s\\22,\\22mMac\\22:\\22%s\\22,\\22type\\22:\\22%s\\22,\\22time\\22:%s,\\22mac\\22:\\22%s\\22}",
		"sos",MAC_IDstring,send_type,real_time_str,MAC_IDstring);
	}
	else
	{
		sprintf(send_data11,"{\\22function\\22:\\22%s\\22,\\22mMac\\22:\\22%s\\22,\\22type\\22:\\22%s\\22,\\22time\\22:%s,\\22mac\\22:\\22%s\\22}",
		"sos",MAC_IDstring,send_type,real_time_str,SlaveSOS_MAC);
	}
	
	
	sprintf(devPubTopic,"/device/CMCC-591217-%s/real",MAC_IDstring);
	if(MQTT_PUB(devPubTopic,send_data11))   //发布成功
	{
		MQTT_MSGGET_0(); //后台应答
		return 1;
	}
	else
	{
		if(MQTT_PUB(devPubTopic,send_data11))  //再发一次
		{
			MQTT_MSGGET_0(); //后台应答
			return 1;
		}
		else
		{
			return 0;
		}
	}
}
/****************************************************************************
*	函 数 名: 
*	功能说明: 批量实时数据
*	形    参：无
*	返 回 值: 
*****************************************************************************/
void iSuke_MQTT_RealBatch(uint8_t len)
{
	uint8_t i;
	int index = 0;
    char real_time_str[] = "00000000000000";  // 开始时间
	char send_data11[1000];
	char send_hr[400],send_rr[350],send_status[230];
	if((OffTime[0]<23) || (OffTime[1]>12) || (OffTime[2]>31))  //日期错误
	{
		if(Flag_COMDebug == 1)
			printf("日期错误，不发送3\r\n");
		return;
	}
	sprintf(real_time_str, "20%02d%02d%02d%02d%02d%02d", OffTime[0], OffTime[1], OffTime[2], OffTime[3], OffTime[4], OffTime[5]);
	for(i=0; i<len; i++)
	{
		if(i>0)
        {
            if(hrtest[i-1]>=100)
                index = index + 4;
            else if(hrtest[i-1]>=10)
                index = index + 3;
            else
                index = index + 2;
			
            if(i<(len-1))
                sprintf(send_hr + index, "%d,", hrtest[i]);  
            else
                sprintf(send_hr + index, "%d", hrtest[i]);  
        }
        else
            sprintf(send_hr , "%d,", hrtest[i]); 
	}
	index = 0;
	for(i=0; i<len; i++)
	{
		if(i>0)
        {
            if(rrtest[i-1]>=10)
                index = index + 3;
            else
                index = index + 2;
			
            if(i<(len-1))
                sprintf(send_rr + index, "%d,", rrtest[i]);  
            else
                sprintf(send_rr + index, "%d", rrtest[i]);  
        }
        else
            sprintf(send_rr , "%d,", rrtest[i]); 
	}
	index = 0;
	for(i=0; i<len; i++)
	{
		if(i<(len-1))
			sprintf(send_status + index, "%d,", statustest[i]);  
		else
			sprintf(send_status + index, "%d", statustest[i]);  
		index = index + 2;
	}
	sprintf(send_data11,"{\\22function\\22:\\22%s\\22,\\22mac\\22:\\22%s\\22,\\22battery\\22:%d,\\22num\\22:%d,\\22hr\\22:\\22%s\\22,\\22rr\\22:\\22%s\\22,\\22status\\22:\\22%s\\22,\\22time\\22:\\22%s\\22}",
		"real_batch",MAC_IDstring,SOS_Battery,len,send_hr,send_rr,send_status,real_time_str);
	
	sprintf(devPubTopic,"/device/CMCC-591217-%s/real",MAC_IDstring);
    if(MQTT_PUB(devPubTopic,send_data11))   //发布成功
		return;
	else
		MQTT_PUB(devPubTopic,send_data11);  //再发一次
}

/****************************************************************************
*	函 数 名: 
*	功能说明: 在床监测带从机实时数据
*	形    参：从机的MAC、从机的状态
*	返 回 值: 
*****************************************************************************/
void ExistSlave_MQTT_Data(char *MAC,uint8_t status)
{
	char real_time_str[] = "00000000000000";  // 实时时间
	char send_data11[300];
	
	if((Timebuf[0]<23) || (Timebuf[1]>12) || (Timebuf[2]>31))  //日期错误
	{
		if(Flag_COMDebug == 1)
			printf("日期错误，不发送4\r\n");
		return;
	}
	
	sprintf(real_time_str, "20%02d%02d%02d%02d%02d%02d", Timebuf[0], Timebuf[1], Timebuf[2], Timebuf[3], Timebuf[4], Timebuf[5]);
	sprintf(send_data11,"{\\22function\\22:\\22real_data_L\\22,\\22mac\\22:\\22%s\\22,\\22status\\22:%d,\\22time\\22:\\22%s\\22,\\22deviceType\\22:\\22%s\\22,\\22master\\22:%d}",
		MAC,status,real_time_str,device_slave1,DevNature_slave);
	
    sprintf(devPubTopic,"/device/CMCC-591217-%s/real",MAC_IDstring); //用主机的topic
//	printf("%s\r\n",send_data11);
//	printf("%s\r\n",devPubTopic);
	if(MQTT_PUB(devPubTopic,send_data11))   //发布成功
	{
		return;
	}
	else
	{
		MQTT_PUB(devPubTopic,send_data11);  //再发一次
	}
}

/****************************************************************************
*	函 数 名: 
*	功能说明: 睡眠监测带从机实时数据
*	形    参：从机的MAC、从机的状态、心率、呼吸等
*	返 回 值: 
*****************************************************************************/
void RealSlave_MQTT_Data(char *MAC,uint8_t *status)
{
	char real_time_str[] = "00000000000000";  // 实时时间
	char send_data11[300];
	
	if((Timebuf[0]<23) || (Timebuf[1]>12) || (Timebuf[2]>31))  //日期错误
	{
		if(Flag_COMDebug == 1)
			printf("日期错误，不发送5\r\n");
		return;
	}
	
	sprintf(real_time_str, "20%02d%02d%02d%02d%02d%02d", Timebuf[0], Timebuf[1], Timebuf[2], Timebuf[3], Timebuf[4], Timebuf[5]);
	sprintf(send_data11,"{\\22function\\22:\\22real_data\\22,\\22mac\\22:\\22%s\\22,\\22hr\\22:%d,\\22rr\\22:%d,\\22status\\22:%d,\\22time\\22:\\22%s\\22,\\22deviceType\\22:\\22%s\\22,\\22master\\22:%d}",
		MAC,status[0],status[1],status[2],real_time_str,device_slave2,DevNature_slave);
	
    sprintf(devPubTopic,"/device/CMCC-591217-%s/real",MAC_IDstring);
//	printf("%s\r\n",send_data11);
//	printf("%s\r\n",devPubTopic);
	if(MQTT_PUB(devPubTopic,send_data11))   //发布成功
	{
		return;
	}
	else
	{
		MQTT_PUB(devPubTopic,send_data11);  //再发一次
	}
}

//从机管理
void Slave_Manage_PutIn(char *MAC,uint8_t *status,uint8_t device)
{
	uint8_t i;
	for(i=0;i<SlaveNum;i++)
	{
		//先判断与已存的是否一致
		if((strcmp(Slave_MAC[i],MAC) == 0)&&(Slave_flag[i] == 1))
		{
			Slave_SecCnt[i] = 0;  //一致清零
			if(Flag_COMDebug == 1)
				printf("从机设备的MAC:%s,Slave_SecCnt:%d\r\n", Slave_MAC[i],Slave_SecCnt[i]);  
			goto SEND_INFO_DATA;
			break;
		}
	}
	//没有与已入库的一致的则进行入库判断
	for(i=0;i<SlaveNum;i++)
	{
		if(Slave_flag[i] == 0)
		{
			Slave_flag[i] = 1;    //入库
			Slave_SecCnt[i] = 0;
			memcpy(Slave_MAC[i],MAC,20);
			if(Flag_COMDebug == 1)
				printf("入库设备的MAC:%s\r\n", Slave_MAC[i]);
			
			if(device == Device_Onbed)
			{
				Slave_type[i] = Device_Onbed;
				Slave_MQTT_Mboot(Slave_MAC[i],device_slave1);  //从机上线
			}
			else if(device == Device_Real)
			{
				Slave_type[i] = Device_Real;
				Slave_MQTT_Mboot(Slave_MAC[i],device_slave2);  //从机上线
			}
			else if(device == Device_SOS)
			{
				Slave_type[i] = Device_SOS;
				Slave_MQTT_Mboot(Slave_MAC[i],device_slave3);  //从机上线
			}
			break;
		}
	}
	if(i == SlaveNum)  //已满
	{
		if(Flag_COMDebug == 1)
			printf("MESH从设备已满\r\n");
		return;
	}

	SEND_INFO_DATA:	
	if(device == Device_Onbed)
		ExistSlave_MQTT_Data(Slave_MAC[i],status[0]);
	else if(device == Device_Real)
		RealSlave_MQTT_Data(Slave_MAC[i],status);
}
	
//出库
void Slave_Manage_PutOut(void)
{
	uint8_t i;
	for(i=0;i<SlaveNum;i++)
	{
		if((Slave_type[i] == Device_Onbed)||(Slave_type[i] == Device_Real))
		{
			if(Slave_SecCnt[i] >= 60)
			{
				Slave_flag[i] = 0;
				Slave_SecCnt[i] = 0;
				if(Slave_type[i] == Device_Onbed)
					Slave_MQTT_Will(Slave_MAC[i],device_slave1);
				else if(Slave_type[i] == Device_Real)
					Slave_MQTT_Will(Slave_MAC[i],device_slave2);
				Slave_type[i] = 0;
				memset(Slave_MAC[i],0,20);
			}
		}
		else if(Slave_type[i] == Device_SOS)
		{
			if(Slave_SecCnt[i] >= 660)
			{
				Slave_flag[i] = 0;
				Slave_SecCnt[i] = 0;
				Slave_MQTT_Will(Slave_MAC[i],device_slave3);
				Slave_type[i] = 0;
				memset(Slave_MAC[i],0,20);
			}
		}
	}
}

//超时管理
void Slave_Manage_Time(void)
{
	uint8_t i;
	for(i=0;i<SlaveNum;i++)
	{
		if((Slave_flag[i] == 1)&&(Slave_type[i] != Device_SOS))
		{
			Slave_SecCnt[i]++;
			if(Slave_SecCnt[i] >= 60)
				Slave_SecCnt[i] = 61;
		}
		else if((Slave_flag[i] == 1)&&(Slave_type[i] == Device_SOS))
		{
			Slave_SecCnt[i]++;
			if(Slave_SecCnt[i] >= 660)
				Slave_SecCnt[i] = 661;
		}
		else
		{
			Slave_SecCnt[i] = 0;
		}
	}
}

//测试

/****************************************************************************
*	函 数 名: ESP8266_WaitRecive
*	功能说明: 等待接收完成
*	形    参：无
*	返 回 值: REV_OK-接收完成		REV_WAIT-接收超时未完成
*  说    明：循环调用检测是否接收完成
*           20230517增加
*****************************************************************************/
uint16_t esp8266_cntPre = 0;
char ESP8266_WaitRecive(void)
{

	if(ReceEnd3 == 0) 							//如果接收计数为0 则说明没有处于接收数据中，所以直接跳出，结束函数
		return REV_WAIT;
		
	if(ReceEnd3 == esp8266_cntPre)				//如果上一次的值和这次相同，则说明接收完毕
	{
		ReceEnd3 = 0;							//清0接收计数
			
		return REV_OK;								//返回接收完成标志
	}
		
	esp8266_cntPre = ReceEnd3;					//置为相同
	
	return REV_WAIT;								//返回接收未完成标志

}
/****************************************************************************
*	函 数 名: ESP8266_GetIPD
*	功能说明: 获取平台返回的数据
*	形    参：等待的时间(乘以10ms)
*	返 回 值: 平台返回的原始数据
*  说    明：20230517增加
*           不同网络设备返回的格式不同，需要去调试
*			如ESP8266的返回格式为	"+IPD,x:yyy"	x代表数据长度，yyy是数据内容
*****************************************************************************/
unsigned char *ESP8266_GetIPD(uint16_t timeOut)
{

	char *ptrIPD = NULL;
	
	do
	{
		if(ESP8266_WaitRecive() == REV_OK)								//如果接收完成
		{
//			printf("%s\r\n",WIFI_RX_BUFFER); //代码调试时使用，
            
			ptrIPD = strstr((char *)ucUar3tbuf, "body:");				//搜索“IPD”头
			if(ptrIPD == NULL)											//如果没找到，可能是IPD头的延迟，还是需要等待一会，但不会超过设定的时间
			{
//				printf("\"IPD\" not found\r\n");
			}
			else
			{
				ptrIPD = strchr(ptrIPD, ':');							//找到':'
				if(ptrIPD != NULL)
				{
					ptrIPD++;
					return (unsigned char *)(ptrIPD);
				}
				else
					return NULL;
				
			}
		}
		
		delay_ms(10);
        timeOut--;//延时等待
	} while(timeOut>0);
	
	return NULL;														//超时还未找到，返回空指针

}

/****************************************************************************
*	函 数 名: SaveAndlinkinfoToFlash
*	功能说明: 保存andlink云网关验证参数
*	形    参：无
*	返 回 值: 
*  说    明： 
*****************************************************************************/
GWresp_Para Andlink_GW_Info;
char SaveAndlinkinfoToFlash(void)	
{ 
    
	Andlink_GW_Info.flag =  Flag_FirstRun; 
    
    STMFlashErase(FLASH_AndLinkInfoAddress,1);
    STMFlashWrite ( FLASH_AndLinkInfoAddress, (uint8_t *)&(Andlink_GW_Info.flag), sizeof(Andlink_GW_Info) );
    
	return 1;
}
/****************************************************************************
*	函 数 名: Andlinkinfo
*	功能说明: 读andlink云网关验证参数
*	形    参：无
*	返 回 值: 返回1已有注册信息，返回0表示未注册
* 	说    明：
*****************************************************************************/
char ReadAndlinkinfoFromFlash(void)	
{

    memset(&(Andlink_GW_Info.flag),0,sizeof(Andlink_GW_Info));


    STMFlashRead ( FLASH_AndLinkInfoAddress, (uint8_t *)&(Andlink_GW_Info.flag), sizeof(Andlink_GW_Info) );
               
	if(Andlink_GW_Info.flag == Flag_FirstRun)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
/****************************************************************************
*	函 数 名: RespQlikNetInfo
*	功能说明: 回复app发送的联网信息
*	形    参：
*	返 回 值: 
*   说    明：
*****************************************************************************/
void RespQlikNetInfo(void)
{
    cJSON *postdata1;
    char *send_data= NULL;
     postdata1  = cJSON_CreateObject();
	 cJSON_AddNumberToObject(postdata1,"respCode",1);
	 cJSON_AddStringToObject(postdata1,"respCont", "received netinfo");
    send_data = cJSON_PrintUnformatted(postdata1);
    coapClient_post("192.168.5.255","5683","qlink/netinfo",send_data,strlen(send_data));
    
    cJSON_Delete(postdata1);
}
/****************************************************************************
*	函 数 名: BroadcastRegistResultByCoap
*	功能说明: Wi-Fi 设备入网成功广播
*	形    参：无
*	返 回 值: 1 广播收到回复， 0 无
*   说    明：设备入网成功后，以广播形式发送确认信息
*    请求 url：coap://broadcastIp:5683/qlink/success
*     请求类型：POST-CON，设备->网络
*****************************************************************************/
//DeviceInfo_Para Device_Info;
char BroadcastAccessInNetworkByCoap(void)
{
    char coapip[16]={0};
    char res = 0;
    char  *p1,*p2;
    cJSON *postdata2,*getvalue;
    char *send_data= NULL;
    
//     WIFI_Query_LocalIP();

    postdata2  = cJSON_CreateObject();
	cJSON_AddStringToObject(postdata2,"deviceMac",MAC_ID); 
    cJSON_AddStringToObject(postdata2,"deviceType", IOTDEVICETYPE);
   
    send_data = cJSON_PrintUnformatted(postdata2);
//    sprintf(coapip,"%d.%d.%d.255",Local_IP[0],Local_IP[1],Local_IP[2]);  // 需要确认广播IP
    
    MQTT_TCP_connect();
    coapClient_post(URL_GETAHOST_IP,URL_GETAHOST_PORT,URL_HEADER,send_data,strlen(send_data));
    MQTT_Close();
    ClearUSART3BUF();
    cJSON_Delete(postdata2);
    return res ;
}

/****************************************************************************
*	函 数 名: WIFI_Query_LocalIP
*	功能说明: 获取本地IP
*	形    参：
*	返 回 值:
* 	说    明：模块返回,20230521增加
*         +CIFSR:STAIP,"192.168.0.108"
*   +CIFSR:STAMAC,"24:d7:eb:c8:a1:72"
*****************************************************************************/
uint16_t Local_IP[4];
char WIFI_Query_LocalIP(void)
{
	//char cmd[30]="";
    char stringbuf1[30]={0};
	char *pstr;
//	char *cmd;
//	sprintf(cmd, "AT+CIFSR\r\n");	
	ClearUSART3BUF();
	UART3_SendString("AT+CIFSR\r\n");
	delay_ms(10);
	mytime = 0;
	while(1)
	{
		delay_ms(50);
//		if(strstr(ucUar3tbuf,"OK")!= NULL)
		{	          
            sscanf(ucUar3tbuf,"  \"%d.%d.%d.%d\"  \r\n",&Local_IP[0],&Local_IP[1],&Local_IP[2],&Local_IP[3]);
//            Local_IP[0]=10;
//			Local_IP[1]=4
//			Local_IP[2]=149;
//			Local_IP[3]=136;
			if(Flag_COMDebug == 1)
			{
				printf("Local ip:%d.%d.%d.%d\r\n",Local_IP[0],Local_IP[1],Local_IP[2],Local_IP[3]);
			}
            ClearUSART3BUF();
			return 1;
		}		
		if(mytime > 3 )
		{
			ClearUSART3BUF();
			if(Flag_COMDebug == 1)
			{
				printf("Read local ip time out:%s\r\n",ucUar3tbuf);
			}
			return 0;			
		}
        delay_ms(10);
	}
}
/****************************************************************************
*	函 数 名: BroadcastRegistResultByCoap
*	功能说明: 查找智能组网终端
*	形    参：无
*	返 回 值: 1广播收到回复， 0 无
*   说    明：设备通过云网关注册到平台后，设备将云网关返回的注册结果简单转换后广播给局域网中的 APP
*    请求 url：coap://broadcastIp/qlink/regist
*     请求类型：POST-CON，设备->网络
*****************************************************************************/
char BroadcastRegistResultByCoap(void)
{
    char coapip[16]={0};
    char res = 0;
    char  *p1,*p2;
    cJSON *postdata3,*getvalue;
    char *send_data= NULL;
    char cmd[100]={0};
    char deviceID[64] = {0};
    
    snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
    
     WIFI_Query_LocalIP();
//     WIFI_Close_TCPConnect(0);
    
    postdata3  = cJSON_CreateObject();
	cJSON_AddNumberToObject(postdata3,"respCode",1);        //1 成功,其他为异常
	cJSON_AddStringToObject(postdata3,"respCont", "regist success"); //描述信息
    cJSON_AddStringToObject(postdata3,"deviceId",deviceID );
    cJSON_AddStringToObject(postdata3,"deviceType", IOTDEVICETYPE);
    
    send_data = cJSON_PrintUnformatted(postdata3);
    sprintf(coapip,"%d.%d.%d.255",Local_IP[0],Local_IP[1],Local_IP[2]);  // 需要确认广播IP
//    WIFI_Set_UDPConnect(coapip,COAPLINK_PORT,COAPLINK_PORT);
//	MQTT_TCP_connect();
	ClearUSART3BUF();
	sprintf(cmd,"AT+CIPSTART=\"UDP\",\"%s\",%s\r\n",coapip,COAPLINK_PORT); 
	UART3_SendString(cmd);
    coapClient_post(coapip,COAPLINK_PORT,"qlink/regist",send_data,strlen(send_data));
	GPRS_Wait_Resp("}", 5);
    
//    MQTT_Close();
	GPRS_CloseSocket();
    ClearUSART3BUF();
    cJSON_Delete(postdata3);
    return res ;
}

/****************************************************************************
*	函 数 名: Andlink_GetGWAddress
*	功能说明: 获取网关地址
*	形    参：无
*	返 回 值: 1 获取成功，0 失败
*   说    明：
*****************************************************************************/
char Andlink_GetGWAddress(void)
{
    char coapip[16]={0};
    char res = 0;
//    unsigned char *dataPtr = NULL;
    char  *p1,*p2;
//	char  poststr[500] = {0};
     
    cJSON *postdata4;
    cJSON *getvalue;
    //cJSON *server_data4;
    
    char *send_data= NULL;
   
 
     postdata4  = cJSON_CreateObject();
	cJSON_AddStringToObject(postdata4,"deviceType",IOTDEVICETYPE);
	cJSON_AddStringToObject(postdata4,"productToken", IOTPRODUCTTOKEN);
    
//      send_data = cJSON_Print(postdata);
    send_data = cJSON_PrintUnformatted(postdata4);
    memset(poststr,0,1024);
    HTTP_PostPkt(poststr,URL_GETGWADDRESS,URL_GETAHOST_IP,URL_HEADER,send_data);
    GPRS_Send_Data(poststr,strlen(poststr));
    log_trace("poststr=[%s] \r\n", poststr);
    GPRS_Wait_Resp("}", 5);
    // 这个会失败，但是直接发杭研平台地址是正常返回的，可能我们平台对接有点问题
    // 暂时不用管，现在还没有用到这些
    
    ClearUSART3BUF();
    cJSON_Delete(postdata4);
    if (send_data) {
        free(send_data);
    }
    //cJSON_Delete(server_data4);
    return res ;
}

/* Base64 编码表 */
static const unsigned char base64_table[] = {
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
    'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
    'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
    'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
    'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
    'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
    'w', 'x', 'y', 'z', '0', '1', '2', '3',
    '4', '5', '6', '7', '8', '9', '+', '/', '=',
};

/****************************************************************************
*	函 数 名: Andlink_DeviceRegist
*	功能说明: 使用默认用户信息向平台发起首次注册、上线请求
*	形    参：无
*	返 回 值: 1 获取成功，0 失败
*   说    明：设备（网络通畅）上电后，检测到本地没有 deviceId 和 deviceToken 缓存，则
*           执行首次注册上线请求，使用获取 Andlink 云网关地址接口获取云网关地址，使用默认用户
*           信息向平台发起首次注册、上线请求
*       默认用户信息 User-Key：***   默认为：（CMCC-厂商名-deviceType）其中厂商名为全英文长度小于 32 字节。
*****************************************************************************/
extern unsigned char SIMCard_IMEI[25];
char Andlink_DeviceRegist(void)
{
    char ulheard[150] ={0};
//    char timestr[20]={0};
    char res = 0;
//    unsigned char *dataPtr = NULL;
    char  *p1,*p2;
//    char  poststr[500] = {0};
    cJSON *postdata5, *getvalue, *server_data5,*deviceInfo, *chiparray,*chipInfo;
    cJSON *resp_json, *item_json;
    
    char *send_data= NULL;
    char *user_key=NULL;
    int i = 0, j = 0;
    
    RealTime2Data.Year = 2000+Timebuf[0];
    RealTime2Data.Mon = Timebuf[1];
    RealTime2Data.Day = Timebuf[2];
    RealTime2Data.Hour = Timebuf[3];
    RealTime2Data.Min =  Timebuf[4];
    RealTime2Data.Second = Timebuf[5]; 
    TimeStamp = Date2timeStamp(RealTime2Data);
    
     postdata5  = cJSON_CreateObject();
	cJSON_AddStringToObject(postdata5,"deviceMac",(char *)SIMCard_IMEI);   //业务唯一标识：设备可根据实际业务需求上报 SN 值或真实 MAC 值(填写 MAC 时，全大写不带冒号)，必填
	cJSON_AddStringToObject(postdata5,"productToken", IOTPRODUCTTOKEN);//为设备在开发者门户注册的产品类型 Token，平台会检查该值的合法性，非法则不允许注册，必填
    cJSON_AddStringToObject(postdata5,"deviceType",IOTDEVICETYPE); //设备在开发者门户注册的产品类型码，必填
    
//    sprintf(timestr,"%lld", Date2timeStamp(RealTime2Data));
    cJSON_AddNumberToObject(postdata5,"timestamp",TimeStamp);  //时间戳，毫秒，必填
    cJSON_AddStringToObject(postdata5,"protocolVersion","V3.2");  //协议版本号，本协议版本默认填写：V3.2
    
    cJSON_AddItemToObject(postdata5,"deviceExtInfo",deviceInfo  = cJSON_CreateObject());
    cJSON_AddStringToObject(deviceInfo,"imei",(char *)SIMCard_IMEI); //设备唯一标识
    cJSON_AddNumberToObject(deviceInfo,"authMode",0); // 0 代表类型认证,1 代表设备认证,认证 ID 和密钥分别为 authId 和 productToken
//    cJSON_AddStringToObject(deviceInfo,"authId",MAC_ID); //需确认使用authId 还是 productToken？authId为智能设备安全认证唯一标识，数字家庭合作伙伴门户申请，一机一密设备必选, 
    cJSON_AddStringToObject(deviceInfo,"mac",MAC_ID); 
    cJSON_AddStringToObject(deviceInfo,"sn", Device_Info.CMCC_SN);   //设备真实 SN,必选  
//    cJSON_AddStringToObject(deviceInfo,"reserve",Device_Info.MAC_ID); //标记字段,可选
    cJSON_AddStringToObject(deviceInfo,"manuDate","20240523"); //设备生产日期,格式为:年-月，必填  Device_Info.MANUDATE  
    cJSON_AddStringToObject(deviceInfo,"OS","NONE"); //操作系统，android 9.0、Linux 2.6.18 等需包含操作系统版本号，必填，如不存在填 NONE
    
    cJSON_AddItemToObject(deviceInfo,"chips",chiparray  = cJSON_CreateArray());
    cJSON_AddItemToArray(chiparray,chipInfo=cJSON_CreateObject());
    cJSON_AddStringToObject(chipInfo,"type","4G");//芯片类型,Main/Wi-Fi/Zigbee/BLE 等，必填
    cJSON_AddStringToObject(chipInfo,"factory","Luat");//芯片厂商，必填
    cJSON_AddStringToObject(chipInfo,"model","Air720SG");//芯片型号，必填
    
    
//      send_data = cJSON_Print(postdata);
    send_data = cJSON_PrintUnformatted(postdata5);
//      printf("send_data=%s \r\n",send_data); 
#if 1
    memset(poststr,0,1024);
    user_key="CMCC-ibreezee-591217";
    sprintf(ulheard,"%sUser-Key:%s\r\n",URL_HEADER,user_key);
    HTTP_PostPkt(poststr,URL_REGISTADDRESS,URL_GETAHOST_IP,ulheard,send_data); // 打包http post数据
    GPRS_Send_Data(poststr,strlen(poststr));
    
    log_trace("bootarg post: [%s] \r\n", poststr);
    GPRS_Wait_Resp("}", 5);
    log_trace("bootarg resp: [%s] \r\n", ucUar3tbuf);
    resp_json = format_to_json(ucUar3tbuf);
    if (resp_json) {
        item_json = cJSON_GetObjectItem(resp_json, "respCode");
        if (item_json && 0 != item_json->valueint) {
            log_trace("bootstrap failed");
            res = 1;
        } else {           
            item_json = cJSON_GetObjectItem(resp_json, "gwToken");
            if (item_json) {
                strncpy(Andlink_GW_Info.gwToken, item_json->valuestring, sizeof(Andlink_GW_Info.gwToken));
            }
            item_json = cJSON_GetObjectItem(resp_json, "deviceId");
            if (item_json) {
                strncpy(Andlink_GW_Info.deviceID, item_json->valuestring, sizeof(Andlink_GW_Info.deviceID));
            }
            item_json = cJSON_GetObjectItem(resp_json, "deviceToken");
            if (item_json) {
                strncpy(Andlink_GW_Info.deviceToken, item_json->valuestring, sizeof(Andlink_GW_Info.deviceToken));
            }
            item_json = cJSON_GetObjectItem(resp_json, "andlinkToken");
            if (item_json) {
                strncpy(Andlink_GW_Info.andlinkToken, item_json->valuestring, sizeof(Andlink_GW_Info.andlinkToken));
            }
            item_json = cJSON_GetObjectItem(resp_json, "dmToken");
            if (item_json) {
                strncpy(Andlink_GW_Info.dmToken, item_json->valuestring, sizeof(Andlink_GW_Info.dmToken));
            }
            item_json = cJSON_GetObjectItem(resp_json, "userId");
            if (item_json) {
                Andlink_GW_Info.userId = item_json->valueint;
            }

            SaveAndlinkinfoToFlash();
            res =1;
            if(Flag_COMDebug == 1){
                log_trace("Andlink register sucess(bootstrap)\r\n");
                log_trace("gwToken： %s\r\n",Andlink_GW_Info.gwToken);
                log_trace("AdeviceId：%s\r\n",Andlink_GW_Info.deviceID); 
                log_trace("deviceToken：%s \r\n",Andlink_GW_Info.deviceToken); 
                log_trace("andlinkToken：%s \r\n",Andlink_GW_Info.andlinkToken); 
                log_trace("dmToken：%s \r\n",Andlink_GW_Info.dmToken);
                log_trace("userId:%d \r\n",Andlink_GW_Info.userId);                       
            }
            
            // check dmToken
            for (i = 0; i < strlen(Andlink_GW_Info.dmToken); i++) {
                for (j = 0; j < strlen(base64_table); j ++) {
                    if (Andlink_GW_Info.dmToken[i] == base64_table[j]) {
                        break;
                    }
                }
                if (j == strlen(base64_table)) {
                    log_trace("dmToken is not base64 string \r\n");
                    res = 0;
                    break;
                }
            }
            if (i == strlen(Andlink_GW_Info.dmToken)) {
                log_trace("dmToken is base64 string, check ok \r\n");
            }
        }         
        
        cJSON_Delete(resp_json);
    }
#endif
    ClearUSART3BUF();
    cJSON_Delete(postdata5);
    //cJSON_Delete(server_data5);
    
    if (send_data) {
        free(send_data);
    }
    
    return res ;
}


/****************************************************************************
*	函 数 名: isuke_DeviceOnline
*	功能说明: 获取当前是否绑定了用户，如果没绑定用户，直接清除配网信息
*	形    参：无
*	返 回 值: 1 绑定，0 未绑定
*   说    明：
*****************************************************************************/
char isuke_DeviceOnline(void)
{
	cJSON *postdata6, *getvalue, *server_data;
	char *send_data= NULL;	
	char ulheard[150] ={0};
	char coapip[16]={0};
    char str[20] ={0};
    char res = 0;
    uint8_t i = 0;
    int  array_size = 0;
    char  *p1,*p2;
//	char  poststr[500] = {0};
//	send_data=malloc(500);
	postdata6  = cJSON_CreateObject();
	cJSON_AddStringToObject(postdata6,"mac",MAC_ID);
	send_data = cJSON_PrintUnformatted(postdata6);
	if(Flag_COMDebug == 1)
		printf("send_data=%s \r\n",send_data); 
	
	memset(poststr,0,1024);
	
    sprintf(ulheard,"%sUser-Key:%s\r\n",URL_HEADER,Router_Info.user_key);
    HTTP_PostPkt(poststr,URL_BINDING,URL_GETAHOST_IP,URL_HEADER,send_data); // 打包http post数据
//	HTTP_PostPkt(poststr,URL_GETGWADDRESS1,URL_GETAHOST_IP,URL_HEADER,send_data); // 打包http post数据
    GPRS_Send_Data(poststr,strlen(poststr));
    
//	if(ESP8266_GetIPD(1000) != NULL)    //10s内反馈
//    {
//        p1 = strchr(WIFI_RX_BUFFER, '{');
//        p2 = strrchr(WIFI_RX_BUFFER, '}');
//        
//        if( (p1 != NULL)&&(p2 != NULL) )
//        {
//            memset(json_data,0,MAX_WIFIUART_LEN);
//            memcpy (json_data,p1,p2-p1+1);
//            if(Flag_COMDebug == 1)
//                printf("json:%s \r\n",json_data);  
//           server_data = cJSON_Parse(json_data);  //解析字符串 
//		   getvalue = cJSON_GetObjectItem(server_data, "bind");
//		   printf("getvalue[0]:%d\r\n",getvalue->valueint);
//		   if(getvalue->valueint == 1)
//		   {
//			   if(Flag_COMDebug == 1)
//					printf("有绑定用户!\r\n");
//				res =  1;
//		   }
//		   else
//		   {
//				if(Flag_COMDebug == 1)
//					printf("无绑定用户!复位:%s\r\n",getvalue->valuestring);
//				STMFLASH_SectorErase(FLASH_ServerInfoAddress);  //删除IP信息
//				STMFLASH_SectorErase(FLASH_VerifyInfoAddress);  //删除token信息
//				STMFLASH_SectorErase(FLASH_WIFIInfoAddress);
//				STMFLASH_SectorErase(FLASH_AndLinkInfoAddress);
//				NVIC_SystemReset();
//		   }
//        }       
//    }
//    else
//    {
//        if(Flag_COMDebug == 1)
//            printf("获取当前是否绑定了用户指令无响应!\r\n");
//       res =  0;
//    }
	
    ClearUSART3BUF();
    cJSON_Delete(postdata6);
    cJSON_Delete(server_data);
	free(send_data);
    return res ;
}

uint8_t rand_nums=0;
void generateRandomString(char* str, int length) 
{
    uint8_t i,num;
	rand_nums++;
	if(rand_nums>=255)
	{
		rand_nums=0;
	}
	srand(rand_nums);
//	srand((unsigned int)time(NULL));
 
    for(i = 0; i < length; i++) {
        num = rand() % 10;
        sprintf(str + i, "%d", num);
    }
 
    str[length] = '\0'; // 添加字符串结束标识
//	return *str;
}

/****************************************************************************
*	函 数 名: isuke_UserUnbind
*	功能说明: 用户解绑，并清除配网信息
*	形    参：无
*	返 回 值: 
*   说    明：
*****************************************************************************/
void isuke_UserUnbind(void)
{
    char send_data1[500];   
	char real_time_str[] = "00000000000000";  // 实时时间
	char str[9]; // 存储随机生成的数字字符串，最多8位
	char my_str[50];
    char deviceID[64] = {0};
    
    snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
    
    
//	printf("str:%s\r\nmy_str:%s\r\n",str,my_str);
    generateRandomString(str, 8);	
	sprintf(real_time_str, "20%02d%02d%02d%02d%02d%02d", Timebuf[0], Timebuf[1], Timebuf[2], Timebuf[3], Timebuf[4], Timebuf[5]);
	sprintf(my_str,"%s_%s_%s",deviceID,real_time_str,str);
    sprintf(send_data1,"{\\22deviceId\\22:\\22%s\\22,\\22eventType\\22:\\22Unbind\\22,\\22timestamp\\22:\\22%s\\22,\\22seqId\\22:\\22%s\\22,\\22deviceType\\22:\\22%s\\22,\\22mac\\22:\\22%s\\22}",
		deviceID,real_time_str,my_str,IOTDEVICETYPE,MAC_IDstring);

	sprintf(devPubTopic,"/device/%s/upward",deviceID);
//    MQTT_PUB(devPubTopic,send_data1);
	if(MQTT_PUB(devPubTopic,send_data1))   //发布成功
	{
		return;
	}
	else
	{
		MQTT_PUB(devPubTopic,send_data1);  //再发一次
	}
}

cJSON *format_to_json(char *str)
{
    char *p1, *p2;
    int ret;
    cJSON *root = NULL;
    char json_str[1024];
    int len = 0;
    
    if (!str) {
        return NULL;
    }
    
    p1 = strchr(str, '{');
    p2 = strrchr(str, '}');
    if (p1 && p2 && p2 > p1) {
        len = p2 - p1 + 1;
        if (sizeof(json_str) < len) {
            log_trace("error: len(%d) bigger then %d \r\n", len, sizeof(json_str));
            return root;
        } else {
            memset(json_str,0, sizeof(json_str));
            memcpy(json_str, p1, p2 - p1 + 1);
            
            root = cJSON_Parse(json_str);  //解析字符串
        }
    }
    
    return root;
    
}

/****************************************************************************
*	函 数 名: Andlink_DeviceOnline
*	功能说明: 设备上线
*	形    参：无
*	返 回 值: 1 获取成功，0 失败
*   说    明：
*****************************************************************************/
extern volatile uint8_t receive_unbind_flag;
char Andlink_DeviceOnline(void)
{
    char ulheard[150] ={0};
    char coapip[16]={0};
    char str[20] ={0};
    char res = 0;
    uint8_t i = 0;
    int  array_size = 0;
//    unsigned char *dataPtr = NULL;
    char  *p1,*p2;
//	char  poststr[1024] = {0};
     
    cJSON *postdata7, *getvalue, *server_data7,*xData,*pSub;
    
    char *send_data= NULL;
	char *user_key=NULL;
    cJSON *resp_json = NULL;
    cJSON *item_json = NULL;
//	send_data=malloc(500);
    char deviceID[64] = {0};
    
    snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
    
    RealTime2Data.Year = 2000+Timebuf[0];
    RealTime2Data.Mon = Timebuf[1];
    RealTime2Data.Day = Timebuf[2];
    RealTime2Data.Hour = Timebuf[3];
    RealTime2Data.Min =  Timebuf[4];
    RealTime2Data.Second = Timebuf[5]; 
    TimeStamp = Date2timeStamp(RealTime2Data); 
         
    postdata7  = cJSON_CreateObject();
    cJSON_AddStringToObject(postdata7,"deviceId",deviceID);   
    
    cJSON_AddStringToObject(postdata7,"deviceType",IOTDEVICETYPE); 
	cJSON_AddStringToObject(postdata7,"productToken", IOTPRODUCTTOKEN);
//    sprintf(str,"%d.%d.%d",HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER);
    memset(str,0,20);
    sprintf(str,"%d.%d.%d",SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER);
	cJSON_AddStringToObject(postdata7,"firmwareVersion",str);  //固件版本号
    cJSON_AddStringToObject(postdata7,"softwareVersion",str);  //软件版本号
    cJSON_AddStringToObject(postdata7,"protocolVersion","V3.2"); 
	if(receive_unbind_flag==1){
		cJSON_AddNumberToObject(postdata7,"userBind",0);  //设备当前绑定状态 0 表示未绑定、1 表示已绑定（真实用户）、2 表示默认用户信息绑定
		receive_unbind_flag=0;
	} else {
		cJSON_AddNumberToObject(postdata7,"userBind",1);  
	}
    cJSON_AddNumberToObject(postdata7,"bootType",1);  //boot 触发类型,1 为上电触发,0 为重试触发    
    cJSON_AddNumberToObject(postdata7,"timestamp",TimeStamp); 
//    cJSON_AddStringToObject(postdata7,"mac",MAC_ID); 
//	cJSON_AddStringToObject(postdata7,"sn","1860059121700000001");
    cJSON_AddItemToObject(postdata7,"XData",xData  = cJSON_CreateObject()); //Xdata为不同类型设备的扩展属性，为空json

    
//      send_data = cJSON_Print(postdata);
    send_data = cJSON_PrintUnformatted(postdata7);
      printf("send_data=%s \r\n",send_data); 
 #if 1
    memset(poststr,0,1024);
    user_key="CMCC-ibreezee-591217";
    sprintf(ulheard,"%sUser-Key:%s\r\n",URL_HEADER,user_key);
    HTTP_PostPkt(poststr,URL_ONLINEADDRESS,URL_GETAHOST_IP,ulheard,send_data); // 打包http post数据
//	HTTP_PostPkt(poststr,URL_GETGWADDRESS1,URL_GETAHOST_IP,URL_HEADER,send_data); // 打包http post数据
    GPRS_Send_Data(poststr,strlen(poststr));
    
    GPRS_Wait_Resp("}", 5);
    
    resp_json = format_to_json(ucUar3tbuf);
    if (resp_json) {
        item_json = cJSON_GetObjectItem(resp_json, "respCode");
        if (item_json && 0 != item_json->valueint) {
            log_trace("Andlink online failed(boot) \r\n");
        } else {
            log_trace("Andlink online success(boot) \r\n");
            res = 1;
        }
        cJSON_Delete(resp_json);
    }
    
#endif
    ClearUSART3BUF();
    cJSON_Delete(postdata7);
    //cJSON_Delete(server_data7);
    if (send_data) {
        free(send_data);
    }
    return res ;
}
/****************************************************************************
*	函 数 名: TerminalManageDataReport
*	功能说明: 终端管理数据上报
*	形    参：无
*	返 回 值: 1 获取成功，0 失败
*   说    明：设备在成功完成 8.2.4 节设备上线之后根据本节要求完成终端管理数据上报，完成首次
*  上报后设备以 24 小时以内的随机时间点作为后续终端管理数据上报的时间节点，设备需每
* 天按该时间节点周期性上报。在出现设备上线反复执行的异常情况下，终端管理数据上报一
* 天不超过 3 次，
*****************************************************************************/
char TerminalManageDataReport(void)
{
    char urlHeader[150] ={0};
	char *cmcVersion;
    char WLAN_MAC[20]={0};
    char str[20] ={0};
    char res = 0;
    char rssi[5] = {0};
//    unsigned char *dataPtr = NULL;
    char  *p1,*p2;
    char ip[16]={0};
    cJSON *postdata8,*item,*getvalue, *server_data8,*versionarray,*cmccVersion;
    char *user_key=NULL;
	char *dmToken1=NULL;
    char *send_data= NULL;
    cJSON *resp_json, *item_json;
//	char  poststr[500] = {0};
//    send_data=malloc(500);
    char deviceID[64] = {0};
    
    snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);

    sprintf(rssi,"%d",CSQNual*2-113);  
       
//     WIFI_Query_LocalIP();
       
//    sprintf(ip,"%d.%d.%d.%d",Local_IP[0],Local_IP[1],Local_IP[2],Local_IP[3]);    
//    sprintf(urlHeader,"%sUser-Key:%s\r\ndmToken:%s\r\n",URL_HEADER,Router_Info.user_key,Andlink_GW_Info.dmToken);
	user_key="CMCC-ibreezee-591217";
//	dmToken1="eA3GlHsBqI9b0BU927UyE5YQ71rOyktQkpMAYbFzdKI=";
	dmToken1 = Andlink_GW_Info.dmToken;
    snprintf(urlHeader, sizeof(urlHeader), "%sUser-Key:%s\r\ndmToken:%s\r\n",URL_HEADER,user_key,dmToken1);
    RealTime2Data.Year = 2000+Timebuf[0];
    RealTime2Data.Mon = Timebuf[1];
    RealTime2Data.Day = Timebuf[2];
    RealTime2Data.Hour = Timebuf[3];
    RealTime2Data.Min =  Timebuf[4];
    RealTime2Data.Second = Timebuf[5]; 
    TimeStamp = Date2timeStamp(RealTime2Data);
//	WIFI_wlanMAC(WLAN_MAC);    
	postdata8  = cJSON_CreateObject();
	cJSON_AddItemToObject(postdata8, "deviceId", cJSON_CreateString(deviceID));
	cJSON_AddItemToObject(postdata8, "deviceType", cJSON_CreateString(IOTDEVICETYPE));
	cJSON_AddItemToObject(postdata8, "timestamp", cJSON_CreateNumber(TimeStamp));
	sprintf(str,"%d.%d.%d",SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER);
	cJSON_AddItemToObject(postdata8, "firmwareVersion", cJSON_CreateString(str));
	cJSON_AddItemToObject(postdata8, "softwareVersion", cJSON_CreateString(str));
	cJSON_AddItemToObject(postdata8, "cmei", cJSON_CreateString((char *)SIMCard_IMEI));
	cJSON_AddItemToObject(postdata8, "mac", cJSON_CreateString(MAC_ID));
	cJSON_AddItemToObject(postdata8, "sn", cJSON_CreateString(Device_Info.CMCC_SN)); //Device_Info.CMCC_SN
	cJSON_AddItemToObject(postdata8, "OS", cJSON_CreateString("NONE"));
	cJSON_AddItemToObject(postdata8, "cmccVersion", item = cJSON_CreateObject());
	cJSON_AddItemToObject(item, "andlinkVersion", cJSON_CreateString("protocol")); 
	cJSON_AddItemToObject(item, "anddmVersion", cJSON_CreateString("protocol"));
	cJSON_AddItemToObject(postdata8, "cpuModel", cJSON_CreateString("N32G452CCL7"));
	cJSON_AddItemToObject(postdata8, "romStorageSize", cJSON_CreateString("512K"));
	cJSON_AddItemToObject(postdata8, "ramStorageSize", cJSON_CreateString("144K"));
	cJSON_AddItemToObject(postdata8, "networkType", cJSON_CreateString("4G"));
	cJSON_AddItemToObject(postdata8, "locationInfo", cJSON_CreateString("NONE"));
	cJSON_AddItemToObject(postdata8, "deviceVendor", cJSON_CreateString("isuke"));
	cJSON_AddItemToObject(postdata8, "deviceBrand", cJSON_CreateString("ibreezee"));
	cJSON_AddItemToObject(postdata8, "deviceModel", cJSON_CreateString("CC08-G"));
	cJSON_AddItemToObject(postdata8, "wlanMac", cJSON_CreateString(WLAN_MAC));
	cJSON_AddItemToObject(postdata8, "powerSupplyMode", cJSON_CreateString("USB"));
//	cJSON_AddItemToObject(postdata8, "wifiRssi", cJSON_CreateString(rssi));
	cJSON_AddItemToObject(postdata8, "deviceIP", cJSON_CreateString("NONE"));
		
	cJSON_AddItemToObject(postdata8, "deviceManageExtInfo", item =  cJSON_CreateObject());

    send_data = cJSON_PrintUnformatted(postdata8);
    //printf("send_data=%s \r\n",send_data); 
 #if 1
    memset(poststr,0,1024);
    HTTP_PostPkt(poststr,URL_REPORTADDRESS,URL_GETAHOST_IP,urlHeader,send_data); // 打包http post数据
    GPRS_Send_Data(poststr,strlen(poststr));
    log_trace("poststr=[%s] \r\n",poststr); 
    GPRS_Wait_Resp("}", 5);
    resp_json = format_to_json(ucUar3tbuf);
    if (resp_json) {
        item_json = cJSON_GetObjectItem(resp_json, "respCode");
        if (item_json && 0 != item_json->valueint) {
            log_trace("Andlink termina data report failed(dmReport) \r\n");
        } else {
            log_trace("Andlink termina data report success(dmReport) \r\n");
            res = 1;
        }
        cJSON_Delete(resp_json);
    }
    
#endif
    ClearUSART3BUF();
    cJSON_Delete(postdata8);
//	cJSON_Delete(item);
    //cJSON_Delete(server_data8);
    if (send_data) {
        free(send_data);
    }
    return res ;
}
/****************************************************************************
*	以下为MQTT连接相关定义
*****************************************************************************/
char *devSubTopic[]={"/device/CMCC-591217-123456789001/downward000000000000000"};
char devPubTopic[50] ;
char testamentTopic[50] ={0};

/****************************************************************************
*	函 数 名: MQTTLink_iSukeServer
*	功能说明: 向苏仁转发服务器发送MQTT连接参数
*	形    参：无
*	返 回 值: 
*   说    明：
*****************************************************************************/
void MQTTLink_iSukeServer(void)
{
     cJSON *postdata;
    char *send_data= NULL;
    char mqttlinkpara[100] = {0};
	char cmd[100]={0};
//    char  poststr[500] = {0};
//	send_data=malloc(500);
//MQTT_TCP_connect();
//    MQTT_Close();
    char deviceID[64] = {0};
    
    snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);

    sprintf(mqttlinkpara,"/device/%s",deviceID);
    postdata  = cJSON_CreateObject();
    cJSON_AddStringToObject(postdata,"topic",mqttlinkpara); 

    send_data = cJSON_PrintUnformatted(postdata);
    
    memset(poststr,0,1024);
    HTTP_PostPkt(poststr,MQTT_ISUKEADDRESS,URL_GETAHOST_IP,URL_HEADER,send_data); // 打包http post数据
    

//    if(WIFI_Set_TCPConnectIP(MQTT_FORWARD,MQTTPARA_HOST_PORT)==WIFI_SUCCESS) //MQTT测试服务器
//    {
//        if(Flag_COMDebug == 1)
//            printf("iSuke MQTT 参数转发服务器已连接\r\n");
//    }
	
//	GPRS_CloseSocket();
Connect_DM_Server();
	ClearUSART3BUF();
	sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",MQTT_FORWARD,MQTTPARA_HOST_PORT); 
	UART3_SendString(cmd);
	delay_ms(200);
    
	GPRS_Send_Data(poststr,strlen(poststr));
    ClearUSART3BUF();
    cJSON_Delete(postdata);
	free(send_data);
}
/****************************************************************************
*	函 数 名: Andlink_MQTT_Link
*	功能说明: 创建MQTT连接
*	形    参：无
*	返 回 值: 1-成功	0-失败
*   说    明：
*****************************************************************************/
char Andlink_MQTT_Link(void)
{
    MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};					//协议包

	unsigned char *dataPtr;
	cJSON *postdata;
    
    char *send_data= NULL;
    
	char status = 1;
   char cmd[100]={0};
//    send_data=malloc(500);
    char deviceID[64] = {0};
    
    snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
    
    RealTime2Data.Year = 2000+Timebuf[0];
    RealTime2Data.Mon = Timebuf[1];
    RealTime2Data.Day = Timebuf[2];
    RealTime2Data.Hour = Timebuf[3];
    RealTime2Data.Min =  Timebuf[4];
    RealTime2Data.Second = Timebuf[5]; 
    TimeStamp = Date2timeStamp(RealTime2Data);
    
    sprintf(testamentTopic,"/device/%s/upward",deviceID);
    
    postdata  = cJSON_CreateObject();
    cJSON_AddStringToObject(postdata,"deviceId",deviceID);  
    cJSON_AddStringToObject(postdata,"eventType","Offline");
	cJSON_AddStringToObject(postdata,"mac",MAC_ID);
    cJSON_AddNumberToObject(postdata,"timestamp",TimeStamp); 
    send_data = cJSON_PrintUnformatted(postdata);

        
	GPRS_CloseSocket();
	ClearUSART3BUF();
	sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",URL_MQTT_IP,MQTT_HOST_PORT); 
	UART3_SendString(cmd);

    MQTT_Link_Info.mqttKeepalive = 10; //该值影响服务器离线指令的响应时间，但是不是很准确的以秒为单位
	if(MQTT_PacketConnect("sleepace", "sleepace2022.", deviceID, MQTT_Link_Info.mqttKeepalive, 0, MQTT_QOS_LEVEL0, testamentTopic, send_data, 0, &mqttPacket) == 0)	
	{
        GPRS_Send_Data((char *)mqttPacket._data,mqttPacket._len);//上传平台
        if(Flag_COMDebug == 1)
		{
            printf("服务器账号验证通过,等待响应.....\r\n");
		}
	}
	MQTT_DeleteBuffer(&mqttPacket);								//删包   
		
    cJSON_Delete(postdata);
    if (send_data) {
        free(send_data);
    }
	return status;
}
/****************************************************************************
*	函 数 名: Andlink_Subscribe
*	功能说明: 订阅
*	形    参：无
*	返 回 值: 
*   说    明：
*****************************************************************************/
// void Andlink_Subscribe(void)
// {
// 	char str[100]={0},i;
//     const char *deubTopic[] = {"/device/%s/downward",MY_DEVICEID};
// 	MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};						   //协议包	
//     char deviceID[64] = {0};
    
//     snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
    
//     sprintf(str,"/device/%s/downward",deviceID);
// //    memset(devSubTopic,0,sizeof(devSubTopic));
// //	strcpy(*devSubTopic,str);
     
//     if(Flag_COMDebug == 1)
//         printf("MQTT Subscribe,topic is:%s\r\n ",str);
    
// 	if(MQTT_PacketSubscribe(MQTT_SUBSCRIBE_ID, MQTT_QOS_LEVEL0, deubTopic, 1, &mqttPacket) == 0)
// 	{
//         GPRS_Send_Data((char *)mqttPacket._data,mqttPacket._len);  //向平台发送订阅请求
// 		MQTT_DeleteBuffer(&mqttPacket);							  //删包
// 	}
    
// }
//==========================================================
//	函数名称：	OneNet_Subscribe
//
//	函数功能：	订阅
//
//	入口参数：	topics：订阅的topic
//				topic_cnt：topic个数
//
//	返回参数：	SEND_TYPE_OK-成功	SEND_TYPE_SUBSCRIBE-需要重发
//
//	说明：		
//==========================================================
void OneNet_Subscribe(char *topics[], unsigned char topic_cnt)
{
	unsigned char i = 0;
	MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};							//协议包
	
//	for(; i < topic_cnt; i++)
//		printf("Subscribe Topic: %s\r\n", topics[i]);
	
	if(MQTT_PacketSubscribe(MQTT_SUBSCRIBE_ID, MQTT_QOS_LEVEL0, topics, topic_cnt, &mqttPacket) == 0)
	{
        GPRS_Send_Data((char *)mqttPacket._data,mqttPacket._len);
		MQTT_DeleteBuffer(&mqttPacket);											//删包
	}
}
/****************************************************************************
*	函 数 名: Andlink_Publish
*	功能说明: 发布消息
*	形    参：无
*	返 回 值: 
*   说    明：
*****************************************************************************/
char Andlink_Publish( char *topic,char *msg)
{
	char res = 0;
    MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};							//协议包	
//	printf("Publish Topic: %s, Msg: %s\r\n", topic, msg);
    if(MQTT_PacketPublish(MQTT_PUBLISH_ID, topic, msg, strlen(msg), MQTT_QOS_LEVEL0, 0, 1, &mqttPacket) == 0)
	{
        res = GPRS_Send_Data((char *)mqttPacket._data,mqttPacket._len);	
		MQTT_DeleteBuffer(&mqttPacket);											//删包
	}
	return res;
}
/****************************************************************************
*	函 数 名: Andlink_MQTT_Online
*	功能说明: MQTT上线通知
*	形    参：无
*	返 回 值: 
*   说    明：
*****************************************************************************/
void Andlink_MQTT_Online(void)
{
    cJSON *postdata;
    char res = 0,res1 = 0;
    char *send_data= NULL;
//    send_data=malloc(500);
	char cmd[100]={0};
    char deviceID[64] = {0};
    
    snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
    
    RealTime2Data.Year = 2000+Timebuf[0];
    RealTime2Data.Mon = Timebuf[1];
    RealTime2Data.Day = Timebuf[2];
    RealTime2Data.Hour = Timebuf[3];
    RealTime2Data.Min =  Timebuf[4];
    RealTime2Data.Second = Timebuf[5]; 
    TimeStamp = Date2timeStamp(RealTime2Data);
    
    postdata  = cJSON_CreateObject();
	cJSON_AddStringToObject(postdata,"function", "eventType");
    cJSON_AddStringToObject(postdata,"deviceId",deviceID);  
	cJSON_AddStringToObject(postdata,"mac",MAC_ID);   //增加MAC号
    cJSON_AddStringToObject(postdata,"eventType","MBoot"); 
    cJSON_AddNumberToObject(postdata,"timestamp",TimeStamp);  
    cJSON_AddStringToObject(postdata,"deviceType", IOTDEVICETYPE);
    
    send_data = cJSON_PrintUnformatted(postdata);
    
//	GPRS_CloseSocket();
//	ClearUSART3BUF();
//	sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",URL_MQTT_IP,MQTT_HOST_PORT); 
//	UART3_SendString(cmd);
    
    sprintf(devPubTopic,"/device/%s/upward",deviceID);
    
    res = Andlink_Publish(devPubTopic,send_data);
    if(res != 1)
	{
		res1 = Andlink_Publish(devPubTopic,send_data);  //重发
		if(res1 != 1){
            SaveSoftRebootFlagToFlash();
            delay_ms(1000);
            NVIC_SystemReset(); //复位
        }
			
	}
     cJSON_Delete(postdata);
    if (send_data) {
        free(send_data);
    }
    
    log_trace("Andlink mqtt Mboot success \r\n");
    // if(Flag_COMDebug == 1)
    //     printf("MQTT 发布上线消息\r\n ");
}

/****************************************************************************
*	函 数 名: Andlink_MQTT_Offline
*	功能说明: MQTT离线通知
*	形    参：无
*	返 回 值: 
*   说    明：
*****************************************************************************/
void Andlink_MQTT_Offline(void)
{
    cJSON *postdata;
    
    char *send_data= NULL;
    char deviceID[64] = {0};
    
    snprintf(deviceID, sizeof(deviceID), "CMCC-%s-%s", IOTDEVICETYPE, Device_Info.CMCC_CMEI);
    
    send_data=malloc(500);
    RealTime2Data.Year = 2000+Timebuf[0];
    RealTime2Data.Mon = Timebuf[1];
    RealTime2Data.Day = Timebuf[2];
    RealTime2Data.Hour = Timebuf[3];
    RealTime2Data.Min =  Timebuf[4];
    RealTime2Data.Second = Timebuf[5]; 
    TimeStamp = Date2timeStamp(RealTime2Data);
    
    postdata  = cJSON_CreateObject();
    cJSON_AddStringToObject(postdata,"deviceId",deviceID);  
    cJSON_AddStringToObject(postdata,"eventType","Offline"); 
    cJSON_AddNumberToObject(postdata,"timestamp",TimeStamp); 
	
     
    send_data = cJSON_PrintUnformatted(postdata);
    
     
    Andlink_Publish(devPubTopic,send_data);
     cJSON_Delete(postdata);
	 free(send_data);
    if(Flag_COMDebug == 1)
        printf("MQTT 发布离线消息\r\n ");
}

/****************************************************************************
*	函 数 名: Andlink_MQTT_RevPro
*	功能说明: MQTT数据返回处理
*	形    参：无
*	返 回 值: 
*   说    明：
*****************************************************************************/
void Andlink_MQTT_RevPro(unsigned char *cmd)
{

    MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};								//协议包

    char *req_payload = NULL;
    char *cmdid_topic = NULL;
	char *time = NULL;

    unsigned short topic_len = 0;
    unsigned short req_len = 0;

    unsigned char type = 0;
    unsigned char qos = 0;
    static unsigned short pkt_id = 0;

    short result = 0;

    char numBuf[12];
    int num = 0;

    cJSON *json ;

    type = MQTT_UnPacketRecv(cmd);
    switch(type)
    {
        case MQTT_PKT_CMD:															//命令下发

            result = MQTT_UnPacketCmd(cmd, &cmdid_topic, &req_payload, &req_len);	//解出topic和消息体
            if(result == 0)
            {
                printf("cmdid: %s, req: %s, req_len: %d\r\n", cmdid_topic, req_payload, req_len);

                MQTT_DeleteBuffer(&mqttPacket);									//删包
            }
            break;

        case MQTT_PKT_PUBLISH:			//接收的Publish消息，根据实际协议进行修改

            result = MQTT_UnPacketPublish(cmd, &cmdid_topic, &topic_len, &req_payload, &req_len, &qos, &pkt_id);
            if(result == 0)
            {
                printf("topic: %s, topic_len: %d, payload: %s, payload_len: %d\r\n",
                            cmdid_topic, topic_len, req_payload, req_len);
				if(strstr(req_payload,"sync_time") != NULL)   //校时  
				{
					time = strstr(req_payload,"extra");
					for(num=0;num<12;num++)
					{
						numBuf[num] = time[num+10] - 0x30;
					}
					for(num=0;num<6;num++)  //获取服务器时间
					{
						Timebuf[num] = (numBuf[num*2])*10+(numBuf[num*2+1]); //将ASCII字符的两个字节的时间转换为1个字节的时间		 
					}
					if((Timebuf[1]>12)||(Timebuf[2]>31))
					{
						printf("time is error,restart!");
						NVIC_SystemReset();
					}
//					HeartBeat = 0;
					printf("Renew Server time is:%d-%d-%d %d:%d:%d\r\n",Timebuf[0],Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5]);
				}
//				if(strstr(req_payload,"Unbind") != NULL)   //解绑  
//				{
//					printf("得到解绑指令 \r\n");
//					STMFLASH_SectorErase(FLASH_ServerInfoAddress);  //删除IP信息
//					STMFLASH_SectorErase(FLASH_VerifyInfoAddress);  //删除token信息
//					STMFLASH_SectorErase(FLASH_WIFIInfoAddress);
//					STMFLASH_SectorErase(FLASH_AndLinkInfoAddress);
//					NVIC_SystemReset();
//				}
				if(strstr(req_payload,"test") != NULL) 
				{
					printf("只是测试 \r\n");
				}
				cJSON_Delete(json);
            }
            break;
		case MQTT_PKT_PUBACK:														//发送Publish消息，平台回复的Ack
		
			if(MQTT_UnPacketPublishAck(cmd) == 0)
				printf("Tips:	MQTT Publish Send OK\r\n");
		break;
		
		default:
			result = -1;
		break;
	}
	
	ClearUSART3BUF();									//清空缓存
	
	if(result == -1)
		return;

	if(type == MQTT_PKT_CMD || type == MQTT_PKT_PUBLISH)
	{
		MQTT_FreeBuffer(cmdid_topic);
		MQTT_FreeBuffer(req_payload);
	}

}