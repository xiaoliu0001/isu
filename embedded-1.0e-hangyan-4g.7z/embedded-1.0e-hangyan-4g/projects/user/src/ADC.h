/******************************************************************************
 * @file     ADC.H
 * @brief   ADC采样
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par     ADC采样  严斌 2016
*******************************************************************************/
#ifndef __ADC_H_
#define __ADC_H_

#include "main.h"
#include "Parameter.h"

#define ADC_NOFCHANEL     2


// ADC DR寄存器宏定义，ADC转换后的数字值则存放在这里
#define ADC2_DR_ADDR    ((u32)ADC2+0x40)


void ADC_Comfig(void);
uint16_t GetADCData(void);
void ADC_GPIO_Comfig(void);
void Delay(unsigned int us);
void ADC2_Mode_Config(void);


#endif
