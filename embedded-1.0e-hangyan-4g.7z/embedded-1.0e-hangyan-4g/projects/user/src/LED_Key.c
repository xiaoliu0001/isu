/******************************************************************************
 * @file     LED_Key.C
 * @brief   按键以及LED配置
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par       严斌 2016
*******************************************************************************/

#include "LED_Key.h"
#include "GPRS.h"

__IO uint8_t flag=0x0;

/****************************************************************************
*	函 数 名: delay_ms_YB
*	功能说明: 延时
*	形    参：无
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void delay_ms_YB(void)
{
	unsigned int ms=5000;
	int i;
	while(ms--)                                
	{
		for(i = 0; i < 120; i++); //内部晶振
//		for(i = 0; i < 1000; i++);
	}
}
/****************************************************************************
*	函 数 名: delay_ms_YB2
*	功能说明: 延时
*	形    参：无
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void delay_ms_YB2(void)
{
	unsigned int ms=500;
	int i;
	while(ms--)                                
	{
		for(i = 0; i < 120; i++); //内部晶振
//		for(i = 0; i < 1000; i++);
	}
}
/****************************************************************************
*	函 数 名: LED_Init
*	功能说明: LED初始化
*	形    参：无
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void LED_Init(void)
{
	GPIO_InitType GPIO_InitStruct;

	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);

	GPIO_InitStruct.Pin =LED2_PIN;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO, ENABLE);
	GPIO_ConfigPinRemap(GPIO_RMP_SW_JTAG_SW_ENABLE, ENABLE);

	GPIO_InitPeripheral(LED_GPIO_PORT, &GPIO_InitStruct);


}









