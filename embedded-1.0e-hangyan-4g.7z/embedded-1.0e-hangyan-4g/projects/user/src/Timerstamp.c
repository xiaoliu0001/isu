/******************************************************************************
 * @file     Timerstamp.h
 * @brief   获取时间戳
 * @version  v1.0
 * @date     2023.05.31
 * @note
 * Copyright (C)  张炜 2023
 *
 * @par      
 *    V1.0    
*******************************************************************************/

#include "Timerstamp.h"
#include "USART.h"

Date specialTime = {
        2000,
        01,
        01,
        00,
        00,
        00
};
//31 : 1  3 5 7 8 10 12 ; 30 : 4 6 9 11
const int daysofmon[] ={0,
                  31 * SECONDS_IN_A_DAY,
                  (28 + 31) * SECONDS_IN_A_DAY,
                  (31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (30 + 31 + 28 + 31 ) * SECONDS_IN_A_DAY,
                  (31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (31 + 31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (30 + 31 + 31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY,
                  (30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 + 28 + 31) * SECONDS_IN_A_DAY
                  };
const int _daysofmon[] ={0,
                        31 * SECONDS_IN_A_DAY,
                        (29 + 31) * SECONDS_IN_A_DAY,
                        (31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (30 + 31 + 29 + 31 ) * SECONDS_IN_A_DAY,
                        (31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (31 + 31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (30 + 31 + 31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY,
                        (30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31 + 29 + 31) * SECONDS_IN_A_DAY
};

/****************************************************************************
*	函 数 名: GetTimestamp
*	功能说明: 获取时间戳数据
*	形    参：无
*	返 回 值: 
*   说    明： 获取的时间戳单位为s
*****************************************************************************/
uint64_t Date2timeStamp(Date standardTime)
{
	int i;
    //需要计算 传进来的 standardTime 比 specialTime 大多少秒
    uint64_t differenceValue = 0;     //定义这个差值，单位为秒
    int leapYears = 0;

    if((standardTime.Year < specialTime.Year) || (standardTime.Year > 2099))//不允许 specialTime.Year 之前的时间传进来
    {
        printf("The year %d is not supported\r\n",standardTime.Year);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Mon < 1) || (standardTime.Mon > 12))//不允许 无效的mon 传入
    {
        printf("The month %.2d is out of line\r\n",standardTime.Mon);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Day < 1) || (standardTime.Day > 31))//不允许 无效的day 传入
    {
        printf("The day %.2d is out of line\r\n",standardTime.Day);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Hour < 0) || (standardTime.Hour > 24))//不允许 无效的hour 传入
    {
        printf("The hour %.2d is out of line\r\n",standardTime.Hour);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Min < 0) || (standardTime.Min > 59))//不允许 无效的min 传入
    {
        printf("The min %.2d is out of line\r\n",standardTime.Min);
        return SPECIALTIMESTAMP;
    }
    if((standardTime.Second < 0) || (standardTime.Second > 59))//不允许 无效的sec 传入
    {
        printf("The sec %.2d is out of line\r\n",standardTime.Second);
        return SPECIALTIMESTAMP;
    }


    //从 specialTime 开始，到 standardTime 的前一年之间有过少个闰年
    for( i = specialTime.Year; i < standardTime.Year; i++)
    {
        if((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0))
        {
            leapYears++;
        }
    }
    differenceValue += (SECONDS_IN_A_LEAP_YEAR * leapYears +
            SECONDS_IN_A_COMMON_YEAR * (standardTime.Year - specialTime.Year - leapYears));
    //判断 是不是闰年
    if((standardTime.Year % 4 == 0 && standardTime.Year % 100 != 0) || (standardTime.Year % 400 == 0))  
    {
        differenceValue += (_daysofmon[standardTime.Mon - 1] +
                            (standardTime.Day - 1) * SECONDS_IN_A_DAY +
                            (standardTime.Hour ) *  SECONDS_IN_AN_HOUR +
                            (standardTime.Min ) * SECONDS_IN_A_MINUTE +
                            standardTime.Second);
    }else
    {
        differenceValue += (daysofmon[standardTime.Mon - 1] +
                           (standardTime.Day - 1) * SECONDS_IN_A_DAY +
                           (standardTime.Hour) *  SECONDS_IN_AN_HOUR +
                           (standardTime.Min) * SECONDS_IN_A_MINUTE +
                           standardTime.Second
                           );
    }
    differenceValue += SPECIALTIMESTAMP;
    return differenceValue;
}
