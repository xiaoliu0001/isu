/**************************************************************************/
/* Algorithm Engineer:    		liuwen 									  */
/* Date:						20160929								  */
/* Name:					BERpara.c									  */
/**************************************************************************/
#ifndef BERPARA_H
#define BERPARA_H

#ifndef U8
#define U8 unsigned char 
#endif
#ifndef S8
#define S8 signed char
#endif	
#ifndef U16
#define U16 unsigned short
#endif	
#ifndef S16
#define S16 signed short
#endif	
#ifndef U32
#define U32 unsigned int
#endif	
#ifndef S32
#define S32 signed int
#endif	
#ifndef BOOL
#define BOOL unsigned char
#endif
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#ifndef SampleRate
#define SampleRate	50
#endif

#ifndef TS
#define	TS	10*SampleRate
#endif
#ifndef TM
#define TM	1*SampleRate
#endif

#ifndef Is
#define Is 2*SampleRate
#endif

#ifndef RW
#define RW 8*SampleRate
#endif

#ifndef GrogshopFlag
#define GrogshopFlag FALSE		//酒店
#endif

#ifndef	BeiGuSleep
#define BeiGuSleep FALSE//贝骨睡眠带心率算法
#endif

#ifndef SHrv
#define SHrv 5*60*SampleRate        //7500
#endif

#ifndef HRG
#define HRG 5*SampleRate
#endif

#ifndef LHrv
#define LHrv 12*60*60/5             //8640
#endif

#ifndef Int5m
#define Int5m 5            
#endif

//for HR 贝骨
#ifndef	window
#define window 10*SampleRate		//进行10s窗口数据的峰谷查找
#endif
#ifndef PTn
#define PTn  4		//峰谷信息保存数据大小
#endif
#ifndef NG
#define NG 5		//NG个点分析心跳值
#endif
#ifndef	kks
#define kks 5		//平滑窗口大小
#endif
/*-------------------------------------------------------*/
//定义全局变量
extern	U8		RRH;
extern	U8		RRL;
extern	U8		HRH;
extern	U8		HRL;

extern	U8 		g1sFlag;

extern	U16 	gdatas;	//原始数据初次滤波结果基线需要
extern 	U16     SampleData; // 原始采集的数据
extern	U16	    SampleBase;	//采样基线
extern	S32	    SampleEcg;	//去基线后的心跳波形数据
extern  S32     SampleBreath; //去基线后的波形数据

extern 	S32     RespData;     // 呼吸波形数据
extern 	S32     EcgData;     //心电波形数据
extern	S32		Ecg_Data;	//有无人判断
extern 	U8 	    RR;     // 呼吸率
extern 	U8 	    HR;     // 心率

extern  U32 	gTimes;	//翻身时间计数
extern  U8 	    TurnTimes;	//翻身次数
extern	U8      gTurnFlag;	//统计5s内是否翻身的标志
// 20150911
extern	U8	    gTimeTurnFlag;	//实时体动监测，与有无人无关，无延时处理
extern	U8		gTimeWinFlag;	//实时体动监测，饱和窗口的体动信息
extern	U8		gTimeAFlag;		//实时体动监测，幅度跳变体动标志
extern	U8		gT1sCount;//实时体动，1s持续计数
//
extern 	U8	    gTurnLastFlag;	//翻身持续与否的标志
extern  U16	    gTurntimeThMax;	//翻身信号阈值最大
extern 	U16	    gTurntimeThMin;	//翻身信号阈值最小
extern  U16     gNoFirst;		//翻身统计初始值
extern 	U8	    gPeopleHR;			//判断床上是否有人的阈值
extern 	U8	    gPeopleRR;			//判断床上是否有人的阈值
extern 	U8	    gPeopleFlag;		//床上有人的标志(ture有人)
extern	U32		gNoNumber;		//从无人到有人的计数器

extern	S16	    gPeopleDataRR[5*SampleRate];	//连续存储50个数据的判断判断床上有人
extern	S16	    gPeopleDataHR[5*SampleRate];	//连续存储50个数据的判断
//extern	S16	gPeopleDataRR[250];	//调整  727
//extern	S16	gPeopleDataHR[250];	//调整  727
extern S16		gWakeupDataHR[50];
extern U8		gWakeupFlag;	//唤醒标志

//	呼吸暂停相关变量
extern 	U8	    gTurnRespFlag;		//呼吸暂停的翻身后非检测标志
extern	U8	    gRRFlag;			//前面有N个呼吸后才进行呼吸暂停判断
extern	U8  	gRRData[25];		//存储当前以及之前的10个呼吸数据判断呼吸暂停
extern	U16	    gTSF;				//翻身后开始计时计数器
extern 	U8  	gRespStopFlag;	//呼吸暂停标志
extern	U8	    gRespStopDataRR[16];	//连续存储15s数据判断呼吸暂停每秒1个数
extern	U8	    gRespStopDataHR[16];	//连续存储15s数据判断心跳情况

/*-------------------------------------------------------------------*/
//呼吸相关变量
extern 	U8 		gPulseRateRR;			//呼吸值
extern	U8		gRespRR;				//呼吸暂停时的呼吸 实时值
extern	U16   	gCountRR;				//采样点计数
extern	U8 		gWaveHeadRR;			//头指针
extern	U8		gWaveTailRR;			//尾指针
extern	S16 	gWaveBufRR[70];		            //呼吸保存70个数据
extern	S16 	gWaveSlopeBufRR[70];	            //斜率数组
extern	S16 	gPeakBufRR[5];				        //存储峰值
extern	U16 	gPeakSampleRR[5];			//存储峰值对应位置
extern	U16 	gSampleTimeRR[5];			//采样间距存储
extern	U16 	gSamplePulseValRR[5];      //脉率均值15--10
extern	U8 		gFengCountRR;				//峰值个数计数
extern	U8  	gSlopFlagRR;				//波形标志，0上升，1下降
extern	U8  	gabsRR0;					//斜率判断趋于0的阈值
extern	BOOL    gFengFlagRR;            //找到峰值标志

extern	U16 	gSamplePrValCountRR;
extern 	U16 	gSampleMinRR;		//峰值间距最小值		对应呼吸约5次/min
extern 	U16 	gSampleMaxRR;		//峰值间距最大值		对应呼吸率30次/min
/*--------------------------------------------------------------------*/

#if GrogshopFlag
/*--------------------------------------------------------------------*/
//for 深浅睡眠
extern	U8		gSleepStateFlag;	// -(0无人；1---上床;2---离床;4---浅睡眠;=8---深睡眠;)
extern	U8		gLateFlag;		//刚上床时延迟10分钟判断深浅睡眠
extern	U16 	gGrogCouter;	//酒店计数
extern	U16 	gGrogData[Int5m][2];	//保存的间隔2min的体动信息数
extern	U8 		pp;				//保存体动信息的数组脚标
extern	U8 		gTurnDatas[2];	//存储当前体动标志值
extern	U8 		g1turnflag;		//一个体动持续的标志
extern	U16 	nutotal;			// 2min内体动个数计数
extern	U16 	nutime;			// 2min内体动总时长
extern	U8		gDeepStateFlag;			//深睡眠状态标志
extern	U8 		gDepthStateFlag;			//浅睡眠状态标志
extern	U16 	gTurnStore[Int5m][2];		//保存的间隔2min的体动信息数
extern	U8 		KS;						//体动保存总数的脚标
/*--------------------------------------------------------------------*/
#endif

/*-------------------------------------------------------------------*/
/* 滤波系数 */
extern const double Resp_highB[5][5];
extern const double Resp_highA[5][5];
extern const double Resp_lowB[5][5];
extern const double Resp_lowA[5][5];
extern const double Ecg_highB[5][5];
extern const double Ecg_highA[5][5];
extern const double Ecg_lowB[5][5];
extern const double Ecg_lowA[5][5];

//高通
extern double Bhigh_Resp[5];	
extern double Ahigh_Resp[5]; 

//高通
extern double Bhigh_Ecg[5];	
extern double Ahigh_Ecg[5]; 

//低通
extern double Blow_Resp[5];	
extern double Alow_Resp[5]; 

//低通
extern double Blow_Ecg[5];	
extern double Alow_Ecg[5];

/*--------------------------------------------------------------------*/

//心跳相关变量
extern	U8 		gPulseRateHR;			//脉率值
extern	U8		gRespHR;				//呼吸暂停时的心跳 实时的
extern	U32   	gCountHR;				//采样点计数
extern	U8 		gWaveHeadHR;			//头指针
extern	U8 		gWaveTailHR;			//尾指针
extern	S16 	gWaveBufHR[70];		            //
extern	S16 	gWaveSlopeBufHR[70];	            //斜率数组
extern	S16 	gPeakBufHR[4];				        //存储峰值
extern	U16 	gPeakSampleHR[4];			//存储峰值间距
extern	U16 	gSampleTimeHR[4];			//采样位置
extern 	U16		gTimeHR[5];
extern	U8 		Sa[3];
//extern	U16 		gSamplePulseValHR[5];      //脉率均值15--10
extern	U32 	gFengCountHR;				//峰值个数计数
extern	U8  	gSlopFlagHR;				//波形标志，0上升，1下降
extern	U8 		gabsHR0;					//斜率判断趋于0的阈值
extern	BOOL    gFengFlagHR;            //找到峰值标志

extern	U16 	gSamplePrValCountHR;
extern	U16 	gSampleMinHR;		//峰值间距最小值		对应脉率250
extern	U16 	gSampleMaxHR;		//峰值间距最大值		对应脉率40
extern	U16		gPeakMinHR;			//峰值幅度最小值
extern	U16		gPeakMaxHR;		//峰值幅度最大值

extern	S8		gValueTH;			//波谷幅度阈值

/*-------------------------------------------------------------------*/

extern 	U8		Resp_time;	//呼吸婴儿滤波档位选择
extern	U8		Ecg_time;	//心跳婴儿滤波档位选择

extern 	U8	  	gRST_Flag1;			//根据呼吸波形极值得出的呼吸暂停标志1
extern 	U8	 	gRST_Flag2;				//根据心跳波形极值得出的呼吸暂停标志2

/*-------------------------------------------------------------------*/
//ecg新算法变量
extern	U16 	HRcouter1;
extern	U8	  	gHR_Flag ;
extern	U32	  	HRcouter2 ;
extern	S32  	gHRData[TS] ;

extern	U8 		iis;	//峰点计数
extern	U8 		iit;	//谷点计数
extern	U8		iiff;	//峰峰计数
extern	U8 		iift;	//峰谷计数
extern	U8 		iitf;	//谷峰计数
extern	U8 		iitt;	//谷谷计数

extern	S32 	gDiff_Data[TS-2];	//差分斜率值
extern	S32 	gFengData[TS-2] ;	//峰幅度
extern	S32 	gFengPoint[TS-2] ;	//峰采样点
extern	U8	 	gFengSample[TS-2] ;	//峰间距值
extern	S32 	gGuData[TS-2] ;	//谷幅度
extern	S32 	gGuPoint[TS-2] ;	//谷采样点
extern	U8	 	gGuSample[TS-2] ;	//谷间距值

extern	U8 		gPeakPeak[TS-2] ;	//峰峰间距
extern	U8 		gPeakTrough[TS-2] ;	//峰谷间距
extern	U8		gTroughPeak[TS-2];	//谷峰间距
extern	U8		gTroughTrough[TS-2];//谷谷间距

extern	U16 	AveragePeak;		//峰间距平均值 
extern	U16 	AverageTrough;		//谷间距平均值
extern	U8		gTHAverage;			//峰谷均值的差值阈值

extern	U8		gPeakDiff[TS-2];		//峰与峰均差值
extern	U8		gTroughDiff[TS-2];		//谷与谷均差值
extern	U8		gDiffTH;			//与均值差阈值
extern	U8		gResultData[3];	//结果保存3个值进行判断处理
extern	U8		icount;			//结果数组的计数
	
extern	U8		gEcgHR;			//新算法的心跳结果
extern	U8		gResultTH;		//新心跳结果前后跳跃阈值

extern	U8 		gThreePeak[3];		//当前三个峰峰间距
extern	U8 		gThreeTrough[3];	//当前三个谷谷间距
extern	U8 		ipoint1,ipoint2;				//当前峰峰谷谷间距计数

extern	S32 	Data_Resp[Is] ;
extern	S32 	Data_SA ;
extern	U16 	gTH_AS ;
extern	S32 	RIS[5] ;
extern	U8 		gAS_count ;
extern	U8 		gASFlag ;
extern	U8 		gindex;
extern	U8 		I_AS;

/*-------------------------*/
//fft定义
extern	double 	gfft_L ;		//根据上一fft结果确定当前频率范围下限
extern	double 	gfft_H ;		//根据上一fft结果确定当前频率范围上限
extern U8	 	mt;		//保存最大频率点的数组计数
/*-------------------------------------------------------------------*/

/*------------------------*/
//for 贝骨Sleep HR
//预处理数据
extern U32  gBGcounter;		
extern S32  gBeiGuData[window];		//预处理后的10s数据
extern U8   gIns;	
//峰谷信息数组
extern S32  PeakPoint[PTn];		//波峰值位置
extern S32  PeakValue[PTn];		//波峰值
extern S32  TroughPoint[PTn];	//波谷值位置
extern S32  TroughValue[PTn];	//波谷值
extern U16  PeakStop;	//波峰谷信息个数
extern U16  TroughStop;	//波峰谷信息个数
//峰值筛选
extern U16  ValueMax[PTn];	//存储的峰谷幅度值
extern S32  FinalValue[PTn];	//筛选出的峰谷幅度值
extern U16  FinalPoint[PTn];	//筛选出的峰谷幅度值位置
extern U8   Fps;		//刷选出的峰谷个数
extern U16  FinalTimes[PTn];	//最终心跳采样间距值

//心跳计算
extern U8   gBeiGu_HR;	//计算的最终心率值
//平滑处理
extern U8   datas[kks];
extern U8   ttp;

/*-------------------------------------------------------------------*/

//信号强度
extern    U8 gPowerSample;  //  采样信号强度
extern    U8 gPowerBreath;  //呼吸信号强度
extern    U8 gPowerHeart;   //心跳信号强度
extern    U8 gPowerTurn;
extern    U8 gPowNum1;  //采样计数
extern    U8 gPowNum2; //呼吸计数
extern    U8 gPowNum3;  //心跳计数
extern    U16 gSData[4*SampleRate];   //采样信号4s
extern    S32 gBData[4*SampleRate];   //呼吸信号4s
extern    S32 gHData[2*SampleRate];   //心跳信号2s

void DataInitial(void);

#endif

