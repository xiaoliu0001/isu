/******************************************************************************
 * @file     Parameter.h
 * @brief   参数设定
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par     此文件仅用于定参数   严斌 2016
*******************************************************************************/
#ifndef __PARAMETER_H_
#define __PARAMETER_H_

#include "stdio.h"
#include "stdlib.h"
#include "BERpara.h"
#include <n32g45x.h>


/***************************************************/
//错误码说明
//1-C_SESSION or P_DATA is null
//2-MAC is not registered
//3-userId-token-deviceId is error
//4-MAC for everToken is null
//5-MD5(MAC+123456) check failly
//6-temToken is null,please again
//7-MD5(MAC+token+temToken) is check failly
//
/***************************************************/
#define SlaveNum              8   //从机数量
/************************************************************************
*张炜20170519 增加
*新协议指令CMD
*************************************************************************/
#define TypeID                    0x01   //设备ID编号
#define CMD_START                 0x24   //指令头
#define CMD_LF1                   0x69
#define CMD_LF2                   0x42
#define  SYNC                     0x01  //同步指令
#define  REQ_SECOND_SERVER        0x02  //请求后置服务器
#define  REQ_SECOND_TOKEN         0x03  //获取后置服务器token2
#define  REQ_SECOND_MD5           0x04  //获取后置服务器MD5	
#define  REQ_SECOND_VERIFY        0x04  //获取后置服务器校验
#define  GPRS_LOCATION            0x05  //GPRS定位
#define  REQ_SERVER_TIME          0x06   //获取服务器时间
#define  SENSORTESTOVER           0X07   //压阻测试结束
#define  REALTIME_HRPARA          0x10  //实时呼吸心率等参数
#define  BREATHE_WAVE             0x11  //呼吸波形数据
#define  REQ_BINDING_USERS        0x12   //查询是否关联用户
#define  CARD_IMSI                0x13   //发送卡号或IMSI号码
#define  AMP_CHG                  0x14   //发送放大倍数
#define  SEND_STATISTICS_SLEEPDTAT 0x15  //发送断网的统计数据
#define  CMD_DEBUG                0x20   //串口打印日志
#define  READ_REALTIME_ADCDATA    0x21  //读取实时监测数据
#define  CMD_SETMAC               0x22  //设置设备MAC
#define  CMD_READMAC              0x23  //读取设备MAC
#define  CMD_READVER              0x25  //读取设备软硬件版本号
#define  CMD_SETBTNAME            0x26      //设置蓝牙名称
#define  CMD_REQMOUDLE_INFO       0x27      //查询设备状态信息
#define  CMD_SETCMEI              0x28  //设置IMEI
#define  CMD_READCMEI             0x29  //设置SN
#define  CMD_SETMANUDATE          0x2A      //设置设备生产日期，张炜20230827增加
#define  CMD_SETSN                0x2B      //设置移动SN，张炜20230916增加   
#define  DEVICE_ABNORMAL_MESSAGE  0xF1  //设备异常信息
#define  SERVER_ABNORMAL_MESSAGE  0xF2  //服务器异常信息
#define  SLEEPDATA_ABNORMAL_MESSAGE 0xF3 //心率呼吸数据异常信息
#define  CMD_PRESSSENSER           0xF4  //压力传感器状态

#define  UART_SOS_NETWORK         0xA1  //联网状态
#define  UART_SOS_SLEEP           0xA2  //睡眠状态
#define  UART_SOS_EVENT           0xB1  //SOS事件
#define  UART_SOS_POWER           0xB2  //供电方式
#define  UART_SOS_STATUS          0xB3  //在线汇报
#define  UART_SOS_10E_STATUS      0xC1  //1.0E在床监测带
#define  UART_SOS_10E_REAL        0xC2  //1.0E睡眠监测带

#define  FLASH_No_MAC             0x01  //设备未写入序列号
#define  FLASH_NO_TOKEN2          0X02  //设备未保存token2
#define  FLASH_NO_CMEI            0x03   //设备未保存cmei
#define  FLASH_NO_SN              0x04   //设备未保存SN

#define  SERVER_CHECK_MAC_ERR     0X02  //服务器验证MAC错误 
#define  SERVER_CHECK_MD5_ERR     0x01  //后置服务器MD5验证错误

#define  BINDING_USERS_YES        0x02   //设备已关联用户
#define  BINDING_USERS_NO         0x01   //设备未关联用户
#define  MONITOR_OFFLINE          0x00   //脱离监测
#define  MONITOR_ONLINE           0x01    //监测中
#define  SLEEPDATA_CHANGETIME     300    //脱离监测时间改变数据传输速率
#define  SLEEPDATA_SENDTIME_1MIN  60     //1分钟发送一次睡眠数据
#define  SLEEPDATA_SENDTIME_30S   30     //30S发送一次睡眠数据

#define  NO_ERROR                 0x00  
#define  ERROR_N0_MAC             0X01    //设备无编号
#define  ERROR_NO_TOKEN2          0X02    //设备无token2
#define  ERROR_MAC_ERR            0x04     //Mac验证错误
#define  ERROR_MD5_ERR            0x08     //MD5校验错误
#define  ERROR_NO_CARD            0x10     //未插入卡
#define  ERROR_NO_ROUTERNAME      0X20    //设备无保存路由器名称
#define  ERROR_NO_CMEI            0x40    //未设置CMEI

#define  START_POWERON            0X01     //电源重启
#define  START_NETWOEK_RECONNECT  0X02     //断网重连
#define  START_GPRS_RESTART       0X03     //GPRS模块上电重启
#define  START_GPRS_LINKOK        0X04     //设备已完成上电第一次联网

#define  HR_ABNORMAL               0x01     //心率异常
#define  RR_ABNORMAL               0x02     //呼吸异常

#define  PRESSSENSER_OFF           0X01   //压力传感器未压下
#define  PRESSSENSER_ON            0X02   //压力传感器压下


#define  SYSTEM_INIT              0
#define  MAC_INIT_OK              1
#define  WIRELESS_INIT_OK         2
#define  SEVER_LINK_OK            3 

#define  CARD_HASCHANGE          1
#define  CARD_NOCHANGE           0

#define  STATIST_TURN       1
#define  STATIST_PEOPLE     2
#define  STATIST_NOPEOPLE   3

#define ENABLE_SENDPRESSSERSONSTATUS

#define CMD_DELFLASHDATA        0XD1      //删除FLASH数据
#define CMD_DELSAVENUM          0x01      //删除保存的发送数据编号
#define CMD_DELSERVERIP         0X02      //删除服务器IP
#define CMD_DELALLDATA          0XFF      //删除所有的数据
#define CMD_SIMVERIFYERR        0X01      //sim卡校验错误代码
#define CMD_MACVERIFYERR        0X02      //MAC校验错误
#define CMD_DATAFORMATERR       0x03      //数据格式错误。重新发送
#define CMD_RE_REGISTER         0x04      //重新注册

#define  MOUDLE_STATUS_RUNTIME    0X01   //设备运行时间
#define  MOUDLE_STATUS_ROUTERSSID 0X02   //wifi模块保存的路由器名称和密码
#define  MOUDLE_STATUS_CONNECTIP  0X03   //wifi模块当前连接的服务器IP
#define  MOUDLE_DEL_ROUTERNAME    0x04	 //删除设备内保存的WiFi账号信息
#define  MOUDLE_DEL_MAC           0x05	 //删除设备内保存的mac信息
#define  MOUDLE_DEL_CMEI          0x06	 //删除设备内保存的cmei信息,张炜20230530增加


/*********************************************************************************/

#define U8 unsigned char 
#define S8 signed char
#define U16 unsigned short
#define S16 signed short
#define U32 unsigned int
#define S32 signed int
#define BOOL unsigned char
#define TRUE 1
#define FALSE 0

//--------ADC采样值处理参数--------------------
#define  STANDARD_VOLTAGE  1500    //稳定基线
#define  ECG_COMPARE_TIMES  3       //稳定状态监测次数
#define  ECG_STABLE_SECTION1  20    //稳定值区间
#define  ECG_STABLE_SECTION2  80    //数值放大区间1
#define  ECG_STABLE_SECTION3  150    //数值放大区间2
#define  ECG_STABLE_SECTION4  800     //数值放大区间2

//#define  ADC_MAXDATA1     1600     //数值放大区间1
#define  ADC_MAXDATA1     1510     //数值放大区间1
#define  ADC_MAXDATA2     1650      //数值放大区间2   7.29测试范围为1800
#define  ADC_MAXDATA3     1750       //数值放大区间3
#define  ADC_MAXDATA4     2000       //数值放大区间4
#define  ADC_CHGMAXDATA   2400
#define  ADC_CHGMINDATA   2000
#define  ADC_AMPSTADATA   2400
#define  ADC_MINDATA1     1490     //数值放大区间1
#define  ADC_MINDATA2     1250      //数值放大区间2
#define  ADC_MINDATA3     1000       //数值放大区间2

#define UARTBUF_MAX_LEN  250
#define	BufMAX	1024
#define SLEEPDTATABUF   100
#define SAVESLEEPDATALEN  200      //断网保存数组大小，最大不得超过255
#define MYUSRAT1	1
#define MYUSRAT2	2
#define MYUSRAT3	3
#define GPRS		0
#define WIFI		1

#define WYID		0		//记录芯片ID是否唯一


#define CONECTIP1			0		//链接前置服务器
#define CONECTIP1OK			1		//链接前置服务器成功
#define GETFRONTSERVEROK	2		//获取token1成功
#define GETBACKSERVERIPOK	3		//获取后置服务器IP成功
#define CONECTIP2			4		//链接后置服务器
#define CONECTIP2OK			5		//链接后置服务器成功
#define GETBACKSERVEROK		6		//获取token2成功
#define POWER_ON_NOTIFY	    7		//上电接口
#define SendSleepDataR		8		//开始发送睡眠数据
#define ANDLINK_MQTT		9		//MQTT
#define ONLINE_MQTT			10		//上线
#define POWERERROR			11		//电源异常情况
#define POWERNORMAL			12		//电源正常情况
#define DM_CONFIG_Auto		13		//DM配置拉取 自注册
#define DM_CONFIG_Heart		16		//DM配置拉取 心跳
#define DM_REGIST			14		//DM注册上报
#define DM_HEART			15		//DM心跳上报
#define MACERROR			99		//MAC地址不存在

#define OK					1		//表示成功
#define NO					0		//表示失败
#define ConnetServerTimeOut	60		//链接服务器超时时间
#define GetFirstDataTimeOut	10		//获取第一组数据超时时间
#define GetDataTimerOut		10		//正常通讯下，数据获取时间
#define	ATTimer				5		//一般AT指令执行时间 
#define	ConectServerTimer	30		//链接服务器时间
#define FrontServerTimeOut 30
#define TokenLen8			8		//token长度为8
#define TokenLen9			9		//token长度为9
#define CMDLenFill			0		//CMD的长度是两位数，当小于10的时候，需要填充0
#define	ADCCountTimer		1		//算法采集计算时间，记一次20ms
#define Send_Timer			3		//睡眠数据发送频率，单位s

#define CGATTime			3		 //网络状态查询时间，默认发送的数据时间为3s
#define CGATTime_3			3		//网络状态查询时间，默认发送的数据时间为3s 
#define CGATTime_10			10		//网络状态查询时间，默认发送的数据时间为10s

#define  Flag_FirstRun   0x55       //程序第一次运行，清除Flash，保存默认数据
#define  Flag_SoftReboot   0x55 

typedef struct SOFT_REBOOT_INFO
{
    uint8_t flag; //  0 -- 插电重启 1 -- 软重启
    uint8_t reserve[3];
    uint32_t  dm_report_count;
}SOFT_REBOOT_INFO_T;

extern SOFT_REBOOT_INFO_T g_softboot_info;
extern uint32_t TerminalManage_cnt;

/******************设备保存信息******************************/
#define IDLEN  20     //张炜20230530增加
typedef struct 
{
    char flag;
    uint8_t MAC_LEN;
    char MAC_ID[IDLEN];    
    char CMCC_CMEI[IDLEN] ;
	char CMCC_SN[IDLEN] ;
	char manuDate[IDLEN];
}DeviceInfo_Para;    
extern   DeviceInfo_Para Device_Info;

extern unsigned char Flagbuf[BufMAX];

//extern unsigned char ucUar1tRecbuf[BufMAX];
//extern unsigned char ucUar2tRecbuf[BufMAX];
//extern unsigned char ucUar3tRecbuf[BufMAX];
extern unsigned char Recestop1,Recestop2,Recestop3;


extern unsigned char ucUar1tbuf[BufMAX];
extern unsigned char ucUar2tbuf[BufMAX];
extern unsigned char ucUar3tbuf[BufMAX];
extern unsigned int ReceEnd1,ReceEnd2,ReceEnd3;

extern char SlaveSOS_MAC[20];
extern uint8_t Slave_flag[SlaveNum];    //存在标志
extern uint16_t Slave_SecCnt[SlaveNum];  //存在计数，超时则清除
extern uint8_t Slave_type[SlaveNum];    //类型
extern char Slave_MAC[SlaveNum][20];

extern u8 Times,First_Int,shijian,mytime,mytime2,token1time,SOS_Connect_Time,sleeptime,AUTOTime,YZTime;
extern u16 Heartbeat,Battery_CntTime;
extern uint16_t ucUar1InterrFlag,ucUar2InterrFlag,ucUar3InterrFlag;
extern uint8_t SOS_Report_Time;  //3秒内不重复报警


extern uint8_t RT_Hr;
extern uint8_t RT_Rr;
extern uint8_t RT_Status;
extern uint8_t RealBatchIndex;
extern uint8_t hrtest[110];
extern uint8_t rrtest[110];
extern uint8_t statustest[110];

extern uint8_t SOSConnectFlag;
extern uint8_t  ucConectFlag;
extern unsigned char MAC_IDstring[21]; //设备编号字符串，张炜20170522修改长度13->22,以\0结束
extern U8 Version[3];
extern unsigned char Token1[15];
extern unsigned char IP2[20],chanl2[5],Token2[15],ucToken2[15],ucToken[15];
extern volatile uint8_t PowerBatteryFlag;
extern uint8_t SOS_Battery;
extern unsigned char GPRS_or_WIFI;
extern unsigned char Ver[12];
extern unsigned char AngelPace;
extern unsigned char SendDataStatus;
extern unsigned char SendDataBuff[500];
extern unsigned char SleepData[50];
extern unsigned char SendSleepDataStatus;
extern unsigned char TemporaryBuff[100];
extern unsigned char GetSleepTime;
extern unsigned int AT_CGATT_Count;
extern unsigned char Algorithm_TIMER_FLAG;

extern unsigned char TokenFlag;
extern unsigned char RegEnable;
extern uint8_t Luat_15min_SendFlag;
extern uint8_t LuatPowerOnWay;
extern char Timebuf[8];
extern char OffTime[8];
extern char DMHeartTime[8];
extern unsigned char LedFlash;
extern unsigned char CSQNual;
extern unsigned char gQuickFlashTimer;
extern unsigned char ATCGATT_Count;

extern uint16_t   USART1_RX_LEN;  //串口1接收的数据长度，张炜20170519加
extern uint16_t   USART2_RX_LEN;  //串口2接收的数据长度，张炜20170519加
extern uint16_t   USART3_RX_LEN;  //串口3接收的数据长度，张炜20170519加
extern uint8_t    MAC_LEN;        //MAC数据长度，张炜20170522增加
extern uint8_t    TOKEN2_LEN;     //token2长度，张炜20170523增加
extern uint16_t   SleepData_SendTime;  //睡眠数据发送的时间，张炜20170523增加
extern uint8_t    Flag_Binding_Users;  //设备是否绑定用户,张炜20170523增加
//extern uint8_t    Flag_FirstRetuen_Binding;  //设备
extern uint16_t   Monitor_Offline_Time; //脱离监测计时，张炜20170525增加
extern uint16_t   No_Binding_Users_Time; //未关联用户计时，张炜20170525增加
extern uint8_t    Flag_No_Binding_Users_Time;//未关联用户计时标志，服务器第一次返回开始计时，张炜20170525增加
extern uint8_t    Flag_Register_OK;      //设备开机注册成功，张炜20170525增加
extern uint8_t    Flag_Check_Status;     //验证状态，张炜20170525增加
extern uint8_t     Flag_Start_Mode ;   //网络重连的原因：上电重启还是断网重连，张炜20170526增加
extern uint8_t    Flag_Send_GPRS_Position;  //发送一次GPRS位置，张炜20170526增加
extern int        Position_LAC;        //GPRS LAC位置数据，张炜20170526增加
extern int        Position_CID;        //GPRS CID位置数据，张炜20170526增加
extern uint8_t    Flag_start_time;     //启动时间计时标志
extern uint8_t    Last_gPulseRateHR;   //保存上次的心率数值，当心率异常时发送上次的数据，张炜20170527增加
extern uint8_t    Last_gPulseRateRR;   //保存上次的呼吸数值，当心率异常时发送上次的数据，张炜20170527增加
extern uint8_t    ABN_gPulseRateHR;   //保存异常的心率数值，当心率异常时发送上次的数据，张炜20170527增加
extern uint8_t    ABN_gPulseRateRR;   //保存异常的呼吸数值，当心率异常时发送上次的数据，张炜20170527增加
extern uint8_t    Flag_SendDataAbnormal;   //发送异常标记，当心率呼吸异常的时候发送，张炜20170527增加
extern uint8_t   Flag_init ;    //初始化进程
extern uint8_t   Flag_TimeAdj;          //用于时间校准，1分钟之内不和服务器进行两次校准
extern uint16_t   Adj_Time;             //校准时间计时

extern uint8_t   ICCID_LEN;           //保存卡号或者IMSI号长度
extern char MAC_ID[30];
extern char   ICCID_Save[30];       //保存在flash中的卡号或者IMSI号
extern uint8_t   ICCID_LEN;           //保存卡号或者IMSI号长度
extern char   IMEI_Save[30] ;       //保存在flash中的卡号或者IMSI号
extern uint8_t   IMEI_LEN; 
extern char   IMSI_Save[30] ;
extern uint8_t   IMSI_LEN; 

extern uint8_t   Flag_CARD_ISCHANGE;    //更换了卡号
extern uint8_t  Flag_LinkStatus;        //联网状态，联网成功之后一直发送实时数据
extern uint16_t  GPRS_ConnetTime;       //GPRS连接时间
extern uint8_t  Flag_COMDebug;          //串口打印标志

extern S32  ECG_MAX[ECG_COMPARE_TIMES];                //ADC采样数值处理
extern S32  SEND_ECG_MAX[ECG_COMPARE_TIMES];                //ADC采样数值处理
extern S32  ECG_MIN[ECG_COMPARE_TIMES]; 
extern S32  CHGECG_MAX[ECG_COMPARE_TIMES];                //ADC处理后数据
extern S32  CHGECG_MIN[ECG_COMPARE_TIMES]; 
extern S32  ADC_DATA[500]; 
extern S32  ECG_Data[500];
extern S32  ADC_QuietCount;
extern uint8_t   ECG_COMPARE_COUNT;          //平稳值比较次数
extern uint8_t   CHGECG_COMPARE_COUNT;          //平稳值比较次数
extern char      Flag_ADC_ADJ;              //调整状态
extern uint16_t  ADC_COUNT;                //ADC采样计数
extern uint16_t  CHGADC_COUNT;                //ADC采样计数
extern uint16_t  ADC_AdjTime;              //ADC采样平稳状态检查间隔时间
extern float   ADC_AmpMultiple;    //放大倍数
extern uint8_t Last_gPeopleFlag;   //是否有人的状态
extern float   LastADC_AmpMultiple;    //上一次放大倍数
extern uint8_t Flag_PowerOn;       //是否是上电
extern uint8_t Last_StatusFlag; //上一个状态
extern uint8_t BeforeLast_StatusFlag; //上上一个状态
extern uint8_t Keep_StatusFlag; //现在保持的状态状态
extern  unsigned char Buffer_SleepData[SLEEPDTATABUF][40];   //数据缓存
extern  uint16_t  Flag_SleepDataBuffer_Save;
extern  uint16_t  Flag_SleepDataBuffer_Send;
extern  uint8_t   SleepDataBuffer_SendTime;
extern  uint32_t    DM_Heart_Time;
extern unsigned char Statist_TurnStartTimebuf[6];  //断网统计开始时间
extern unsigned char Statist_PeopleStartTimebuf[6];    //
extern unsigned char Statist_NoPeopleStartTimebuf[6]; 
extern unsigned char Statist_TurnEndTimebuf[6];  //断网统计结束时间
extern unsigned char Statist_PeopleEndTimebuf[6];    //
extern unsigned char Statist_NoPeopleEndTimebuf[6];
extern uint32_t  Statist_AddHR;       //断网统计心率累加
extern uint32_t  Statist_AddRR;       //断网统计呼吸累加
extern uint16_t  Statist_AddCount;    //断网统计呼吸/心率累加次数
extern unsigned char   Save_SleepHRData[6];  //断网情况下6组心率呼吸数据
extern unsigned char   Save_SleepRRData[6];  //断网情况下6组心率呼吸数据
extern uint8_t   Flag_SavepPos;
extern uint16_t TurnKeepTime ;       //统计计时时间
extern uint16_t  PeopleKeepTime ;       //统计计时时间
extern uint16_t   NoPeopleKeepTime ;       //统计计时时间
extern uint8_t   Flag_NoNetWorkStart;        //断网开始标志
extern uint8_t  Flag_CanSendStatistData;      //可以发送统计数据；
extern uint8_t  CanSendStatistTime;          //统计数据接收间隔时间


extern uint8_t Status_ExtSensorIn;    //外部传感器是否插入状态  20180320增加
extern uint8_t Status_ExtSensorOnbed;    //外部传感器是否有人在床状态  20180320增加
extern uint8_t ExtSensor_OnbedStatus_Count;  //传感器在床状态次数统计，累计多次状态一致才确定是否在床 20180320增加
extern uint8_t OnbedStatus_CountTimer;   //外部传感器在床状态统计间隔时间
extern uint8_t LastOnbedStatus;          //上一次的在床状态 
extern uint8_t Flag_SendPresensorStatus;  //发送压力传感器状态
extern uint8_t SendPresensorStatus_Time;  //发送压力传感器时间

extern volatile uint32_t ADC_ConvertedValue[2];  //ADC采样值
extern float  ADC_VoltageValue[2];   //adc电压值


extern u8 sync_sever_time_count;

extern u16 test_timer;
extern u16 GPRS_Wait_Reconn;
extern u8  flag_Gprs_Reconn;
typedef enum Sync_Time_State_t{
IDLE,
START,
SYNCING
    
}Sync_Time_State;
extern Sync_Time_State Sync_State;
#endif

