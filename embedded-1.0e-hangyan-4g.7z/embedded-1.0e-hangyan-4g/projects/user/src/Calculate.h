/******************************************************************************
 * @file     Calculate.c
 * @brief   ADC数据处理
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par       严斌 2016
*******************************************************************************/
#ifndef __CALCULATE_H_
#define __CALCULATE_H_

#include "n32g45x.h"

typedef struct status{
	unsigned char isOnbed;//是否在床, 0: 否 1:是
	unsigned char isMove;//是否体动, 0: 否 1:是
	unsigned char isStopBreath;//是否停止呼吸0:否 1:是
}STATUS;

void getFilterWave(int* wave);//获取采样 后得到的波形

void putWaveDataToBuf(int org,int hrWave,int rrWave);//把波形放到缓冲区中
void sendPackDataToUART1(void);
void SendDeviceMacToUart1(void);
void SendDeviceVerInfoToUart1(char *str);
void getStatus(STATUS *status);

unsigned char GetDataHead(unsigned char* datas,unsigned char len);//获取数据头
void COMRetuenOneByte(USART_Module* USARTx,uint8_t cmd,uint8_t data);
void COMRetuenSOS_POWER(USART_Module* USARTx,uint8_t data1,uint8_t data2);
void COMRetuenSOS_event(USART_Module* USARTx,uint8_t data1);
void COMSynSOS_NetStatus(USART_Module* USARTx,uint8_t data1);
void COMSynSOS_SleepStatus(USART_Module* USARTx);
void COMSynSOS_SleepStatus_end(USART_Module* USARTx);
void COMSynSOS_test(USART_Module* USARTx);
#endif
