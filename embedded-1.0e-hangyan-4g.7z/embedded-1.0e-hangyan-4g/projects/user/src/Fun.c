/******************************************************************************
 * @file     Fun.c
 * @brief   GPRS和WIFI连接
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par      严斌 2016
 *     张炜20170522 按照新的通讯协议修改相关函数
 *     张炜20170612增加读取SIM卡的IMSI号并发送服务器和保存的功能
*******************************************************************************/
#include "Fun.h"
//#include "GPRS.h"
#include "m26.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "BERpara.h"
#include "ADC.h"
#include "Parameter.h"
#include "Calculate.h"
#include "Flash.h"
#include <math.h>
#include "LED_Key.h"
#include "Delay.h"
#include "MobileAndlink.h"
#include "n32g45x_rtc.h"
#include "User_RTC_Config.h"
//const unsigned char *IPstring = "AT+CIPSTART=\"TCP\",\"117.78.41.203\",6006";	//IP登录服务器

unsigned char *IPstring = "AT+IP=117.78.41.203:6006#";	//IP登录服务器				03 29  test
//unsigned char *IPstring = "AT+IP=devstv100r001.ibreezee.cn:6006#";	//IP登录服务器				03 29  test
//unsigned char *IPstring = "AT+IP=betadev.isuke.com.cn:6011#";
//unsigned char *IPstring = "AT+IP=devstv100r001.ibreezee.cn:6006#";
unsigned char RecTrue[] = "CONNECT  OK";						//连接服务器返回的字符
unsigned char ucIP2buff[50] = {0};									//记录后置服务器地址的buff
unsigned char *ForIP = "AT+CIPSTART=\"TCP\",\"117.78.41.203\",6006\r\n";	//IP登录服务器
char *IP1="device.isuke.com.cn";//"114.116.105.56";//"117.78.41.203";
char *PORT1="6011";//"6007";
//char *IP1="device.isuke.com.cn";
//char *PORT1="6011";
uint8_t CheckCount_ExtSensor = 0;    //外部传感器检测次数
uint16_t ExtSensor_PeopleOFFBed_Time = 0;
uint32_t ADCVol_ExtSensor = 0;

#define  PRESSURESENSOR_BASEMAXVALUE   500
#define  PRESSURESENSOR_BASEMINVALUE   300

uint16_t PressureSensor_BaseValue = PRESSURESENSOR_BASEMAXVALUE;    //压力传感器基础值
uint8_t CheckCount_ExtSensorMaxVal = 0;
uint8_t CheckCount_ExtSensorMinVal = 0;
void uart_send_sleep_data(void);
/*****************************************************************************/
//name:		GetToken1
//explain:	获取token1
//para:		NULL
//return:	NULL
/*****************************************************************************/
void GetToken1(void)
{
    unsigned char ucCmd[] = "2509C_SESSION12";  //12为MAC长度，后期需要修改为变长度调用,张炜20170522
    unsigned char ucdata[30] = {0};
    unsigned char ucSdata[50] = {0};
    unsigned char ucLingshi[20] = {0};
    //unsigned char tokenlen[2]={0};
    char *pstr = NULL;

    ClearUSART3BUF();
    memcpy(ucdata, MAC_IDstring, MAC_LEN);  //张炜20170522修改，chipid长度不固定，并且第一个字节为长度数据

    sprintf(ucSdata, "%s%s", ucCmd, ucdata);

    //printf("GetToken1 Data:%s\r\n", ucSdata);

    if(GPRS_or_WIFI == GPRS)
    {
        GPRSSendData(ucSdata, strlen(ucSdata));
        token1time = 0;
        while(1)
        {
            pstr = strstr(ucUar3tbuf, "8");
            if(pstr == NULL)
            {
                pstr = strstr(ucUar3tbuf, "7");
            }
            if(pstr != NULL)
            {
                delay_ms_YB();
                memcpy(ucLingshi, ucUar3tbuf, 9);
                if(ucUar3tbuf[0] == '8')
                {
                    memcpy(Token1, ucLingshi, 9);
                }
                else
                {
                    memcpy(Token1, ucLingshi, 8);
                }
//                printf("Fuwuqi data:%s\r\n", ucLingshi);
//                printf("Token1:%s\r\n", Token1);
                break;
            }
            if(token1time > 5) 				//超时时间为3s
            {
//                printf("Time Out!%s\r\n", ucUar3tbuf);
                break;
            }
            if(strstr(ucUar3tbuf, "CLOSED") != NULL)
            {
//                printf("CL:%s\r\n", ucUar3tbuf);
                break;
            }
        }
    }
}


/************************************************************************************/
// C prototype : void StrToHex(BYTE *pbDest, BYTE *pbSrc, int nLen)
// parameter(s): [OUT] pbDest - 输出缓冲区
// [IN] pbSrc - 字符串
// [IN] nLen - 16进制数的字节数(字符串的长度/2)
// return value:
// remarks : 将字符串转化为16进制数
/************************************************************************************/
void StrToHex(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    char h1, h2;
    unsigned char s1, s2;
    int i;

    for (i = 0; i < nLen; i++)
    {
        h1 = pbSrc[2 * i];
        h2 = pbSrc[2 * i + 1];

        s1 = toupper(h1) - 0x30;
        if (s1 > 9)
            s1 -= 7;

        s2 = toupper(h2) - 0x30;
        if (s2 > 9)
            s2 -= 7;

        pbDest[i] = s1 * 16 + s2;
    }
}

/**************************************************************************/
// C prototype : void HexToStr(BYTE *pbDest, BYTE *pbSrc, int nLen)
// parameter(s): [OUT] pbDest - 存放目标字符串
// [IN] pbSrc - 输入16进制数的起始地址
// [IN] nLen - 16进制数的字节数
// return value:
// remarks : 将16进制数转化为字符串
/*************************************************************************/
void HexToStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    char ddl, ddh;
    int i;

    for (i = 0; i < nLen; i++)
    {
        ddh = 48 + pbSrc[i] / 16;
        ddl = 48 + pbSrc[i] % 16;
        if (ddh > 57) ddh = ddh + 7;
        if (ddl > 57) ddl = ddl + 7;
        pbDest[i * 2] = ddh;
        pbDest[i * 2 + 1] = ddl;
    }

    pbDest[nLen * 2] = '\0';
}

void HexToLowerStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    char ddl, ddh;
    int i;

    for (i = 0; i < nLen; i++)
    {
        ddh = 48 + pbSrc[i] / 16;
        ddl = 48 + pbSrc[i] % 16;
        if (ddh > 57) ddh = ddh + 39;//'9'和'a'相差39
        if (ddl > 57) ddl = ddl + 39;
        pbDest[i * 2] = ddh;
        pbDest[i * 2 + 1] = ddl;
    }

    pbDest[nLen * 2] = '\0';
}
/*******************************************************************************
* 函数名 : ConnectFrontServer
* 描述   : 链接前置服务器
* 输入   :
* 输出   :
* 返回   :
* 注意   :
*******************************************************************************/
void ConnectFrontServer(void)
{
    char cmd[100]={0};
    if((GPRS_or_WIFI == GPRS) && (AngelPace == CONECTIP1))
    {
//        GPRS_CloseSocket();
        if(SendDataStatus != OK) 			//发送数据
        {
            ClearUSART3BUF();
//            UART3_SendString_YB(IPstring, strlen(IPstring));
//            UART3_SendLR();
            //sprintf(cmd,"AT+QIOPEN=\"TCP\",\"%s\",\"%s\"\r\n",IP1,PORT1);  //
            sprintf(cmd,"AT+MIPOPEN=1,0,\"%s\",%s,0\r\n",IP1,PORT1); 
            UART3_SendString(cmd);
					  if(Flag_COMDebug == 1)
							printf("%s", cmd);
            SendDataStatus = OK;
            mytime = 0;
        }
    }
}
void ConnectServertEST(void)
{
    char cmd[100]={0};
	GPRS_CloseSocket();
	ClearUSART3BUF();
	sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",IP1,PORT1); 
	UART3_SendString(cmd);
	if(Flag_COMDebug == 1)
		printf("%s", cmd);
	SendDataStatus = OK;
	mytime = 0;
}

char Connect_DM_Server(void)
{
	char cmd[100]={0};
//	GPRS_CloseSocket();
	ClearUSART3BUF();
	#ifdef Demonstrate
	sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",URL_demonstrate_IP,URL_GETAHOST_PORT); 
	#else
	sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",URL_GETAHOST_IP,URL_GETAHOST_PORT); 
	#endif
	UART3_SendString(cmd);
	mytime = 0;
	
	while(1)
	{
		if((strstr(ucUar3tbuf,"OK") != NULL)||(strstr(ucUar3tbuf,"ALREADY") != NULL))					//是否返回指定字符串
        {
			if(Flag_COMDebug == 1)
			{
				printf("CMD Success!\r\n");
			}
			return 1;
        }
        if(mytime > 3) 						//超时
        {
			if(Flag_COMDebug == 1)
				printf("Timer Out:%s\r\n", ucUar3tbuf);
			return 0;
        }
	}
}
/*******************************************************************************
* 函数名 : ConnectFrontServerRcvCtr
* 描述   : 链接前置服务器指令接收处理
* 输入   :
* 输出   :
* 返回   :
* 注意   :
*******************************************************************************/
void ConnectFrontServerRcvCtr(void)
{
        if((strstr(ucUar3tbuf, "OK") != NULL))					//是否返回指定字符串
        {
			  if(Flag_COMDebug == 1)
				{
					printf("%s\r\n", ucUar3tbuf);
					printf("CMD Success!\r\n");
				}
            //AngelPace = CONECTIP1OK;							//链接服务器成功
              AngelPace=GETFRONTSERVEROK;
              SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "ERROR") != NULL) 		//返回error的话，进行三次重发数据，去除数据传输不稳定的影响
        {
			  if(Flag_COMDebug == 1)
				  printf(" ERROR:%s\r\n", ucUar3tbuf);
                      
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "CONNECT FAIL") != NULL)
        {
					  if(Flag_COMDebug == 1)
                          printf("CONNECT:%s\r\n", ucUar3tbuf);
             Flag_init = MAC_INIT_OK;  //可以进行无线模块初始化          
            SendDataStatus = NO;
        }
        if(mytime > 5) 						//超时
        {
					  if(Flag_COMDebug == 1)
							printf("Timer Out:%s\r\n", ucUar3tbuf);
                      Flag_init = MAC_INIT_OK;  //可以进行无线模块初始化
            SendDataStatus = NO;
        }
}

/*******************************************************************************
* 函数名 : GetFrontEndServerPw
* 描述   : 获取前置服务器token
* 输入   :
* 输出   :
* 返回   :
* 注意   :
*******************************************************************************/
void GetFrontEndServerPw(void)
{
    unsigned char CMD[] = "C_SESSION";
    unsigned char CMD_LEN = 0, TOTAL_LEN = 0;  //张炜20170522删除MAC_LEN = 0
    unsigned char ucSendData[40] = {0};
    unsigned char ucLingshi[20] = {0};
    char *pstr = NULL;


    if(AngelPace == CONECTIP1OK) 							//只有连接前置服务成功后才能进行下一步
    {
        if(SendDataStatus != OK)
        {
            memset(SendDataBuff, 0x00, sizeof(SendDataBuff));
            memset(Token1, 0x00, sizeof(Token1));				//Token使用前先clear下
            CMD_LEN = strlen(CMD);							//数据拼接
            MAC_LEN = strlen(MAC_IDstring);					//计算mac长度
            if(CMD_LEN < 10) 								//如果CMD长度不满两位数，需要填0
            {
                sprintf(ucSendData, "%d%d%s%d%s", CMDLenFill, CMD_LEN, CMD, MAC_LEN, MAC_IDstring);	//拼接发送的数据
            }
            else
            {
                sprintf(ucSendData, "%d%s%d%s", CMD_LEN, CMD, MAC_LEN, MAC_IDstring);	//拼接发送的数据
            }
            TOTAL_LEN = strlen(ucSendData);					//计算总长度

            if(GPRS_or_WIFI == GPRS)
            {
                sprintf(SendDataBuff, "AT+GPRS=%d%s", TOTAL_LEN, ucSendData);					//拼接最终发送数据
            }
            else
            {
                sprintf(SendDataBuff, "%d%s", TOTAL_LEN, ucSendData);					//拼接最终发送数据
            }
            //sprintf(SendDataBuff,"AT+SEND=2509C_SESSION12%s",MAC_IDstring);

            /*****************************数据发送*******************************************/
            if(GPRS_or_WIFI == GPRS)
            {
                GPRSSendData(SendDataBuff, strlen(SendDataBuff));		//发送数据
							  if(Flag_COMDebug == 1)
									printf("C_SESSION:%s\r\n",SendDataBuff);
            }

            SendDataStatus = OK;							//发送完毕
            mytime = 0;										//开始计时超时
            ClearUSART3BUF();				
        }
    }
    else
    {
        return;
    }
}
/*******************************************************************************
* 函数名 : GetFrontEndServerPwRcvCtr
* 描述   : 获取前置服务器token,接收数据处理
* 输入   :
* 输出   :
* 返回   :
* 注意   :
*******************************************************************************/
void GetFrontEndServerPwRcvCtr(void)
{
    char *pstr1 = NULL;
    char *pstr2 = NULL;
	  uint8_t i = 0;
	
    if(GPRS_or_WIFI == GPRS)
    {
        pstr1 = strstr(ucUar3tbuf, "8");
        pstr2 = strstr(ucUar3tbuf, "7");
        if((pstr1 != NULL)||(pstr2 != NULL))
        {
            delay_ms_YB();
					  delay_ms_YB();
					  if(Flag_COMDebug == 1)
							printf("ucUar3tbuf:%s\r\n", ucUar3tbuf);
          
						if((pstr1 != NULL)&&(pstr2 != NULL))
						{
							  if(pstr1>pstr2)
								{
									 memcpy(Token1, pstr2, TokenLen8);
								}
								else
								{
									 memcpy(Token1, pstr1, TokenLen9);
								}
						}
						else 
						{
								if(pstr1[0] == '8')
								{
										memcpy(Token1, pstr1, TokenLen9);
								}
								else
								{
										memcpy(Token1, pstr2, TokenLen8);
								}
					  }
            //printf("Fuwuqi data:%s\r\n",ucLingshi);
						if(Flag_COMDebug == 1)
							printf("Token1:%s\r\n", Token1);
            if(Token1[0] == '7' || Token1[0] == '8')
            {
                AngelPace = GETFRONTSERVEROK;
                SendDataStatus = NO;
							  if(Flag_COMDebug == 1)
									printf("GETFRONTSERVEROK\r\n");
            }
            else
            {
                SendDataStatus = NO;
							  if(Flag_COMDebug == 1)
									printf("GETFRONTSERVERNO\r\n");
            }
        }
			 
        if(mytime > GetFirstDataTimeOut) 			//超时时间为30s
        {
					  if(Flag_COMDebug == 1)
							printf("Time Out!%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//重新连接前置服务器
            SendDataStatus = NO;					//打开发送开关
        }
        if(strstr(ucUar3tbuf, "CLOSED") != NULL)
        {
					  if(Flag_COMDebug == 1)
							printf("CL:%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//重新连接前置服务器
            SendDataStatus = NO;					//打开发送开关
        }
        if(strstr(ucUar3tbuf, "SHUT OK") != NULL)
        {
					  if(Flag_COMDebug == 1)
							printf("CL:%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//重新连接前置服务器
            SendDataStatus = NO;					//打开发送开关
        }
        CheckSystemErrorContrl();					//模块出现异常情况
    }
}

/*******************************************************************************
* 函数名 : GetBackEndServerIP
* 描述   : 获取后置服务器IP
* 输入   :
* 输出   :
* 返回   :
* 注意   :
*******************************************************************************/
void GetBackEndServerIP(void)
{
    unsigned char CMD[] = "G_IP";
    unsigned char CMD_LEN = 4, TOTAL_LEN = 0, MD5_LEN = 32, i = 0; //张炜20170522删除,MAC_LEN = 12
    unsigned char ucSendData[100] = {0};
    unsigned char ucdata[30] = {0};
    unsigned char ucMd5data[30] = {0};
    unsigned char ucmd5string[40] = {0};
    unsigned char ucSenddata1[40] = {0};
    unsigned char ucSenddata2[40] = {0};

    if(AngelPace == GETFRONTSERVEROK)
    {
        if(SendDataStatus != OK) 									//发送数据
        {

					memset(SendDataBuff,0x00,sizeof(SendDataBuff));
					memcpy(ucdata,MAC_IDstring,MAC_LEN);							//获取MD5数据
					sprintf(ucMd5data,"%s%s",ucdata,Token1+1);
					MDString(ucMd5data,ucmd5string);
					HexToLowerStr(ucSenddata1,ucmd5string,16);
          ClearUSART3BUF();
					if(Flag_COMDebug == 1)
					{
						printf("MD5data:%s\r\n",ucMd5data);
						printf("MD5rcvdara:%s\r\n",ucSenddata1);
          }
            if(CMD_LEN < 10)
            {
                sprintf(ucSendData, "%d%d%s%d%s%d%s", CMDLenFill, CMD_LEN, CMD, MAC_LEN, ucdata, MD5_LEN, ucSenddata1);			//拼接发送的数据
            }
            else
            {
                sprintf(ucSendData, "%d%s%d%s%d%s", CMD_LEN, CMD, MAC_LEN, ucdata, MD5_LEN, ucSenddata1);			//拼接发送的数据
            }
            TOTAL_LEN = strlen(ucSendData);										//计算总长度
            if(GPRS_or_WIFI == GPRS)
            {
                sprintf(SendDataBuff, "AT+GPRS=%d%s", TOTAL_LEN, ucSendData);					//拼接最终发送数据
            }
            else
            {
                sprintf(SendDataBuff, "%d%s", TOTAL_LEN, ucSendData);					//拼接最终发送数据
            }

            if(GPRS_or_WIFI == GPRS)
            {
                GPRSSendData(SendDataBuff, strlen(SendDataBuff));
            }


            SendDataStatus = OK;							//发送完毕
            mytime = 0;										//开始计时超时
            memset(SendDataBuff, 0x00, sizeof(SendDataBuff));
            memset(IP2, 0x00, sizeof(IP2));
            memset(chanl2, 0x0, sizeof(chanl2));

        }
    }
    else
    {
        return;
    }
}
/*******************************************************************************
* 函数名 : GetBackEndServerIPRcvCtr
* 描述   : 获取后置服务器IP接收处理
* 输入   :
* 输出   :
* 返回   :
* 注意   :
*******************************************************************************/
void GetBackEndServerIPRcvCtr(void)
{
    char *pstr = NULL;
	  unsigned int TDNum = 0;
    unsigned char ucLingshi[30] = {0};
    unsigned char uclenbuf[3] = {0}, uclen = 0;
    unsigned char uciplenbuf[3] = {0}, uciplen = 0;
    unsigned char ucip2[20] = {0};

    if(GPRS_or_WIFI == GPRS) 				//GPRS接收处理
    {
        pstr = strstr(ucUar3tbuf, "1");
        if(pstr != NULL)
        {
            delay_ms_YB();
					  delay_ms_YB();
            memcpy(ucLingshi, pstr, 25);
            memcpy(uciplenbuf, ucLingshi, 2);
            uciplen = atoi(uciplenbuf);
            memcpy(ucip2, ucLingshi + 2, uciplen);
            strcpy(IP2, ucip2);
            memcpy(chanl2, ucLingshi + 2 + uciplen + 1, 4);
					  TDNum = atoi(chanl2);
					  if(Flag_COMDebug == 1)
						{
							printf("IPdata:%s\r\n", ucUar3tbuf);
							printf("IP2:%s\r\n", IP2);
							printf("chanl2:%s\r\n", chanl2);
						}
            if((MyCountChar(IP2, 20) == 3) &&(strlen(IP2)>7)&& (TDNum >100 ))
            {
                AngelPace = GETBACKSERVERIPOK;
                SendDataStatus = NO;
							  
            }
            else
            {
                memset(IP2, 0x00, sizeof(IP2));
                memset(chanl2, 0x0, sizeof(chanl2));
                SendDataStatus = NO;
            }
        }
        if(mytime > GetDataTimerOut)
        {
					  if(Flag_COMDebug == 1)
							printf("Timer out!%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//重新连接前置服务器
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "CLOSED") != NULL)
        {
					  if(Flag_COMDebug == 1)
							printf("CL:%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//重新连接前置服务器
            SendDataStatus = NO;
        }
        CheckSystemErrorContrl();				//模块出现异常情况
    }
}

/*******************************************************************************
* 函数名 : ConnectBackServer
* 描述   : 链接后置服务器
* 输入   :
* 输出   :
* 返回   :
* 注意   :
*******************************************************************************/
void ConnectBackServer(void)
{
    unsigned int TDNum = 0;
    unsigned char len = 0;
    unsigned char ucstatu = 0;

	
    if(AngelPace == GETBACKSERVERIPOK)
    {
        if(SendDataStatus != OK) 			//发送数据
        {
            ClearUSART3BUF();
            TDNum = atoi(chanl2);
            if(GPRS_or_WIFI == GPRS)
            {
                //TDNum=6008;				//17-03-06   邋YB  test
                sprintf(ucIP2buff, "AT+IP=%s:%d#", IP2, TDNum);
							if(Flag_COMDebug == 1)
							{
                printf("ucIP:%s\r\n", ucIP2buff);
							}
                UART3_SendString_YB(ucIP2buff, strlen(ucIP2buff));
                UART3_SendLR();
            }
						if(Flag_COMDebug == 1)
							printf("%s", ucIP2buff);
            SendDataStatus = OK;
            mytime = 0;
        }
        else 								//开始接收数据
        {
            if(GPRS_or_WIFI == GPRS)
            {
                if(strstr(ucUar3tbuf, "CONNECT  OK") != NULL)							//是否返回指定字符串
                {
									 if(Flag_COMDebug == 1)
                     printf("%s\r\n", ucUar3tbuf);
//                    printf("CMD Success!\r\n");
                    AngelPace = CONECTIP2OK;							//链接服务器成功
                    SendDataStatus = NO;
					          RegEnable=1;
									
                }
                if(strstr(ucUar3tbuf, "ERROR") != NULL || strstr(ucUar3tbuf, "error") != NULL) 		//返回error的话，进行三次重发数据，去除数据传输不稳定的影响
                {
									  if(Flag_COMDebug == 1)
											printf("%s\r\n", ucUar3tbuf);
                    SendDataStatus = NO;
                }
                if(strstr(ucUar3tbuf, "CONNECT FAIL") != NULL)
                {
									  if(Flag_COMDebug == 1)
											printf("%s\r\n", ucUar3tbuf);
                    SendDataStatus = NO;
                }
								 if(strstr(ucUar3tbuf, "SHUT") != NULL)
								 {
										if(Flag_COMDebug == 1)
											printf("IP2 shut:%s\r\n", ucUar3tbuf);
										Flag_Check_Status |= ERROR_NO_TOKEN2;
										AngelPace = CONECTIP1;
										SendDataStatus = NO;					//打开发送开关
										SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
								 }
                if(mytime > ConnetServerTimeOut) 									//超时
                {
									  if(Flag_COMDebug == 1)
											printf("Timer Out:%s\r\n", ucUar3tbuf);
									 
                    SendDataStatus = NO;
                }
                CheckSystemErrorContrl();				//模块出现异常情况
            }
        }
    }
    else
    {
        return;
    }
}

/*******************************************************************************
* 函数名 : GetBackServerPw
* 描述   : 获取后置服务器验证码token2
* 输入   :
* 输出   :
* 返回   :
* 注意   :张炜20170523修改为新协议进行验证码获取
*******************************************************************************/
void GetBackServerPw(void)
{
    unsigned char CMD[] = "C_SESSION";
    unsigned char ucMd5data[30] = {0};
    unsigned char ucMd5string[40] = {0};
    unsigned char ucMd5string1[40] = {0};
    unsigned char ucMAC[15] = {0};
    unsigned char ucSdata[70] = {0};
    int i = 0;
    char *pstr = NULL;
    unsigned char TOTAL_LEN = 0, CMD_LEN = 9, MD5_LEN = 32;  //张炜20170522删除MAC_LEN = 12的定义
    uint8_t ucjiaoyan = 0;
																
    if(AngelPace == CONECTIP2OK)
    {
        if((SendDataStatus != OK)&&(AT_CGATT_Ctrl() == 1))
        {
           
            if(GPRS_or_WIFI == GPRS)
            {
								ClearUSART3BUF();	
               memset(ucUar3tbuf,0x00,sizeof(ucUar3tbuf));  //清除串口缓存;
//--------------以下为张炜20170522按照新的协议修改发送的数据----------------------
							 UART3_SendString("AT+GPRS=\0");
							 SendDataToUSART(USART3,0x24);
							 SendDataToUSART(USART3,0x01);
							 SendDataToUSART(USART3,(MAC_LEN+2)|0x80);			
							 SendDataToUSART(USART3,REQ_SECOND_TOKEN);
							 for(i=0;i<MAC_LEN ;i++)
							 {
									SendDataToUSART(USART3,MAC_ID[i]);
							 }  
							 for(i = 0;i< MAC_LEN;i++)
								{
									ucjiaoyan += MAC_ID[i];
								}
							 ucjiaoyan +=REQ_SECOND_TOKEN;
							 SendDataToUSART(USART3,ucjiaoyan|0x80 );
							 SendDatasToUSART(USART3,0x6942 );
							 UART3_SendLR();
            }
            
            mytime = 0;
            SendDataStatus = OK;
            						
            memset(Token2, 0x00, sizeof(Token2));					//Token使用前先clear下
        }
        else
        {
           AngelPace = GETBACKSERVERIPOK;
				  
				   SendDataStatus = NO;					//打开发送开关
        }
        //ClearUSART3BUF();
    }
    else
    {
        return;
    }
}
/**
 * @brief  Reconfig the system clock.
 */
void SYSCLKConfig_STOP(uint32_t RCC_PLLMULL)
{
    __IO uint32_t StartUpCounter = 0, HSEStatus = 0;
    uint32_t Flash_Latency_Temp=0;
    uint32_t PLL_Temp=0;
    uint32_t System_Temp=0;	
    /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration ---------------------------*/
    /* Enable HSE */
    RCC->CTRL |= ((uint32_t)RCC_CTRL_HSEEN);
    /* Wait till HSE is ready and if Time out is reached exit */
    do
    {
        HSEStatus = RCC->CTRL & RCC_CTRL_HSERDF;
        StartUpCounter++;
    } while ((HSEStatus == 0) && (StartUpCounter != HSE_STARTUP_TIMEOUT));
    if ((RCC->CTRL & RCC_CTRL_HSERDF) != RESET)
    {
       HSEStatus = (uint32_t)0x01;
    }
    else
    {
       HSEStatus = (uint32_t)0x00;
    }
    if (HSEStatus == (uint32_t)0x01)
    {
       /* Enable Prefetch Buffer */
       FLASH->AC |= FLASH_AC_PRFTBFEN;
       /* Flash 2 wait state */
       Flash_Latency_Temp = FLASH->AC;
       Flash_Latency_Temp &= (uint32_t)((uint32_t)~FLASH_AC_LATENCY);
       Flash_Latency_Temp |= (uint32_t)FLASH_AC_LATENCY_4;
       FLASH->AC = Flash_Latency_Temp;
       /* HCLK = SYSCLK */
       RCC->CFG |= (uint32_t)RCC_CFG_AHBPRES_DIV1;
       /* PCLK2 = HCLK */
       RCC->CFG |= (uint32_t)RCC_CFG_APB2PRES_DIV2; 
       /* PCLK1 = HCLK */
       RCC->CFG |= (uint32_t)RCC_CFG_APB1PRES_DIV4; 
       /*  PLL configuration: PLLCLK = HSE * 18 = 144 MHz */
       PLL_Temp = RCC->CFG;
       PLL_Temp &= (uint32_t)((uint32_t) ~(RCC_CFG_PLLSRC | RCC_CFG_PLLHSEPRES | RCC_CFG_PLLMULFCT));
       PLL_Temp |= (uint32_t)(RCC_CFG_PLLSRC_HSE | RCC_PLLMULL);
       RCC->CFG = PLL_Temp;
       /* Enable PLL */
       RCC->CTRL |= RCC_CTRL_PLLEN;
       /* Wait till PLL is ready */
       while ((RCC->CTRL & RCC_CTRL_PLLRDF) == 0)
       {
       }
       /* Select PLL as system clock source */
       System_Temp = RCC->CFG;
       System_Temp &= (uint32_t)((uint32_t) ~(RCC_CFG_SCLKSW));
       System_Temp |= (uint32_t)RCC_CFG_SCLKSW_PLL;
       RCC->CFG = System_Temp;
       /* Wait till PLL is used as system clock source */
       while ((RCC->CFG & (uint32_t)RCC_CFG_SCLKSTS) != (uint32_t)0x08)
       {
       }
    }
    else
    { 
       /* If HSE fails to start-up, the application will have wrong clock
          configuration. User can add here some code to deal with this error */
    }
}
/**
 * @brief  Configures key GPIO.
 * @param key Specifies the Led to be configured.
 *   This parameter can be GPIO_PIN_0~GPIO_PIN_15.
 */
void KeyInputExtiInit(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_InitType GPIO_InitStructure;
    EXTI_InitType EXTI_InitStructure;
    NVIC_InitType NVIC_InitStructure;
    /* Check the parameters */
    assert_param(IS_GPIO_ALL_PERIPH(GPIOx));
    /* Enable the GPIO Clock */
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
    /*Configure the GPIO pin as input floating*/
    GPIO_InitStructure.Pin        = Pin;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitPeripheral(GPIOx, &GPIO_InitStructure);
    /*Configure key EXTI Line to key input  Pin*/
    GPIO_ConfigEXTILine(GPIOA_PORT_SOURCE, GPIO_PIN_SOURCE10);
    /*Configure key EXTI line*/
    EXTI_InitStructure.EXTI_Line = EXTI_LINE10;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_InitPeripheral(&EXTI_InitStructure);
    /*Set key input interrupt priority*/
    NVIC_InitStructure.NVIC_IRQChannel                   = EXTI15_10_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x05;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 0x0F;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void KeyInputExtiInit_test(GPIO_Module* GPIOx, uint16_t Pin)
{
    GPIO_InitType GPIO_InitStructure;
    EXTI_InitType EXTI_InitStructure;
    NVIC_InitType NVIC_InitStructure;
    /* Check the parameters */
    assert_param(IS_GPIO_ALL_PERIPH(GPIOx));
    /* Enable the GPIO Clock */
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
    /*Configure the GPIO pin as input floating*/
    GPIO_InitStructure.Pin        = Pin;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitPeripheral(GPIOx, &GPIO_InitStructure);
    /*Configure key EXTI Line to key input  Pin*/
    GPIO_ConfigEXTILine(GPIOA_PORT_SOURCE, GPIO_PIN_SOURCE5);
    /*Configure key EXTI line*/
    EXTI_InitStructure.EXTI_Line = EXTI_LINE5;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_InitPeripheral(&EXTI_InitStructure);
    /*Set key input interrupt priority*/
    NVIC_InitStructure.NVIC_IRQChannel                   = EXTI9_5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x05;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 0x0F;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
/*******************************************************************************
* 函数名 : 
* 描述   : 设备进行休眠，可用PA10高电平以及22点的闹钟唤醒
*******************************************************************************/
void DeviceIntoSleep(void)
{
	uint8_t i,date0[3],date1[3];
	uint8_t compensate_min = 0;
	LED_OFF;
	
//	RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_WWDG, DISABLE);  //关闭窗口看门狗
	if(LuatModule_PowerDown() != 1)
	{
		if(LuatModule_PowerDown() != 1)
		{
			LuatModule_PowerDown();
		}
	}
	if(Flag_COMDebug == 1)
		//按唤醒时间22:00:00来计算
		printf("补偿前时间为:%d,%d,%d\r\n",Timebuf[3],Timebuf[4],Timebuf[5]);
	compensate_min = 22-Timebuf[3]; //补偿时间，1h补偿1min
	if(compensate_min >= 17)        //补偿时间不能超过17分钟
	{
		compensate_min = 0;
	}
	
	for(i=0;i<3;i++)
		date0[i] = Timebuf[i+3];
	
	date1[0] = 22;	date1[1] = compensate_min;	date1[2] = 0;
	//闹钟唤醒
	if(Flag_COMDebug == 1)
	{
		printf("当前时间为:%d,%d,%d\r\n",date0[0],date0[1],date0[2]);
		printf("闹钟时间为:%d,%d,%d\r\n",date1[0],date1[1],date1[2]);
	}
	/* RTC time and Date default Value */
	RTC_DateAndTimeDefaultVale(date0,date1); 
	/* RTC clock source select */
	RTC_CLKSourceConfig(RTC_CLK_SRC_TYPE_LSI, true, true);
	RTC_PrescalerConfig();
	/* RTC Date time and Alarm value set */
	RTC_DateRegulate();
	RTC_TimeRegulate();
	RTC_AlarmRegulate(RTC_A_ALARM);
	/* Enable RTC Alarm Interrupt */
	EXTI17_RTCAlarm_Configuration(ENABLE);
	/* Enable PWR clock */
	RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_PWR, ENABLE);
	
	//PA10高电平唤醒
	if(Flag_COMDebug == 1)
		printf("关模组、芯片休眠，唤醒引脚为PA10\r\n");
	PWR_BackupAccessEnable(ENABLE);
	RCC_EnableBackupReset(DISABLE);
	KeyInputExtiInit(KEY_INPUT_PORT, KEY_INPUT_PIN);
//	KeyInputExtiInit_test(GPIOA,GPIO_PIN_5); //压阻压下唤醒
	
	delay_ms(500);	
	/* Request to enter STOP mode with regulator in low power mode*/
	PWR_EnterSTOP2Mode(PWR_STOPENTRY_WFI);
	/* Exit the low power ,need to reconfig the system clock */
	SYSCLKConfig_STOP(RCC_CFG_PLLMULFCT18);

	NVIC_SystemReset();  //重启
}
/*******************************************************************************
* 函数名 : 
* 描述   : 设备如果处于22~6点期间，则进行15min1发，否则进行休眠
*******************************************************************************/
char PowerBatteryDetermine(void)
{
	if((Timebuf[0]>22) && (Timebuf[1]<13) && (Timebuf[2]<32))  //日期正确
	{
		if((Timebuf[3]>=DEVICE_SLEEP_TIME_BEGIN) || (Timebuf[3]<DEVICE_SLEEP_TIME_END))  //处于22~6点
		{
			return 1;
		}
		else                                     //其他时间休眠
		{
			delay_ms(50);	                     //避免SOS同时收到两帧
			COMSynSOS_SleepStatus(USART1);       //告知SOS，待应答后进行休眠
		}
	}
}
/*******************************************************************************
* 函数名 : PowerBatteryDeal
* 描述   : 电池供电时处理
*******************************************************************************/
void PowerBatteryDeal(void)
{
	uint8_t i;
	
	LED_OFF;
	if(Flag_COMDebug == 1)
		printf("电池供电，关模组\r\n");
	Flag_init = SYSTEM_INIT;
	if(LuatModule_PowerDown() != 1)
	{
		if(LuatModule_PowerDown() != 1)
		{
			LuatModule_PowerDown();
		}
	}
		
	Flag_PowerOn = 0;
	Battery_CntTime = 0;
	Luat_15min_SendFlag = 0;
	
	//清除缓存数据，为15min一发做准备
	RealBatchIndex = 0;
	for(i=0;i<110;i++)
	{
		hrtest[i] = 0;
		rrtest[i] = 0;
		statustest[i] = 0;
	}
	
	for(i=0;i<6;i++)  //发送批量数据的起始时间
		OffTime[i] = Timebuf[i];
	
	PowerBatteryDetermine(); //深度休眠判断
}
/*******************************************************************************
* 函数名 : GetADCSampleData
* 描述   : 获取睡眠数据
*******************************************************************************/
void GetADCSampleData(void)
{
	uint8_t i;
	int a,p;
	static uint8_t false_cnt = 0;
//	if(((gPeopleFlag==1) || (gTurnFlag==1))&&(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED))
	#ifdef Only_PIE
	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)
	{
		RT_Hr = 75;
		RT_Rr = 15;
		RT_Status = 1;
	}
	else
	{
		RT_Hr = 0;
		RT_Rr = 0;
		RT_Status = 0;
	}
	#else
	if((gPeopleFlag==1) || (gTurnFlag==1)) //test code!!! 压电
	{
		if(((gPulseRateHR>45)&&(gPulseRateHR<100))||(gPulseRateHR == 0))//心跳正常
		{
			RT_Hr = gPulseRateHR;							
			Last_gPulseRateHR = gPulseRateHR;	
		}
		else
		{
			 ABN_gPulseRateHR = gPulseRateHR;	
			 RT_Hr = Last_gPulseRateHR;
		}
		if(((gPulseRateRR>5)&&(gPulseRateRR<35))||( gPulseRateRR == 0))
		{
			RT_Rr = gPulseRateRR;
			Last_gPulseRateRR = gPulseRateRR;
		}	
		else
		{
			 ABN_gPulseRateRR = gPulseRateRR;
			 RT_Rr = Last_gPulseRateRR;
		}				

		if(( gPulseRateHR == 0)&&(gPulseRateRR != 0)) //假数据
			RT_Hr = 75;
		if(( gPulseRateRR == 0)&&(gPulseRateHR != 0)) //假数据
			RT_Rr = 15;
		if(gTurnFlag)
			 RT_Status = 2; //体动
		else
			RT_Status = 1;
		if(( gPulseRateHR == 0)&&(gPulseRateRR == 0)) 
			RT_Status = 0;
	}
	else if((gPeopleFlag == 0)&&(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED))   //有人无法计算心率，则状态5
	{
		//随机数
		false_cnt++;
		srand(false_cnt); //生成随机数
		a = rand();
		p = a % 10 ;//设置范围  0-10
		RT_Hr = 80+p;
		RT_Rr = 10+(p/2)+(p/3);
		if(p%7 == 0)
			RT_Status = 2;
		else
			RT_Status = 1;
	}
	else  //离床
	{
		RT_Hr = 0;
		RT_Rr = 0;
		RT_Status = 0;
	}
	#endif
	
	if(PowerBatteryFlag == 0)  //插电供电
    {
        Andlink_MQTT_DataReport();
        iSuke_MQTT_Data();
    }
	else if(PowerBatteryFlag == 1)  //电池供电
	{
		if(RealBatchIndex > 110)  //防止越界
			RealBatchIndex = 110;
		hrtest[RealBatchIndex] = RT_Hr;
		rrtest[RealBatchIndex] = RT_Rr;
		statustest[RealBatchIndex] = RT_Status;
		RealBatchIndex++;
		if(Flag_COMDebug == 1)
			printf("RealBatchIndex:%d\r\n",RealBatchIndex);
		if(Luat_15min_SendFlag == 1)  //4G模组已经上电完成 
		{
			if(RealBatchIndex<=110)
				iSuke_MQTT_RealBatch(RealBatchIndex);
			else
				iSuke_MQTT_RealBatch(110);
			
			PowerBatteryDeal();  //关机处理
		}
	}
//	if(Flag_COMDebug == 1)
//	{
//		printf("Time is:%d-%d-%d %d:%d:%d\r\n",Timebuf[0],Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5]);//张炜20170524增加，打印发送时间
//		printf("SampleData:%d mV  gPulseRateRR:%d  gPulseRateHR:%d\r\n",SampleData,gPulseRateRR,gPulseRateHR);
//		printf("gTurnFlag:%d  gPeopleFlag:%d \r\n",gTurnFlag,gPeopleFlag);
//		printf("gPowerHeart:%d  gPowerBreath:%d  gPowerSample:%d gPowerTurn:%d \r\n",gPowerHeart,gPowerBreath,gPowerSample,gPowerTurn); //张炜20170601增加
//	}
}
/*******************************************************************************
* 函数名 : SendSleepData
* 描述   : 发送数据，获取服务器验证
* 输入   :
* 输出   :
* 返回   :
* 注意   :张炜2017023修改，按照新的协议发送MD5校验，
*         校验格式为：包头+ID+长度+指令+MAC+"123456"+TOKEN2
*******************************************************************************/
unsigned char uCMD[] = "P_DATA";
void SendSleepData(void)
{
    unsigned char i = 0;
    unsigned char ucMd5data[30] = {0};
    unsigned char ucMd5string[40] = {0};
    unsigned char ucMd5string1[40] = {0};
    unsigned char ucSenddata[100] = {0};
    unsigned char TOTAL_LEN = 0, CMD_LEN = 6, MD5_LEN = 32; //张炜20170522删除MAC_LEN = 12
    uint8_t len = 0; 
    uint8_t ucjiaoyan=0;		
		
	if(AngelPace == GETBACKSERVEROK)
	{
		memset(SendDataBuff,0x00,sizeof(SendDataBuff));
		if((SendDataStatus != OK)&&(AT_CGATT_Ctrl()==1))   //发送数据
		{	
			
//			if(SendSleepDataStatus == NO) //需要重新组装数据,张炜0170620修改
//				{	
         ClearUSART3BUF();						
					memset(TemporaryBuff,0x0,sizeof(TemporaryBuff));
						//获取MD5数据
					sprintf(ucMd5data,"%s123456%s",MAC_IDstring,Token2);
					  if(Flag_COMDebug == 1)
						{
							printf("Token2:%s",Token2);						
							printf("ucMd5data:%s\r\n",ucMd5data);
						}
						MDString(ucMd5data,ucMd5string);
						HexToLowerStr(ucMd5string1,ucMd5string,16);
						//log	
						if(Flag_COMDebug == 1)
						  printf("ucMd5string1:%s\r\n",ucMd5string1);
            }

//           GetADCSampleData();	//获取睡眠数据

            if(GPRS_or_WIFI == GPRS)
            {
//                sprintf(SendDataBuff, "AT+GPRS=%s%s", TemporaryBuff, SleepData);
            }
            else
            {
//                sprintf(SendDataBuff, "%s%s", TemporaryBuff, SleepData);
            }
//            ClearUSART3BUF();
            if(GPRS_or_WIFI == GPRS)
            {
//                GPRSSendData(SendDataBuff, strlen(SendDataBuff));
//--------------以下为张炜20170523按照新的协议修改发送的数据----------------------
								 UART3_SendString_YB("AT+GPRS=",8);
								 SendDataToUSART(USART3,0x24);
								 SendDataToUSART(USART3,0x01 );
							   len = strlen(ucMd5string1);
								 SendDataToUSART(USART3,(len+MAC_LEN+2)|0x80);							
								 SendDataToUSART(USART3,REQ_SECOND_MD5);
							   for(i=0;i<len ;i++)
							   {
									  SendDataToUSART(USART3,ucMd5string1[i]);
								 }
								 for(i=0;i<MAC_LEN ;i++)
								 {
										SendDataToUSART(USART3,MAC_ID[i]);
								 } 
                 for(i = 0;i< len;i++)
									{
										ucjiaoyan += ucMd5string1[i];
									}								 
								 for(i = 0;i< MAC_LEN;i++)
									{
										ucjiaoyan += MAC_ID[i];
									}
								 ucjiaoyan +=REQ_SECOND_MD5;
								 SendDataToUSART(USART3,ucjiaoyan|0x80 );
								 SendDatasToUSART(USART3,0x6942 );
								 UART3_SendLR();
								 if(Flag_COMDebug == 1)
										printf("Send MD5 data!\r\n");						
//            }
            SendDataStatus = OK;
            mytime = 0;										//开始计时超时
            YZTime = 0;	
           															
//            memset(SendDataBuff, 0x00, sizeof(SendDataBuff));
        }
       else   //发送数据
			 {
				   AngelPace = GETBACKSERVERIPOK;
				   
				   SendDataStatus = NO;					//打开发送开关
			 }       
    }
    else
    {
        return;
    }
}
/*******************************************************************************
* 函数名 : SendSleepDataRcvCtr
* 描述   : 获取后置服务器验证是否成功
* 输入   :
* 输出   :
* 返回   :
* 注意   :
*******************************************************************************/
void SendSleepDataRcvCtr(void)
{
 	SendSleepDataRece(ucUar3tbuf);   
}
/*******************************************************************************
* 函数名 : GetBackServerPwRece
* 描述   : 获取token2时，接收函数处理
* 输入   :
* 输出   :
* 返回   :
* 注意   :张炜20170523按照新的协议修改GPRS数据通讯，未修改WiFi接收部分
*******************************************************************************/
void GetBackServerPwRece(unsigned char ucP)
{
    char *pstr = NULL;
    unsigned char ucTokenOK = 0,i=0;
    uint8_t ucjiaoyan = 0;
	  uint8_t cmd[20];
	  
    if(ucP == GPRS)
    {
			  delay_ms_YB();									//等待接收完数据
//			  delay_ms_YB2();
//			  delay_ms_YB2();
        pstr = strstr(ucUar3tbuf, "$");		  
        if(pstr != NULL)
        {
          delay_ms_YB2();
//					printf("Receinved Token2:%s\r\n",ucUar3tbuf);		
				  if((pstr[0] == CMD_START)&&(pstr[1] == TypeID)&&(pstr[3] == REQ_SECOND_TOKEN))   //返回的指令是获取token指令
         {             					 
					  TOKEN2_LEN = (pstr[2]&0x7F)-2;
						 for(i = 0;i< TOKEN2_LEN;i++)
								{
									Token2[i] = pstr[i+4];
								}
						 for(i = 0;i< TOKEN2_LEN;i++)
							{
								ucjiaoyan += Token2[i];
							}
						   ucjiaoyan +=REQ_SECOND_TOKEN;
												
//							if(ucUar3tbuf[TOKEN2_LEN+2] == (ucjiaoyan|0x80) ) 			//token2校验成功
//							{									
								  ucTokenOK = 1;
							    if(Flag_COMDebug == 1)
											printf("Get Token2 is:%s\r\n", Token2);
									SaveMACToFlash();    //张炜20170523增加，获取成功则保存
							    Flag_Check_Status &= 0xFD;
								  AngelPace = GETBACKSERVEROK;		//如果验证码合法，进入下一步
								  SendDataStatus = NO;   //
							    
							    ClearUSART3BUF();  //清除串口缓存;
//							}
//							else 											//校验不成功
//							{
//									printf("ERROR Token2:%s\r\n", ucUar3tbuf);
//									SendDataStatus = NO;
//								  ucTokenOK = 0;
//								  memset(Token2, 0x00, sizeof(Token2));
//							}	
						}
				    if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== SERVER_ABNORMAL_MESSAGE)) //MAC验证错误
						 {								
							 if(pstr[4] == SERVER_CHECK_MAC_ERR)
							 {
								  if(Flag_COMDebug == 1)
										printf("Server Return MAC Verify Error!\r\n");
									AngelPace = CONECTIP1;
									Flag_Check_Status |= ERROR_NO_TOKEN2;
									SendDataStatus = NO;					//打开发送开关
									SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
					//			  Flag_Check_Status = ERROR_MAC_ERR;
							 }
							 ClearUSART3BUF();
						 }
         }	
        if(strstr(ucUar3tbuf, "SHUT") != NULL)
       {
				  if(Flag_COMDebug == 1)
						printf("SendSleepData U3 ERROR2:%s\r\n", ucUar3tbuf);
					Flag_Check_Status |= ERROR_NO_TOKEN2;
					AngelPace = CONECTIP1;
					SendDataStatus = NO;					//打开发送开关
					SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
       }				
        if(mytime > GetFirstDataTimeOut) 				//超时时间为3s		//等待接收数据超时
        {
					  if(Flag_COMDebug == 1)
							printf("Time Out!%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
            AngelPace = GETBACKSERVERIPOK;
        }
        CheckSystemErrorContrl();				//模块出现异常情况
        if(strstr(ucUar3tbuf, "CLOSED") != NULL)
        {
					  if(Flag_COMDebug == 1)
							printf("CL:%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
            AngelPace = GETBACKSERVERIPOK;
        }
#if 0
        /***********************2017-03-02 start 获取token返回OK的解决办法******************************/
        pstr = strstr(ucUar3tbuf, "OK\n");				//判断中断接收是否有需要的数据
        if(pstr != NULL)
        {
            delay_ms_YB2();
            if(strstr(ucUar3tbuf, "CLOSED") != NULL)
            {
                printf("CL:%s\r\n", ucUar3tbuf);
            }
            if(pstr[3 + 8] == '\n' || pstr[3 + 9] == '\n')
            {
                if(pstr[3] == '7')
                {
                    memcpy(Token2, pstr + 3, 8);
                }
                if(pstr[3] == '8')
                {
                    memcpy(Token2, pstr + 3, 9);
                }
                printf("Token2:%s\r\n", Token2);
            }
        }
        pstr = strstr(ucUar3tbuf, "K\n");
        if(pstr != NULL)
        {
            delay_ms_YB2();
            if(strstr(ucUar3tbuf, "CLOSED") != NULL)
            {
                printf("CL:%s\r\n", ucUar3tbuf);
            }
            if(pstr[2 + 8] == '\n' || pstr[2 + 9] == '\n')
            {
                if(pstr[2] == '7')
                {
                    memcpy(Token2, pstr + 2, 8);
                }
                if(pstr[2] == '8')
                {
                    memcpy(Token2, pstr + 2, 9);
                }
                printf("Token2:%s\r\n", Token2);
            }
        }
        /***********************2017-03-02 end 获取token返回OK的解决办法******************************/
#endif
        //if(strstr(ucUar3tbuf,"C_SESSION or P_DATA is null")!=NULL){
        if(ucUar3tbuf[0] == '1' || ucUar3tbuf[0] == '2' || ucUar3tbuf[0] == '3')
        {
					  if(Flag_COMDebug == 1)
							printf("DataErr:%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        if(ucUar3tbuf[0] == '4' || ucUar3tbuf[0] == '5' || ucUar3tbuf[0] == '6' || ucUar3tbuf[0] == '7')
        {
					  if(Flag_COMDebug == 1)
							printf("DataErr:%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
            AngelPace = GETBACKSERVERIPOK;
        }
    }   			
}
/*******************************************************************************
* 函数名 : SendSleepDataRece
* 描述   : 服务器MD5验证数据返回
* 输入   :
* 输出   :
* 返回   :
* 注意   :张炜20170523按新的协议修改，验证成功返回0x0401，验证失败返回0xF201
*******************************************************************************/
void SendSleepDataRece(unsigned char * p)
{
	unsigned char SeverTimebuf[20]={0},i=0;
	char Fbuff[3]={0};
	uint8_t len = 0;
	char *pstr = NULL;
	char *pstr1 = NULL;
	unsigned char receivetime[6];
	
	
	 ucUar3InterrFlag = 0;
	 								//防止接收不完整	
	 pstr = strstr(ucUar3tbuf, "$");
   pstr1 = strstr(ucUar3tbuf, "iB");	
   if((pstr != NULL)&&(pstr1 != NULL))
	 {
		 if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== REQ_SECOND_MD5)) //MD5验证成功
		 {
             if(Flag_COMDebug == 1)
						printf("[OK]Server Return MD5 Verify OK!\r\n");
			 len = pstr[2]&0x7F-2;	
				for(i=0;i<6;i++)  //获取服务器时间
				{
					receivetime[i] = (pstr[4+i*2]&0x7F-0x30)*10+(pstr[5+i*2]&0x7F-0x30); //将ASCII字符的两个字节的时间转换为1个字节的时间		 
				}
				if(Flag_PowerOn == 0)   //设置统计的结束状态
				{
					 Set_StatistEndTime();
				}
				if((receivetime[0]>0)&&(receivetime[0]<99)&&(receivetime[1]>0)&&(receivetime[1]<13)&&(receivetime[2]>0)&&(receivetime[2]<32))
				{
					 for(i=0;i<6;i++)
					{
						 Timebuf[i] = receivetime[i];
					}
					if(Flag_COMDebug == 1)
						printf("[OK]Server time is:%d-%d-%d %d:%d:%d\r\n",Timebuf[0],Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5]);
				}		
				SendDataStatus = NO;					//打开发送开关
//				UART3_SendString("AT+REGISTER=1");		//允许外发给服务器数据
//				UART3_SendLR();
				Flag_TimeAdj = 0;
							
			  //GetGPRSPosition();
			  Send_GPRSPosition(Flag_Start_Mode,Position_LAC,Position_CID);
			  //if(Flag_CARD_ISCHANGE == CARD_HASCHANGE)  //发送卡的IMSI号
			  {
					if(Flag_COMDebug == 1)
							printf("SIM Card has changed!\r\n");
					//Send_CARD_IMSI();
                    Send_CARD_ICCID();
                    SaveMACToFlash();
			  }			 
				 Flag_LinkStatus = START_GPRS_LINKOK;
				 AngelPace = SendSleepDataR;				//进入发送睡眠数据模式
				 Flag_start_time = 0;
				 GPRS_ConnetTime =0;
				 Flag_CanSendStatistData = 1;
				 SleepDataBuffer_SendTime = 0;
				 Flag_PowerOn = 0;	
		 }
		 if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== SERVER_ABNORMAL_MESSAGE)) 
		 {		 
			 if(pstr[4] == SERVER_CHECK_MD5_ERR)  //MD5验证错误
			 {
				  if(Flag_COMDebug == 1)
						printf("Server Return MD5 Verify Error!\r\n");
					AngelPace = CONECTIP2OK;
					Flag_Check_Status |= ERROR_NO_TOKEN2;
					SendDataStatus = NO;					//打开发送开关
					SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
	//			  Flag_Check_Status = ERROR_MD5_ERR;					
			 }
			 if(pstr[4] == SERVER_CHECK_MAC_ERR)  //MAC验证错误
			 {
				  if(Flag_COMDebug == 1)
						printf("Server Return MAC Verify Error!\r\n");
					AngelPace = CONECTIP1;
				  Flag_Check_Status |= ERROR_NO_TOKEN2;
					SendDataStatus = NO;					//打开发送开关
					SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
	//			  Flag_Check_Status = ERROR_MAC_ERR;
					
			 }				 
		 }
		 ClearUSART3BUF();
     return ;		 
	 }
    if(strstr(ucUar3tbuf, "SEND FAIL") != NULL) 	//发送失败
    {
			  if(Flag_COMDebug == 1)
					printf("SendSleepData U3 ERROR0:%s\r\n", ucUar3tbuf);
        AngelPace = GETBACKSERVERIPOK;			//进入链接模式
        SendDataStatus = NO;					//打开发送开关
        SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
    }
    if(strstr(ucUar3tbuf, "CLOSED") != NULL) 		//链路意外关闭
    {
			  if(Flag_COMDebug == 1)
						printf("SendSleepData U3 ERROR1:%s\r\n", p);
        AngelPace = GETBACKSERVERIPOK;			//进入链接模块
        SendDataStatus = NO;					//打开发送开关
        SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
    }
    if(strstr(ucUar3tbuf, "SHUT") != NULL)
    {
			  if(Flag_COMDebug == 1)
					printf("SendSleepData U3 ERROR2:%s\r\n", ucUar3tbuf);
        Flag_Check_Status |= ERROR_NO_TOKEN2;
        AngelPace = CONECTIP1;
        SendDataStatus = NO;					//打开发送开关
        SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
    }
    if(YZTime >= GetFirstDataTimeOut)
    {
    	  YZTime =0;
			  if(Flag_COMDebug == 1)
					printf("Send MD5 TimeOut:%s\r\n", ucUar3tbuf);
        ClearUSART3BUF();								//清空缓存
        SendDataStatus = NO;					//打开发送开关
        SendSleepDataStatus = OK;				//发送成功

    }
    //CheckSystemErrorContrl();					//模块出现异常情况
}

/*******************************************************************************
* 函数名 : CheckSystemErrorContrl
* 描述   : 检查模块出现异常情况，如POWER ON
* 输入   :
* 输出   :
* 返回   :
* 注意   :
*******************************************************************************/
char CheckSystemErrorContrl(void)
{
    char statue = 0;
//    if((strstr(ucUar3tbuf, "POWER ON") != NULL)||(strstr(ucUar3tbuf, "SMS Ready") != NULL))
//    {
//			 if(AngelPace == SendSleepDataR)
//			 {
//          Set_StatistStartTime();	
//				  Flag_Start_Mode = START_NETWOEK_RECONNECT;  //网络关闭重连
//				  GPRS_ConnetTime =0;	
//			 }
//        SendDataStatus = NO;					//打开数据发送
//        SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
//        statue = 1;
//			  if(Flag_COMDebug == 1)
//					printf("Restart GPRS!\r\n");		 	
//			 Flag_Send_GPRS_Position = 0;								 
//			 SendDataStatus = NO;					//打开发送开关
//			 SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
//			 Flag_init = MAC_INIT_OK;  //进行无线模块初始化
//			 Flag_start_time = 1;	
//			 ClearUSART3BUF();					 						 
//    }

    return statue;
}
#if 0
void uart_send_sleep_data(void)
{
    //奥飞医疗-9600bps
    char send_data[20];
    char sum_check;
    char i=0,j;
    //send_data[i++]=gPulseRateHR;
    send_data[i++]=SleepData[5]&(~0x80);
    //send_data[i++]=gPulseRateRR;
    send_data[i++]=SleepData[6]&(~0x80);
    send_data[i++]=gTurnFlag;
    send_data[i++]=gPeopleFlag;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    send_data[i++]=0x0d;
    send_data[i++]=0x0a;
   UART1_SendString_YB(send_data,7);
    //printf("%s",send_data);

}
#else
void uart_send_sleep_data(void)
{
    //百世联-智美康床垫
    char send_data[35];
    char sum_check;
    char i=0,j;
    uint16_t heart,resp;
    //心率
    heart=SleepData[5]&(~0x80);
    resp=SleepData[5]&(~0x80);
    send_data[i++]=1;
    send_data[i++]=heart/256;
    send_data[i++]=heart%256;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
    //呼吸
    i=0;
    send_data[i++]=3;
    send_data[i++]=resp/256;
    send_data[i++]=resp%256;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
     //休息
     i=0;
    send_data[i++]=0x4a;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
         //抽搐
    i=0;
    send_data[i++]=0x4b;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
         //呼吸弱
    i=0;     
    send_data[i++]=0x4c;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
          //辗转
    i=0;      
    send_data[i++]=0x4d;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=0x32;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;
    UART1_SendString_YB(send_data,5);
           //有人到无人
    i=0;       
    send_data[i++]=0x4e;
    send_data[i++]=0;
    send_data[i++]=0;
    send_data[i++]=1;
    sum_check=0;
    for(j=0;j<i;j++)
        sum_check+=send_data[j];
    send_data[i++]=sum_check;

   UART1_SendString_YB(send_data,5);
    //printf("%s",send_data);

}
#endif
/*******************************************************************************
* 函数名 : SendSleepDataReally
* 描述	 : 发送睡眠数据处理
* 输入	 :
* 输出	 :
* 返回	 :
* 注意	 :
*******************************************************************************/
char SendSleepDataReally(void)
{
    if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0)) 		//有校时过
	{
		if(AngelPace == SendSleepDataR)
			GetADCSampleData();									//发送睡眠数据
	}
}
/*******************************************************************************
*	函 数 名:  Statist_SleepStatus
*	功能说明:  统计睡眠状态
*	形    参：
*	返 回 值:
* 说    明：在断网的情况下统计睡眠状态
*          统计数据在状态改变的时候保存，有人/无人/体动，小于20s体动不统计，小于1分钟脱离监护不统计
*          每条数组最多保存一个小时的数据，心率呼吸值10分钟统计一次
*******************************************************************************/
void Statist_SleepStatus(void)
{
	  uint8_t i = 0;
	  uint8_t AveraveHR = 0;
	  uint8_t AveraveRR = 0;
	  unsigned char buf[2];
	
	  if((gPulseRateHR!=0)&&(gPulseRateRR!=0)&&(gPulseRateHR<200)&&(gPulseRateRR<60))//累积心率呼吸数值
		 {
				Statist_AddHR += gPulseRateHR;
				Statist_AddRR += gPulseRateRR;
				Statist_AddCount++;
		 }	 
/*******************************体动状态**********************************/
		 if(gTurnFlag == 1)    //
		 {
			 if(Keep_StatusFlag == STATIST_TURN)  //持续体动状态
			 {
				  TurnKeepTime += AT_CGATT_Count;  //体动时间累计
			 }
			 if(Keep_StatusFlag != STATIST_TURN)   //开始体动
			 {
				 if(Keep_StatusFlag == STATIST_NOPEOPLE )
				 {
					   NoPeopleKeepTime += AT_CGATT_Count;
				 }
				 if(Keep_StatusFlag == STATIST_PEOPLE )
				 {
					   PeopleKeepTime += AT_CGATT_Count;
				 }
				 if(Flag_NoNetWorkStart == 1)
				 {
					  Flag_NoNetWorkStart = 2;
					  Last_StatusFlag  = Keep_StatusFlag;
					  Keep_StatusFlag = STATIST_TURN;
					  if(Flag_COMDebug == 1)
					     printf("First Change! \r\n");
				 }
				 else
				 {
				 //---------------------------体动之前的无人状态超过60s----------------------------------------
				  if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60))//
					{
						  if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //上次超过20s体动，则保存
							{
								  AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
									AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
									Statist_AddCount = 0;
									Statist_AddHR=0;
									Statist_AddRR = 0;
								  Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
							}
							if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //上上次少于20s体动，将体动时间赋值给其之前状态
							{
									for(i=0;i<6;i++)
									{
										 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
									}
							}
							if(Last_StatusFlag == STATIST_PEOPLE) //上上次为有人状态
							{
								 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
								 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
								 Statist_AddCount = 0;
								 Statist_AddHR=0;
								 Statist_AddRR = 0;
								 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
								 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
								 Flag_SavepPos++;
								 PeopleKeepTime = 0;
								 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
								 if( Flag_SavepPos == 6)
									  Flag_SavepPos = 0;						
							}
							Last_StatusFlag  = Keep_StatusFlag;
							TurnKeepTime = 0;
							for(i=0;i<6;i++)
							{
								 Statist_TurnStartTimebuf[i]= Timebuf[i];  //获取状态改变开始时间
								 Statist_NoPeopleEndTimebuf[i]= Timebuf[i];
							}	
					}
					if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60))//体动之前的无人状态小于60s，状态有效
				 	{
						  if(Last_StatusFlag == STATIST_PEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_PeopleEndTimebuf[i] = Timebuf[i];
										Statist_TurnStartTimebuf[i]= Timebuf[i];
									}
								  PeopleKeepTime += NoPeopleKeepTime;
								  TurnKeepTime = 0;									
							}							
						  if(Last_StatusFlag == STATIST_TURN)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_TurnEndTimebuf[i] = Timebuf[i];
									}
									TurnKeepTime += NoPeopleKeepTime;
							}
							
					}
		//-----------------------体动之前是有人状态---------------------------------------------------		
					if(Keep_StatusFlag ==STATIST_PEOPLE)  //上个状态是有人，则直接保存上上个状态
					{
						 if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //上次超过20s体动，则保存
							{
								  AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
									AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
									Statist_AddCount = 0;
									Statist_AddHR=0;
									Statist_AddRR = 0;
								  Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
							}
							if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  
							{
								 for(i=0;i<6;i++)
									{
										 Statist_PeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
									}
									PeopleKeepTime += TurnKeepTime;	
							}
							if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //上上个状态是无人
							{
								buf[0] = 0;
								buf[1]= 0;
								Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
							}
							if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //上上个状态是无人
							{
								 for(i=0;i<6;i++)
									{
										 Statist_PeopleStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];
									}
									PeopleKeepTime += NoPeopleKeepTime;	
							}
							Last_StatusFlag  = Keep_StatusFlag;
							TurnKeepTime = 0;
							for(i=0;i<6;i++)
							{
								 Statist_TurnStartTimebuf[i]= Timebuf[i];  //获取状态改变开始时间
								 Statist_PeopleEndTimebuf[i]= Timebuf[i];  //获取状态改变开始时间
							}	
					}
																		
					Keep_StatusFlag = STATIST_TURN;						
					Flag_SavepPos = 0;
					if(Flag_COMDebug == 1)
					   printf("Start Turn! \r\n");
		 	 }
		  }				 
		}

/*******************************开始无人状态**********************************/		 
		 if(gPeopleFlag == 0) //
		 {
			 if(Keep_StatusFlag == STATIST_NOPEOPLE)  //持续无人状态
			 {
				  NoPeopleKeepTime += AT_CGATT_Count;  //无人时间累计
			 }
			 if(Keep_StatusFlag != STATIST_NOPEOPLE)   //开始无人
			 {
				 if(Keep_StatusFlag == STATIST_TURN )
				 {
					  TurnKeepTime += AT_CGATT_Count;
				 }
				 if(Keep_StatusFlag == STATIST_PEOPLE )
				 {
					   PeopleKeepTime += AT_CGATT_Count;
				 }
				 
				if(Flag_NoNetWorkStart == 1)
				 {
					  Flag_NoNetWorkStart = 2;
					  Last_StatusFlag  = Keep_StatusFlag;
					  Keep_StatusFlag = STATIST_NOPEOPLE;
						if(Flag_COMDebug == 1)
							printf("First Change! \r\n");
				 }
				 else
				 {				 
	//--------------上个状态是体动----------------------------------------			 
				  if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //体动小于20s
					{
						 if(Last_StatusFlag == STATIST_PEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_PeopleEndTimebuf[i] = Timebuf[i];
										Statist_NoPeopleStartTimebuf[i] = Timebuf[i];										
								}	
									PeopleKeepTime += TurnKeepTime;
								NoPeopleKeepTime = 0;									
							}							
						  if(Last_StatusFlag == STATIST_NOPEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_NoPeopleEndTimebuf[i] = Timebuf[i];
									}
									NoPeopleKeepTime += TurnKeepTime;
							}						
					}
					if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //体动大于20s
					{
						if(Last_StatusFlag == STATIST_PEOPLE)  //体动之前是有人，直接保存
						{
							 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
							 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
							 Statist_AddCount = 0;
							 Statist_AddHR=0;
							 Statist_AddRR = 0;
							 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
							 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
							 Flag_SavepPos++;
							 PeopleKeepTime = 0;
							 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
							 if( Flag_SavepPos == 6)
									Flag_SavepPos = 0;			
							
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //上上个状态是无人
						{
								buf[0] = 0;
								buf[1]= 0;
								Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //上上个状态是无人
						{
							 for(i=0;i<6;i++)
								{
									 Statist_TurnStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];								 
								}
						}
						Last_StatusFlag  = Keep_StatusFlag;	
						NoPeopleKeepTime = 0;
						for(i=0;i<6;i++)
						{
							 Statist_NoPeopleStartTimebuf[i]= Timebuf[i];  //获取状态改变开始时间
							 Statist_TurnEndTimebuf[i]= Timebuf[i];
						}
						
					}
//--------------上个状态是有人----------------------------------------	
				 if(Keep_StatusFlag == STATIST_PEOPLE) 
				 {
					  if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //上上个状态是无人
						{
								buf[0] = 0;
								buf[1]= 0;
								Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //上上个状态是无人
						{
							 for(i=0;i<6;i++)
								{
									 Statist_PeopleStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];
								}
								PeopleKeepTime += NoPeopleKeepTime;	
						}
						if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //上次超过20s体动，则保存
							{
								  AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
									AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
									Statist_AddCount = 0;
									Statist_AddHR=0;
									Statist_AddRR = 0;
								  Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
							}
							if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //上上次少于20s体动，将体动时间赋值给其之前状态
							{
									for(i=0;i<6;i++)
									{
										 Statist_PeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
									}
									PeopleKeepTime += TurnKeepTime;	
							}						
							Last_StatusFlag  = Keep_StatusFlag;
						NoPeopleKeepTime = 0;	
						for(i=0;i<6;i++)
					  {
						   Statist_PeopleEndTimebuf[i]= Timebuf[i];  //获取状态改变开始时间
							 Statist_NoPeopleStartTimebuf[i]= Timebuf[i];
					  }	
           						
				 }
				 					
					Keep_StatusFlag = STATIST_NOPEOPLE;						
					Flag_SavepPos = 0;
					if(Flag_COMDebug == 1)
						printf("Start no people on bed! \r\n");	
			 }
		 }				 
	 }
/*******************************有人状态**********************************/	
   if((gPeopleFlag == 1)&&(gPowerTurn == 0)) //
	 {				 
      if(Keep_StatusFlag == STATIST_PEOPLE)  //持续有人
			{
				 PeopleKeepTime+= AT_CGATT_Count;
				 if(PeopleKeepTime>=540)  //  9分钟计算一次数据
				 {
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;				  
						Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
						Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
						Flag_SavepPos++;
						if( Flag_SavepPos == 6)   //6组数据为1个小时
						{
							 Save_StatistStatusData(Statist_PeopleStartTimebuf,Timebuf,STATIST_PEOPLE ,6,Save_SleepHRData,Save_SleepRRData);
							 Flag_SavepPos = 0;
							 for(i=0;i<6;i++)
								{
										Statist_PeopleStartTimebuf[i]= Timebuf[i];  //获取状态改变开始时间
								}
						}
						if(Flag_COMDebug == 1)
							printf("People keep on bed!,keep time:%d s,average HR:%d,average RR:%d \r\n",PeopleKeepTime,AveraveHR,AveraveRR);
						PeopleKeepTime = 0;
				 }
			}
		if(Keep_StatusFlag != STATIST_PEOPLE)  //开始有人
		 {
			 if(Keep_StatusFlag == STATIST_TURN )
				 {
					  TurnKeepTime += AT_CGATT_Count;
				 }
				 if(Keep_StatusFlag == STATIST_NOPEOPLE )
				 {
					   NoPeopleKeepTime += AT_CGATT_Count;
				 }
			if(Flag_NoNetWorkStart == 1)
			 {
					Flag_NoNetWorkStart = 2;
					Last_StatusFlag  = Keep_StatusFlag;
				 Keep_StatusFlag = STATIST_PEOPLE;
				if(Flag_COMDebug == 1)
						printf("First Change! \r\n");
			 }
			 else
			 {
		//-----------------上个状态为体动-------------------------	 
			  if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //体动小于20s
					{
						 if(Last_StatusFlag == STATIST_PEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_PeopleEndTimebuf[i] = Timebuf[i];									
									}	
									PeopleKeepTime += TurnKeepTime;										
							}							
						  if(Last_StatusFlag == STATIST_NOPEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_NoPeopleEndTimebuf[i] = Timebuf[i];
										Statist_PeopleStartTimebuf[i]= Timebuf[i]; 
									}
									NoPeopleKeepTime += TurnKeepTime;
									PeopleKeepTime = 0;									
							}						
					}
					if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //体动大于20s
					{
						if(Last_StatusFlag == STATIST_PEOPLE)  //体动之前是有人，直接保存
						{
							 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
							 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
							 Statist_AddCount = 0;
							 Statist_AddHR=0;
							 Statist_AddRR = 0;
							 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
							 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
							 Flag_SavepPos++;
							 PeopleKeepTime = 0;
							 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
							 if( Flag_SavepPos == 6)
									Flag_SavepPos = 0;			
							
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //上上个状态是无人
						{
								buf[0] = 0;
								buf[1]= 0;
								Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
						}
						if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //上上个状态是无人
						{
							 for(i=0;i<6;i++)
								{
									 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
								}
								TurnKeepTime += NoPeopleKeepTime;
						}
						Last_StatusFlag  = Keep_StatusFlag;
						PeopleKeepTime = 0;
						for(i=0;i<6;i++)
						{
							 Statist_PeopleStartTimebuf[i]= Timebuf[i];  //获取状态改变开始时间
							 Statist_TurnEndTimebuf[i] = Timebuf[i];
						}						
					}
			//-----------------上个状态为无人-------------------------		
					if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60))//
					{
						  if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //上次超过20s体动，则保存
							{
								  AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
									AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
									Statist_AddCount = 0;
									Statist_AddHR=0;
									Statist_AddRR = 0;
								  Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
							}
							if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //上上次少于20s体动，将体动时间赋值给其之前状态
							{
									for(i=0;i<6;i++)
									{
										 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
									}
							}
							if(Last_StatusFlag == STATIST_PEOPLE) //上上次为有人状态
							{
								 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
								 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
								 Statist_AddCount = 0;
								 Statist_AddHR=0;
								 Statist_AddRR = 0;
								 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
								 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
								 Flag_SavepPos++;
								 PeopleKeepTime = 0;
								 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
								 if( Flag_SavepPos == 6)
									  Flag_SavepPos = 0;						
							}
							Last_StatusFlag  = Keep_StatusFlag;
							PeopleKeepTime = 0;
							for(i=0;i<6;i++)
							{
								 Statist_PeopleStartTimebuf[i]= Timebuf[i];  //获取状态改变开始时间
								 Statist_NoPeopleEndTimebuf[i]= Timebuf[i];
							}
					}
					if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60))//体动之前的无人状态小于60s，状态有效
				 	{
						  if(Last_StatusFlag == STATIST_PEOPLE)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_PeopleEndTimebuf[i] = Timebuf[i];
									}
									PeopleKeepTime += NoPeopleKeepTime;	
							}							
						  if(Last_StatusFlag == STATIST_TURN)
							{
								  for(i=0;i<6;i++)
								  {
										Statist_TurnEndTimebuf[i] = Timebuf[i];
										Statist_PeopleStartTimebuf[i]= Timebuf[i];
									}
									TurnKeepTime += NoPeopleKeepTime;	
									PeopleKeepTime = 0;
							}
							
					}						   					
					Keep_StatusFlag = STATIST_PEOPLE;	
					
				if(Flag_COMDebug == 1)
					printf("Start people on bed! \r\n");
		  }
	   }
	 }	
}
/*******************************************************************************
*	函 数 名:  Save_StatistStatusData
*	功能说明:  保存状态统计数据时间
*	形    参：*starttime开始时间，*endtime结束时间,status状态，len 心率呼吸数组长度，averavehr平均心率，averagerr平均呼吸
*	返 回 值:
* 说    明：
*******************************************************************************/
void  Save_StatistStatusData(unsigned char *starttime,unsigned char *endtime,uint8_t status,uint8_t len,unsigned char *averavehr,unsigned char *averagerr)
{
	  uint8_t i=0;
	
	  Buffer_SleepData[Flag_SleepDataBuffer_Save][0] = CMD_START;
	  Buffer_SleepData[Flag_SleepDataBuffer_Save][1] = TypeID;
	  Buffer_SleepData[Flag_SleepDataBuffer_Save][2] = (2*len+15)|0x80;
	  Buffer_SleepData[Flag_SleepDataBuffer_Save][3] = SEND_STATISTICS_SLEEPDTAT;
	  for(i=0;i<6;i++)
		{
			Buffer_SleepData[Flag_SleepDataBuffer_Save][4+i] = starttime[i]|0x80;
		}
		for(i=0;i<6;i++)
		{
			Buffer_SleepData[Flag_SleepDataBuffer_Save][10+i] = endtime[i]|0x80;
		}		
		Buffer_SleepData[Flag_SleepDataBuffer_Save][16] = status|0x80;
		for(i=0;i<len;i++)
		{
			Buffer_SleepData[Flag_SleepDataBuffer_Save][17+2*i] = averavehr[i]|0x80;
			Buffer_SleepData[Flag_SleepDataBuffer_Save][18+2*i] = averagerr[i]|0x80;
		}

		Buffer_SleepData[Flag_SleepDataBuffer_Save][17+2*len] = 0xff;
		Buffer_SleepData[Flag_SleepDataBuffer_Save][18+2*len] = 0x69;
		Buffer_SleepData[Flag_SleepDataBuffer_Save][19+2*len] = 0x42;
		Buffer_SleepData[Flag_SleepDataBuffer_Save][20+2*len] = '\0';
		
		Flag_SleepDataBuffer_Save++;    //下一个保存位置
		if(Flag_SleepDataBuffer_Save==SLEEPDTATABUF)
		{
			  Flag_SleepDataBuffer_Save=0;
			  if(Flag_SleepDataBuffer_Send == Flag_SleepDataBuffer_Save)
					Flag_SleepDataBuffer_Send++;
		}
			
		 if(Flag_COMDebug == 1)
		{
			printf("\r\n--------Save Statistics Data:%d-----------\r\n",Flag_SleepDataBuffer_Save-1);
			printf("Start Time is:%d-%d-%d %d:%d:%d\r\n",starttime[0],starttime[1],starttime[2],starttime[3],starttime[4],starttime[5]);
		  printf("Finish Time is:%d-%d-%d %d:%d:%d\r\n",endtime[0],endtime[1],endtime[2],endtime[3],endtime[4],endtime[5]);
		  printf("Statistics data len is:%d",len);
			printf("Statistics status is:%d\r\n",status);
		}
}
/*******************************************************************************
*	函 数 名:  Send_StatistStatusData
*	功能说明:  发送保存的状态统计数据时间
*	形    参：
*	返 回 值:
* 说    明：
*******************************************************************************/
void  Send_StatistStatusData(void)
{
	  uint8_t len =0;
	  uint8_t i=0;
	  uint8_t sendstatistdata[60];
	
//	  len = strlen(Buffer_SleepData[Flag_SleepDataBuffer_Send]);
	
	  //sprintf(sendstatistdata, "AT+GPRS=%s",Buffer_SleepData[Flag_SleepDataBuffer_Send]);		//将睡眠数据加上GPRS发送的AT+SEND指令头
		if(Flag_COMDebug == 1)
		{
			 printf("GPRS send Statistics buff is :%d \r\n",Flag_SleepDataBuffer_Send);
//			  for(i=0;i<len;i++)
//			  {
//					printf("0x%02x ",Buffer_SleepData[Flag_SleepDataBuffer_Send][i]);
//			   }
			  printf("\r\n----------------------------\r\n");
		}
		GPRS_Send_Data(Buffer_SleepData[Flag_SleepDataBuffer_Send], strlen(Buffer_SleepData[Flag_SleepDataBuffer_Send]));
	  
}
/*******************************************************************************
*	函 数 名:  Set_StatistStartTime
*	功能说明:  断网开始时，设置统计的开始时间
*	形    参：
*	返 回 值:
* 说    明：
*******************************************************************************/
void  Set_StatistStartTime(void)
{
	uint8_t i = 0;
	if(Flag_COMDebug == 1)
		printf("Set_StatistStartTime...%d\r\n",Flag_COMDebug);
		Flag_NoNetWorkStart = 1;         //开始断网
		if((gPeopleFlag == 1)&&(gPowerTurn == 0))  //有人状态
		 {      
				
				Keep_StatusFlag = STATIST_PEOPLE;
				Last_StatusFlag = STATIST_PEOPLE;
		 }
		 if((gPeopleFlag == 0)&&(gPowerTurn == 0))  //无人状态
		{

			Keep_StatusFlag = STATIST_NOPEOPLE;
			Last_StatusFlag = STATIST_NOPEOPLE;
		}	
		if(gPowerTurn == 1)   //体动状态
		{
		  
			Keep_StatusFlag = STATIST_TURN;
			Last_StatusFlag = STATIST_TURN;
		}
		PeopleKeepTime = 0;
		TurnKeepTime = 0;
		NoPeopleKeepTime = 0;
		for(i=0;i<6;i++)
		{
				Statist_NoPeopleStartTimebuf[i]= Timebuf[i];
			  Statist_NoPeopleEndTimebuf[i]= Timebuf[i];
				Statist_TurnStartTimebuf[i]= Timebuf[i];
			  Statist_TurnEndTimebuf[i]= Timebuf[i];
				Statist_PeopleStartTimebuf[i]= Timebuf[i];
			  Statist_PeopleEndTimebuf[i]= Timebuf[i];
		}	
		if(Flag_COMDebug == 1)
			printf("Network start disconnect! \r\n");
}
/*******************************************************************************
*	函 数 名:  Set_StatistEndTime
*	功能说明:  重新联网后，设置结束时间并统计
*	形    参：
*	返 回 值:
* 说    明：
*******************************************************************************/
void  Set_StatistEndTime(void)
{
	 uint8_t AveraveHR = 0;
	 uint8_t AveraveRR = 0;
	 uint8_t i = 0;
	 unsigned char buf[2];
	
	  Flag_NoNetWorkStart = 0;         //已联网
/**********************结束时为有人****************************************/
	  if(Keep_StatusFlag == STATIST_PEOPLE) 
		 {
				if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //上上个状态是无人
				{
						buf[0] = 0;
						buf[1]= 0;
						Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);					  
					
				}
				if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //上上个状态是无人
				{
					 for(i=0;i<6;i++)
						{
							 Statist_PeopleStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];
						}
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //上次超过20s体动，则保存
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //上上次少于20s体动，将体动时间赋值给其之前状态
				{
						for(i=0;i<6;i++)
						{
							 Statist_PeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
						}
				}						
				 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
				 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
				 Statist_AddCount = 0;
				 Statist_AddHR=0;
				 Statist_AddRR = 0;
				 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
				 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
				 Flag_SavepPos++;
				 PeopleKeepTime = 0;
				 Save_StatistStatusData(Statist_PeopleStartTimebuf,Timebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
				 Flag_SavepPos = 0;							
		 }
/**********************结束时为无人********************************************/	
   if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60))//
		{
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //上次超过20s体动，则保存
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;
						Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //上上次少于20s体动，将体动时间赋值给其之前状态
				{
						for(i=0;i<6;i++)
						{
							 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
						}
				}
				if(Last_StatusFlag == STATIST_PEOPLE) //上上次为有人状态
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);			 
					 Flag_SavepPos = 0;						
				}
				buf[0] = 0;
				buf[1]= 0;
			 Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);		
		}
		if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60))//结束时为无人并且小于60s
		{
				if(Last_StatusFlag == STATIST_PEOPLE)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,Timebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
					 Flag_SavepPos = 0;						
				}							
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime >= 20))  //体动20s
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;
						Save_StatistStatusData(Statist_TurnStartTimebuf,Timebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime < 20))  //体动小于20s
				{
						buf[0] = 0;
					  buf[1]= 0;
					  Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);	
				}
				if(Last_StatusFlag == STATIST_NOPEOPLE)
				{
					 buf[0] = 0;
					 buf[1]= 0;
					 Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);	
				}
		}			 
 /*******************上个状态是体动******************************************************/
		if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //体动小于20s
		{
			 if(Last_StatusFlag == STATIST_PEOPLE)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,Timebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
					 Flag_SavepPos = 0;	
					
				}							
				if(Last_StatusFlag == STATIST_NOPEOPLE)
				{
						buf[0] = 0;
			      buf[1]= 0;
			      Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);
				}	
				if(Last_StatusFlag == STATIST_TURN)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					Statist_AddCount = 0;
					Statist_AddHR=0;
					Statist_AddRR = 0;
					Save_StatistStatusData(Statist_TurnStartTimebuf,Timebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);	
				}			
		}
		if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //体动大于20s
		{
			if(Last_StatusFlag == STATIST_PEOPLE)  //体动之前是有人，直接保存
			{
				 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
				 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
				 Statist_AddCount = 0;
				 Statist_AddHR=0;
				 Statist_AddRR = 0;
				 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
				 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
				 Flag_SavepPos++;
				 PeopleKeepTime = 0;
				 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);				 
				 Flag_SavepPos = 0;			
				
			}
			if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //上上个状态是无人
			{
					buf[0] = 0;
					buf[1]= 0;
					Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
			}
			if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //上上个状态是无人
			{
				 for(i=0;i<6;i++)
					{
						 Statist_TurnStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];					 
					}
			}
			AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
			AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
			Statist_AddCount = 0;
			Statist_AddHR=0;
			Statist_AddRR = 0;
			Save_StatistStatusData(Statist_TurnStartTimebuf,Timebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);			
		}	  
}
/*******************************************************************************
*	函 数 名:  Statist_NextDayStart
*	功能说明:  每天中午12点重新统计
*	形    参：
*	返 回 值:
* 说    明：
*******************************************************************************/
void  Statist_NextDayStart(void)
{
	 uint8_t AveraveHR = 0;
	 uint8_t AveraveRR = 0;
	 uint8_t i = 0;
	 unsigned char buf[2];
	 unsigned char time[6];
	
	 for(i=0;i<3;i++)
	 {
		  time[i] = Timebuf[i];
	 }
	 time[3] = 11;
	 time[4] = 59;
	 time[5] = 59;
	  
/**********************结束时为有人****************************************/
	  if(Keep_StatusFlag == STATIST_PEOPLE) 
		 {
				if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //上上个状态是无人
				{
						buf[0] = 0;
						buf[1]= 0;
						Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);					  
					
				}
				if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //上上个状态是无人
				{
					 for(i=0;i<6;i++)
						{
							 Statist_PeopleStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];
						}
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //上次超过20s体动，则保存
					{
							AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
							AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
							Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
					}
					if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //上上次少于20s体动，将体动时间赋值给其之前状态
					{
							for(i=0;i<6;i++)
							{
								 Statist_PeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
							}
					}						
				 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
				 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
				 Statist_AddCount = 0;
				 Statist_AddHR=0;
				 Statist_AddRR = 0;
				 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
				 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
				 Flag_SavepPos++;
				 PeopleKeepTime = 0;
				 Save_StatistStatusData(Statist_PeopleStartTimebuf,time,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
				 Flag_SavepPos = 0;							
		 }
/**********************结束时为无人********************************************/	
   if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60))//
		{
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //上次超过20s体动，则保存
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;
						Save_StatistStatusData(Statist_TurnStartTimebuf,Statist_TurnEndTimebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //上上次少于20s体动，将体动时间赋值给其之前状态
				{
						for(i=0;i<6;i++)
						{
							 Statist_NoPeopleStartTimebuf[i] = Statist_TurnStartTimebuf[i];
						}
				}
				if(Last_StatusFlag == STATIST_PEOPLE) //上上次为有人状态
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);			 
					 Flag_SavepPos = 0;						
				}
       buf[0] = 0;
			 buf[1]= 0;
			 Save_StatistStatusData(Statist_NoPeopleStartTimebuf,time,STATIST_NOPEOPLE,1,buf,buf);		
		}
		if((Keep_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60))//体动之前的无人状态小于60s，状态有效
		{
				if(Last_StatusFlag == STATIST_PEOPLE)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,time,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
					 Flag_SavepPos = 0;	
						
				}							
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime >= 20))  //体动20s
				{
						AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
						AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
						Statist_AddCount = 0;
						Statist_AddHR=0;
						Statist_AddRR = 0;
						Save_StatistStatusData(Statist_TurnStartTimebuf,time,STATIST_TURN,1,&AveraveHR,&AveraveRR);
				}
				if((Last_StatusFlag == STATIST_TURN)&&(TurnKeepTime < 20))  //体动小于20s
				{
						buf[0] = 0;
			      buf[1]= 0;
			      Save_StatistStatusData(Statist_NoPeopleStartTimebuf,time,STATIST_NOPEOPLE,1,buf,buf);	
				}
				if(Last_StatusFlag == STATIST_NOPEOPLE)
				{
					 buf[0] = 0;
			     buf[1]= 0;
			     Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Timebuf,STATIST_NOPEOPLE,1,buf,buf);	
				}
				
		}			 
 /*******************上个状态是体动******************************************************/
		if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime<20))  //体动小于20s
		{
			 if(Last_StatusFlag == STATIST_PEOPLE)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					 Statist_AddCount = 0;
					 Statist_AddHR=0;
					 Statist_AddRR = 0;
					 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
					 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
					 Flag_SavepPos++;
					 PeopleKeepTime = 0;
					 Save_StatistStatusData(Statist_PeopleStartTimebuf,time,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);
					 Flag_SavepPos = 0;	
					
				}							
				if(Last_StatusFlag == STATIST_NOPEOPLE)
				{
						buf[0] = 0;
			      buf[1]= 0;
			      Save_StatistStatusData(Statist_NoPeopleStartTimebuf,time,STATIST_NOPEOPLE,1,buf,buf);
				}	
        if(Last_StatusFlag == STATIST_TURN)
				{
					 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
					AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
					Statist_AddCount = 0;
					Statist_AddHR=0;
					Statist_AddRR = 0;
					Save_StatistStatusData(Statist_TurnStartTimebuf,Timebuf,STATIST_TURN,1,&AveraveHR,&AveraveRR);	
				}					
		}
		if((Keep_StatusFlag == STATIST_TURN)&&(TurnKeepTime>=20))  //体动大于20s
		{
			if(Last_StatusFlag == STATIST_PEOPLE)  //体动之前是有人，直接保存
			{
				 AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
				 AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
				 Statist_AddCount = 0;
				 Statist_AddHR=0;
				 Statist_AddRR = 0;
				 Save_SleepHRData[Flag_SavepPos]=AveraveHR ;
				 Save_SleepRRData[Flag_SavepPos]=AveraveRR ;
				 Flag_SavepPos++;
				 PeopleKeepTime = 0;
				 Save_StatistStatusData(Statist_PeopleStartTimebuf,Statist_PeopleEndTimebuf,STATIST_PEOPLE ,Flag_SavepPos,Save_SleepHRData,Save_SleepRRData);				 
				 Flag_SavepPos = 0;			
				
			}
			if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime >=60)) //上上个状态是无人
			{
					buf[0] = 0;
					buf[1]= 0;
					Save_StatistStatusData(Statist_NoPeopleStartTimebuf,Statist_NoPeopleEndTimebuf,STATIST_NOPEOPLE,1,buf,buf);
			}
			if((Last_StatusFlag ==STATIST_NOPEOPLE)&&(NoPeopleKeepTime <60)) //上上个状态是无人
			{
				 for(i=0;i<6;i++)
					{
						 Statist_TurnStartTimebuf[i] = Statist_NoPeopleStartTimebuf[i];					 
					}
			}
			AveraveHR =  (uint8_t)(Statist_AddHR/Statist_AddCount);
			AveraveRR =  (uint8_t)(Statist_AddRR/Statist_AddCount);
			Statist_AddCount = 0;
			Statist_AddHR=0;
			Statist_AddRR = 0;
			Save_StatistStatusData(Statist_TurnStartTimebuf,time,STATIST_TURN,1,&AveraveHR,&AveraveRR);			
		}
  //重新初始化数据  
    Statist_AddCount = 0;
	  Statist_AddHR = 0;
		Statist_AddRR = 0;
		Flag_SavepPos = 0;
		TurnKeepTime = 0;
		PeopleKeepTime = 0;
		NoPeopleKeepTime = 0;
		Set_StatistStartTime();
		
}
/****************************************************************************
*	函 数 名:  Req_Users_Binding
*	功能说明:  查询是否关联用户
*	形    参：
*	返 回 值:
* 说    明：张炜20170523增加
*****************************************************************************/
void Req_Users_Binding(void)
{
	 UART3_SendString_YB("AT+SEND=",8);
	 SendDataToUSART(USART3,0x24);
	 SendDataToUSART(USART3,0x01 );
	 SendDataToUSART(USART3,0x82);			
	 SendDataToUSART(USART3,REQ_BINDING_USERS);
	 SendDataToUSART(USART3,0xFF);
	 SendDatasToUSART(USART3,0x6942 );
	 UART3_SendLR();
	 delay_ms(10);
}
/****************************************************************************
*	函 数 名:  SendSleepDataReallyRcvCtr
*	功能说明:  解析无线模块返回的数据
*	形    参：
*	返 回 值:
* 说    明：
*****************************************************************************/
char SendSleepDataReallyRcvCtr(void)
{
	uint8_t i,j;
	char *pstr =NULL;
	char *pstr1=NULL;
	unsigned char  receivetime[6];

	if(!ucUar3InterrFlag){
		return 0;
	}
	Delay(200);
	pstr = strstr(ucUar3tbuf,"$");
	if(pstr != NULL)
		delay_ms(5);
	pstr1 = strstr(ucUar3tbuf,"iB");
		
	if((pstr != NULL)&&(pstr1 != NULL))
	{
		if(Flag_COMDebug == 1)
			printf("U3 校时:%s\r\n",ucUar3tbuf);  //qs add
		ucUar3InterrFlag = 0;
		//----------------------以下为服务器返回是否关联用户，张炜20170523增加------------------------
		if((pstr[0]==CMD_START)&&(pstr[1]==TypeID)&&(pstr[3]==SERVER_ABNORMAL_MESSAGE))   //服务器返回错误，未关联用户
		{
			if((pstr[2]== 0x84 )&&(pstr[5]== BINDING_USERS_NO))
			{
				Flag_Binding_Users = BINDING_USERS_NO;
				if(Flag_No_Binding_Users_Time == 0)  //未关联用户计时标志
				{
					Flag_No_Binding_Users_Time = 1;
					No_Binding_Users_Time = 0;						 
				}
				if(Flag_COMDebug == 1)
					printf("The device does not binding to users!\r\n");

			}
			if((pstr[2]== 0x84 )&&(pstr[5]== BINDING_USERS_YES))
			{
				Flag_Binding_Users = BINDING_USERS_YES;
				Flag_No_Binding_Users_Time = 0;		
//				if(gPeopleFlag == TRUE)
//				{
//					if((Timebuf[3] >= 9)&&(Timebuf[3] <= 17)) //9~18点3秒1帧、其余10秒一帧 
//						SleepData_SendTime = CGATTime_3;
//					else
//						SleepData_SendTime = CGATTime_10; 
//				}
				if(Flag_COMDebug == 1)
					printf("The device is  binding to users!\r\n");

			}				 
		}
		if((pstr[0]==CMD_START)&&(pstr[1]==TypeID)&&(pstr[3]==REQ_SERVER_TIME))//服务器返回更新的时间
		{	
			for(i=0;i<6;i++)  //获取服务器时间
			{
				receivetime[i] = (pstr[4+i*2]&0x7F-0x30)*10+(pstr[5+i*2]&0x7F-0x30); //将ASCII字符的两个字节的时间转换为1个字节的时间		 
			}
			if((receivetime[0]>0)&&(receivetime[0]<99)&&(receivetime[1]>0)&&(receivetime[1]<13)&&(receivetime[2]>0)&&(receivetime[2]<32))
			{
				if((receivetime[3]>=0)&&(receivetime[3]<60)&&(receivetime[4]>=0)&&(receivetime[4]<60)&&(receivetime[5]>=0)&&(receivetime[5]<60))
				{
					for(i=0;i<6;i++)
					{
						Timebuf[i] = receivetime[i];
					}
					Flag_TimeAdj = 0;
                    Heartbeat=0;
					if(Flag_COMDebug == 1)
						printf(">>>[√]Renew Server time is:%d-%d-%d %d:%d:%d\r\n",Timebuf[0],Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5]);
				}
			}
		}
		if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== SERVER_ABNORMAL_MESSAGE)) //MAC验证错误
		{
			if(pstr[4] == SERVER_CHECK_MAC_ERR)
			{
				if(Flag_COMDebug == 1)
					printf("Server Return MAC Verify Error!\r\n");
				AngelPace = GETBACKSERVERIPOK;					 
				SendDataStatus = NO;					//打开发送开关
				SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
				Flag_Start_Mode = START_NETWOEK_RECONNECT;  //网络关闭重连
				//			  Flag_Check_Status = ERROR_MAC_ERR;
				Set_StatistStartTime();	
			}
		}
		if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== CARD_IMSI)) //返回接收到IMSI卡号			 
		{			  
		//			  for(i=0;i<7;i++)
		//			 {
		//			   printf("0x%x",pstr[i]);
		//			 }
			if(pstr[4] == 0x81)
			{
				SaveMACToFlash();
				Flag_CARD_ISCHANGE = CARD_NOCHANGE;
				if(Flag_COMDebug == 1)
					printf("Server has received IMSI!\r\n");					
			}
		}
		if((pstr[0]== CMD_START)&&(pstr[1]== TypeID)&&(pstr[3]== SEND_STATISTICS_SLEEPDTAT)) //回应发送的统计数据
		{
			if((pstr[4] == 0x81)&&(Flag_SleepDataBuffer_Save != Flag_SleepDataBuffer_Send))   //接收到正确的统计数据
			{
				if(Flag_COMDebug == 1)
					printf("Server Receive Right Statistics Data:%d!\r\n",Flag_SleepDataBuffer_Send);
				Flag_CanSendStatistData = 1;
				CanSendStatistTime = 0;				
				Flag_SleepDataBuffer_Send++;
				if(Flag_SleepDataBuffer_Send == Flag_SleepDataBuffer_Save)
				{
					Flag_SleepDataBuffer_Send = 0;
					Flag_SleepDataBuffer_Save = 0;
					Flag_SavepPos = 0;
					Flag_CanSendStatistData = 0;
					for(i=0;i<SLEEPDTATABUF;i++)
					{
						for(j=0;j<40;j++)
							Buffer_SleepData[i][j] = 0;
					}
				} 
				if(Flag_SleepDataBuffer_Send ==SLEEPDTATABUF )
				{
					Flag_SleepDataBuffer_Send = 0;
				}
			}	
		//        if(pstr[4] == 0x80)   //接收到错误的统计数据
		//				 {
		//					  if(Flag_COMDebug == 1)
		//							printf("Server Receive Error Statistics Data:%d,!Resend\r\n",Flag_SleepDataBuffer_Send);
		//						Flag_CanSendStatistData = 1;
		//            CanSendStatistTime = 0;						
		//			   }
		}
		#ifdef ENABLE_SENDPRESSSERSONSTATUS
		if((pstr[1]== TypeID)&&(pstr[3]== CMD_PRESSSENSER)) //压力传感器状态返回
		{
			if(pstr[4] == 0x81)
			{
				Flag_SendPresensorStatus = 0;
				SendPresensorStatus_Time = 0;
				if(Flag_COMDebug == 1)
					printf("Server Received pressure sensor status\r\n");

			}								 
		}
		#endif
		ClearUSART3BUF();
	}	 
	//-------------------------------------------------------------------------------------------------
	if(strstr(ucUar3tbuf, "RESET") != NULL)
	{	//从新链接后置服务器
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);
		AngelPace = CONECTIP1;					//进入链接模块
		SendDataStatus = NO;					//打开发送开关
		SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //网络关闭重连
		ucUar3InterrFlag = 0;
		Set_StatistStartTime();	
	}
	else if(strstr(ucUar3tbuf,"SEND FAIL")!=NULL)
	{		//发送失败
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);
	
		SendDataStatus=NO;					//打开发送开关
		SendSleepDataStatus=NO;				//发送失败,需要重新组装数据
		if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
			SendSleepDataReally();				//唤醒数据
		else
			Send_SyncDataToServer();		
		AngelPace = GETBACKSERVERIPOK;		//重新注册
		ucUar3InterrFlag = 0;
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //网络关闭重连
		Set_StatistStartTime();	
	}	
	else if(strstr(ucUar3tbuf,"CLOSED")!=NULL)
	{			//链路意外关闭
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //网络关闭重连
		SendDataStatus=NO;					//打开发送开关
		SendSleepDataStatus=NO;				//发送失败,需要重新组装数据
		Flag_Send_GPRS_Position = 0;	
		if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
			SendSleepDataReally();				//唤醒数据
		else
			Send_SyncDataToServer();
		AngelPace = GETBACKSERVERIPOK;		//重新注册
		ucUar3InterrFlag = 0;
		Set_StatistStartTime();	
	}
	else if(strstr(ucUar3tbuf,"SHUT")!=NULL)
	{
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);

		SendDataStatus=NO;					//打开发送开关
		SendSleepDataStatus=NO;				//发送失败,需要重新组装数据
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //网络关闭重连
		Flag_Send_GPRS_Position = 0;	
		if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
			SendSleepDataReally();				//唤醒数据
		else
			Send_SyncDataToServer();
		AngelPace = GETBACKSERVERIPOK;		//重新注册
		ucUar3InterrFlag = 0;
		GPRS_ConnetTime =0;	
		Set_StatistStartTime();			
	}
	else if(strstr(ucUar3tbuf,"+REGISTE:0")!=NULL)
	{
		if(Flag_COMDebug == 1)
			printf("U3 ERROR:%s\r\n",ucUar3tbuf);
		if((Timebuf[0]!=0)&&(Timebuf[1]!=0)&&(Timebuf[2]!=0))
			SendSleepDataReally();				//唤醒数据
		else
			Send_SyncDataToServer();
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //网络关闭重连
		AngelPace = GETBACKSERVERIPOK;		//重新注册
		ucUar3InterrFlag = 0;
		Set_StatistStartTime();	
	}
	else
		{
		if(ucUar3tbuf[1] != 0)
			{
			if(Flag_COMDebug == 1)
				printf("U3 :%s\r\n",ucUar3tbuf);
			ucUar3InterrFlag = 0;
		}
	}
	CheckSystemErrorContrl();					//模块出现异常情况,如重启
	return 1;
}

char My_strstr(unsigned char *str1,unsigned char *str2)
{
	int len = 0;
	char ch = 0,i=0,count=0;

	if(str2[0] == '7'){
		len = 8;
	}else if(str2[0] == '8'){
		len = 9;
	}

	for(i=0;i<len;i++){
		if(str1[i] == str2[i]){
			count++;
		}
		else{
			break;
		}
	}

	if(count == len){
		return 1;			//表示两个字符串一致
	}
	else{
		return 0;			//表示不一致
	}

}
/****************************************************************************
*	函 数 名: ADDTime
*	功能说明: 更新时间
*	形    参：无
*	返 回 值: 无
* 说    明：
*****************************************************************************/
static int timeCorrectionCount=0;//10分钟，设备比服务器快1s
void ADDTime(void)
{
	char len=0,i=0;
	u8 year = 0,month = 0,daysPerMonth = 0;
	//Timebuf[len + 0]			//年
	//Timebuf[len + 1]			//月
	//Timebuf[len + 2]			//日
	//Timebuf[len + 3]			//时
	//Timebuf[len + 4]			//分
	//Timebuf[len + 5]			//秒
	timeCorrectionCount++;
	if(timeCorrectionCount > 600)
	{
		//10分钟的时候，设备减慢一秒
		timeCorrectionCount = 0;
	}
	Timebuf[len + 5] += 1;						//秒计时
	if(Timebuf[len + 5] == 60)    //60s 分进位
	{			
		Timebuf[len + 5]= 0;
		Timebuf[len + 4]++;
		if(Timebuf[len + 4] == 60)  //60min 时进位
	  {				
			Timebuf[len + 4]=0;
			Timebuf[len + 3]++;
			if(Flag_TimeAdj == 0)
			{
				Adj_Time = 0;
//				Flag_TimeAdj = 1;		  //发送指令同步服务器时间
			}
		}
		if(Timebuf[len + 3] == 24)  //24h 日进位
		{				
			Timebuf[len + 3]=0;
			Timebuf[len + 2]++;
		}
		//判断每个月份的天数
		year = Timebuf[len + 0];
		month = Timebuf[len + 1];
		if(year % 4 == 0 && month == 2){
			daysPerMonth= 29;
		}else{
			switch(month){
				case 1:
				case 3:
				case 5:
				case 7:
				case 8:
				case 10:
				case 12:
					daysPerMonth = 31;
					break;
				case 2:
					daysPerMonth = 28;
					break;
				default:
					daysPerMonth = 30;
					break;
			}
		}
		if(Timebuf[len + 2] > daysPerMonth){				//月进位
			Timebuf[len + 2]=1;
			Timebuf[len + 1]++;
		}
		if(Timebuf[len + 1] >  12){				//年进位
			Timebuf[len + 1]=1;
			Timebuf[len + 0]++;
		}
		if(Timebuf[len + 0] >=  99){				//年复位
			Timebuf[len + 0] = 0;
		}
	}	
//	printf("time...%d/%d/%d %02d:%02d:%02d\r\n",Timebuf[1],Timebuf[2],Timebuf[3],Timebuf[4],Timebuf[5],Timebuf[6]);
}
/****************************************************************************
*	函 数 名: GetServerTime
*	功能说明: 获取服务器时间
*	形    参：无
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void GetServerTime(void)
{
//	 Flag_SleepData_SendOver = 1;
//	 UART3_SendString_YB("AT+GPRS=",8);
//	 SendDataToUSART(USART3,0x24);
//	 SendDataToUSART(USART3,0x01 );
//	 SendDataToUSART(USART3,0x82);			
//	 SendDataToUSART(USART3,REQ_SERVER_TIME);
//	 SendDataToUSART(USART3,0xFF);
//	 SendDatasToUSART(USART3,0x6942 );
//	 UART3_SendLR();
//	 //Flag_TimeAdj = 1;
    uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
     
	 uint16_t data_len=0;
	 SendData[data_len++] = CMD_START;
	 SendData[data_len++] = TypeID;
	 SendData[data_len++] = 0x82;
	 SendData[data_len++] = REQ_SERVER_TIME;
	 SendData[data_len++] = 0xff ;
	 SendData[data_len++] = CMD_LF1;
	 SendData[data_len++] = CMD_LF2;
     ClearUSART3BUF();
     GPRS_Send_Data(SendData,data_len);
	 //Adj_Time = 0;
}
/****************************************************************************
*	函 数 名: LedContrl
*	功能说明: LED闪烁状态改变
*	形    参：无
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void LedContrl(int csq,int Tcpstatues)
{
	if((csq < 7) && (RegEnable == 1) && (Tcpstatues == 0) && (AngelPace == SendSleepDataR)){
		if(LedFlash < 50){
			GPIO_SetBits(LED_GPIO_PORT,LED5_PIN);	//关灯，发送数据成功		
		}else if(LedFlash < 100){
			GPIO_ResetBits(LED_GPIO_PORT,LED5_PIN);	//开灯，表示在开始链接
		}else if(LedFlash >= 100){
			LedFlash = 0;
		}
	}
	else if((csq < 99) && (RegEnable == 1) && (Tcpstatues == 0) && (AngelPace == SendSleepDataR))
	{
		GPIO_SetBits(LED_GPIO_PORT,LED5_PIN);	//关灯，发送数据成功	
	}
	else
	{
		GPIO_ResetBits(LED_GPIO_PORT,LED5_PIN);	//开灯，表示在开始链接
	}	
}
/****************************************************************************
*	函 数 名: Send_GPRSPosition
*	功能说明: 发送GPRS定位数据
*	形    参：st 表示启动模式：电源重启还是网络重启，lac和cid为定位数据
*	返 回 值: 
* 说    明：张炜20170526增加
*****************************************************************************/
void  Send_GPRSPosition(uint8_t st,int lac,int cid)
{
	 uint8_t podata[13];
	 uint8_t  i =0;
	 uint8_t jiaoyan = 0;
	
	 podata[0] = 0x24;
   podata[1] = 0x01;
   podata[2] = 0x08|0x80;	//数据长度8字节	
	 podata[3] = GPRS_LOCATION;
	 podata[5] = st;
	 podata[6] = lac/256;
	 podata[7] = lac%256;
	 podata[8] = cid/256;
	 podata[9] = cid%256;
	 podata[4] = GetDataHead(&podata[5],5);  //数据头
	  
	 for(i=3;i<10;i++)
	 { 
		 jiaoyan += podata[i];
	  }	 
	 podata[10] = jiaoyan;
	 for(i=4;i<11;i++)
	 { 
		 podata[i] |= 0x80;
	  }	
	 podata[11] = 0x69;
	 podata[12] = 0x42;
	 
	GPRS_Send_Data(podata,13);
	 delay_ms(10);
}
/****************************************************************************
*	函 数 名: Send_DataUnusual
*	功能说明: 发送数据异常数据
*	形    参：flag_un异常标记  unHr异常心率数据 unRr 异常呼吸数据
*	返 回 值: 
* 说    明：张炜20170527增加
*****************************************************************************/
void Send_DataUnusual(uint8_t flag_un,uint8_t unHr,uint8_t unRr)
{
	 uint8_t podata[11];
	 uint8_t  i =0;
	 uint8_t jiaoyan = 0;
	
	 podata[0] = 0x24;
   podata[1] = 0x01;
   podata[2] = 0x06|0x80;	//数据长度8字节	
	 podata[3] = SLEEPDATA_ABNORMAL_MESSAGE;
	 podata[5] = flag_un;
	 podata[6] = unHr;
	 podata[7] = unRr;
	 podata[4] = GetDataHead(&podata[5],3);  //数据头
	  
	 for(i=3;i<8;i++)
	 { 
		 jiaoyan += podata[i];
	  }
	 podata[8] = jiaoyan;
	 for(i=4;i<9;i++)
	 { 
		 podata[i] |= 0x80;
	  }	
	 podata[9] = 0x69;
	 podata[10] = 0x42;
	 
	 UART3_SendString_YB("AT+SEND=",8);	 
	 for(i=0;i<11;i++)
	 {
		  SendDataToUSART(USART3,podata[i]);
	 }	 
	 UART3_SendLR();
	 delay_ms(10);
}
/****************************************************************************
*	函 数 名:  Send_SyncDataToServer
*	功能说明:  发送同步数据包到服务器
*	形    参：
*	返 回 值:
* 说    明：在设备和服务器未连接成功或者校验成功的情况下发送,张炜20170601增加
*****************************************************************************/
void Send_SyncDataToServer(void)
{
	 UART3_SendString_YB("AT+SEND=",8);
	 SendDataToUSART(USART3,0x24);
	 SendDataToUSART(USART3,0x01 );
	 SendDataToUSART(USART3,0x82);			
	 SendDataToUSART(USART3,SYNC);
	 SendDataToUSART(USART3,0xFF);
	 SendDatasToUSART(USART3,0x6942 );
	 UART3_SendLR();
	 if(Flag_COMDebug == 1)
			printf("Send SyncData To Server!\r\n");
}
/****************************************************************************
*	函 数 名: Send_CARD_IMSI
*	功能说明: 发送卡号或者IMSI号
*	形    参：
*	返 回 值: 
* 说    明：张炜20170610增加
*****************************************************************************/
void Send_CARD_IMSI(void)
{
	 uint8_t podata[50]={0};
	 uint8_t  i =0,j;
	 uint8_t jiaoyan = 0;
	 
	 podata[i++] = 0x24;
    podata[i++] = 0x01;
    podata[i++] = (SIMCard_ICCID_Len+2)|0x80;	//数据长度8字节	
	 podata[i++] = CARD_IMSI;

	 for(j=0;j<SIMCard_ICCID_Len;j++)
	 { 
		 podata[i++] = SIMCard_ICCID[j];
	 }
	 	for(j=0;j<SIMCard_ICCID_Len+1;j++)
	 { 
		 jiaoyan += podata[j+3];
	  }	 
	 podata[i++] = jiaoyan|0x80;			
	 podata[i++] = 0x69;
	 podata[i++] = 0x42;
	 
	 GPRS_Send_Data(podata,i);
	 delay_ms(10);
   if(Flag_COMDebug == 1)
	 {		 
		 printf("Send MAC and IMSI to Server!\r\n");
//			 for(i=0;i<ICCID_LEN+7;i++)
//		 {
//			 printf("0x%x ",podata[i]);
//		 }
//		 printf("\r\n");
  }
}
void Send_CARD_ICCID(void)
{
	 uint8_t podata[50]={0};
	 uint8_t  i =0,j;
	 uint8_t jiaoyan = 0;
	 
	 podata[i++] = 0x24;
    podata[i++] = 0x01;
    podata[i++] = (SIMCard_ICCID_Len+2)|0x80;	//数据长度8字节	
	 podata[i++] = CARD_IMSI;

	 for(j=0;j<SIMCard_ICCID_Len;j++)
	 { 
		 podata[i++] = SIMCard_ICCID[j];
	 }
	 	for(j=0;j<SIMCard_ICCID_Len+1;j++)
	 { 
		 jiaoyan += podata[j+3];
	  }	 
	 podata[i++] = jiaoyan|0x80;			
	 podata[i++] = 0x69;
	 podata[i++] = 0x42;
	 
	 GPRS_Send_Data(podata,i);
	 delay_ms(10);
   if(Flag_COMDebug == 1)
	 {		 
		 printf("Send MAC and ICCID to Server!\r\n");
//			 for(i=0;i<ICCID_LEN+7;i++)
//		 {
//			 printf("0x%x ",podata[i]);
//		 }
//		 printf("\r\n");
  }
}
/****************************************************************************
*	函 数 名: RePowerOn_GPRS
*	功能说明: GPRS模块重新上电重启
*	形    参：
*	返 回 值: 
* 说    明：张炜20170705增加
*****************************************************************************/
void  RePowerOn_GPRS(void)
{
    GPRS_or_WIFI = GPRS;
//    Set_StatistStartTime();
//	 GPRS_POWER(0);
//	 delay_ms(2000);
//	 GPRS_POWER(1);
//	 delay_ms(1000);
     Flag_Init_Step=3;
	 AngelPace = CONECTIP1;
   if(Flag_Start_Mode == START_NETWOEK_RECONNECT )	
	     Flag_Start_Mode = START_GPRS_RESTART;  //网络关闭重连	
	 Flag_Send_GPRS_Position = 0;								 
	 SendDataStatus = NO;					//打开发送开关
	 SendSleepDataStatus = NO;				//发送失败,需要重新组装数据
	 Flag_init = MAC_INIT_OK;  //进行无线模块初始化
	 Flag_start_time = 1;	
	 ClearUSART3BUF();		
	 GPRS_ConnetTime =0;	
	 flag_Gprs_Reconn=1;
}
/****************************************************************************
*	函 数 名: AMPCHGDataToServer
*	功能说明: 发送放大倍数
*	形    参：
*	返 回 值: 
* 说    明：
*****************************************************************************/
void Send_AMPCHGDataToServer(void)
{
	 uint8_t dat[8];
	 uint8_t  i = 0;
	
	 dat[0]= (uint8_t)(ADC_AmpMultiple*10);
	 dat[1] = SEND_ECG_MAX[0]/256;
	 dat[2] = SEND_ECG_MAX[0]%256;
	 dat[3] = SEND_ECG_MAX[1]/256;
	 dat[4] = SEND_ECG_MAX[1]%256;
	 dat[5] = SEND_ECG_MAX[2]/256;
	 dat[6] = SEND_ECG_MAX[2]%256;
	 dat[7] = GetDataHead(&dat[0],7);  //数据头
	 
	 UART3_SendString_YB("AT+SEND=",8);
	 SendDataToUSART(USART3,0x24);
	 SendDataToUSART(USART3,0x01 );
	 SendDataToUSART(USART3,0x8A);			
	 SendDataToUSART(USART3,AMP_CHG);
	 for(i=0;i<8;i++)
	 {
		 SendDataToUSART(USART3,dat[i]|0x80);
	 }
	 SendDataToUSART(USART3,0xFF);
	 SendDatasToUSART(USART3,0x6942 );
	 UART3_SendLR();
   delay_ms(10);
	 if(Flag_COMDebug == 1)
		 printf("Send Amplification Data:%f To Server!\r\n",ADC_AmpMultiple);
}

/****************************************************************************
*	函 数 名: DealADCSampleData
*	功能说明: 处理ADC采样值
*	形    参：
*	返 回 值: 
* 说    明：
*****************************************************************************/	
void  DealADCSampleData(void)
{
   uint32_t Dvalue0 = 0;
	 uint32_t Dvalue1 = 0;
	 uint16_t maxaerage = 0;
	 uint16_t minaerage = 0;
	 uint16_t maxecgaerage = 0;
	 uint16_t minecgaerage = 0;
	 uint16_t ecgdata = 0;
	 uint16_t i = 0 ;
	 uint8_t ampchange = 0;
	 s32 ecgaeragedata = 0;

//----------------------------状态判断------------------------------------------------------------			   
//	 if((PeopleOn_Time > 10)&&(gTurnFlag==0)&&(Flag_ADC_ADJ == 0)&&(Flag_HasPeople == 1)&&(SampleData>STANDARD_VOLTAGE))
//	 {
//		 ADC_DATA[ADC_QuietCount] = SampleData;
//		 ADC_QuietCount++;
//		 if(ADC_QuietCount == 50)
//		 {
//				for(i=0;i<50;i++)
//				 {
//					 Dvalue0 += ADC_DATA[i];
//				 }	
//				 maxaerage =  (uint16_t)(Dvalue0/50);
//				 if(ECG_MAX[ECG_COMPARE_COUNT]<1750)
//				 {
//						Flag_ADC_ADJ = 1;
//						PeopleOn_Time = 0;
//						Flag_HasPeople = 0;
////					  ADC_AmpMultiple = 4;
//				 }
//				ADC_QuietCount =0;
//		 }
//	 }				 
	 if(SampleData > ECG_MAX[ECG_COMPARE_COUNT])
	 {
			ECG_MAX[ECG_COMPARE_COUNT] = SampleData;
	 }
	 if(SampleData< ECG_MIN[ECG_COMPARE_COUNT])
	 {
			ECG_MIN[ECG_COMPARE_COUNT] = SampleData;
	 }
	 ADC_COUNT++;
	 if(ADC_COUNT >= 500)
	 {
			ECG_COMPARE_COUNT++;
			ADC_COUNT = 0;
	 }
	 if(ECG_COMPARE_COUNT >= ECG_COMPARE_TIMES)
	 {
			for(i=0;i<ECG_COMPARE_TIMES;i++)
		 {
			 Dvalue0 += ECG_MAX[i];
			 Dvalue1 += ECG_MIN[i];
			 SEND_ECG_MAX[i]=ECG_MAX[i];
		 }				
		 maxaerage =  (uint16_t)(Dvalue0/ECG_COMPARE_TIMES);
		 minaerage =  (uint16_t)(Dvalue1/ECG_COMPARE_TIMES);
		 maxecgaerage = abs(maxaerage - STANDARD_VOLTAGE);
		 minecgaerage = abs(STANDARD_VOLTAGE - minaerage);
		 
		if((ECG_MAX[0] < ADC_MAXDATA1)&&(ECG_MAX[1] < ADC_MAXDATA1)&&(ECG_MAX[2] < ADC_MAXDATA1)&&(ADC_AmpMultiple != 1))
		{
			 Flag_ADC_ADJ = 0;
			 ADC_AmpMultiple = 1;
		}	
		if(((maxaerage-minaerage)<50)&&(ADC_AmpMultiple != 1))
		{
			 Flag_ADC_ADJ = 0;
			 ADC_AmpMultiple = 1;
		}
    if((ECG_MAX[0] > ADC_MAXDATA4)&&(ECG_MAX[1] > ADC_MAXDATA4)&&(ECG_MAX[2] > ADC_MAXDATA4)&&(ADC_AmpMultiple != 1))
		{
			 Flag_ADC_ADJ = 0;
			 ADC_AmpMultiple = 1;
		}			
		if((abs(ECG_MAX[1]-ECG_MAX[0])< 100)&&(abs(ECG_MAX[2]-ECG_MAX[1])< 100)&&((maxaerage-minaerage)>50))  //平稳状态
		 {
			 if((maxaerage < ADC_MAXDATA4)&&(ECG_MAX[0]> ADC_MAXDATA1)&&(ECG_MAX[1]> ADC_MAXDATA1)&&(ECG_MAX[2]> ADC_MAXDATA1)&&(minaerage<ADC_MINDATA1)&&(Flag_ADC_ADJ == 0))
			 {			
						Flag_ADC_ADJ = 1;
				    ampchange = 1;			 
			 }
//-------------------放大倍数计算---------------------------------------------------------------------
			if( ampchange == 1)
			{
					ampchange = 0;
					if(Flag_ADC_ADJ != 0)
					{
						 ADC_AmpMultiple =(float)(ADC_AMPSTADATA-STANDARD_VOLTAGE)/(maxaerage-STANDARD_VOLTAGE);					
							if(ADC_AmpMultiple > 10)	
								 ADC_AmpMultiple = 10;	

						 if(LastADC_AmpMultiple != ADC_AmpMultiple)
						 {
									LastADC_AmpMultiple = ADC_AmpMultiple;
									ADC_AdjTime = 0;
						 }
					}				 
	//			printf("Amplification parameter is:%f \r\n",ADC_AmpMultiple);
			}		 
		 }					
			for(i=0;i<ECG_COMPARE_TIMES-1;i++)
			{
				ECG_MAX[i] = ECG_MAX[i+1];
				ECG_MIN[i] = ECG_MIN[i+1];
			}			
			ECG_COMPARE_COUNT = 2;
			ECG_MAX[ECG_COMPARE_COUNT] = STANDARD_VOLTAGE;
			ECG_MIN[ECG_COMPARE_COUNT] = ECG_MAX[1];
		}       									
}
/****************************************************************************
*	函 数 名: DealSmallADCSampleData
*	功能说明: 处理小信号ADC采样值
*	形    参：信号状态，状态不同，调整幅度不同
*	返 回 值: 
* 说    明：
*****************************************************************************/	
void  DealSmallADCSampleData(float status)
{
	 float absdata = 0;	
	 uint8_t i =0;

	 if(SampleData > STANDARD_VOLTAGE)
	 {
		 absdata = SampleData -STANDARD_VOLTAGE;
		 absdata *= status;
		 SampleData = (uint16_t)(STANDARD_VOLTAGE+ absdata);
		 if(SampleData>3299)
		 {
			 SampleData = 3299;
		 }
	 }
	 else
	 {
		 absdata = STANDARD_VOLTAGE - SampleData;
		 absdata *= status;
		 SampleData = (uint16_t)(STANDARD_VOLTAGE - absdata);
		 if(SampleData < 1)
		 {
			 SampleData = 1;
		 }
	 }	 							
}
/****************************************************************************
*	函 数 名: CheckAmpADCData
*	功能说明: 检查放大后的ADC数据
*	形    参：
*	返 回 值: 
* 说    明：
*****************************************************************************/
void CheckAmpADCData(void)
{
	 uint32_t Dvalue0 = 0;
	 uint32_t Dvalue1 = 0;
	 uint16_t maxaerage = 0;
   uint16_t minaerage = 0;
	 uint16_t i = 0 ;

//----------------------------状态判断------------------------------------------------------------			   				 
	 if(SampleData > CHGECG_MAX[CHGECG_COMPARE_COUNT])
	 {
			CHGECG_MAX[CHGECG_COMPARE_COUNT] = SampleData;
	 }
	 if(SampleData< ECG_MIN[CHGECG_COMPARE_COUNT])
	 {
			CHGECG_MIN[CHGECG_COMPARE_COUNT] = SampleData;
	 }	 
	 CHGADC_COUNT++;

	 if(CHGADC_COUNT >= 500)
	 {
			CHGECG_COMPARE_COUNT++;
			CHGADC_COUNT = 0;
	 }
	 if(CHGECG_COMPARE_COUNT >= ECG_COMPARE_TIMES)
	 {
		 for(i=0;i<ECG_COMPARE_TIMES;i++)
		 {
			 Dvalue0 += CHGECG_MAX[i];
			 Dvalue1 += CHGECG_MIN[i];
		 }
		 maxaerage =  (uint16_t)(Dvalue0/ECG_COMPARE_TIMES);
		 minaerage =  (uint16_t)(Dvalue1/ECG_COMPARE_TIMES);
		 
//    if((abs(CHGECG_MAX[1]-CHGECG_MAX[0])< 50)&&(abs(CHGECG_MAX[2]-CHGECG_MAX[1])< 50)&&((maxaerage-minaerage)<80)&&(ADC_AmpMultiple != 1))
//		{
//			 Flag_ADC_ADJ = 0;
//			 ADC_AmpMultiple = 1;
//			
//		}			 
		if((CHGECG_MAX[0]>ADC_CHGMAXDATA)&&(CHGECG_MAX[1]>ADC_CHGMAXDATA)&&(CHGECG_MAX[2]>ADC_CHGMAXDATA))  //放大后数据超过限制
		 {
			  if((Flag_ADC_ADJ != 0)&&(ADC_AdjTime > 60))  //间隔1分钟才可以调整
				{
					 Flag_ADC_ADJ = 0;
				}
		 }
		if((CHGECG_MAX[0]<ADC_CHGMINDATA)&&(CHGECG_MAX[1]<ADC_CHGMINDATA)&&(CHGECG_MAX[2]<ADC_CHGMINDATA)&&(maxaerage > 1600))  //放大后数据超过限制
		 {
			  if((Flag_ADC_ADJ != 0)&&(ADC_AdjTime > 60))  //间隔1分钟才可以调整
				{
					 Flag_ADC_ADJ = 0;
				}
		 }		 
			for(i=0;i<ECG_COMPARE_TIMES-1;i++)
			{
				CHGECG_MAX[i] = CHGECG_MAX[i+1];
				CHGECG_MIN[i] = CHGECG_MIN[i+1];
			}			
			CHGECG_COMPARE_COUNT = 2;
			CHGECG_MAX[CHGECG_COMPARE_COUNT] = STANDARD_VOLTAGE;
			CHGECG_MIN[CHGECG_COMPARE_COUNT] = CHGECG_MAX[1];
		}
}
/****************************************************************************
*	函 数 名: SleepDataCalculate
*	功能说明: 计算睡眠数据
*	形    参：
*	返 回 值: 
* 说    明：
*****************************************************************************/
void SleepDataCalculate(void)
{
		SampleData = GetADCData();	
	//避免SampleData越界 2019/6/5by DYP
    if(SampleData>3300)
        SampleData=3300;
    if(SampleData<1)
        SampleData=1;
	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)  //有人状态则执行放大
	{
		DealADCSampleData();					 //处理原始采样信号
		if((gTurnFlag != 1)&&(ADC_AmpMultiple != 1))  //放大原始采样信号
		{						
			DealSmallADCSampleData(ADC_AmpMultiple);					
		}
		CheckAmpADCData();  //检查放大后的信号
	}	
	SleepAlgorithm();	 						//数据处理函数						
	putWaveDataToBuf(SampleData,EcgData,RespData);//+128);

//	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEOFFBED)  //压力带未压下，则数据全部置0   test code!!!
//	{  
//		gPeopleFlag = 0;	
//		gTurnFlag = 0;
//	}
	
		
}
/****************************************************************************
*	函 数 名: SendPressSenserStatus
*	功能说明: 发送压力传感器状态
*	形    参：无
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void SendPressSenserStatus(uint8_t status)
{
	 uint8_t senddata[8]={0};
	 uint8_t  i = 0;
	 
	senddata[0] = CMD_START;
	senddata[1] = TypeID;
	senddata[2] = 0x83;
	senddata[3] = CMD_PRESSSENSER;
	if(status == EXTSENSOR_PEOPLEONBED)
		senddata[4] = PRESSSENSER_ON|0x80;
	else
		senddata[4] = PRESSSENSER_OFF|0x80;
	senddata[5] = 0xFF;
	senddata[6] = 0x69;
	senddata[7] = 0x42;
    GPRS_Send_Data(senddata,8);
}
void SendSensorTestOver(uint32_t times)
{
	 uint8_t senddata[8]={0};
	 uint8_t  i = 0;
	 uint8_t len=0;
	senddata[len++] = CMD_START;
	senddata[len++] = TypeID;
	senddata[len++] = 0x83;
	senddata[len++] = SENSORTESTOVER;
	senddata[len++] = times/256;
    senddata[len++] = times%256;
	senddata[len++] = 0xFF;
	senddata[len++] = 0x69;
	senddata[len++] = 0x42;
	 UART3_SendString_YB("AT+SEND=",len);
	 for(i=0;i<len;i++)
	 {
		 SendDataToUSART(USART3,senddata[i]);
	 }
	UART3_SendLR();
}
/****************************************************************************
*	函 数 名: Check_ExtSensor_PeopleOnBed
*	功能说明: 检查外部传感器是否有人在床
*	形    参：无
*	返 回 值: 
* 说    明：200ms检查一次状态，如果连续10次状态一致，则表明该状态稳定
*****************************************************************************/
void Check_ExtSensor_PeopleOnBed(void)
{
	float adcvlaue = 0;
    static float last_adcvlaue=0;
#if 1	
	if(OnbedStatus_CountTimer >= 10)
	{		
		adcvlaue = ADC_VoltageValue[1];
        #if 0
        adcvlaue=1500;
        #endif 
		//adcvlaue *= 2;
		if(adcvlaue>3299)
		{
			 adcvlaue = 3299;
		}
       
		CheckCount_ExtSensor++;	
		OnbedStatus_CountTimer = 0;		
		if( abs((int)adcvlaue -(int)last_adcvlaue) >1000)   //数据出现跳变的时候，状态不计算，防止信号干扰
		{
			last_adcvlaue = adcvlaue;
			CheckCount_ExtSensor = 0;
			ExtSensor_OnbedStatus_Count = 0;
			ADCVol_ExtSensor = 0;
			return;
		}
		last_adcvlaue = adcvlaue;	
		ADCVol_ExtSensor += (uint32_t)adcvlaue;		
		if(adcvlaue > 400)
        //if(adcvlaue > 400)
		{
			ExtSensor_OnbedStatus_Count++;				
		}
		if(CheckCount_ExtSensor >= 25)
		{
			ADCVol_ExtSensor /= 25;
//			if(Flag_COMDebug == 1)
//			{		
//				printf("\r\naverage pressure adc vol:%d mV \r\n\r\n",ADCVol_ExtSensor);
//				
//			}
            if((ADCVol_ExtSensor>=800)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED))  //压力平均值大于500mV
			//if((ADCVol_ExtSensor>=500)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED))  //压力平均值大于500mV
			{
//				if(Flag_PeopleTurnforPresensor == 1)
				{
					if(Flag_COMDebug == 1)
					{		
						printf("\r\n======有人======\r\n");
						
					}									
					Status_ExtSensorOnbed = EXTSENSOR_PEOPLEONBED;

					Monitor_Offline_Time = 0;
					#ifdef ENABLE_SENDPRESSSERSONSTATUS
					Flag_SendPresensorStatus = 1;
					SendPresensorStatus_Time = 4;
					#endif
				}
			}
			if((ExtSensor_OnbedStatus_Count<5)&&(ADCVol_ExtSensor<400)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEOFFBED))  //每个压力值都小于400
			{
				if(Flag_COMDebug == 1)
				{		
					printf("\r\n======无人======\r\n");
					
				}			
				Status_ExtSensorOnbed = EXTSENSOR_PEOPLEOFFBED;
				#ifdef ENABLE_SENDPRESSSERSONSTATUS
				Flag_SendPresensorStatus = 1;
				SendPresensorStatus_Time = 4;
				#endif				
			}
			ExtSensor_OnbedStatus_Count = 0;
			CheckCount_ExtSensor = 0;
	
			ADCVol_ExtSensor = 0;
		}
	}
#else
	if(OnbedStatus_CountTimer >= 10)
	{		
		adcvlaue = ADC_ConvertedValue[1]*3300/4096.0;
		if(adcvlaue>3299)
		{
			 adcvlaue = 3299;
		}
	   if(adcvlaue<0)
	   {
		   adcvlaue = 0;
	   }
	   	   
		CheckCount_ExtSensor++;	
		OnbedStatus_CountTimer = 0;		
		if( abs((int)adcvlaue -(int)ADC_VoltageValue[1] ) >1000)   //数据出现跳变的时候，状态不计算，防止信号干扰
		{
			ADC_VoltageValue[1] = adcvlaue;
			CheckCount_ExtSensor = 0;
			ExtSensor_OnbedStatus_Count = 0;
			ADCVol_ExtSensor = 0;
			return;
		}
		ADC_VoltageValue[1] = adcvlaue;	
		ADCVol_ExtSensor += (uint32_t)adcvlaue;		
		if(adcvlaue > PressureSensor_BaseValue)
		{
			ExtSensor_OnbedStatus_Count++;				
		}
		if(CheckCount_ExtSensor >= 25)
		{
			ADCVol_ExtSensor /= 25;
            if(Flag_COMDebug == 1)
			{		
				printf("\r\naverage pressure adc vol:%d mV \r\n\r\n",ADCVol_ExtSensor);
				
			}
			if((ADCVol_ExtSensor>=PressureSensor_BaseValue)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED))  //压力平均值大于500mV，原始电压值经过了分压处理
			{
				if((ADCVol_ExtSensor>PRESSURESENSOR_BASEMAXVALUE)||(CheckCount_ExtSensorMaxVal>2))
				{
					if(Flag_COMDebug == 1)
					{		
						printf("\r\n======有人======\r\n");
						
					}									
					Status_ExtSensorOnbed = EXTSENSOR_PEOPLEONBED;
					CheckCount_ExtSensorMaxVal = 0;
					Monitor_Offline_Time = 0;
					#ifdef ENABLE_SENDPRESSSERSONSTATUS
					Flag_SendPresensorStatus = 1;
					SendPresensorStatus_Time = 4;
					#endif
				}
				else
				{					
					CheckCount_ExtSensorMaxVal++;
				}
				CheckCount_ExtSensorMinVal = 0;
				
				PressureSensor_BaseValue = ADCVol_ExtSensor-50;		
				if(PressureSensor_BaseValue>PRESSURESENSOR_BASEMAXVALUE)
				{
					PressureSensor_BaseValue = PRESSURESENSOR_BASEMAXVALUE;
				}
				if(PressureSensor_BaseValue<PRESSURESENSOR_BASEMINVALUE)
				{
					PressureSensor_BaseValue = PRESSURESENSOR_BASEMINVALUE;
				}
			}
			if((ExtSensor_OnbedStatus_Count<1)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEOFFBED))  //每个压力值都小于400
			{
				if((ADCVol_ExtSensor<PRESSURESENSOR_BASEMINVALUE)||(CheckCount_ExtSensorMinVal>2))
				{
					if(Flag_COMDebug == 1)
					{		
						printf("\r\n======无人======\r\n");
						
					}			
					Status_ExtSensorOnbed = EXTSENSOR_PEOPLEOFFBED;
					CheckCount_ExtSensorMinVal = 0;
					#ifdef ENABLE_SENDPRESSSERSONSTATUS
					Flag_SendPresensorStatus = 1;
					SendPresensorStatus_Time = 4;
					#endif	
				}
				else
				{
					
					CheckCount_ExtSensorMinVal++;
				}
				CheckCount_ExtSensorMaxVal = 0;

				PressureSensor_BaseValue = ADCVol_ExtSensor;		
				if(PressureSensor_BaseValue>PRESSURESENSOR_BASEMAXVALUE)
				{
					PressureSensor_BaseValue = PRESSURESENSOR_BASEMAXVALUE;
				}
				if(PressureSensor_BaseValue<PRESSURESENSOR_BASEMINVALUE)
				{
					PressureSensor_BaseValue = PRESSURESENSOR_BASEMINVALUE;
				}
			}			
			ExtSensor_OnbedStatus_Count = 0;
			CheckCount_ExtSensor = 0;
						
			ADCVol_ExtSensor = 0;
		}
	}	
#endif	
}
/****************************************************************************
*	函 数 名: IWDG_Config
*	功能说明: 设置 IWDG 的超时时间
*	形    参：prv:预分频器值  rlv:预分频器值
*	返 回 值: 无
 * Tout = prv/40 * rlv (s)
 *      prv可以是[4,8,16,32,64,128,256]
 * prv:预分频器值，取值如下：
 *     @arg IWDG_Prescaler_4: IWDG prescaler set to 4
 *     @arg IWDG_Prescaler_8: IWDG prescaler set to 8
 *     @arg IWDG_Prescaler_16: IWDG prescaler set to 16
 *     @arg IWDG_Prescaler_32: IWDG prescaler set to 32
 *     @arg IWDG_Prescaler_64: IWDG prescaler set to 64
 *     @arg IWDG_Prescaler_128: IWDG prescaler set to 128
 *     @arg IWDG_Prescaler_256: IWDG prescaler set to 256
 *
 * rlv:预分频器值，取值范围为：0-0XFFF
 * 函数调用举例：
 * IWDG_Config(IWDG_Prescaler_64 ,625);  // IWDG 1s 超时溢出
*****************************************************************************/
void IWDG_Config(uint8_t prv ,uint16_t rlv)
{	
	// 使能 预分频寄存器PR和重装载寄存器RLR可写
	IWDG_WriteConfig( IWDG_WRITE_ENABLE );
	
	// 设置预分频器值
	IWDG_SetPrescalerDiv( prv );
	
	// 设置重装载寄存器值
	IWDG_CntReload( rlv );
	
	// 把重装载寄存器的值放到计数器中
	IWDG_ReloadKey();
	
	// 使能 IWDG
	IWDG_Enable();	
}

/****************************************************************************
*	函 数 名: IWDG_Feed
*	功能说明: 喂狗程序
*	形    参：无
*	返 回 值: 无
*****************************************************************************/
void IWDG_Feed(void)
{
	// 把重装载寄存器的值放到计数器中，喂狗，防止IWDG复位
	// 当计数器的值减到0的时候会产生系统复位
	IWDG_ReloadKey();
}



/****************************************************************************
*	函 数 名: SaveMACToFlash
*	功能说明: 保存设备MAC
*	形    参：无
*	返 回 值: 0x01
*  说    明： 张炜20230530修改
*****************************************************************************/
char SaveMACToFlash(void)	
{ 
    
	Device_Info.flag =  Flag_FirstRun; 
    
    STMFlashErase(FLASH_EquipmentInfoAddress,1);
    STMFlashWrite ( FLASH_EquipmentInfoAddress, (uint8_t *)&(Device_Info.flag), sizeof(Device_Info) );
    
	Flag_Check_Status &= ~ERROR_N0_MAC;
	return 1;
}
/****************************************************************************
*	函 数 名: ReadMACFromFlash
*	功能说明: 读设备MAC
*	形    参：无
*	返 回 值: 返回1表示正确读取，返回0表示第一次程序启动，未初始化
* 	说    明：张炜20230530修改
*****************************************************************************/
char ReadMACFromFlash(void)	
{

    memset(Device_Info.MAC_ID,0,IDLEN);
    memset(Device_Info.CMCC_CMEI,0,IDLEN);

    STMFlashRead ( FLASH_EquipmentInfoAddress, (uint8_t *)&(Device_Info.flag), sizeof(Device_Info) );
    
	if(Device_Info.flag == Flag_FirstRun)
	{
		Flag_Check_Status &= ~ERROR_N0_MAC;
		return 1;
	}
	else
	{
		Flag_Check_Status |= ERROR_N0_MAC;
		return 0;
	}
}
/****************************************************************************
*	函 数 名: ReadCMEIFromFlash
*	功能说明: 读设备CMEI
*	形    参：无
*	返 回 值: 返回1表示正确读取，返回0表示第一次程序启动，未初始化
* 	说    明：张炜20230530修改
*****************************************************************************/
char ReadCMEIFromFlash(void)	
{	
    memset(Device_Info.MAC_ID,0,IDLEN);
    memset(Device_Info.CMCC_CMEI,0,IDLEN);

    STMFlashRead ( FLASH_EquipmentInfoAddress, (uint8_t *)&(Device_Info.flag), sizeof(Device_Info) );
    
	if(strncmp(Device_Info.CMCC_CMEI,CMEI_START,8) == 0) //CMEI必须以CMEI_START定义的字符串开始
	{
		Flag_Check_Status &= ~ERROR_NO_CMEI;
		return 1;
	}
	else
	{
		Flag_Check_Status |= ERROR_NO_CMEI;
		return 0;
	}
    
}
