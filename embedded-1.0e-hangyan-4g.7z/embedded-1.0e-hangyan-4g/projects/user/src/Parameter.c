/******************************************************************************
 * @file     Parameter.c
 * @brief   参数设定
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par     此文件仅用于定参数   严斌 2016
*******************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "Parameter.h"


SOFT_REBOOT_INFO_T g_softboot_info = {0};

//unsigned char ucUar1tRecbuf[BufMAX]={0};
//unsigned char ucUar2tRecbuf[BufMAX]={0};
//unsigned char ucUar3tRecbuf[BufMAX]={0};
unsigned char Recestop1=0,Recestop2=0,Recestop3=0;
unsigned char Ver[12]="MCSDVer002";

unsigned char ucUar1tbuf[BufMAX]={0};
unsigned char ucUar2tbuf[BufMAX]={0};
unsigned char ucUar3tbuf[BufMAX]={0};
u8 Times=0,First_Int = 0,shijian=0,mytime=0,mytime2=0,token1time=0,sleeptime=0,AUTOTime=0,YZTime=0;
u16 Heartbeat=0;
uint16_t ucUar1InterrFlag=0,ucUar2InterrFlag=0,ucUar3InterrFlag=0;


unsigned char MAC_IDstring[21]={0}; //设备编号字符串，张炜20170522修改长度13->21，以\0结束
U8 Version[3]={0};
unsigned char Token1[15]={0};
unsigned char IP2[20]={0},chanl2[5]={0},Token2[15]={0},ucToken2[15]={0},ucToken[15]={0};

char Timebuf[8]={0};			//服务器下发的时间记录
char OffTime[8]={0};			//离线数据时间记录
char DMHeartTime[8]={0};		//DM心跳时间记录

unsigned char SendDataBuff[500]={0};

unsigned int ReceEnd1=0,ReceEnd2=0,ReceEnd3=0;
uint8_t  ucConectFlag=0;  //联网状态
unsigned char GPRS_or_WIFI=GPRS;    //0: GPRS    1:WIFI
unsigned char AngelPace=0;		//0:链接前置服务器     1:获取token1     2:获取后置服务器IP    3:获取token2   4:发送睡眠数据

unsigned char SendDataStatus=0;	//发送数据状态
unsigned char SleepData[50]={0};
unsigned char SendSleepDataStatus=0;	//发送睡眠数据的状态
unsigned char TemporaryBuff[100]={0};
unsigned char GetSleepTime=0;		//获取睡眠数据时间
unsigned int AT_CGATT_Count = 0;	
unsigned char Algorithm_TIMER_FLAG = 0;//算法库调用的标记(在定时器里把标记置1)
unsigned char TokenFlag = 0;
unsigned char RegEnable = 0;		//表示允许注册
unsigned char LedFlash = 0;			//控制ed闪烁  cSQ<7闪烁
unsigned char CSQNual = 0;			//信号值存储变量
unsigned char gQuickFlashTimer = 0;	//初始化计时
unsigned char ATCGATT_Count = 0;	//查询网络状态计时，每60s查询一次

//供电方式
volatile uint8_t PowerBatteryFlag = 0;  //0：插电  1：电池
uint8_t SOS_Battery = 0;  		//sos的电池
uint8_t Luat_15min_SendFlag = 0;	//4G模组的联网状态

//SOS是否连接
uint8_t SOSConnectFlag=0;  //由心跳帧判断0xB2
uint16_t Battery_CntTime=0;
uint8_t SOS_Connect_Time=0;
uint8_t SOS_Report_Time=4;  //3秒内不重复报警

//从机的管理,目前只管理6个
char SlaveSOS_MAC[20]={0};
uint8_t Slave_flag[SlaveNum] = {0};    //存在标志
uint16_t Slave_SecCnt[SlaveNum] = {0};  //存在计数，超时则清除
uint8_t Slave_type[SlaveNum] = {0};    //类型，Device_Onbed、Device_Real
char Slave_MAC[SlaveNum][20]={0};


//4G模组开机触发方式
uint8_t LuatPowerOnWay = 0;  //1:15min时间到 2:SOS事件触发 3:插电情况下等待联网后发SOS事件

//心率、呼吸率等
uint8_t RT_Hr = 0;
uint8_t RT_Rr = 0;
uint8_t RT_Status = 0;

//离线时的数据量 10s一个值
uint8_t RealBatchIndex = 0;
uint8_t hrtest[110];
uint8_t rrtest[110];
uint8_t statustest[110];  

uint16_t   USART1_RX_LEN = 0;  //串口1接收的数据长度，张炜20170519加
uint16_t   USART2_RX_LEN = 0;  //串口2接收的数据长度，张炜20170519加
uint16_t   USART3_RX_LEN = 0;  //串口3接收的数据长度，张炜20170519加
uint8_t    MAC_LEN = 0;        //MAC数据长度，张炜20170522增加
uint8_t    TOKEN2_LEN = 0;     //token2长度，张炜20170523增加
uint16_t   SleepData_SendTime=0;  //睡眠数据发送的时间，张炜20170523增加
uint8_t    Flag_Binding_Users = 0;  //设备是否绑定用户,张炜20170523增加
uint16_t   Monitor_Offline_Time = 0; //脱离监测计时，张炜20170525增加
uint16_t   No_Binding_Users_Time = 0; //未关联用户计时，张炜20170525增加
uint8_t    Flag_No_Binding_Users_Time = 0;//未关联用户计时标志，服务器第一次返回开始计时，张炜20170525增加
uint8_t    Flag_Register_OK = 0;      //设备开机注册成功，张炜20170525增加
uint8_t    Flag_Check_Status = 0; //服务器返回的验证状态，张炜20170525增加
uint8_t     Flag_Start_Mode = 0;   //网络重连的原因：上电重启还是断网重连，张炜20170526增加
uint8_t    Flag_Send_GPRS_Position = 0;  //发送一次GPRS位置
int        Position_LAC = 0;        //GPRS LAC位置数据，张炜20170526增加
int        Position_CID = 0;        //GPRS CID位置数据，张炜20170526增加
uint8_t    Flag_start_time = 0;     //启动时间计时标志
uint8_t    Last_gPulseRateHR = 0;   //保存上次的心率数值，当心率异常时发送上次的数据，张炜20170527增加
uint8_t    Last_gPulseRateRR = 0;   //保存上次的呼吸数值，当心率异常时发送上次的数据，张炜20170527增加
uint8_t    ABN_gPulseRateHR = 0;   //保存异常的心率数值，当心率异常时发送上次的数据，张炜20170527增加
uint8_t    ABN_gPulseRateRR = 0;   //保存异常的呼吸数值，当心率异常时发送上次的数据，张炜20170527增加
uint8_t    Flag_SendDataAbnormal = 0;   //发送一次标记，当心率呼吸异常的时候发送
uint8_t    Flag_init = 0 ;    //初始化进程
uint8_t   Flag_TimeAdj = 0;          //用于时间校准，1分钟之内不和服务器进行两次校准
uint16_t   Adj_Time = 0;             //校准时间计时

uint8_t   ICCID_LEN=0;           //保存卡号或者IMSI号长度
char MAC_ID[30] = {0};
char   ICCID_Save[30] = {0};       //保存在flash中的卡号或者IMSI号
char   IMEI_Save[30] = {0};       //保存在flash中的卡号或者IMSI号
char   IMSI_Save[30] = {0};       //保存在flash中的卡号或者IMSI号
uint8_t   ICCID_LEN;           //保存卡号或者IMSI号长度
uint8_t   IMEI_LEN; 
uint8_t   IMSI_LEN;

uint8_t   Flag_CARD_ISCHANGE;    //更换了卡号
uint8_t  Flag_LinkStatus=0;        //联网状态，联网成功之后一直发送实时数据
uint16_t  GPRS_ConnetTime=0;       //GPRS连接时间
uint8_t  Flag_COMDebug = 1;          //串口打印标志

S32  ECG_MAX[ECG_COMPARE_TIMES];                //ADC采样数值处理
S32  SEND_ECG_MAX[ECG_COMPARE_TIMES];                //ADC采样数值处理
S32  ECG_MIN[ECG_COMPARE_TIMES];
S32  CHGECG_MAX[ECG_COMPARE_TIMES];                //ADC处理后数据
S32  CHGECG_MIN[ECG_COMPARE_TIMES]; 
S32  ADC_DATA[500];
S32  ECG_Data[500]; 
S32  ADC_QuietCount = 0;
uint8_t   ECG_COMPARE_COUNT = 0;
uint8_t   CHGECG_COMPARE_COUNT = 0;
char      Flag_ADC_ADJ = 0;              //调整幅度
uint16_t  ADC_COUNT=0;
uint16_t  CHGADC_COUNT=0;
uint16_t  ADC_AdjTime=0;
float   ADC_AmpMultiple = 1;    //放大倍数
uint8_t Last_gPeopleFlag = 0;   //是否有人的状态
float   LastADC_AmpMultiple = 1;    //上一次放大倍数

uint8_t Flag_PowerOn = 1;       //是否是上电
uint8_t Last_StatusFlag = 0; //上一个状态
uint8_t Keep_StatusFlag = 0; //现在保持的状态状态
uint8_t BeforeLast_StatusFlag=0;
unsigned char Buffer_SleepData[SLEEPDTATABUF][40];   //数据缓存
uint16_t  Flag_SleepDataBuffer_Save = 0;
uint16_t  Flag_SleepDataBuffer_Send = 0;
uint8_t   SleepDataBuffer_SendTime = 0;
uint32_t  DM_Heart_Time = 0; 

unsigned char Statist_TurnStartTimebuf[6];  //断网统计开始时间
unsigned char Statist_PeopleStartTimebuf[6];    
unsigned char Statist_NoPeopleStartTimebuf[6];
unsigned char Statist_TurnEndTimebuf[6];  //断网统计结束时间
unsigned char Statist_PeopleEndTimebuf[6];    
unsigned char Statist_NoPeopleEndTimebuf[6];
uint32_t  Statist_AddHR = 0;       //断网统计心率累加
uint32_t  Statist_AddRR = 0;       //断网统计呼吸累加
uint16_t  Statist_AddCount = 0;    //断网统计呼吸/心率累加次数
unsigned char  Save_SleepHRData[6];  //断网情况下保存10分钟状态
unsigned char  Save_SleepRRData[6];
uint8_t   Flag_SavepPos = 0;
uint16_t  TurnKeepTime = 0;       //统计计时时间
uint16_t  PeopleKeepTime = 0;       //统计计时时间
uint16_t  NoPeopleKeepTime = 0;       //统计计时时间
uint8_t   Flag_NoNetWorkStart=0;        //断网开始标志
uint8_t  Flag_CanSendStatistData = 0;      //可以发送统计数据
uint8_t  CanSendStatistTime = 0;          //统计数据接收间隔时间

uint8_t Status_ExtSensorIn = 0;    //外部传感器是否插入状态  20180320增加
uint8_t Status_ExtSensorOnbed = 0;    //外部传感器是否有人在床状态  20180320增加
uint8_t ExtSensor_OnbedStatus_Count = 0;  //传感器在床状态次数统计，累计多次状态一致才确定是否在床 20180320增加
uint8_t OnbedStatus_CountTimer = 0;   //外部传感器在床状态统计间隔时间
uint8_t LastOnbedStatus = 0;          //上一次的在床状态 
uint8_t Flag_SendPresensorStatus = 0;  //发送压力传感器状态
uint8_t SendPresensorStatus_Time = 0;  //发送压力传感器时间


volatile uint32_t ADC_ConvertedValue[2]={0};
float  ADC_VoltageValue[2]={0};   //adc电压值

u8 sync_sever_time_count=0;
u16 test_timer=0;
Sync_Time_State Sync_State=IDLE;
u16 GPRS_Wait_Reconn=0;
u8  flag_Gprs_Reconn=1;



DeviceInfo_Para Device_Info;
