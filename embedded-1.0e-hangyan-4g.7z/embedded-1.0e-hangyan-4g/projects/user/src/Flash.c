/******************************************************************************
 * @file     flash.c
 * @brief   存储程序
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par     FLASH数据存储   严斌 2016
 *    张炜20170519修改flash存储格式
 *    张炜20170610在MAC后增加保存卡号IMSI号
*******************************************************************************/
#include "Fun.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "BERpara.h"
#include "Parameter.h"
#include "n32g45x.h"
#include "Flash.h"
#include "m26.h"

#define FLASH_COMPLETE FLASH_COMPL
#define FLASH_ErasePage  FLASH_EraseOnePage
#define FLASH_Status FLASH_STS

void WriteFlash(void);

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint32_t EraseCounter = 0x00, Address = 0x00;
uint32_t Data = 0x3210ABCD;
uint32_t Data1 = 0x0;
uint32_t Data2 = 0x0;
uint32_t Data3 = 0x0;
uint32_t Data4 = 0x0;
uint32_t Data5 = 0x0;

uint32_t NbrOfPage = 0x00;
__IO FLASH_Status FLASHStatus = FLASH_COMPLETE;
__IO TestStatus MemoryProgramStatus = PASSED;

/****************************************************************************
*	函 数 名: 
*	功能说明: flash存储测试
*	形    参：无
*	返 回 值: 无
* 说    明：
*****************************************************************************/
#if 0
int main(void)
{
    /* 解锁Flash *************/
    FLASH_Unlock();

    /* 清楚各个标志位 */
    FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);

    /* 计算擦除的页数 */
    NbrOfPage = (FLASH_USER_END_ADDR - FLASH_USER_START_ADDR) / FLASH_PAGE_SIZE;

    /* 擦除Flash */
    for(EraseCounter = 0; (EraseCounter < NbrOfPage) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
    {
        if (FLASH_ErasePage(FLASH_USER_START_ADDR + (FLASH_PAGE_SIZE * EraseCounter)) != FLASH_COMPLETE)
        {
            /*擦除Flash出错，可写一些对应的处理*/
            while (1)
            {
            }
        }
    }
    /*开始写入数据***********/

    Address = FLASH_USER_START_ADDR;

    while (Address < FLASH_USER_END_ADDR)
    {
        if (FLASH_ProgramWord(Address, DATA_32) == FLASH_COMPLETE)
        {
            Address = Address + 4;		//DATA_32是unit32,占四个字节
        }
        else
        {
            /*写入数据出错*/
            while (1)
            {
            }
        }
    }

    /* 锁定Flash*********/
    FLASH_Lock();


    /* Check if the programmed data is OK
        MemoryProgramStatus = 0: data programmed correctly
        MemoryProgramStatus != 0: number of words not programmed correctly ******/
    Address = FLASH_USER_START_ADDR;
    MemoryProgramStatus = PASSED;

    while (Address < FLASH_USER_END_ADDR)
    {
        Data = *(__IO uint32_t *)Address;

        if (Data != DATA_32)
        {
            MemoryProgramStatus = FAILED;
        }

        Address = Address + 4;
    }

    /* Infinite loop */
    while (1)
    {
    }
}
#endif

#if 0
/****************************************************************************
*	函 数 名: SetMac
*	功能说明: 设置设备MAC
*	形    参：mac 设备mac
*	返 回 值: 无
* 说    明：
*****************************************************************************/
void SetMac(U8* mac){
	memcpy(&MAC_ID[1],mac,6);
	WriteFlash();
}


/****************************************************************************
*	函 数 名: SetVersion
*	功能说明: 设置设备版本信息
*	形    参：ver 设备版本信息
*	返 回 值: 无
* 说    明：暂不使用，张炜20170519注
*****************************************************************************/
void SetVersion(U8* ver){
	memcpy(Version,ver,3);
	WriteFlash();
}
#endif
/****************************************************************************
*	函 数 名: CheckMac
*	功能说明: 检查设置的MAC指令串是否正确
*	形    参：无
*	返 回 值: 无
* 说    明：张炜20170522，新的存储方式中设备mac是否写入和MAC字符串分开表示
*****************************************************************************/
  void CheckMac(void)
{	 
    uint8_t i;	
	  	 				
	  if((Flag_Check_Status&ERROR_N0_MAC) != ERROR_N0_MAC)
    {        
				AngelPace = CONECTIP1;
        SendDataStatus = NO;					//打开数据发送
        SendSleepDataStatus = NO;				//发送失败,需要重新组装数据    		     
//        HexToStr(MAC_IDstring, MAC_ID+1, 6);			
			  for(i=0;i<MAC_LEN;i++)
			  {
				   MAC_IDstring[i] = MAC_ID[i];
			  }
				MAC_IDstring[MAC_LEN+1] = '\0';	
        if((Status_ExtSensorIn == EXTSENSOR_ISOUT)&&(Flag_COMDebug == 1))
					printf("Mac:%s\r\n", MAC_IDstring);				
    }
    else
    {
        mytime2 = 0;
        AngelPace = MACERROR;		
       if((Status_ExtSensorIn == EXTSENSOR_ISOUT)&&(Flag_COMDebug == 1))				
        printf("MAC NULL!\r\n");
    }
}
/****************************************************************************
*	函 数 名: SendDataBegin
*	功能说明: 开始发送数据
*	形    参：无
*	返 回 值: 
* 说    明：
*****************************************************************************/
char SendDataBegin(void)
{
	u8 ch=0;

	if((Flag_Check_Status & ERROR_NO_TOKEN2) != ERROR_NO_TOKEN2)
	{					//已经有token存在，等待IP链接成功
		//while(1){
		//	if(strstr(ucUar3tbuf,"CONNECT  OK") != NULL){	//链接成功
		//		printf("U3Rcv:%s\r\n",ucUar3tbuf);
		//		break;
		//	}
		//}
//		SendSleepDataReally();				//发送唤醒数据
											//获取状态
//		Send_SyncDataToServer(); //未连接成功，发送同步数据包用于网络连接
//		if(Flag_COMDebug == 1)
//			printf("Send Data!\r\n");
		if(Flag_Start_Mode != START_GPRS_RESTART)  	
		   AngelPace = GETBACKSERVERIPOK;		//如果有token，直接连接后置服务器
    SendDataStatus = NO;
		ch = 1;								//不需要链接前置服务器
	}
	else{
		if(Flag_COMDebug == 1)
			printf("Conect IP1!\r\n");
		AngelPace = CONECTIP1;
		ch = 0;
	}

	return ch;
}

#if 0
/****************************************************************************
*	函 数 名: WriteMACToFlash
*	功能说明: 将设备MAC数据保存到单片机flash中
*	形    参：无
*	返 回 值: 返回0x01表示写入成功，返回0x00表示写入失败
* 说    明：张炜20170610增加保存IMSI号
*****************************************************************************/
uint8_t WriteMACToFlash(void)
{
			int i = 0;
    u32 ucData[100] = {0};
    uint8_t datalen=0;

//	memset(ucData,0,sizeof(ucData));

    FLASH_Unlock();// 解锁Flash
    FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR); 		/* 清楚各个标志位 */
    NbrOfPage = 1;	/* 计算擦除的页数 */
    for(EraseCounter = 0; (EraseCounter < NbrOfPage) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
    {
        if(FLASH_ErasePage(MAC_FLASH_ADDR+ (FLASH_PAGE_SIZE * EraseCounter)) != FLASH_COMPLETE) /* 擦除Flash */
        {
            FLASH_Lock(); /*擦除Flash出错，可写一些对应的处理*/
			if(Flag_COMDebug == 1)
				printf("Clear Flash Fail!\r\n");
            return 0x00;
        }
    }
    /*开始写入MAC数据***********/
     Address = MAC_FLASH_ADDR;
	    ucData[0] = (uint32_t)0x5A;     //标记位
		  ucData[1] = (uint32_t)MAC_LEN;  //设备MAC长度  
        datalen=2;
        for(i=0;i<MAC_LEN;i++)
        {
            ucData[datalen++] = (uint32_t) MAC_ID[i];
        }
	    ucData[datalen++] = (uint32_t)SIMCard_ICCID_Len;  //保存ICCID号码
        for(i=0;i<SIMCard_ICCID_Len;i++)
        {
            ucData[datalen++] = (uint32_t) SIMCard_ICCID[i];
        }
		ucData[datalen++] = (uint32_t)SIMCard_IMEI_Len;  //保存IMEI号码
        for(i=0;i<SIMCard_IMEI_Len;i++)
        {
            ucData[datalen++] = (uint32_t) SIMCard_IMEI[i];
        }
		
        ucData[datalen++] = (uint32_t)SIMCard_SN_Len;  //保存SN号码		
		for(i=0;i<SIMCard_SN_Len;i++)
        {
            ucData[datalen++] = (uint32_t) SIMCard_SN[i];
        }
		
		
    for(i = 0; i < datalen; i++)
    {
        if (FLASH_ProgramWord(Address, ucData[i]) == FLASH_COMPLETE)
        {
            Address = Address + 4;		//DATA_32是unit32,占四个字节
        }
        else
        {
			if(Flag_COMDebug == 1)
				printf("Write Flash Error!\r\n");
					  return 0x00;
        }
    }

    FLASH_Lock(); //锁定Flash
//    ReadFlash();
		ReadMACFromFlash();
    return 0x01;
}
/****************************************************************************
*	函 数 名: ReadMACFromFlash
*	功能说明: 将单片机flash中保存的设备MAC读出
*	形    参：无
*	返 回 值: 返回0x01表示读取成功。返回0x00表示设备号未写入
* 说    明：张炜20170522增加 读取设备卡号IMSI号
*****************************************************************************/
uint8_t ReadMACFromFlash(void)
{
	unsigned char ucbuf[45]={0};
	char *ptr=NULL;
	uint8_t i = 0;
	uint32_t mac_addr;
	
//	 Data = *(__IO uint32_t *)MAC_FLASH_ADDR;

    ucbuf[0] = (u8)(  *(__IO uint32_t *)MAC_FLASH_ADDR &0x000000FF);
	  if(ucbuf[0] != 0x5A)
		{
			   
            printf("read mac from flash error \r\n");
			return 0x00;
		}
		else
		{
			MAC_LEN = (u8)(( *(__IO uint32_t *)(MAC_FLASH_ADDR+4))&0x000000FF);
            MAC_LEN=12;
			for(i=0;i<MAC_LEN;i++)
			{
				MAC_ID[i] = (u8)(( *(__IO uint32_t *)(MAC_FLASH_ADDR+8+i*4))&0x000000FF);
			}	
			
			ICCID_LEN = (u8)(( *(__IO uint32_t *)(MAC_FLASH_ADDR+8+MAC_LEN*4))&0x000000FF);
			for(i=0;i<ICCID_LEN;i++)
			{
				ICCID_Save[i] =(u8)(( *(__IO uint32_t *)(MAC_FLASH_ADDR+12+MAC_LEN*4+i*4))&0x000000FF); 
			}
			ICCID_Save[ICCID_LEN] = '\0';
			
            SIMCard_IMEI_Len = (u8)(( *(__IO uint32_t *)(MAC_FLASH_ADDR+12+MAC_LEN*4+ICCID_LEN*4))&0x000000FF);
			for(i=0;i<SIMCard_IMEI_Len;i++)
			{
				SIMCard_IMEI[i] =(u8)(( *(__IO uint32_t *)(MAC_FLASH_ADDR+16+MAC_LEN*4+ICCID_LEN*4+i*4))&0x000000FF); 
			}
			SIMCard_IMEI[SIMCard_IMEI_Len] = '\0';
			
			SIMCard_SN_Len = (u8)(( *(__IO uint32_t *)(MAC_FLASH_ADDR+16+MAC_LEN*4+ICCID_LEN*4+SIMCard_IMEI_Len*4))&0x000000FF);
			for(i=0;i<SIMCard_SN_Len;i++)
			{
				SIMCard_SN[i] =(u8)(( *(__IO uint32_t *)(MAC_FLASH_ADDR+20+MAC_LEN*4+ICCID_LEN*4+SIMCard_IMEI_Len*4+i*4))&0x000000FF); 
			}
			SIMCard_SN[SIMCard_SN_Len] = '\0';
			
//			printf("The Device IMEI is:");//上位机解析不到MAC地址
//			for(i=0;i<IMEI_LEN;i++)
//			   printf("0x%02x ",IMEI_Save[i]);
//			printf("\r\n");
//			printf("The SIM CARD IMSI is:%s,len is:%d",ICCID_Save,ICCID_LEN);
			return 0x01;
		}		
}
/****************************************************************************
*	函 数 名: WriteToken2ToFlash
*	功能说明: 将服务器token2数据保存到单片机flash中
*	形    参：无
*	返 回 值: 返回0x01表示写入成功。返回0x00表示写入失败
* 说    明：张炜20170523增加
*****************************************************************************/
uint8_t WriteToken2ToFlash(void)
{
	int i = 0;
    u32 ucData[50] = {0};


//	memset(ucData,0,sizeof(ucData));

    FLASH_Unlock();// 解锁Flash
    FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR); 		/* 清楚各个标志位 */
    NbrOfPage = 1;	/* 计算擦除的页数 */
    for(EraseCounter = 0; (EraseCounter < NbrOfPage) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
    {
        if(FLASH_ErasePage(TOKEN2_FLASH_ADDR+ (FLASH_PAGE_SIZE * EraseCounter) ) != FLASH_COMPLETE) /* 擦除Flash */
        {
            FLASH_Lock(); /*擦除Flash出错，可写一些对应的处理*/
			if(Flag_COMDebug == 1)
				printf("Clear Flash Fail!\r\n");
            return 0x00;
        }
    }
 /*开始写入token2数据***********/
     Address = TOKEN2_FLASH_ADDR ;
	    ucData[0] = (uint32_t)0x5A;     //标记位
		  ucData[1] = (uint32_t)TOKEN2_LEN;  //设备MAC长度  
		  for(i=0;i<TOKEN2_LEN;i++)
		  {
	     ucData[2+i] = (uint32_t) Token2[i];
		  }
	    for(i=0;i<20;i++)
			{
				 ucData[2+TOKEN2_LEN+i] = (uint32_t)IP2[i];
			}
			 for(i=0;i<5;i++)
			{
				 ucData[22+TOKEN2_LEN+i] = (uint32_t)chanl2[i];
			}
			for(i = 0; i < TOKEN2_LEN+27; i++)
			{
					if (FLASH_ProgramWord(Address, ucData[i]) == FLASH_COMPLETE)
					{
							Address = Address + 4;		//DATA_32是unit32,占四个字节
					}
					else
					{
						if(Flag_COMDebug == 1)
							printf("Write Token2 Error!\r\n");
							return 0x00;
					}
			}


    FLASH_Lock(); //锁定Flash
   return 0x01;	
}
/****************************************************************************
*	函 数 名: ReadToken2FromFlash
*	功能说明: 将单片机flash中保存的token2读出
*	形    参：无
*	返 回 值: 返回0x01表示读取成功。返回0x00表示未写入
* 说    明：张炜20170523增加
*****************************************************************************/
uint8_t ReadToken2FromFlash(void)
{
	unsigned char ucbuf[50]={0};
	char *ptr=NULL;
	uint8_t i = 0;
	uint32_t mac_addr;
	
//	 Data = *(__IO uint32_t *)MAC_FLASH_ADDR;

    ucbuf[0] = (u8)(  *(__IO uint32_t *)TOKEN2_FLASH_ADDR &0x000000FF);
	  if(ucbuf[0] != 0x5A)
		{
//----------------------测试强制赋值token2为3646824------------------------------------------			
//			Token2[0]= 0x33;
//			Token2[1]= 0x36;
//			Token2[2]= 0x34;
//			Token2[3]= 0x36;
//			Token2[4]= 0x38;
//			Token2[5]= 0x32;
//			Token2[6]= 0x34;
//			TOKEN2_LEN = 7;
//			Token2[TOKEN2_LEN] = '\0';
//			printf("The Token2 is:");
//			for(i=0;i<TOKEN2_LEN;i++)
//			   printf("%c",Token2[i]);
//			printf("\r\n");
//-----------------------------------------------------------------------
//		  printf("No Token2！Please Connect to Server!\r\n");	
		
			return 0x00;
		}
		else
		{
			TOKEN2_LEN = (u8)(( *(__IO uint32_t *)(TOKEN2_FLASH_ADDR+4))&0x000000FF);
			for(i=0;i<TOKEN2_LEN;i++)
			{
				Token2[i] = (u8)(( *(__IO uint32_t *)(TOKEN2_FLASH_ADDR+8+i*4))&0x000000FF);
			}
			for(i=0;i<20;i++)
			{
				IP2[i] = (u8)(( *(__IO uint32_t *)(TOKEN2_FLASH_ADDR+8+TOKEN2_LEN*4+i*4))&0x000000FF);
			}
			for(i=0;i<5;i++)
			{
				chanl2[i] = (u8)(( *(__IO uint32_t *)(TOKEN2_FLASH_ADDR+88+TOKEN2_LEN*4+i*4))&0x000000FF);
			}
			Token2[TOKEN2_LEN] = '\0';
			if(Flag_COMDebug == 1)
			{
				printf("The Token2 is:%s \r\n",Token2);
				printf("IP2:%s\r\n", IP2);
				printf("chanl2:%s\r\n", chanl2);
			}
//			for(i=0;i<TOKEN2_LEN;i++)
//			   printf("%c",Token2[i]);
//			printf("\r\n");
		}
		return 0x01;
}

/****************************************************************************
*	函 数 名: WriteFlash
*	功能说明: 将数据保存到单片机flash中
*	形    参：无
*	返 回 值: 
* 说    明：
*****************************************************************************/
void WriteFlash(void)
{
	int i = 0;
    u32 ucData[7] = {0};
	//u32 uctoken[4] = {0};

	memset(ucData,0,sizeof(ucData));

    FLASH_Unlock();// 解锁Flash
    FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR); 		/* 清楚各个标志位 */
    NbrOfPage = (FLASH_USER_END_ADDR - FLASH_USER_START_ADDR) / FLASH_PAGE_SIZE;	/* 计算擦除的页数 */
    for(EraseCounter = 0; (EraseCounter < NbrOfPage) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
    {
        if(FLASH_ErasePage(FLASH_USER_START_ADDR + (FLASH_PAGE_SIZE * EraseCounter)) != FLASH_COMPLETE) /* 擦除Flash */
        {
            FLASH_Lock(); /*擦除Flash出错，可写一些对应的处理*/
			if(Flag_COMDebug == 1)
				printf("Clear Flash Fail!\r\n");
            return;
        }
    }
    /*开始写入数据***********/
    Address = FLASH_USER_START_ADDR;

	//write mac
	if(MAC_ID[1] != 0xff || MAC_ID[2] != 0xff || MAC_ID[3] != 0xff || MAC_ID[4] != 0xff || MAC_ID[5] != 0xff || MAC_ID[6] != 0xff ){
	    ucData[0] = ucData[0] | 0x01;//标记位
	    ucData[0] = (ucData[0] << 8) | MAC_ID[1];
	    ucData[0] = (ucData[0] << 8) | MAC_ID[2];
		  ucData[0] = (ucData[0] << 8) | MAC_ID[3];
	    ucData[1] = ucData[1] | MAC_ID[4];
	    ucData[1] = (ucData[1] << 8) |  MAC_ID[5];
		  ucData[1] = (ucData[1] << 8) |  MAC_ID[6];
		  ucData[1] = (ucData[1] << 8) |  0xff;
		  MAC_ID[0] = 0x01;
	}

	//write Version
	ucData[2] = ucData[2] |  Version[0];
	ucData[2] = (ucData[2] << 8) |  Version[1];
	ucData[2] = (ucData[2] << 8) |  Version[2];

	//Write Token
	StrToHex(ucToken,Token2,5);
	//for(i=0;i<5;i++){
	//	printf("aa%x--",ucToken[i]);
	//}
	//printf("\r\n");

	if(Token2[0] == '7' || Token2[0] == '8'){
		ucData[3] = ucData[3]|0x11;					//标志位
		ucData[3] = (ucData[3] << 8) | ucToken[0];
		ucData[3] = (ucData[3] << 8) | ucToken[1];
		ucData[3] = (ucData[3] << 8) | ucToken[2];
		ucData[4] = ucData[4]|ucToken[3];
		ucData[4] = (ucData[4] << 8) | ucToken[4];
		ucData[4] = (ucData[4] << 8) | ucToken[5];
		ucData[4] = (ucData[4] << 8) | ucToken[6];
		ucData[5] = ucData[5]|ucToken[7];
		ucData[5] = (ucData[5] << 8) | ucToken[8];
	}
	
    for(i = 0; i < 7; i++)
    {
        if (FLASH_ProgramWord(Address, ucData[i]) == FLASH_COMPLETE)
        {
            Address = Address + 4;		//DATA_32是unit32,占四个字节
        }
        else
        {
			if(Flag_COMDebug == 1)
				printf("Write Flash Error!\r\n");
        }
    }

    FLASH_Lock(); //锁定Flash
    ReadFlash();
}
/****************************************************************************
*	函 数 名: ReadFlash
*	功能说明: 读取保存在单片机flash中的数据
*	形    参：无
*	返 回 值: 
* 说  
*****************************************************************************/
void ReadFlash(void){
	unsigned char ucbuf[15]={0};
	char *ptr=NULL;
	uint8_t st;
	
   st=ReadMACFromFlash();   //张炜20170523增加，Mac和token2分开位置保存
	 if(st == 0x00)
		  Flag_Check_Status |= ERROR_N0_MAC;
	 if(Flag_COMDebug == 1)
	 if((st == 0x01)&&(Status_ExtSensorIn == EXTSENSOR_ISOUT))
     {
		  printf("Saved  ICCID is:%s,len is:%d\r\n",ICCID_Save,ICCID_LEN);
          printf("Saved  IMEI  is:%s,len is:%d\r\n",SIMCard_IMEI,SIMCard_IMEI_Len);
     }
	 st = ReadToken2FromFlash();
	 if(st == 0x00)
		  Flag_Check_Status |= ERROR_NO_TOKEN2;	  
}

#endif