/******************************************************************************
 * @file     MobileAndlink.h
 * @brief   移动网关Ank-Link协议通信
 * @version  v1.0
 * @date     2023.05.17
 * @note
 * Copyright (C)  张炜 2023
 *
 * @par      
 *    V1.0    使用ESP8266 WiFi，
 *        协议MQTT ，Json， 移动And-link
*******************************************************************************/

#ifndef  __MOBILEANDLINK_H__
#define  __MOBILEANDLINK_H__


#include "time.h"
#include <string.h>
#include <stdio.h>
#include "USART.h"
#include "Parameter.h"
#include "cJSON.h"
#include "Mqttkit.h"
#include "m26.h"

#define REV_OK		0	//接收完成标志
#define REV_WAIT	1	//接收未完成标志

#define NOT_CMCC      //不要移动流程
//#define Demonstrate  //演示环境
//#define Only_PIE     //只有压阻没有压电
#define SOS_1_0     //SOS 1.0版本

#define URL_GETGWADDRESS1     "http://yddevice.isuke.com.cn:38888/dm-multi-accept/multi/getMultiTerminalConfig" 	 		//1.DM配置拉取接口
#define URL_REGISTADDRESS2    "http://yddevice.isuke.com.cn:38888/dm-multi-accept/multi/acceptMultiTerminalRegInfo"  		//2.DM设备注册上报接口
#define URL_HEARTADDRESS3     "http://yddevice.isuke.com.cn:38888/dm-multi-accept/multi/acceptMultiTerminalHeartbeatInfo"   //3.DM设备心跳上报接口

#define URL_GETGWADDRESS     "http://yddevice.isuke.com.cn:38888/espapi/m2m/rest/devices/cgw"  //苏仁后台转换的url
#define URL_REGISTADDRESS    "http://yddevice.isuke.com.cn:38888/device/inform/bootstrap"  //注册URL苏仁后台转换的url
#define URL_ONLINEADDRESS    "http://yddevice.isuke.com.cn:38888/device/inform/boot"  //设备上线URL

#define URL_REPORTADDRESS    "http://yddevice.isuke.com.cn:38888/device-manage/device/inform/dmReport"   //终端数据上报URL

#define URL_BINDING          "http://yddevice.isuke.com.cn:38888/device-manage/device/isBind"  //询问是否有绑定

#define URL_DEVICE_PWON_ADDRESS "http://yddevice.isuke.com.cn:38888/dm/device/inform/boot"//设备上电请求的地址
#define URL_demonstrate_ADDRESS "http://yddevice2.isuke.com.cn:38888/dm/device/inform/boot"  //演示环境
#define URL_GETAHOST_IP      "yddevice.isuke.com.cn"
//#define URL_GETAHOST_IP      "114.116.49.249"
#define URL_demonstrate_IP   "yddevice2.isuke.com.cn"
#define URL_MQTT_IP          "mqtt.isuke.com.cn"
#define URL_HEADER  "Content-Type: application/json\r\nAccept-Charset: utf-8\r\n"
#define URL_GETAHOST_PORT     "38888"
#define MQTT_HOST_PORT        "1888"
#define MQTTPARA_HOST_PORT    "3777"

#define MQTT_FORWARD           "ydzf.isuke.com.cn" //mqtt转发

#define COAPLINK_PORT  "5683"   //配网引导通道coap协议端口

#define DM_brand           "isuke"
#define DM_model           "CC08-G"
#define DM_sysVersion      "BareMachine"
#define DM_softwareVer     "6.1.1"
#define DM_softwareName    "1007"
#define DM_board           "1.0E-4G-V5.3"
#define DM_appInfo         "isuke APP"

#define device_master       "CC08-G"
#define device_slave1       "CC08-B-L"
#define device_slave2       "CC08-B"
#define device_slave3       "CC09-S"
#define DevNature_master      1
#define DevNature_slave       0
#define Device_Onbed       1
#define Device_Real        2
#define Device_SOS         3

#define IOTDEVICETYPE   "591217"    //智能设备类型码，,在 Andlink 开发者门户中预先定义
#define IOTPRODUCTTOKEN  "erTtwBfy0QN3jw23"   //产品创建时由开发者门户生成，一机一密设备填普通TOKEN
#define ANDLINKTOKEN "ikswmdaZEFA0l2Fq" 
#define COAPLINK_PORT  "5683"   //配网引导通道coap协议端口
#define MQTT_ISUKEADDRESS   "/subscribe"
 
#if 0
#define MY_DEVICEID   "CMCC-591217-860597010007965"
//#define MY_MAC "CMCC-591217-843F2898EE24"
#define MY_SN  "1860059121700000010"
#endif
#if 0
#define MY_DEVICEID   "CMCC-591217-860597010007882"
//#define MY_MAC "CMCC-591217-843F2898EE24"
#define MY_SN  "1860059121700000002"
#endif
#if 0
#define MY_DEVICEID   "CMCC-591217-860597010007940"
//#define MY_MAC "CMCC-591217-843F2898EE24"
#define MY_SN  "1860059121700000008"
#endif

/******************* 软硬件版本号 *******************/
#define  HARDWARE_MAJORVER      5	//硬件主版本号
#define  HARDWARE_MINORVER      1	//硬件次版本号
#define  HARDWARE_TESTVER       0	//硬件测试版本号

#define  SOFTWARE_MAJORVER      6	//软件件主版本号
#define  SOFTWARE_MINORVER      0	//软件次版本号
#define  SOFTWARE_TESTVER       1	//软件测试版本号

#define  RELEASE_TIME        "20240927"   //发布时间
#define  CMEI_START          "11110048"  //CMEI 必须以此为字符串开始，不可变更

#define  FLASH_EquipmentInfoAddress       ((uint32_t)0x08032000)     //设备信息保存位置，设备MAC，CMEI
#define  FLASH_WIFIInfoAddress            ((uint32_t)0x08032800)    //WIFI模块连接的路由器名称和密码
#define  FLASH_ServerInfoAddress          ((uint32_t)0x08033000)     //保存服务器IP、服务器设置信息等  没用上
#define  FLASH_VerifyInfoAddress          ((uint32_t)0x08033800)    //设备上线过的标志位
#define  FLASH_AndLinkInfoAddress         ((uint32_t)0x08034000)     //保存移动Andlink协议设备连接信息


typedef struct 
{
    bool flag;
    bool f_imsi;
    bool f_imsi2;
    bool f_sn;
    bool f_mac;    
    bool f_rom;
	bool f_ram;
	bool f_cpu;
	bool f_sysVersion;
	bool f_softwareVer;
	bool f_softwareName;
	bool f_volte;
	bool f_netType;
	bool f_phoneNumber;
	bool f_batteryCapacity;
	bool f_screenSize;
	bool f_networkStatus;
	bool f_wearingStatus;
	bool f_routerMac;
	bool f_bluetoothMac;
	bool f_gpu;
	bool f_board;
	bool f_resolution;
	bool f_appInfo;
}DM_fCONFIG;   //配置拉取阶段fieldConfig_Auto的Json详细信息

typedef struct 
{
    char flag;
    uint16_t reportTime;
    uint16_t reportNum;
    uint16_t heartBeatTime;
    uint16_t retryInterval;    
	uint16_t retryNum;
}DM_rCONFIG;   //配置拉取阶段ruleConfig的Json详细信息

/********移动云网关返回的设备注册响应参数******************************/
typedef struct 
{
    char flag;
    char gwAddress[50];
    char gwAddress2[50];
    char user_key[50];
    char SSID[35];    
    char password[35] ;
}Router_Para;   //APP广播的路由器及网关参数

typedef struct 
{
    char flag;
    char gwToken[30];
    char deviceID[30];    
    char deviceToken[20] ;
    char andlinkToken[30];
    char dmToken[50];
    uint32_t userId;
}GWresp_Para;   //设备注册响应参数

typedef struct 
{
    char mqttUrl[30];   //
    char mqttClientId[30];
    char mqttUser[30];  //mqtt 连接用户名
    char mqttPassword[30]; //mqtt 连接用户密码
    uint16_t mqttKeepalive; //心跳周期（单位秒）
    uint16_t httpRetry[4];  //http 重试策略
    uint16_t mqttRetry[4];  //Mqtt 重试策略
    uint8_t userBind; //0 表示未绑定、1 表示已绑定（真实用户）、2 表示默认用户（CMCC-厂商名-deviceType）绑定
    double timestamp;
//    uint8_t mqttConn ;   //0 表示无需 MQ 连接，无需 MQ 连接的设备必填
    char deviceManageUrl[80];    
}MQTT_Para;  //设备上线回复参数

extern GWresp_Para Andlink_GW_Info;

char Dm_getConfig_Auto(void);
char Dm_getConfig_Heart(void);
char Dm_RegistReport(void);
char Dm_HeartReport(void);
char HttpStageRevRespon(void);

char Power_on_notify(void);
void Slave_MQTT_Will(char *MAC,char *device);
void iSuke_MQTT_Mboot(void);
void Slave_MQTT_Mboot(char *MAC,char *device);
void iSuke_MQTT_Time(void);
void iSuke_MQTT_Data(void);
uint8_t iSuke_MQTT_SOS(uint8_t type);
void iSuke_MQTT_RealBatch(uint8_t len);
void ExistSlave_MQTT_Data(char *MAC,uint8_t status);
void RealSlave_MQTT_Data(char *MAC,uint8_t *status);
void Slave_Manage_PutIn(char *MAC,uint8_t *status,uint8_t device);
void Slave_Manage_PutOut(void);
void Slave_Manage_Time(void);

char isuke_DeviceOnline(void);
char Andlink_DeviceOnline(void);
char TerminalManageDataReport(void);
void MQTTLink_iSukeServer(void);
char Andlink_MQTT_Link(void);
void Andlink_MQTT_Online(void);
void OneNet_Subscribe(char *topics[], unsigned char topic_cnt);
char Andlink_DeviceRegist(void);
char BroadcastRegistResultByCoap(void);
char ReadAndlinkinfoFromFlash(void);
char BroadcastAccessInNetworkByCoap(void);
char Andlink_GetGWAddress(void);
char Andlink_Publish( char *topic,char *msg);
void isuke_UserUnbind(void);
void MQTT_Mboot_Send(void);
#endif

