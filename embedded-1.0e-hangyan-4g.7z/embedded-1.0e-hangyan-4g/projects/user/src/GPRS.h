/******************************************************************************
 * @file     GPRS.h
 * @brief   GPRS通讯函数
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par      严斌 2016
*******************************************************************************/
#ifndef __GPRS_H_
#define __GPRS_H_
#include "Fun.h"
#include "Parameter.h"

//#if _NEW_MODULE
#define GPRS_CQ_GPIO_PORT        		GPIOB
#define GPRS_CQ_GPIO_CLK                RCC_AHBPeriph_GPIOB
#define CHIR_PIN                    	GPIO_Pin_1
#define GPRS_CQ_PIN                    	GPIO_Pin_14	



#define GPRS_POWER(a) if (a)	\
					GPIO_SetBits(GPRS_CQ_GPIO_PORT,GPRS_CQ_PIN);\
					else		\
					GPIO_ResetBits(GPRS_CQ_GPIO_PORT,GPRS_CQ_PIN)
//#endif


void InitGPRS(void);
void Second_AT_Command(char *b,char *a,u8 wait_time);
char Second_AT_Command_YB(char *b,char *a,u8 wait_time);
void Second_AT_Command_CIFSR(char *b,u8 wait_time);
char Second_AT_Command_CFUN(char *b,char *a,u8 wait_time);
u8 Find(char *a);
void Wait_CREG(void);
void Set_ATE0(void);
void Connect_Server(const unsigned char *ucIP);
void Connect_Server2(int chanl);
void Rec_Server_Data(void);
void Send_OK(void);
void Connected(void);
void GPRSSendData(unsigned char *p,unsigned int Len);
char GetConnectionStatus(int chanl);
char MyCountChar(unsigned char *p,int pLen);
char TCCencer(void);
void InquireCSQ(void);
char AT_CGATT_Ctrl(void);
char AT_CGATT_Ctrl_YB(void);
void GetGPRSPosition(void);
int8_t  Read_Card_IMSI(void);


#endif
