/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/

/**
 * @file n32g45x_it.c
 * @author Nations
 * @version v1.0.0
 *
 * @copyright Copyright (c) 2019, Nations Technologies Inc. All rights reserved.
 */
#include "n32g45x_it.h"
#include "main.h"
#include <BERpara.h>
#include <stdio.h>
#include "Parameter.h"
#include "USART.h"
#include "m26.h"
#include "ADC.h"
#include "User_RTC_Config.h"
#include "main.h"
#include "MobileAndlink.h"
/** @addtogroup N32G45X_StdPeriph_Template
 * @{
 */

uint16_t capture = 0;
extern __IO uint16_t CCR1_Val;
extern __IO uint16_t CCR2_Val;
extern __IO uint16_t CCR3_Val;
extern __IO uint16_t CCR4_Val;
extern __IO uint16_t MY_CCR_Val;
extern __IO uint16_t ADC1_ConvertedValue;
extern __IO uint16_t ADC3_ConvertedValue;

extern uint8_t TxBuffer1[];
extern uint8_t TxBuffer2[];
extern uint8_t RxBuffer1[];
extern uint8_t RxBuffer2[];
extern __IO uint8_t TxCounter1;
extern __IO uint8_t TxCounter2;
extern __IO uint8_t RxCounter1;
extern __IO uint8_t RxCounter2;
extern uint8_t NbrOfDataToTransfer1;
extern uint8_t NbrOfDataToTransfer2;
extern uint8_t NbrOfDataToRead1;
extern uint8_t NbrOfDataToRead2;

extern uint8_t KEY_Read_value(void);


void timer1sProcess();
void timer20msProcess();

uint32_t TerminalManage_cnt=0;

extern volatile uint8_t first_power_flag;
extern volatile uint8_t mboot_flag;

extern volatile uint8_t unbind_flag;
uint32_t press_time=0;
uint32_t press_time_flag=0;
volatile uint8_t press_flag=0;
uint8_t press_cnt=0;
/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
 * @brief  This function handles NMI exception.
 */
void NMI_Handler(void)
{
}

/**
 * @brief  This function handles Hard Fault exception.
 */
void HardFault_Handler(void)
{
    /* Go to infinite loop when Hard Fault exception occurs */
    while (1)
    {
		NVIC_SystemReset();  //閲嶅惎
    }
}

/**
 * @brief  This function handles Memory Manage exception.
 */
void MemManage_Handler(void)
{
    /* Go to infinite loop when Memory Manage exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles Bus Fault exception.
 */
void BusFault_Handler(void)
{
    /* Go to infinite loop when Bus Fault exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles Usage Fault exception.
 */
void UsageFault_Handler(void)
{
    /* Go to infinite loop when Usage Fault exception occurs */
    while (1)
    {
    }
}

/**
 * @brief  This function handles SVCall exception.
 */
void SVC_Handler(void)
{
}

/**
 * @brief  This function handles Debug Monitor exception.
 */
void DebugMon_Handler(void)
{
}

/**
 * @brief  This function handles SysTick Handler.
 */
void SysTick_Handler(void)
{
}
/**
 * @brief  This function handles RTC Alarms interrupt request.
 */
void RTCAlarm_IRQHandler(void)
{
    if (RTC_GetITStatus(RTC_INT_ALRA) != RESET)
    {
//        USART_Configuration();
//        RTC_TimeShow();
		NVIC_SystemReset();  //閲嶅惎
        RTC_ClrIntPendingBit(RTC_INT_ALRA);
        EXTI_ClrITPendBit(EXTI_LINE17);
    }
}

void EXTI15_10_IRQHandler(void)  
{
    if (EXTI_GetITStatus(EXTI_LINE10) != RESET)
    {
       /* Clear the Key Button EXTI line pending bit */
       EXTI_ClrITPendBit(EXTI_LINE10);
       /* Turn off LED2 */
       LED_Init();
	   LED_ON;
    }
}

void EXTI9_5_IRQHandler(void)  
{
    if (EXTI_GetITStatus(EXTI_LINE5) != RESET)
    {
       /* Clear the Key Button EXTI line pending bit */
       EXTI_ClrITPendBit(EXTI_LINE5);
       /* Turn off LED2 */
       LED_Init();
	   LED_ON;
    }
}
/******************************************************************************/
/*                 N32G45X Peripherals Interrupt Handlers                     */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_n32g45x.s).                                                 */
/******************************************************************************/

/**
 * @brief  This function handles TIM2 global interrupt request.
 */
int cnt = 0;
int AG_cnt = 0;
const int FRE = 100;
const int AG_FRE = 2;//20ms鐨勮鏁?
int COUNT = 0;
void TIM2_IRQHandler(void)
{
    if (TIM_GetIntStatus(TIM2, TIM_INT_CC1) != RESET)
    {
        TIM_ClrIntPendingBit(TIM2, TIM_INT_CC1);
        capture = TIM_GetCap1(TIM2);

		
				TIM_SetCmp1(TIM2, capture + MY_CCR_Val);

				//1s鏍囪
				cnt++; 
				if(cnt == FRE){
					//1绉?
					timer1sProcess();
//					printf("1 sec\r\n");
				}
				cnt = cnt % FRE;	
				
				//20ms鏍囪
				AG_cnt++;
				if(AG_cnt == AG_FRE)
				{
					//鎵撳嵃adc1 adc3鐨勯噰鏍峰€?
					//printf("get adc1_ch1..%d...%d\r\n",ADC1_ConvertedValue, ADC3_ConvertedValue);
					timer20msProcess();
				}
				AG_cnt = AG_cnt % AG_FRE;
    }

}


/**
 * @brief  This function handles USARTy global interrupt request.
 */
u8 a[20]  = {0};
void USARTy_IRQHandler(void)
{
    if (USART_GetIntStatus(USART1, USART_INT_RXDNE) != RESET)
    {
        /* Read one byte from the receive data register */
        ucUar1tbuf[USART1_RX_LEN++] = USART_ReceiveData(USART1);
        if(USART1_RX_LEN >= BufMAX)
        {
            USART1_RX_LEN = 0;	
        }	 
    }

    #if 0
	uint8_t Res;
	int i,j=0;
    if (USART_GetIntStatus(USART1, USART_INT_RXDNE) != RESET)
    {
        /* Read one byte from the receive data register */
		
  	  	Res =USART_ReceiveData(USART1);   //璇诲彇鎺ユ敹鍒扮殑鏁版嵁锛屼互涓嬪紶鐐?0170519淇敼

		 if((ucUar1InterrFlag&0x8000)==0)
		 {
			if(ucUar1InterrFlag&0x4000)  //鎺ユ敹鍒版暟鎹暱搴?
			{
				ucUar1tbuf[ucUar1InterrFlag&0x00FF]=Res;   //宸茬粡鎸夌収鎸囦护鍗忚鍘绘帀浜嗗崗璁ご閮ㄥ垎锛岀涓€涓瓧鑺傚氨鏄疌MD鍙傛暟
				ucUar1InterrFlag++;
				if((ucUar1InterrFlag&0x00FF)==USART1_RX_LEN)   //鎺ユ敹瀹屾垚
				{
					ucUar1InterrFlag|=0x8000;
//					COM1ProcessCmd();
				}         					
			}
			else if(ucUar1InterrFlag&0x2000)
			{
				USART1_RX_LEN = Res+2;    //鎺ユ敹鍒版暟鎹寘闀垮害
				ucUar1InterrFlag|=0x4000;    
			}
			else if(ucUar1InterrFlag&0x1000)
			{
				if(Res == TypeID)              //鎺ユ敹鍒版爣璇嗙璁惧绫诲瀷
					 ucUar1InterrFlag|=0x2000;    
				else
					 ucUar1InterrFlag=0;//鏍囪瘑绗?閿欒閲嶆柊寮€濮嬫帴鏀?
			}
			else
			{
				if(ucUar2InterrFlag&0x1000)
					goto SOS_UART;
				
				if(Res == CMD_START)
					 ucUar1InterrFlag=0x1000;    //鎺ユ敹鍒板紑濮嬪瓧绗?
				else
					 ucUar1InterrFlag=0;//鏍囪瘑绗﹂敊璇噸鏂板紑濮嬫帴鏀?
			}	
	   }
	   SOS_UART:
		if((ucUar2InterrFlag&0x8000)==0)
		 {
			if(ucUar2InterrFlag&0x4000)  //鎺ユ敹鍒版暟鎹暱搴?
			{
				ucUar2tbuf[ucUar2InterrFlag&0x00FF]=Res;   //宸茬粡鎸夌収鎸囦护鍗忚鍘绘帀浜嗗崗璁ご閮ㄥ垎锛岀涓€涓瓧鑺傚氨鏄疌MD鍙傛暟
				ucUar2InterrFlag++;
				if((ucUar2InterrFlag&0x00FF)==USART2_RX_LEN)   //鎺ユ敹瀹屾垚
				{
					ucUar2InterrFlag|=0x8000;
//					COM1ProcessCmd();
				}       					
			}
			else if(ucUar2InterrFlag&0x2000)
			{
//				if((Res>=7)&&(Res<=9))      //闀垮害閮藉湪7~9涔嬮棿
				if(Res>=7)
				{
					USART2_RX_LEN = Res - 3;    //鎺ユ敹鍒版暟鎹寘闀垮害
					ucUar2InterrFlag|=0x4000;    
				}
				else
					ucUar2InterrFlag=0;//鏍囪瘑绗?閿欒閲嶆柊寮€濮嬫帴鏀?
			}
			else if(ucUar2InterrFlag&0x1000)
			{
				if(Res == 0xba)              //鎺ユ敹鍒版爣璇嗙璁惧绫诲瀷
					 ucUar2InterrFlag|=0x2000;    
				else
					 ucUar2InterrFlag=0;//鏍囪瘑绗?閿欒閲嶆柊寮€濮嬫帴鏀?
			}
			else
			{
				if(Res == 0xab)
					 ucUar2InterrFlag=0x1000;    //鎺ユ敹鍒板紑濮嬪瓧绗?
				else
					 ucUar2InterrFlag=0;//鏍囪瘑绗﹂敊璇噸鏂板紑濮嬫帴鏀?
			}	
	   }
    }
    #endif
}

/**
 * @brief  This function handles USARTz global interrupt request.
 */
void USART3_IRQHandler(void)
{
	uint8_t Res;
    if (USART_GetIntStatus(USART_4G, USART_INT_RXDNE) != RESET)
    {
        /* Read one byte from the receive data register */
        Res = USART_ReceiveData(USART_4G);

		//printf("u3 r %d %d %c \r\n",ReceEnd3,Res,Res);
		ucUar3InterrFlag = 1;
	    ucUar3tbuf[ReceEnd3++] = Res;
		if(ReceEnd3 >= BufMAX)
		{
			ReceEnd3 = 0;		
		}
    }

}

uint8_t key_value = 0;
uint8_t key_value_last = 0;
uint8_t first_key_value = 1;
void timer20msProcess(){
	LedFlash++; 									//鎺у埗鐏殑闂儊
	gQuickFlashTimer++; 							//init Led闂儊
	SleepDataBuffer_SendTime++;
	
    if(Flag_init == MAC_INIT_OK)
    {
        if(gQuickFlashTimer>5)
        {
            gQuickFlashTimer=0;
            Toggle_LED;
        }
    }
    
    
    if((Flag_init == WIRELESS_INIT_OK)&&(AngelPace != SendSleepDataR))
    {
        LED_ON;
    }
    if((AngelPace == SendSleepDataR)&&(Flag_LinkStatus == START_GPRS_LINKOK))
    {
        if (1 == unbind_flag) {
            if(gQuickFlashTimer>1)
            {
                gQuickFlashTimer=0;
                Toggle_LED;
            }
        } else {
            LED_OFF;
        }
      
    }

	if(Flag_PowerOn == 0)
	 {
		 OnbedStatus_CountTimer++;
		 Algorithm_TIMER_FLAG = 1;//绠楁硶璁＄畻鏍囪
	 }
	 
	//  if(unbind_flag==1)
     if(1)
	 {
        #if TOUCH_KEY
        if (first_key_value) {
            first_key_value = 0;
            key_value = KEY_Read_value();
            key_value_last = key_value;
        } else {
            key_value = KEY_Read_value();
            if (key_value != key_value_last) {
                key_value_last = key_value;
                log_trace("key value:%d press_cnt:%d press_time:%d \r\n", KEY_Read_value(), press_cnt, press_time);
                if(press_time >= 200 && press_time <= 2000) {
                    press_time = 0;
                    press_cnt ++;
                    if (4 <= press_cnt) {
                        unbind_flag = 1;
                    }
                } else {
                    press_time = 0;
                    press_cnt = 0;
                    press_cnt ++;
                }
            } else {
                press_time += 20;
            }
        }
        #endif
        

        
        
		//  press_time+=20;
		//  //if(press_time>=800&&press_time<=2000)  //鎸夊帇鏃堕棿鍦?00ms鈥斺€?000ms鍐呭垽鏂负瑙ｇ粦鎸夊帇
        //  if(press_time >= 500 && press_time <= 2000)
		//  {
        //     press_time = 0;
        //     log_trace("key value:%d \r\n", KEY_Read_value());
		// 	 //press_flag=1;
		//  } else{
        //     press_time=0;
        //     press_flag=0;
        //     press_cnt = 0;
        //  }
	 } else{
		 press_time=0;
		 press_flag=0;
	 }

}

/**
 * 1s璋冪敤涓€娆?
*/
void timer1sProcess(){
//			IWDG_Feed();test code!!!
	//-----------------------------10min鏈仈缃戦渶瑕侀噸鍚?------------------------
	if(PowerBatteryFlag == 0)  //鎻掔數鏃朵笉鑳介暱鏃堕棿鏈仈缃戯紝鍚﹀垯閲嶅惎
		Heartbeat++;
	else
		Heartbeat = 0;
	
	//涓€澶╀笂鎶ヤ竴娆＄粓绔鐞嗘暟鎹?
	TerminalManage_cnt++;
	if(TerminalManage_cnt>=86400)//24H
    //if(TerminalManage_cnt>=(60*60))//1H
	{
		log_trace("24h ontime dm report\r\n");
		TerminalManage_cnt=0;
        mboot_flag = 1;
	}
	if(Heartbeat>(601+310))  //15min
	{
		Heartbeat=0;
		if(Flag_COMDebug == 1)
			printf("Heartbeat over time, NVIC_SystemReset!\r\n");
		first_power_flag=0;
        SaveSoftRebootFlagToFlash();
		NVIC_SystemReset();  //閲嶅惎
	}
	
	//-----------------------------24灏忔椂鍚戠Щ鍔ㄤ笂鎶ヤ竴娆″績璺?------------------------
	if(AngelPace == SendSleepDataR)
		DM_Heart_Time++; 
	
	//-----------------------------浠庢満瓒呮椂璁℃暟-------------------------
	Slave_Manage_Time();
	
	//-----------------------------SOS鍥炲簲瓒呮椂璁℃暟-------------------------
	SOS_Connect_Time++;	
	if(SOS_Connect_Time >= 122)
	{
		SOS_Connect_Time = 0;
		SOSConnectFlag = 0; 
	}
	//-----------------------------SOS閬垮厤閲嶅鎶ヨ璁℃暟-------------------------
	SOS_Report_Time++;
	if(SOS_Report_Time >= 3)
		SOS_Report_Time = 4;
	//-----------------------------鐢垫睜渚涚數鎯呭喌涓?5min鍙戦€佷竴娆℃暟鎹?------------------------
	if(PowerBatteryFlag == 1)
		Battery_CntTime++;
	else
		Battery_CntTime = 0;
	if(Battery_CntTime >= 850)  //杩涜4G妯＄粍鐨勫紑鏈?
	{
		LuatPowerOnWay = 1;//15min 鍒?
		Flag_PowerOn = 1;
		Battery_CntTime = 0;
		Flag_init = MAC_INIT_OK;//妯＄粍寮€鏈?
		Flag_Init_Step = 1;
	}
	
	//-----------------------------5min鏍℃椂涓€娆?------------------------
	Adj_Time++;
	if( Adj_Time >= 300)
	{
		Adj_Time = 0;
		Flag_TimeAdj = 1;
	}	
	
	token1time++;	//鑾峰彇token1瓒呮椂璁℃暟
	mytime++;
	sleeptime++;	//鐫＄湢鏁版嵁鍙戦€佸畬姣曡秴鏃惰鏁?
	mytime2++;
	AUTOTime++; 	//wifi鏄惁鑷姩杩炴帴
	AT_CGATT_Count++;
	YZTime++;		//楠岃瘉瓒呮椂璁℃暟
	ATCGATT_Count++;
	ADDTime();//鍚屾鏈嶅姟鍣ㄧ殑鏃堕棿 
	if(Flag_Init_Step==10)
		 Init_pauseTime++;
	else
		GPRS_ConnetTime++;

	
	if(Flag_CanSendStatistData == 2)
	{
		 CanSendStatistTime++;
		 if(CanSendStatistTime == 10)
		 {
			 CanSendStatistTime = 0;
			 Flag_CanSendStatistData = 1;
		 }
	}
	 if(Flag_ADC_ADJ == 1)
	 {
		  ADC_AdjTime++;
	 }
	 if(flag_Gprs_Reconn==0)
		 GPRS_Wait_Reconn++;
	 
	//  if(unbind_flag==1)
	//  {
	// 	 press_time_flag++;
	//  }else{
	// 	 press_time_flag=0;
	//  }
		 
	//  if(press_time_flag>3)
	//  {
	// 	press_cnt=0; 
	//  }
	 
	//  if(press_flag==1)
	//  {
	// 	 press_cnt++;
	//  }
//	 else{
//		 press_cnt=0;
//	 }

}


/**
 * @}
 */
