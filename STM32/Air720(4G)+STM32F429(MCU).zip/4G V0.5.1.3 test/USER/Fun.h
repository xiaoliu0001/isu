/******************************************************************************
 * @file     Fun.h
 * @brief   ���ܺ���
 * @version  
 * @date     2017
 * @note
 * Copyright (C)  2017 ���
 *
 * @par       
*******************************************************************************/
#ifndef __FUN_H_
#define __FUN_H_

#include "includes.h"

extern char isonbed;

void DebugUart_Order_Dispose(void);
void BlueBooth_Order_Dispose(void);
void  LTEUART_Receive_Order_Analys(void);
void Server_Order_Dispose(void);
void UART_Send_Order(USART_TypeDef* USARTx,uint8_t *buf,uint8_t len);
void RePowerOn_LTE(void);
char LinkServerVerifyStep(uint8_t step);	
void ConnectFrontServer(void);
void FrontServerLinkStatus(void);
void GetBackServerIP(void);
void AnalysisBackServerIP(void);
void ConnectBackServer(void);
void BackServerLinkStatus(void);
void GetBackServerToken2(void);
void AnalysisBackServerToken2(void);
void SendBackServerVerify(void);
void GetBackServerVerifyResult(void);
void GetServerTime(void);
void Req_Users_Binding(void);

void SendReConnectMode(uint8_t st,int lac,int cid);
char SendDataBegin(void);
void HexToStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen);
void HexToLowerStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen);
int Comm_bcd_to_bin(uint8_t bcd);
unsigned char GetDataHead(unsigned char* datas,unsigned char len);
void SendRealTimeHRData(void);
void SendRealTimeRRData(void);	
void SendNoHRData(uint8_t status);
void SendNoRRData(uint8_t status);
void RenewRealTime(uint8_t *time);
void SendDeviceMacToUart(USART_TypeDef* USARTx);
void SendDeviceVerInfoToUart(USART_TypeDef* USARTx,char *str);
void COMRetuenOneByte(USART_TypeDef* USARTx,uint8_t cmd,uint8_t data);
void SystemReset_CheckStatus(void);
int CalculateAverageHrRrData(int *dat,uint8_t len);
void SendRspStopStatus(void);

char ReadWiFiNameFromFlash(void);
char SaveWiFiNameToFlash(void);
char ReadToken2FromFlash(void);
char SaveToken2ToFlash(void);
char ReadIP2FromFlash(void);
char SaveIP2ToFlash(void);
char ReadMACFromFlash(void);
char SaveMACToFlash(void);	
void Send_CARD_IMSI(uint8_t *buf,uint8_t len);
void  SaveStartNewStatistStatusData(void);
void AddStatistStatusData(uint8_t *buf,uint8_t len);
void  EndStatistStatusData(void);
char ReadSleepDataPosIndexFromFlash(void);
char SaveSleepDataPosIndexToFlash(uint16_t savenum,uint16_t sendnum);
char SaveSleepDataToFlash(void);
char SendFlashSavedSleepDataToServer(uint16_t num);
uint16_t SendHeartWaveToserver(uint8_t *HRWData);
uint16_t SendRespWaveToserver(uint8_t *RRWData);
void SendPeopleTurnData(uint8_t *timebuf);
void AdddataToavgFilter(uint16_t x);
void RenewRTCTime(uint8_t *time);
char SaveMACTo_InsideFlash(void);
char ReadMACFrom_InsideFlash(void);
void SendWaveDataToserver(void);
void SendVerToServer(void);	
void RetuenCammandToServer(uint8_t *cmd,uint8_t len);

void SendPressSenserStatus(uint8_t status);
float countHeartScore(int x);
uint16_t avgFilter(uint16_t x);
void Send_CurrentLinkStatus(void);
void SendSampelWaveDataToserver(float *hrv,uint16_t hrlen,float *rrv,uint16_t rrlen);	
void SendPressSenserVol(uint16_t vol);
//void judgePeople(float heartSignal);
uint16_t SendSampleRespWaveToserver(uint8_t *RRWData,float *rrv,uint8_t SampInv);

void CalculateHrRrData(void);
//void CalculateBreatheRate(void);
//void CalculateHeartRate(void);
void SetLedStatus(uint8_t led_index);
void Check_ExtSensor_PeopleOnBed(void);

void ArithmeticPara_Init(void);	
void ArithmeticPara_DeInit(void);
void SendHrRrDataToServer(void);

//float avgRespFilter(float x) ;
void SendApnoeaStatus(void);
void HRRRWave_ChangeGainJudge(float wave1,float wave2);

void SendSpO2DataToserver(uint8_t *data,uint8_t len);
void Add1SendSpO2Data(uint8_t *buff,uint8_t data);
void SendOXHrDataToServer(void);
void SendOXPulseWaveToServer(void);

void OXY_Data_Dispose(void);
#endif

