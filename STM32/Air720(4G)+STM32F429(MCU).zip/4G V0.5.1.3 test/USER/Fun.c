/******************************************************************************
 * @file     Fun.c
 * @brief   ���ܺ���
 * @version  
 * @date     2018
 * @note
 * Copyright (C)  2018 ���
 *
 * @par       
*******************************************************************************/

#include "Fun.h"
#include  <stdlib.h>
#include "math.h"
#include <string.h>



#define   HR_AVGLEN  14   //���ʾ�ֵ�˲�����



//uint8_t  *ip;
//uint8_t  *port;

static int countFLen = 0;
static uint16_t  avgf[HR_AVGLEN]={0} ;
static int avgFLen = 0;

#define AVG_INIT_LEN   12 
static float avgResps[AVG_INIT_LEN]={0};
static int avgRespLen = 0;
char isonbed =0 ;
static uint16_t HrWaveData_Len = 0;
static uint16_t RrWaveData_Len = 0;
static uint8_t *HrWaveData;
static uint8_t *RrWaveData;

uint8_t CheckCount_ExtSensor = 0;    //�ⲿ������������

uint32_t ADCVol_ExtSensor = 0;
uint16_t ExtSensor_PeopleOFFBed_Time = 0;

static int flagDownSampleResp = 0;
static int respshiftedPoint = 0;
static int signal_count = 0;
extern uint8_t Pulse_Wave_Data_Num;
extern uint8_t OX_Pulse_Wave_Data[256];
// float RwavPiont[300] ;  //��������
// int RwavLen;
//extern uint8_t OXHrData_Array[50];//Ѫ��������������
//extern uint8_t OXHrDataNum_Count;//Ѫ���������ݸ���������

void Send_Softver2uart(USART_TypeDef* USARTx);
void Send_Hardver2uart(USART_TypeDef* USARTx);
void Send_Mac2uart(USART_TypeDef* USARTx);
void Send_Heart_breath2uart(USART_TypeDef* USARTx);
/****************************************************************************
*	�� �� ��: DebugUart_Order_Dispose
*	����˵��: ���Դ���ָ���
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
char g_dataname[50];
void  DebugUart_Order_Dispose(void)
{
	uint8_t  i ,j;
	uint8_t order_data_len = 0;
    uint8_t order_data[UARTBUF_MAX_LEN];
	uint8_t dealorder = 0;
	uint8_t Res = 0;
    uint8_t send_data[10];
	uint8_t len;
	char SoftVer[100];
	OS_ERR   err;
	char *   p_mem_blk;
	

	for(i=0;i<DebugUART_RX_LEN;i++)
	{
		if(DebugUART_RX_BUFFER[i] == CMD_START)
		{		
			order_data_len = DebugUART_RX_BUFFER[i+2]+5;
//			printf("����ָ���:%d %x %x\r\n",order_data_len,DebugUART_RX_BUFFER[i+order_data_len-2],DebugUART_RX_BUFFER[i+order_data_len-1]);
			if((DebugUART_RX_BUFFER[i+order_data_len-1] == CMD_LF2 )&&(DebugUART_RX_BUFFER[i+order_data_len-2] == CMD_LF1 ))  //a complete command
			{
				for(j=0;j<order_data_len;j++)
				{
					order_data[j] = DebugUART_RX_BUFFER[i+j];
				}
				if(DebugUART_RX_LEN == (i+order_data_len))
				{
					memset(DebugUART_RX_BUFFER,0,UARTBUF_MAX_LEN);
					DebugUART_RX_LEN = 0;
				}
				else
				{
					memset(DebugUART_RX_BUFFER,0,i+order_data_len);
					for(j=0;j<DebugUART_RX_LEN-order_data_len-i;j++)
					{
						DebugUART_RX_BUFFER[j] = DebugUART_RX_BUFFER[i+order_data_len+j];
						DebugUART_RX_BUFFER[i+order_data_len+j] = 0;
					}
					DebugUART_RX_LEN = DebugUART_RX_LEN - order_data_len - i;
				}
				dealorder=1;  //parse the order
			}
            
			
           if(dealorder!=1)
           {
                order_data_len = DebugUART_RX_BUFFER[i+1]+4;
              // printf("�������ݳ���%d\r\n",order_data_len);
    //			printf("����ָ���:%d %x %x\r\n",order_data_len,DebugUART_RX_BUFFER[i+order_data_len-2],DebugUART_RX_BUFFER[i+order_data_len-1]);
                if((DebugUART_RX_BUFFER[i+order_data_len-1] == CMD_LF2 )&&(DebugUART_RX_BUFFER[i+order_data_len-2] == CMD_LF1 ))  //a complete command
                {
                    for(j=0;j<order_data_len;j++)
                    {
                        order_data[j] = DebugUART_RX_BUFFER[i+j];
                    }
                    if(DebugUART_RX_LEN == (i+order_data_len))
                    {
                        memset(DebugUART_RX_BUFFER,0,UARTBUF_MAX_LEN);
                        DebugUART_RX_LEN = 0;
                    }
                    else
                    {
                        memset(DebugUART_RX_BUFFER,0,i+order_data_len);
                        for(j=0;j<DebugUART_RX_LEN-order_data_len-i;j++)
                        {
                            DebugUART_RX_BUFFER[j] = DebugUART_RX_BUFFER[i+order_data_len+j];
                            DebugUART_RX_BUFFER[i+order_data_len+j] = 0;
                        }
                        DebugUART_RX_LEN = DebugUART_RX_LEN - order_data_len - i;
                    }
                    dealorder=2;  //parse the order
                }
                else
                {
                   // printf("����У�����\r\n");
                    
                }
            }
            if((dealorder!=1)&&(dealorder!=2))  //not a complete command
			{
				if(i>0)
				{
					memset(DebugUART_RX_BUFFER,0,i);
					for(j=0;j<DebugUART_RX_LEN-i;j++)
					{
						DebugUART_RX_BUFFER[j] = DebugUART_RX_BUFFER[i+j];
						DebugUART_RX_BUFFER[i+j] = 0;
					}
					DebugUART_RX_LEN = DebugUART_RX_LEN  - i;
				}
			}
		}	
		
	}
	if(dealorder == 1)
	{	
		dealorder = 0;
		switch( order_data[3])
		{

			 case CMD_DEBUG:     //��ӡ������־
				 if(Flag_COMDebug == 0 )
				 {				 
						Flag_COMDebug = 1;										   								
				
				 }
				 else
				 {
						Flag_COMDebug = 0;	
				 }					 
			 break;
				 
			 case CMD_RECORDER:   //¼��
				 if(order_data[4] == 0x01)   
				 {					 
					 #ifdef RECORDERFILE_SAVE
					 /* ���ڴ���� mem ��ȡһ���ڴ�� */
					p_mem_blk = OSMemGet((OS_MEM      *)&mem,
									   (OS_ERR      *)&err);
					
					*p_mem_blk = RECORDER_ON;
					/* ����������Ϣ������ AppTaskRecorderTCB */
					OSTaskQPost ((OS_TCB      *)&AppTaskRecorderTCB,      //Ŀ������Ŀ��ƿ�
								 (void        *)p_mem_blk ,             //��Ϣ���ݵ��׵�ַ
								 (OS_MSG_SIZE  )1,                     //��Ϣ����
								 (OS_OPT       )OS_OPT_POST_FIFO,      //������������Ϣ���е���ڶ�
								 (OS_ERR      *)&err);                 //���ش�������
					#endif
				 }
				 else
				 {				
					 #ifdef RECORDERFILE_SAVE
					 /* ���ڴ���� mem ��ȡһ���ڴ�� */
					p_mem_blk = OSMemGet((OS_MEM      *)&mem,
									   (OS_ERR      *)&err);
					
					*p_mem_blk = RECORDER_OFF;
					/* ����������Ϣ������ AppTaskRecorderTCB */
					OSTaskQPost ((OS_TCB      *)&AppTaskRecorderTCB,      //Ŀ������Ŀ��ƿ�
								 (void        *)p_mem_blk ,             //��Ϣ���ݵ��׵�ַ
								 (OS_MSG_SIZE  )1,                     //��Ϣ����
								 (OS_OPT       )OS_OPT_POST_FIFO,      //������������Ϣ���е���ڶ�
								 (OS_ERR      *)&err);                 //���ش�������
					#endif
				 }
			 break;
			 
			 case CMD_SETMAC:      //�����豸MAC
				MAC_Len = order_data_len-7;
				for(i=0;i<MAC_Len;i++)
				{
					MAC_ID[i] = order_data[4+i];
				}
				MAC_ID[MAC_Len] = 0x00;

				len=strlen(MANUFACTURER_NAME);
				send_data[0] = CMD_SETBTNAME;
				for(i=0;i<len;i++)
				{
					send_data[i+1] = MANUFACTURER_NAME[i];
				}
				for(i=0; i<4;i++)
				{
					send_data[len+1+i] = MAC_ID[MAC_Len-4+i];
				}							
				//UART_Send_Order(BLE_UART,send_data,len+5);
				
				Res = SaveMACToFlash();
                
				if(Res == 0x00)
				{
					COMRetuenOneByte(DEBUG_UART,CMD_SETMAC,0x00);
				}
				else   
				 {					 
					 Flag_ErrInfo &= ~ERROR_N0_MAC;
					 COMRetuenOneByte(DEBUG_UART,CMD_SETMAC,0x01);
				 }
				

			 break;			 	 
				 
			 case CMD_READMAC:   //��ȡ�豸MAC
				SendDeviceMacToUart(DEBUG_UART);
						
			 break;
			 
			 case CMD_READVER:  //��ȡ�豸�汾��
//				 sprintf(SoftVer,"PCB:%s\r\nHardVer:V%d.%d.%d\r\nSoftVer:V%d.%d.%d\r\nSoft release time:%s\r\n",HARDWARE_INFO,HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER,
//								SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER,RELEASE_TIME);
				
             sprintf(SoftVer,"PCB:%s\r\nHardVer:V%d.%d.%d\r\nSoftVer:V%d.%d.%d\r\nSoft release time:%s\r\nMAC:%s\r\nIMEI:%s\r\nICCID:%s\r\n",HARDWARE_INFO,HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER,
								SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER,RELEASE_TIME,MAC_ID,IMEI_Save,ICCID_Save );
             SendDeviceVerInfoToUart(DEBUG_UART,SoftVer);
			 break;
			 
			case CMD_DELFLASHDATA:          //ɾ��flash����
				if(order_data[4] == CMD_DELSAVENUM )
				{
                    W25QXX_Erase_Chip();
                    printf("sflash ������ȫ�����\r\n");

				}
				if(order_data[4] == CMD_DELSERVERIP )
				{
					Flag_InitStatus = WIRELESS_INIT;  //���Խ�������ģ���ʼ��
					Flag_LTEInitStep = LTE_INIT_STEP1;
					LTE_InitTime = 0;
					LinkStep = GETIP2;
					Flag_PowerOn = 1;
					W25QXX_Erase_Sector(FLASH_ServerInfoAddress);
					W25QXX_Erase_Sector(FLASH_VerifyInfoAddress);
					W25QXX_Erase_Sector(FLASH_SaveSleepDataIndexAddress);
					
				}
			break;

			case CMD_REQMOUDLE_INFO:   //��ѯ�豸״̬
				if(order_data[4] == MOUDLE_STATUS_RUNTIME )   //�豸������ʱ��
				{					
					/* ���������ź��������� AppTaskManager */
						OSTaskSemPost((OS_TCB  *)&AppTaskManagerTCB,   //Ŀ������
									(OS_OPT   )OS_OPT_POST_NONE, //ûѡ��Ҫ��
									(OS_ERR  *)&err);            //���ش�������	
				}
//				if(order_data[4] == MOUDLE_STATUS_ROUTERSSID )   //LTEģ�����ӵ�·��������
//				{
//					if(LTE_Req_STASSID()==LTE_SUCCESS)
//					{							 

//						printf("Connected the LTE:%s\r\n",RouterName_InLTE);

//					}					
//				}
				if(order_data[4] == MOUDLE_STATUS_CONNECTIP )   //LTEģ�����ӵķ�����
				{
					printf("IP2:%s,Port2:%s",IP2,Port2);
				}

			break;
				
 #ifdef ADCFILE_OUTPUT	 				
			case CMD_DirName:         //��ӡ����Ŀ¼�������ļ�������
			 scan_dir("0:\\Data");
			 break;			
          
			case CMD_SDCardSpace:     //���SD����ʣ��ռ��С
				SDcardFileInfo(1);
				break;
			
			case CMD_FileName:        //��ӡ���ļ������ļ�����
				for(i=4;i<7;i++)
					order_data[i] = Comm_bcd_to_bin(order_data[i]);
				sprintf(g_dataname,"0:\\%sData\\%s20%02d%02d%02d","\\","\\",order_data[4],order_data[5],order_data[6]);
				printf("\r\n·�� %s �µ��ļ��б����£�\r\n",g_dataname);
				scan_files(g_dataname,Scan_Files_Num(g_dataname));
//				p_mem_blk = OSMemGet((OS_MEM      *)&mem,
//									           (OS_ERR      *)&err);
//				*p_mem_blk = TRAVER_DATAFILE;
//				/* ����������Ϣ������ AppTaskRecorderTCB */
//				OSTaskQPost ((OS_TCB      *)&AppTaskCreatNewFileTCB, //Ŀ������Ŀ��ƿ�
//										 (void        *)p_mem_blk ,              //��Ϣ���ݵ��׵�ַ
//										 (OS_MSG_SIZE  )1,                       //��Ϣ����
//										 (OS_OPT       )OS_OPT_POST_FIFO,      	 //������������Ϣ���е���ڶ�
//										 (OS_ERR      *)&err);                 	 //���ش�������	
				break;
			
			case CMD_OutputFile:      //����ļ�����
				for(i=4;i<7;i++)
					order_data[i] = Comm_bcd_to_bin(order_data[i]);
				sprintf(g_dataname,"%s\\%s%02d%02d%02d%s",g_dataname,"\\",order_data[4],order_data[5],order_data[6],".txt");
//				printf("·����%s\r\n",g_dataname);
				ReadHrRrFile(g_dataname);											 
//				p_mem_blk = OSMemGet((OS_MEM      *)&mem,
//									 (OS_ERR      *)&err);
//				*p_mem_blk = PRINTF_DATAFILE;
//				/* ����������Ϣ������ AppTaskRecorderTCB */
//				OSTaskQPost ((OS_TCB      *)&AppTaskCreatNewFileTCB,      //Ŀ������Ŀ��ƿ�
//							 (void        *)p_mem_blk ,             //��Ϣ���ݵ��׵�ַ
//							 (OS_MSG_SIZE  )1,                     //��Ϣ����
//							 (OS_OPT       )OS_OPT_POST_FIFO,      //������������Ϣ���е���ڶ�
//							 (OS_ERR      *)&err);                 //���ش�������				
				break;
#endif			
			default :
				break;		 			 
		}
	}
    if(dealorder == 2)
	{	
		dealorder = 0;
		switch( order_data[2])
		{
            case 0x01:
                //printf("-------------�����汾 \r\n");
                Send_Softver2uart(DEBUG_UART);
            break;
            case 0x02:
                //printf("-------------Ӳ���汾 \r\n");
                Send_Hardver2uart(DEBUG_UART);
            break;
            case 0x03:
                //printf("-------------mac\r\n");
                Send_Mac2uart(DEBUG_UART);
            break;
            case 0x10:
               // printf("-------------���ݿ��� \r\n");
                if(order_data[3]==1)
                    Sendswitch=1;
                else
                    Sendswitch=0;
            break;
                default :
				 
			 break;
        }
    }
	
}
/****************************************************************************
*	�� �� ��: BlueBooth_Order_Dispose
*	����˵��: ����ָ�� ����
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void  BlueBooth_Order_Dispose(void)
{
	uint8_t  i ,j;
	uint8_t order_data_len = 0;
    uint8_t order_data[UARTBUF_MAX_LEN];
	uint8_t dealorder = 0;
	uint8_t Res = 0;
    uint8_t send_data[10];
	OS_ERR      err;
	
	for(i=0;i<BLEUART_RX_LEN;i++)
	{
		if(BLEUART_RX_BUFFER[i] == CMD_START)
		{			
//			for(j=0;j<BLEUART_RX_LEN;j++)
//			{
//				printf("%02x ",BLEUART_RX_BUFFER[j]);
//			}
			order_data_len = BLEUART_RX_BUFFER[i+2]+5;
			if((BLEUART_RX_BUFFER[i+order_data_len-1] == CMD_LF2 )&&(BLEUART_RX_BUFFER[i+order_data_len-2] == CMD_LF1 ))  //a complete command
			{
				for(j=0;j<order_data_len;j++)
				{
					order_data[j] = BLEUART_RX_BUFFER[i+j];
				}
				if(BLEUART_RX_LEN == (i+order_data_len))
				{
					memset(BLEUART_RX_BUFFER,0,UARTBUF_MAX_LEN);
					BLEUART_RX_LEN = 0;
				}
				else
				{
					memset(BLEUART_RX_BUFFER,0,i+order_data_len);
					for(j=0;j<BLEUART_RX_LEN-order_data_len-i;j++)
					{
						BLEUART_RX_BUFFER[j] = BLEUART_RX_BUFFER[i+order_data_len+j];
						BLEUART_RX_BUFFER[i+order_data_len+j] = 0;
					}
					BLEUART_RX_LEN = BLEUART_RX_LEN - order_data_len - i;
				}
				dealorder=1;  //parse the order
			}
			else  //not a complete command
			{
				if(i>0)
				{
					memset(BLEUART_RX_BUFFER,0,i);
					for(j=0;j<BLEUART_RX_LEN-i;j++)
					{
						BLEUART_RX_BUFFER[j] = BLEUART_RX_BUFFER[i+j];
						BLEUART_RX_BUFFER[i+j] = 0;
					}
					BLEUART_RX_LEN = BLEUART_RX_LEN  - i;
				}
			}
			
		}
	}			
	if(dealorder == 1)
	{
//		for(j=0;j<order_data_len;j++)
//		{
//			printf("%02x ",order_data[j]);
//		}
		dealorder = 0;
		switch( order_data[3])
		{
			 case CMD_BLUETOOTH_LINKSTATUS:   //��������״̬
				 if(order_data[4] == 0x02)   //����������
				 {
					 if(Flag_COMDebug == 1)
					 {
						 printf("����������!\r\n");
					 }
					 Flag_BT_Linkstatus = BT_CONNECTED;
					
				 }
				if(order_data[4] == 0x01)   //����δ����
				 {
					 if(Flag_COMDebug == 1)
					 {
						 printf("����δ����!\r\n");
					 }
					 Flag_BT_Linkstatus = BT_NoCONNECT;
					
				 }
			 
			 break;
				 
			case CMD_REQMODULESTATUS:
			  if(order_data[4] == 0x01)
			 {
					Send_CurrentLinkStatus();	
					Flag_SendLinkStatus = 1;
			 }
			 else
			 {
				  Flag_SendLinkStatus = 0;
			 }
		 break;
			 
			 case CMD_SETBTNAME:
				 if(order_data[4] == 0x01)   //�����������óɹ�
				 {					 
					SaveSleepDataPosIndexToFlash(0,0);
					Res = SaveMACToFlash();
					if(Res == 0x00)
					{
						COMRetuenOneByte(DEBUG_UART,CMD_SETMAC,0x00);
					}
					else   
					 {					 
						 Flag_ErrInfo &= ~ERROR_N0_MAC;
						 COMRetuenOneByte(DEBUG_UART,CMD_SETMAC,0x01);
						 Flag_InitStatus = WIRELESS_INIT;  //���Խ�������ģ���ʼ��
						 Flag_LTEInitStep = LTE_INIT_STEP1;
						 LTE_InitTime = 0;
						 Flag_ErrInfo |=ERROR_NO_TOKEN2;	
					 }
				 }
			 			 
			 default :
			 	 
			 break;
		}
	}
	
}

/****************************************************************************
*	�� �� ��: UART_Receive_Order_Analys
*	����˵��: ģ�鴮��ָ�������
*	��    �Σ���
*	�� �� ֵ: ����-1��ʾ��Ҫ��������������0����
*****************************************************************************/ 
void  LTEUART_Receive_Order_Analys(void)
{
	char printfstr[50];
	char *pstr = NULL;
	char *pstr1 = NULL;	
	char err=0;
	uint8_t i = 0;

	if(strstr(LTEUART_RX_BUFFER,"+QIURC: \"closed\""))  //���������ӶϿ�
	{
		if(Flag_COMDebug == 1)
			printf("Network disconnect!\r\n"); 
		Flag_StepStatus = STEP_RECEIVE;
		LinkStep = CONNECTIP2;	
		Flag_InitStatus = LINK_SERVER	;/*chongqi1*/	 									 
		Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����											
		LinkIPCount = 0;
		Link_Time = 0;
		LTE_ConnetTime = 0;
		if(Flag_Updata == 1)
		{
			Flag_Updata = 0;

			SimpleDataNum1 = 0;
			SimpleDataNum2 = 0;

			CalculateCount = 0;
		}
		if(Flag_Updata == 0)
			SaveStartNewStatistStatusData();   //ͳ�ƿ�ʼ
		     
		ClearUSARTBUF(LTE_UART);
		
	}
	if(strstr(LTEUART_RX_BUFFER,"+QIURC: \"recv\""))  //�յ�������ָ��
	{

		Server_Order_Dispose();
	}
	
}
/****************************************************************************
*	�� �� ��:Server_Order_Dispose
*	����˵��: ������ָ�������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void  Server_Order_Dispose(void)
{
	OS_ERR      err;
	uint8_t receivetime[6];
    uint16_t  i ,j;
	uint16_t order_data_len = 0;
    uint8_t order_data[UARTBUF_MAX_LEN*6];
	uint8_t dealorder = 0;
	uint16_t num = 0;
	uint8_t jiaoyan = 0;
	uint8_t senddata[10];
	
	
	for(i=0;i<LTEUART_RX_LEN;i++)
	{
		if(LTEUART_RX_BUFFER[i] == CMD_START)
		{
//			for(j=0;j<LTEUART_RX_LEN;j++)
//			{
//				printf("%02x ",LTEUART_RX_BUFFER[j]);
//			}
			order_data_len = LTEUART_RX_BUFFER[i+2]*256+LTEUART_RX_BUFFER[i+3]+6;		
			if((LTEUART_RX_BUFFER[i+order_data_len-1] == CMD_LF2 )&&(LTEUART_RX_BUFFER[i+order_data_len-2] == CMD_LF1 ))  //a complete command
			{
				for(j=0;j<order_data_len;j++)
				{
					order_data[j] = LTEUART_RX_BUFFER[i+j];
				}
				if(LTEUART_RX_LEN == (i+order_data_len))
				{
					memset(LTEUART_RX_BUFFER,0,UARTBUF_MAX_LEN*6);
					LTEUART_RX_LEN = 0;
				}
				else
				{
					memset(LTEUART_RX_BUFFER,0,i+order_data_len);
					for(j=0;j<LTEUART_RX_LEN-order_data_len-i;j++)
					{
						LTEUART_RX_BUFFER[j] = LTEUART_RX_BUFFER[i+order_data_len+j];
						LTEUART_RX_BUFFER[i+order_data_len+j] = 0;
					}
					LTEUART_RX_LEN = LTEUART_RX_LEN - order_data_len - i;
				}
				dealorder=1;  //parse the order
				LTEUART_Data_Receive_Time = 0;
                	if(dealorder == 1)
	{

		//---------------����Ϊ�Է��������ݵĽ���--------------------------------------------------------		 		 	 
		if((order_data[1]== TypeID)&&(order_data[4]==SERVER_ABNORMAL_MESSAGE))  //���������ش���δ�����û�
		{
			if(order_data[6]== BINDING_USERS_NO)
			{
				Flag_Binding_Users = BINDING_USERS_NO;
				if(Flag_No_Binding_Users_Time == 0)  //δ�����û���ʱ��־
				{
					Flag_No_Binding_Users_Time = 1;
					No_Binding_Users_Time = 0;						 
				}
				if(Flag_COMDebug == 1)
					printf("The device does not binding to users!\r\n");   			 
			}
			if(order_data[6]== BINDING_USERS_YES)
			{
				Flag_Binding_Users = BINDING_USERS_YES;
				Flag_No_Binding_Users_Time = 0;			  
				if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)
					SleepData_SendTime = SLEEPDATA_SENDTIME_3S;
				if(Flag_COMDebug == 1)
					printf("The device is  binding to users!\r\n");
			} 
		}
		/*********************************���������ظ��µ�ʱ��****************************************/
		if((order_data[1]==TypeID)&&(order_data[4]==REQ_SERVER_TIME))
		{				 
			for(i=0;i<6;i++)  //��ȡ������ʱ��
			{
				receivetime[i] = (order_data[5+i*2]&0x7F-0x30)*10+(order_data[6+i*2]&0x7F-0x30); //��ASCII�ַ��������ֽڵ�ʱ��ת��Ϊ1���ֽڵ�ʱ��		 
			}
			if((receivetime[0]>17)&&(receivetime[0]<99)&&(receivetime[1]>0)&&(receivetime[1]<13)&&(receivetime[2]>0)&&(receivetime[2]<32))
			{
				if((receivetime[3]>=0)&&(receivetime[3]<60)&&(receivetime[4]>=0)&&(receivetime[4]<60)&&(receivetime[5]>=0)&&(receivetime[5]<60))
				{
					for(i=0;i<6;i++)
					{
						RealTime[i] = receivetime[i];
					}
					RenewRTCTime(RealTime);
					Flag_TimeAdj = 0;
					if(Flag_COMDebug == 1)
					{							
						printf("\r\nRenew Server time is:%d-%d-%d %d:%d:%d\r\n",RealTime[0],RealTime[1],RealTime[2],RealTime[3],RealTime[4],RealTime[5]);
					}							
				}
			}
		}
		/*********************************MAC��֤����****************************************/
		if((order_data[1]== TypeID)&&(order_data[4]== SERVER_ABNORMAL_MESSAGE)) //
		{
			if(order_data[5] == SERVER_CHECK_MAC_ERR)
			{
				if(Flag_COMDebug == 1)
					printf("Server Return MAC Verify Error\r\n");
				Flag_StepStatus = STEP_SEND;
				LinkStep = CONNECTIP1;	/*chongqi*/
				Flag_InitStatus = LINK_SERVER	;
				Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
				SaveStartNewStatistStatusData();   //ͳ�ƿ�ʼ
				
			}

		}
		/*********************************���ؽ��յ�IMSI����****************************************/
		if((order_data[0]== CMD_START)&&(order_data[1]== TypeID)&&(order_data[4]== CARD_IMSI)) //			 
		{			  
			if(order_data[5] == 0x81)
			{
				SaveMACToFlash();
                
				Flag_CARD_ISCHANGE = CARD_NOCHANGE;
				if(Flag_COMDebug == 1)
					printf("Server has received IMSI!\r\n");					
			}
		}
		/*********************************��Ӧ���͵�ͳ������****************************************/
		if((order_data[1]== TypeID)&&(order_data[4]== SEND_DISCONNECT_HRRRTIME)) //
		{
			if(order_data[5] == 0x81)   //���յ���ȷ��ͳ������
			{
				num = order_data[6]*256+order_data[7];
				if(Flag_COMDebug == 1)
				{
					printf("Server Receive Right Statistics Data:%d!\r\n",num);
				}				
				if(num == StaticsSleepDataSendNum)
				{
					StaticsSleepDataSendNum++;
					StaticsSleepDataSendCount = 0;
					if(StaticsSleepDataSendNum < StaticsSleepDataSaveNum)
					{
						Flag_CanSendStatistData = 1;
						SleepDataBuffer_SendTime = 4;
						SaveSleepDataPosIndexToFlash(StaticsSleepDataSaveNum,StaticsSleepDataSendNum);						
					}
					else
					{
						Flag_CanSendStatistData = 0;
						StaticsSleepDataSendNum = 0;
						StaticsSleepDataSaveNum = 0;
						SaveSleepDataPosIndexToFlash(0,0);
					}
				}
				
			}	
			if(order_data[5] == 0x80)   //���յ������ͳ������
			{
				if(Flag_COMDebug == 1)
				{
					printf("Server Receive Error Statistics Data:%d,!Resend\r\n",StaticsSleepDataSendNum);
				}
				StaticsSleepDataSendCount++;
				if(StaticsSleepDataSendCount>=5)   
				{
					StaticsSleepDataSendNum++;
					if(StaticsSleepDataSendNum >= StaticsSleepDataSaveNum)
					{
						Flag_CanSendStatistData = 0;
						StaticsSleepDataSendNum = 0;
						StaticsSleepDataSaveNum = 0;
						StaticsSleepDataSendCount = 0;
						SaveSleepDataPosIndexToFlash(0,0);
					}
				}
				Flag_CanSendStatistData = 1;
				SleepDataBuffer_SendTime = 4;		
			}
		}
		/*********************************���Ͳ�������****************************************/
		if((order_data[1]== TypeID)&&(order_data[4]== REQ_ENABLE_SENDWAVE))
		{
			if(order_data[5] == 0x01)
			{
				Flag_SendWave = ENABLE_SENDWAVE; 
				if(Flag_COMDebug == 1)
				{
					printf("Enable send wave\r\n");
				}
			}
			else
			{
				Flag_SendWave = DISABLE_SENDWAVE;
				if(Flag_COMDebug == 1)
				{
					printf("Disable send wave\r\n");
				}
			}
	
		}
		/*********************************��ѯ��Ӳ���汾****************************************/
		if((order_data[1]== TypeID)&&(order_data[4]== CMD_REQHARDSOFTVER))  //
		{
			SendVerToServer();			
		}
		/*********************************�����̼�****************************************/
		#if 1
		if((order_data[1]== TypeID)&&(order_data[4]== CMD_SENDUPDATA))  //
		{
			OS_ERR      err;
			if(order_data[5]== UPDATA_START)    //��ʼ�̼�����
			{
				Updata_packagelen = order_data[6]*256+order_data[7];
				if(Flag_COMDebug == 1)
				{
					printf("Start updata from server,need download %d package!\r\n",Updata_packagelen);
				}					
				if(IAP_Erase_CodeFlash(FLASH_UPCodeAddress,(Updata_packagelen+1)*512)== 1)
				{
					SimpleDataNum1 = 0;
					SimpleDataNum2 = 0;
					HRDataNum = 0;
//					RRDataNum = 0;
					CalculateCount = 0;
					Updata_codelen = 0;														
					if(Flag_COMDebug == 1)
					{
						printf("Save flash address erase over!\r\n");
					}
					#ifdef RECORDERFILE_SAVE
						OSTmrStop(&timer_creatnewrecfile,OS_OPT_TMR_NONE,NULL,&err);       //ֹͣ������ʱ��
						OSTaskSuspend((OS_TCB*)&AppTaskRecorderTCB,&err);   //���𱣴�����
						Recorder_Operate(RECORDER_OFF);   //ֹͣ¼��
						if(Flag_COMDebug == 1)
						{
							printf("Stop Recorder!\r\n");
						}			 
					#endif
						
					HAL_TIM_Base_Stop_IT(&TIM7_Handler);  //ֹͣADC��ʱ��
					#if defined(ADCFILE_SAVE)   | defined(BCGFILE_SAVE) | defined(RESPFILE_SAVE)
						OSTaskSuspend((OS_TCB*)&AppTaskCreatNewFileTCB,&err);   //�����ļ���������
						OSTmrStop(&timer_sdwrite,OS_OPT_TMR_NONE,NULL,&err);       //ֹͣ������ʱ��
						OSTmrStop(&timer_creatnewfile,OS_OPT_TMR_NONE,NULL,&err);       //ֹͣ������ʱ��
						if(Flag_COMDebug == 1)
						{
							printf("Stop txt file save!\r\n");
						}
					#endif	
												
					Flag_Updata = 1;
					Updata_Time = 0;
					senddata[0] = CMD_SENDUPDATA;
					senddata[1] = UPDATA_START;
					senddata[2] = 0x01;
					RetuenCammandToServer(senddata,3);
						
					UPCode_Buff=mymalloc(SRAMCCM,4100);   //����4096�ֽ��ڴ滺���������룬��ΪSPI FLASH ��Ҫ����һ������												
						
				}
				else
				{
					senddata[0] = CMD_SENDUPDATA;
					senddata[1] = UPDATA_START;
					senddata[2] = 0x00;
					RetuenCammandToServer(senddata,3);
					if(Flag_COMDebug == 1)
					{
						printf("Save flash erase error!\r\n");
					}
				}				
			}
			if(order_data[5]== UPDATA_END)    //�̼��������
			{
				
				myfree(SRAMCCM,UPCode_Buff);
				SetUpdataFlag(FLASH_UPCodeInfoAddress,Updata_codelen);
				if(Flag_COMDebug == 1)
				{
					printf("Updata download end,restart!\r\n");
				}
				senddata[0] = CMD_SENDUPDATA;
				senddata[1] = UPDATA_END;
				senddata[2] = 0x01;
				RetuenCammandToServer(senddata,3);
				delay_ms(500);
				NVIC_SystemReset();    //�豸����
			}
			if(order_data[5]== UPDATA_PACKAGE)    //�̼�������
			{				
				jiaoyan = 0;
				for(i=4;i<order_data_len-3;i++)
				{
					jiaoyan += order_data[i];
				}
				if(jiaoyan == order_data[order_data_len-3] )
				{
					if((UpdataPackagenum != (order_data[6]*256+order_data[7]))||(UpdataPackagenum==0))
					{
						UpdataPackagenum = order_data[6]*256+order_data[7];
						Updata_codelen += order_data_len - 11;
                        if(UpdataPackagenum>=Updata_packagelen-1)
						for(i=0;i<order_data_len-11;i++)
                        {
                            printf("%02x ",order_data[8+i]);
                            if((i+1)%16==0)
                                printf("\r\n");
                        }
                        update_progress=(uint8_t)UpdataPackagenum*100/Updata_packagelen;
                        if(Flag_COMDebug == 1)
                            printf("��������%d\%\r\n",update_progress);
						if(Flag_COMDebug == 1)
						{
							printf("Download updata package %d verify ok! Already download %d Bytes\r\n",UpdataPackagenum,Updata_codelen);
						}					
						if(WriteCodeToFlash(FLASH_UPCodeAddress+Updata_codelen-order_data_len +11,&order_data[8],order_data_len - 11) == 1)					
						{
							if(Updata_packagelen == UpdataPackagenum)
							{
															
								senddata[0] = CMD_SENDUPDATA;
								senddata[1] = UPDATA_END;
								senddata[2] = 0x01;
								RetuenCammandToServer(senddata,3);
								delay_ms(100);
								if(Updata_codelen > 20000)    //�������20K����ֹ��������
								{
									myfree(SRAMCCM,UPCode_Buff);
									SetUpdataFlag(FLASH_UPCodeInfoAddress,Updata_codelen);
									if(Flag_COMDebug == 1)
									{
										printf("Updata download end,restart!\r\n");
									}	
									delay_ms(500);
									NVIC_SystemReset();   //�豸����
								}
							}
							else
							{
								senddata[0] = CMD_SENDUPDATA;
								senddata[1] = UPDATA_PACKAGE;
								senddata[2] = 0x01;
								senddata[3] = order_data[6];
								senddata[4] = order_data[7];
								
								RetuenCammandToServer(senddata,5);
							
							}
						}
					}
					else
					{
						senddata[0] = CMD_SENDUPDATA;
						senddata[1] = UPDATA_PACKAGE;
						senddata[2] = 0x00;
						senddata[3] = (UpdataPackagenum+1)/256;
						senddata[4] = (UpdataPackagenum+1)%256;
						RetuenCammandToServer(senddata,5);
					}
				}
				else
				{
					if(Flag_COMDebug == 1)
					{
						printf("Download updata package %d  verify error!\r\n",UpdataPackagenum+1);
					}
					senddata[0] = CMD_SENDUPDATA;
					senddata[1] = UPDATA_PACKAGE;
					senddata[2] = 0x00;
					senddata[3] = (order_data[6]*256+order_data[7])/256;
					senddata[4] = (order_data[6]*256+order_data[7])%256;
					RetuenCammandToServer(senddata,5);
				}

			}
			
		}
		#endif
		/*********************************ѹ������״̬****************************************/
		#ifdef ENABLE_SENDPRESSSERSONSTATUS
		if((order_data[1]== TypeID)&&(order_data[4]== CMD_PRESSSENSER)) //ѹ��������״̬����
		{
			if(order_data[5] == 0x81)
			{
				Flag_SendPresensorStatus = 0;
				SendPresensorStatus_Time = 0;
				if(Flag_COMDebug == 1)
					printf("Server Received pressure sensor status\r\n");
			}								 
		}
		#endif
	}
			}
			else  //not a complete command
			{
				if(i>0)
				{
					memset(LTEUART_RX_BUFFER,0,i);
					for(j=0;j<LTEUART_RX_LEN-i;j++)
					{
						LTEUART_RX_BUFFER[j] = LTEUART_RX_BUFFER[i+j];
						LTEUART_RX_BUFFER[i+j] = 0;
					}
					LTEUART_RX_LEN = LTEUART_RX_LEN  - i;
				}
			}
			
		}
	}
			


}
/****************************************************************************
*	�� �� ��: SetLedStatus
*	����˵��: ����LED״̬
*	��    �Σ�led_index LED���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SetLedStatus(uint8_t led_index)
{
	if(Flag_InitStatus == SYSTEM_INIT)
	{
		if(WS2818_BrightStatus[led_index] == LED_ON)
		{
			SetLEDOff(led_index);
			WS2812_update(1);
		}
		else
		{
			SetLEDOn(led_index,COLOR_YELLOW);
			WS2812_update(1);
		}
	}
	
}
/****************************************************************************
*	�� �� ��: Check_ExtSensor_PeopleOnBed
*	����˵��: ����ⲿ�������Ƿ������ڴ�
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����200ms���һ��״̬���������10��״̬һ�£��������״̬�ȶ�
*****************************************************************************/
void Check_ExtSensor_PeopleOnBed(void)
{
	float adcvlaue = 0;
	
	if(OnbedStatus_CountTimer >= 2)
	{		
        //printf("%d\r\n",ADC_ConvertedValue[2]);
		adcvlaue = ADC_ConvertedValue[2]*3300/4096.0;
        #if 0
            adcvlaue =1500;
        #endif
        adcvlaue *=2;
        #if 0 //SIMULATOR_ON_BED1
        if(!IS_test_over)
        {
            if((sim_time>0)&&(sim_time<=2*60))//�ڴ�
            {
                adcvlaue =3299;
                Flag_PeopleTurnforHert=0;
                
            }
            else if((sim_time>2*60)&&(sim_time<=4*60))//�봲
            {
                adcvlaue=0;
                
            }
            else if((sim_time>4*60)&&(sim_time<=6*60))//t�嶯
            {
                adcvlaue =3299;
                Flag_PeopleTurnforHert=1;
            }
            else
            {
                sim_time=0;
                IS_test_over=1;
            }
        }
        else
             sim_time=0;
        #endif
		if(adcvlaue>3299)
		{
			adcvlaue = 3299;
		}
		CheckCount_ExtSensor++;	
		OnbedStatus_CountTimer = 0;		
		if( abs((int)adcvlaue -(int)ADC_VoltageValue[2] ) >1000)   //���ݳ��������ʱ��״̬�����㣬��ֹ�źŸ���
		{
			ADC_VoltageValue[2] = adcvlaue;
			CheckCount_ExtSensor = 0;
			ExtSensor_OnbedStatus_Count = 0;
			ADCVol_ExtSensor = 0;
			return;
		}
		ADC_VoltageValue[2] = adcvlaue;
		ADCVol_ExtSensor += (uint32_t)adcvlaue;
		
		if(adcvlaue> 800)
		{
			ExtSensor_OnbedStatus_Count++;				
		}
		if(CheckCount_ExtSensor >= 25)
		{
			ADCVol_ExtSensor /= 25;
			if(Flag_COMDebug == 1)
			{		
				printf("ѹ��ƽ��ֵ:%d mV\r\n",ADCVol_ExtSensor);
				
			}
//			if((ADCVol_ExtSensor>=500)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED)&&(gPeopleFlag == 1))   //ѹ��ƽ��ֵ����500mV
			if((ADCVol_ExtSensor>=1000)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED))//???
			{
//				if(Flag_PeopleTurnforPresensor == 1)
				{
					if(Flag_COMDebug == 1)
					{		
						printf("\r\n======����======\r\n");
						
					}
                    //arithmeticHeartInit();//�㷨��ʼ��                   
                    //RingBuff_Init(&ringBuff_ori,0);//�����������

//					Status_ExtSensorOnbed = EXTSENSOR_PEOPLEONBED;
                    pieValue = 1;
//                    isonbed =1;
//					if(Flag_Binding_Users == BINDING_USERS_YES)
						SleepData_SendTime = SLEEPDATA_SENDTIME_3S;
					Monitor_Offline_Time = 0;
					#ifdef ENABLE_SENDPRESSSERSONSTATUS
					Flag_SendPresensorStatus = 1;
					SendPresensorStatus_Time = 4;
					#endif
				}
				ExtSensor_PeopleOFFBed_Time = 0;
			}
//			if((ExtSensor_OnbedStatus_Count<1 || gPeopleFlag == 0) && (Status_ExtSensorOnbed != EXTSENSOR_PEOPLEOFFBED)) //ÿ��ѹ��ֵ��С��400
			if((ExtSensor_OnbedStatus_Count<3)&&(ADCVol_ExtSensor<600) && (Status_ExtSensorOnbed != EXTSENSOR_PEOPLEOFFBED))//???
			{
				if(Flag_COMDebug == 1)
				{		
					printf("\r\n======����======\r\n");
					
				}			
//				Status_ExtSensorOnbed = EXTSENSOR_PEOPLEOFFBED;
                pieValue = 0;
//                isonbed =0;
				#ifdef ENABLE_SENDPRESSSERSONSTATUS
				Flag_SendPresensorStatus = 1;
				SendPresensorStatus_Time = 4;
				#endif
								
			}
			ExtSensor_OnbedStatus_Count = 0;
			CheckCount_ExtSensor = 0;
			Flag_PeopleTurnforPresensor = 0;
						
//			SendPressSenserVol((uint16_t)ADCVol_ExtSensor);//����ѹ����������ѹ��������
			ADCVol_ExtSensor = 0;
			
		}
	}
}
/****************************************************************************
*	�� �� ��: SendPressSenserVol
*	����˵��: ����ѹ����������ѹֵ
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ����
*****************************************************************************/
void SendPressSenserVol(uint16_t vol)
{
	uint8_t senddata[10]={0};
	 	 	   
	senddata[0] = CMD_START;
	senddata[1] = TypeID;
	senddata[2] = 0;
	senddata[3] = 4;
	senddata[4] = CMD_PRESSSENSERVOL;
	senddata[5] = (uint8_t)(vol/256);
	senddata[6] = (uint8_t)(vol%256);
	senddata[7] = 0xFF;
	senddata[8] = CMD_LF1;
	senddata[9] = CMD_LF2;
	LTE_Send_data(Socket,10,senddata);
	if(Flag_COMDebug == 1)
	{		
		printf("ѹ���ѹ:%dmV\r\n",vol);
		
	}
	
}
/****************************************************************************
*	�� �� ��: SendPressSenserStatus
*	����˵��: ����ѹ��������״̬
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ����
*****************************************************************************/
void SendPressSenserStatus(uint8_t status)
{
	 uint8_t senddata[9]={0};
	 	 	   
	senddata[0] = CMD_START;
	senddata[1] = TypeID;
	senddata[2] = 0;
	senddata[3] = 3;
	senddata[4] = CMD_PRESSSENSER;
	if(status == EXTSENSOR_PEOPLEONBED)
		senddata[5] = PRESSSENSER_ON|0x80;
	else
		senddata[5] = PRESSSENSER_OFF|0x80;
	senddata[6] = 0xFF;
	senddata[7] = CMD_LF1;
	senddata[8] = CMD_LF2;
	LTE_Send_data(Socket,9,senddata);

}
/****************************************************************************
*	�� �� ��: UART_Send_Order
*	����˵��: ͨ�����ڷ���ָ��
*	��    �Σ�
*	�� �� ֵ: ��
* 	˵    ����
*****************************************************************************/
void UART_Send_Order(USART_TypeDef* USARTx,uint8_t *buf,uint8_t len)
{
	uint8_t i = 0;
	
	SendDataToUSART(USARTx,CMD_START);
	SendDataToUSART(USARTx,TypeID );
	SendDataToUSART(USARTx,len+1);
	for(i=0;i<len;i++)
	{
		SendDataToUSART(USARTx,buf[i]);
	}
	SendDataToUSART(USARTx,0xFF );
	SendDataToUSART(USARTx,CMD_LF1 );
	SendDataToUSART(USARTx,CMD_LF2 );		
}

/****************************************************************************
*	�� �� ��: RenewRealTime
*	����˵��: ����ʱ��
*	��    �Σ�*time ���º��ʱ��
*	�� �� ֵ: ��
* 	˵    ����
*****************************************************************************/
void RenewRealTime(uint8_t *time)
{
		char i=0;
	uint8_t year = 0,month = 0,daysPerMonth = 0;
#if 0
	 time[5] += 1;						//���ʱ
	if(time[5] >= 60)
	{			                  //�ֽ�λ
		time[5]= 0;
		time[4]++;
		if(time[4] >= 60)
		{				                //ʱ��λ
			time[4]=0;
			time[3]++;
			if(Flag_TimeAdj == 0)
			{
				 Adj_Time = 0;
				 Flag_TimeAdj = 1;		  //����ָ��ͬ��������ʱ��
			}
		}
		if(time[3] >= 24)
		{				//�ս�λ
			time[3]=0;
			time[2]++;
		}
		//�ж�ÿ���·ݵ�����
		year = time[0];
		month = time[1];
		if(year % 4 == 0 && month == 2)
		{
			daysPerMonth= 29;
		}
		else
		{
			switch(month)
			{
				case 1:
				case 3:
				case 5:
				case 7:
				case 8:
				case 10:
				case 12:
					daysPerMonth = 31;
					break;
				case 2:
					daysPerMonth = 28;
					break;
				default:
					daysPerMonth = 30;
					break;
			}
		}
		if(time[2] > daysPerMonth)
		{				//�½�λ
			time[2]=1;
			time[1] ++;
		}
		if(time[1]  >  12)
		{				//���λ
			time[1] =1;
			time[0]++;
		}
		if(time[0]>=  99)
		{				//�긴λ
			time[0] = 0;
		}
	}	
    #endif
    	HAL_RTC_GetTime(&RTC_Handler,&RTC_TimeStruct,RTC_FORMAT_BIN);
        HAL_RTC_GetDate(&RTC_Handler, &RTC_DateStruct,RTC_FORMAT_BIN);
        time[0] =RTC_DateStruct.Year ;
		time[1]=RTC_DateStruct.Month  ;
		time[2]=RTC_DateStruct.Date ;
		time[3]=RTC_TimeStruct.Hours ;
		time[4]=RTC_TimeStruct.Minutes ;
		time[5]=RTC_TimeStruct.Seconds ;
}
/****************************************************************************
*	�� �� ��: RenewRTCTime
*	����˵��: ����RTCʱ��
*	��    �Σ�*time ���º��ʱ��
*	�� �� ֵ: ��
* 	˵    ����
*****************************************************************************/
void RenewRTCTime(uint8_t *time)
{
	HAL_RTC_GetTime(&RTC_Handler,&RTC_TimeStruct,RTC_FORMAT_BIN);
	HAL_RTC_GetDate(&RTC_Handler, &RTC_DateStruct,RTC_FORMAT_BIN);
	
	//if(RTC_TimeStruct.Minutes != time[4])   //����1���ӣ�����RTC
	{
		RTC_DateStruct.Year = time[0];
		RTC_DateStruct.Month = time[1];
		RTC_DateStruct.Date = time[2];
		RTC_TimeStruct.Hours = time[3];
		RTC_TimeStruct.Minutes = time[4];
		RTC_TimeStruct.Seconds = time[5];
		RTC_DateStruct.WeekDay=RTC_get_weekday(time[0]+2000,time[1],time[2]);
		GregorianDay();   //����ʱ���������
		if(Flag_COMDebug == 1)
			printf("RTCʱ�Ӹ���Ϊ:20%02d��%02d��%02d�� ����%s %02d:%02d:%02d\r\n",
					RTC_DateStruct.Year,RTC_DateStruct.Month,RTC_DateStruct.Date,WEEK_STR[RTC_DateStruct.WeekDay],
					RTC_TimeStruct.Hours,RTC_TimeStruct.Minutes,RTC_TimeStruct.Seconds);
        RTC_Set_Time(RTC_TimeStruct.Hours,RTC_TimeStruct.Minutes,RTC_TimeStruct.Seconds);	        //����ʱ�� ,����ʵ��ʱ���޸�
		RTC_Set_Date(RTC_DateStruct.Year,RTC_DateStruct.Month,RTC_DateStruct.Date,RTC_DateStruct.WeekDay);	//��������
	}
}
/*******************************************************************************
*	�� �� ��:  RePowerOn_LTE
*	����˵��:  �ϵ�����LTEģ��
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*******************************************************************************/
void RePowerOn_LTE(void)
{

	Flag_InitStatus = WIRELESS_INIT;
	Flag_LTEInitStep = LTE_INIT_STEP1;
	LTE_InitTime = 0;
	LTE_PowerDown();
	delay_ms(5000);
	LTE_StartUP();
	//Flag_DataSendMode = LTE_DATASEND_TRANSMODE;   //͸��ģʽ
}

/****************************************************************************
*	�� �� ��: LinkServerVerifyStep
*	����˵��: ���ӷ�����У������
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����������У��
*****************************************************************************/
char LinkServerVerifyStep(uint8_t step)
{
	
	 switch(step)
	 {
		 case CONNECTIP1:      //����ǰ�÷�����
			 if(Flag_StepStatus == STEP_SEND)
			 {
				  ConnectFrontServer();
			 }
			 if(Flag_StepStatus == STEP_RECEIVE)
			 {
				  FrontServerLinkStatus();
			 }
		 break;
		 		 
		case GETIP2:         //��ȡ���÷�����IP
			 if(Flag_StepStatus == STEP_SEND)
			 {
				  GetBackServerIP();
			 }
			 if(Flag_StepStatus == STEP_RECEIVE)
			 {
				 AnalysisBackServerIP();
			 }
		 break;
			 
		case CONNECTIP2:        //���Ӻ��÷�����
			 if(Flag_StepStatus == STEP_SEND)
			 {
				  ConnectBackServer();
			 }
			 if(Flag_StepStatus == STEP_RECEIVE)
			 {
				  BackServerLinkStatus();
			 }
		 break;
			 
		case GETTOKEN2:        //��ȡ���÷�����У����
			 if(Flag_StepStatus == STEP_SEND)
			 {
				  GetBackServerToken2();
			 }
			 if(Flag_StepStatus == STEP_RECEIVE)
			 {
				  AnalysisBackServerToken2();
			 }
		 break;
			 
		case BACKSERVERVERFY:     //���÷�����У��
			 if(Flag_StepStatus == STEP_SEND)
			 {
				 SendBackServerVerify();
			 }
			 if(Flag_StepStatus == STEP_RECEIVE)
			 {
				 GetBackServerVerifyResult();
			 }
		 break;
	 }	
}
/****************************************************************************
*	�� �� ��: ConnectFrontServer
*	����˵��: ����ǰ�÷�����
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ��������ǰ�÷�����
*****************************************************************************/
void ConnectFrontServer(void)
{
	 char Res_Mode;  
     char Res_Parameter;

      Res_Parameter = LTE_Set_ConnectIP_Parameter(SERVER_IP1,SERVER_IP1_PORT);

    if(Res_Parameter == LTE_TCP_CONNECT)
    {
        Flag_StepStatus = STEP_RECEIVE;
        Link_Time = 0 ;
    }
    else
    {
         delay_ms(3000);
    }

}
/****************************************************************************
*	�� �� ��: FrontServerLinkStatus
*	����˵��: ǰ�÷���������״̬
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void FrontServerLinkStatus(void)
{

	delay_ms(500);
	 if(LTE_Query_TCPstate() == LTE_TCP_CONNECT) //������������
		{
//			 pstr = strstr(UART_RX_BUFFER,"CONNECT");
//			 Socket = pstr[8]-0x30;
//		 	 LTE_Open_cmdMode();
//			 LTE_Query_TCPConnectSocket();
			 if(Flag_COMDebug == 1)
				{
					printf("TCP1 has connected\r\n");
				}
			 ClearUSARTBUF(LTE_UART);
			 Flag_StepStatus = STEP_SEND;
			 LinkStep = GETIP2;
			 LinkIPCount = 0;
			SentGetServerVerityCount = 0;
		}
	 else
	 {
		 LTE_Close_ConnectedIP();
		 delay_ms(1000);
		 Flag_StepStatus = STEP_SEND;
		 LinkStep = CONNECTIP1;
		 if(Flag_COMDebug == 1)
		 {					
			printf("TCP1 has not connected!\r\n");
		 }
	 }
}
/****************************************************************************
*	�� �� ��: GetBackServerIP
*	����˵��: ��ȡ���÷�����ip
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void GetBackServerIP(void)
{
	 uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
	
	 SendData[0] = CMD_START;
	 SendData[1] = TypeID;
	 SendData[2] = (MAC_Len+2)|0x80;
	 SendData[3] = REQ_SECOND_SERVER;
	 for(i=0;i<MAC_Len ;i++)
	 {
			SendData[4+i]=MAC_ID[i];
	 }
	 for(i = 0;i< MAC_Len;i++)
	 {
			jiaoyan += MAC_ID[i];
	 }
	 jiaoyan +=REQ_SECOND_TOKEN;
	 SendData[4+MAC_Len] = jiaoyan|0x80 ;
	 SendData[5+MAC_Len] = CMD_LF1;
	 SendData[6+MAC_Len] = CMD_LF2;
     //printf("Get IP2_1\r\n");
	 LTE_Send_data(Socket,7+MAC_Len,SendData);
     //printf("Get IP2_2\r\n");
	 Link_Time = 0;
	 Flag_StepStatus = STEP_RECEIVE;
	 SentGetServerVerityCount++;
	 if(Flag_COMDebug == 1)
	 {
		 printf("Get IP2 from front server:");
		 for(i=0;i<7+MAC_Len;i++)
		 {
			 printf("%02x ",SendData[i]);
		 }
		 printf("\r\n");
	 }
}
/****************************************************************************
*	�� �� ��: AnalysisBackServerIP
*	����˵��: �������÷�����ip
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void AnalysisBackServerIP(void)
{
	 char *pstr,*pstr1,*pstr2;
	 uint8_t len;
	 uint8_t i=0;
	 uint8_t ip[6];
	 char buf[100];
	 char err;
     delay_ms(50);
     //printf("URC:%s\r\n",LTEUART_RX_BUFFER);
	 pstr2=strstr(LTEUART_RX_BUFFER,"SEND OK");
	 if(pstr2 != NULL)   //�յ�����������
	 {
	    delay_ms(100);	
		  pstr = strstr(pstr2, "$");
		  pstr1 = strstr(pstr2, "iB");
		  
		  if((pstr!=NULL)&&(pstr1!=NULL))
			{
				 if((pstr[1] == TypeID)&&(pstr[3] == REQ_SECOND_SERVER))
				{   
					memset(IP2,0X00,20);
					memset(Port2,0X00,5);
					 for(i=0;i<6;i++)
					{
						 if(((pstr[4]<<(7-i))&0x80)==0x80)
						    ip[i]= pstr[5+i];
						 else
							  ip[i]= pstr[5+i]&0x7F;
					 }	
					 sprintf(IP2, "%d.%d.%d.%d", ip[0],ip[1],ip[2],ip[3]);
					 sprintf(Port2, "%d", ip[4]*100+ip[5]);
					 SaveIP2ToFlash();
					 if(Flag_COMDebug == 1)
						{						
							printf("IP2:%s\r\n", IP2);
							printf("Port2:%s\r\n", Port2);
						}
					Flag_StepStatus = STEP_SEND;
					LinkStep = CONNECTIP2;
					LinkIPCount = 0;
					ClearUSARTBUF(LTE_UART);
				}
				if((pstr[1]== TypeID)&&(pstr[3] ==SERVER_ABNORMAL_MESSAGE)) 
				 {
					 if(pstr[4] == SERVER_CHECK_MAC_ERR)  //MAC��֤����
					 {
							 if(Flag_COMDebug == 1)
							 {
									printf("Server Return MAC Verify Error!\r\n");
							 }
							 Flag_StepStatus = STEP_SEND;
							LinkStep = GETIP2;
					 }	
				   ClearUSARTBUF(LTE_UART);			 
				 } 	 			 
			}		
	 }
	 if(Link_Time>= NETWORKLINK_TIMEOUT_10S)
		{
			 Flag_StepStatus = STEP_SEND;
			 LinkStep = GETIP2;
//			 err=LTE_Query_TCPStatus();
			 if(err == LTE_TCP_CONNECT)
			 {
					LinkStep = GETIP2;
			 }
			 else
			 {
				 LinkStep = CONNECTIP1;
			 }

			 if(Flag_COMDebug == 1)
				{					
					printf("Get ip2 time out:%s\r\n",LTEUART_RX_BUFFER);
				}
		}
	if(SentGetServerVerityCount > 6)
	{
		Flag_StepStatus = STEP_SEND;
		LinkStep = CONNECTIP1;
	}
}
/****************************************************************************
*	�� �� ��: ConnectBackServer
*	����˵��: ���Ӻ��÷�����
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void ConnectBackServer(void)
{
	 char res;  
	 char Res_Mode;
     char Res_Parameter;
    
      LTE_Close_ConnectedIP();
      Res_Parameter = LTE_Set_ConnectIP_Parameter(IP2,Port2);

	 
	  LinkIPCount++;
     if(Res_Parameter == LTE_TCP_CONNECT)
     {
       // printf("ConnectBackServer succeed\r\n");
        Flag_StepStatus = STEP_RECEIVE;
        Link_Time = 0 ; 
     }
     else
     { 
         delay_ms(3000);
     }	
}
/****************************************************************************
*	�� �� ��: BackServerLinkStatus
*	����˵��: ���÷���������״̬
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void BackServerLinkStatus(void)
{

	delay_ms(500);
	if(LTE_Query_TCPstate() == LTE_TCP_CONNECT) //������������
	{
//			 pstr = strstr(UART_RX_BUFFER,"CONNECT,");
//			 Socket = pstr[8]-0x30;
//		LTE_Open_cmdMode();			
//		LTE_Query_TCPConnectSocket();
		if(Flag_COMDebug == 1)
		{
			printf("TCP2 has connected\r\n");
		}
		ClearUSARTBUF(LTE_UART);
		Flag_StepStatus = STEP_SEND;
		SentGetServerVerityCount = 0;
		LinkIPCount = 0;
		if((Flag_ErrInfo&ERROR_NO_TOKEN2) == ERROR_NO_TOKEN2 )
		{
			LinkStep = GETTOKEN2;
		}
		else
		{
			LinkStep = BACKSERVERVERFY;
		}
	}
	else
	{
		LTE_Close_ConnectedIP();
		delay_ms(1000);
		Flag_StepStatus = STEP_SEND;
		LinkStep = CONNECTIP2;
		if(Flag_COMDebug == 1)
		{					
			printf("TCP2 has not connected!\r\n");
		}
		if(LinkIPCount >5)
		{
			Flag_StepStatus = STEP_SEND;
			LinkStep = CONNECTIP1;
			LinkIPCount = 0;
		}
		
	}	
}
/****************************************************************************
*	�� �� ��: GetBackServerToken2
*	����˵��: ��ȡ���÷�����token
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void GetBackServerToken2(void)
{
   uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
	 
	 SendData[0] = CMD_START;
	 SendData[1] = TypeID;
	 SendData[2] = 0;
	 SendData[3] = MAC_Len+2;
	 SendData[4] = REQ_SECOND_TOKEN;
	 for(i=0;i<MAC_Len ;i++)
	 {
			SendData[5+i]=MAC_ID[i];
	 }
	 for(i = 0;i< MAC_Len;i++)
	 {
			jiaoyan += MAC_ID[i];
	 }
	 jiaoyan +=REQ_SECOND_TOKEN;
	 SendData[5+MAC_Len] = jiaoyan ;
	 SendData[6+MAC_Len] = CMD_LF1;
	 SendData[7+MAC_Len] = CMD_LF2;
     LTE_Send_data(Socket,8+MAC_Len,SendData);	
     Link_Time = 0;	 
	 Flag_StepStatus = STEP_RECEIVE;
	 SentGetServerVerityCount++;
	 if(Flag_COMDebug == 1)
	 {
			printf("Get token2 from IP2!\r\n");
	 }
}	
/****************************************************************************
*	�� �� ��: AnalysisBackServerToken2
*	����˵��: �������÷�����token
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void AnalysisBackServerToken2(void)
{
	char *pstr,*pstr1;
	uint8_t len,i;
	char buf[100];
	char err;
    //delay_ms(50);
    //printf("URC_2:%s\r\n",LTEUART_RX_BUFFER);
	if(strstr(LTEUART_RX_BUFFER,"SEND OK") != NULL)   //�յ�����������
	{
		delay_ms(100);	
		pstr = strstr(LTEUART_RX_BUFFER, "$");
		if(pstr!=NULL)
		{			 
			if((pstr[1] == TypeID)&&(pstr[4] == REQ_SECOND_TOKEN))
			{   												 	         
				Token2_Len = pstr[2]*256+pstr[3]-2;
				if(Token2_Len>10)
				{
					Token2_Len = 10;
				}
				memset(Token2,0X00,15);
				for(i = 0;i< Token2_Len;i++)
				{
					if((pstr[i+5]<0x3A)&&(pstr[i+5]>0x2F))
					{
						Token2[i] = pstr[i+5];
					}
				}
				Token2[Token2_Len] = 0;
				if(Flag_COMDebug == 1)
				{
					printf("Token2 is:%s\r\n",Token2);
				}
				SaveToken2ToFlash();
				Flag_StepStatus = STEP_SEND;
				LinkStep = BACKSERVERVERFY;	
				SentGetServerVerityCount = 0;						
				ClearUSARTBUF(LTE_UART);
			}
			if((pstr[1]== TypeID)&&(pstr[4] ==SERVER_ABNORMAL_MESSAGE)) 
			{
				if(pstr[5] == SERVER_CHECK_MAC_ERR)  //MAC��֤����
				{
					if(Flag_COMDebug == 1)
					{
						printf("Server Return MAC Verify Error!\r\n");
					}
					Flag_StepStatus = STEP_SEND;
					LinkStep = CONNECTIP1;
				}	
				ClearUSARTBUF(LTE_UART);			 
			} 	 			 
		}		
	}
	if(Link_Time>= NETWORKLINK_TIMEOUT_10S)
	{
		Flag_StepStatus = STEP_SEND;
//		err=LTE_Query_TCPStatus();
		if(err == LTE_TCP_CONNECT)
		{
			LinkStep = GETTOKEN2;
		}
		else
		{
			LinkStep = CONNECTIP2;
		}
		if(Flag_COMDebug == 1)
		{					
			printf("Get token2 time out��%s\r\n",LTEUART_RX_BUFFER);
		}
	}
	if(SentGetServerVerityCount > 6)
	{
		Flag_StepStatus = STEP_SEND;
		LinkStep = CONNECTIP1;
		Flag_ErrInfo |= ERROR_NO_TOKEN2;
	}
}
/****************************************************************************
*	�� �� ��: SendBackServerVerify
*	����˵��: ��ȡ���÷�����У��
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendBackServerVerify(void)
{
	 uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
	 uint8_t len=0;
	 char buf[100];
	 unsigned char ucMd5data[30] = {0};
     unsigned char ucMd5string[40] = {0};
     unsigned char ucMd5string1[40] = {0};
		 
	 sprintf(ucMd5data,"%s123456%s",MAC_ID,Token2);
     MDString(ucMd5data,ucMd5string);
	 HexToLowerStr(ucMd5string1,ucMd5string,16);
	 if(Flag_COMDebug == 1)
		{			
			printf("ucMd5data:%s\r\n",ucMd5data);					
			printf("ucMd5string1:%s\r\n",ucMd5string1);		
		}
				
	 SendData[0] = CMD_START;
	 SendData[1] = TypeID;
	 len = strlen(ucMd5string1);
	 SendData[2]= 0;	
	 SendData[3]= len+MAC_Len+2;
	 SendData[4]=REQ_SECOND_VERIFY;
	 for(i=0;i<len ;i++)
	 {
			SendData[5+i]=ucMd5string1[i];
	 }
	 for(i=0;i<MAC_Len ;i++)
	 {
			SendData[5+len+i]=MAC_ID[i];
	 } 
	 for(i = 0;i< len;i++)
		{
			jiaoyan += ucMd5string1[i];
		}								 
	 for(i = 0;i< MAC_Len;i++)
		{
			jiaoyan += MAC_ID[i];
		}
	 jiaoyan +=REQ_SECOND_VERIFY;
	 SendData[5+len+MAC_Len] = jiaoyan ;
	 SendData[6+len+MAC_Len] = CMD_LF1;
	 SendData[7+len+MAC_Len] = CMD_LF2;
	LTE_Send_data(Socket,8+len+MAC_Len,SendData);
	Link_Time = 0;	 
	 Flag_StepStatus = STEP_RECEIVE;
	SentGetServerVerityCount ++;
	
}
/****************************************************************************
*	�� �� ��: GetBackServerVerifyResult
*	����˵��: ��ȡ���÷�����У����
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void GetBackServerVerifyResult(void)
{
	 char *pstr,*pstr1;
	 uint8_t len,i;
	 char err;
	 char buf[100];
	 unsigned char receivetime[6];
	 OS_ERR      oserr;
     //delay_ms(50);
     //printf("URC_3:%s\r\n",LTEUART_RX_BUFFER);
	 if(strstr(LTEUART_RX_BUFFER,"SEND OK") != NULL)   //�յ�����������
	 {
		delay_ms(100);	
		pstr = strstr(LTEUART_RX_BUFFER, "$");
		if(pstr!=NULL)
		{
			//---------------------MD5У��ͨ��----------------------------------
			if((pstr[1] == TypeID)&&(pstr[4] == REQ_SECOND_VERIFY)) //
			{   												 	         
				for(i=0;i<6;i++)  //��ȡ������ʱ��
				{
					receivetime[i] = (pstr[5+i*2]&0x7F-0x30)*10+(pstr[6+i*2]&0x7F-0x30); //��ASCII�ַ��������ֽڵ�ʱ��ת��Ϊ1���ֽڵ�ʱ��		 
				}
			
				if((receivetime[0]>17)&&(receivetime[0]<99)&&(receivetime[1]>0)&&(receivetime[1]<13)&&(receivetime[2]>0)&&(receivetime[2]<32))
				{
					for(i=0;i<6;i++)
					{
						RealTime[i] = receivetime[i];
					}
					RenewRTCTime(RealTime);  //��Ӳ��ʵʱʱ��
					if(Flag_COMDebug == 1)
					{
						printf("Login success��Server time is:%d-%d-%d %d:%d:%d\r\n",receivetime[0],receivetime[1],receivetime[2],receivetime[3],receivetime[4],receivetime[5]);
					}
				}
                delay_ms(200);
                pstr=strstr(&LTEUART_RX_BUFFER[40],"$");
                if(pstr!=NULL)
                {
                	if((pstr[1]== TypeID)&&(pstr[4]== REQ_ENABLE_SENDWAVE))
                    {
                        if(pstr[5] == 0x01)
                        {
                            Flag_SendWave = ENABLE_SENDWAVE; 
                            if(Flag_COMDebug == 1)
                            {
                                printf("----------------Enable send wave\r\n");
                            }
                        }
                        else
                        {
                            Flag_SendWave = DISABLE_SENDWAVE;
                            if(Flag_COMDebug == 1)
                            {
                                printf("---------------Disable send wave\r\n");
                            }
                        }
                
                    }
                
                }
				Flag_TimeAdj = 0;  														 
				LTE_ConnetTime = 0;	
				Position_LAC=0xFFFF;
				Position_CID=0xFFFF;
				SendReConnectMode(Flag_Start_Mode,Position_LAC,Position_CID); 
				delay_ms(500);
				GetServerTime();
//				LED1(0); //���ӳɹ�,ledϨ��										 
								
//				for(i=0;i<6;i++)
//				{
//					HR_StartTime[i] = RealTime[i];
//					RR_StartTime[i] = RealTime[i];
//                    HRW_StartTime[i] = RealTime[i];
//					RRW_StartTime[i] = RealTime[i];
//                    SPO_StartTime[i] = RealTime[i];
//				}
                
				LinkStep = SENDSLEEPDATA;				//���뷢��˯������ģʽ			 				  
				Flag_StepStatus = STEP_SEND;				
				SentGetServerVerityCount = 0;
				Flag_InitStatus = CONTINUE_SENDDATA;
				Time_NetworkInquire = 0;
				UpdataPackagenum = 0;
				Updata_packagelen = 0;
				Updata_codelen = 0;
				GetSleepDataTimeCount = 0;

				
				//if(Flag_CARD_ISCHANGE == CARD_HASCHANGE)  //���Ϳ���IMSI��
				  {
						if(Flag_COMDebug == 1)
								printf("SIM Card has changed!\r\n");
						Send_CARD_IMSI(SIMCard_ICCID,strlen(SIMCard_ICCID));
						CARD_IMSI_Time = 0;
				  }	
				  
				if((Flag_PowerOn == 0)&&(Flag_Updata == 0))
				{
					if(StaticsSleepDataBuffLen>8)  //������һ������
						EndStatistStatusData();   //����ͳ��
//					HRDataNum = 0;
//					RRDataNum = 0;
					CalculateCount = 0;
					SimpleDataNum1 = 0;
					SimpleDataNum2 = 0;
					SleepDataBuffer_SendTime = 3;
					Flag_CanSendStatistData = 1;
				}
				else
				{
					#ifdef  LOGFILE_SAVE
					CreateNewLogfile();
					if(Flag_PowerOn == 1)
					{
						char WriteData[30];
						sprintf(WriteData,"�豸������%s\r\n",SystemReset[Flag_SystemReset]);
						WriteLogInfoToTXT(WriteData);
						
					}
					#endif
				
					Flag_PowerOn = 0;					
//					TIM3_Configuration();   //��ʱ�ɼ����ϵ���һ�������ɹ�����
//					HRDataNum = 0;
//					RRDataNum = 0;
					CalculateCount = 0;
					SimpleDataNum1 = 0;
					SimpleDataNum2 = 0;
					OnbedStatus_CountTimer = 0;
				}			  
				if(StaticsSleepDataSendNum != StaticsSleepDataSaveNum)
				{
					SleepDataBuffer_SendTime = 0;
					Flag_CanSendStatistData = 1;
					StaticsSleepDataSendCount = 0;
				}
				#if (defined(ADCFILE_SAVE)   | defined(BCGFILE_SAVE) | defined(RESPFILE_SAVE)| defined(LOGFILE_SAVE))&& (!defined(SAVEFILE_BYSENSOR))
				char *   p_mem_blk2;	
						 
				p_mem_blk2 = OSMemGet((OS_MEM      *)&mem,
								   (OS_ERR      *)&oserr);
				*p_mem_blk2 = CREATE_DATAFILE;
				/* ����������Ϣ������ AppTaskCreatNewFileTCB */
				OSTaskQPost ((OS_TCB      *)&AppTaskCreatNewFileTCB,      //Ŀ������Ŀ��ƿ�
							 (void        *)p_mem_blk2 ,             //��Ϣ���ݵ��׵�ַ
							 (OS_MSG_SIZE  )1,                     //��Ϣ����
							 (OS_OPT       )OS_OPT_POST_FIFO,      //������������Ϣ���е���ڶ�
							 (OS_ERR      *)&oserr);                 //���ش�������
				
				#endif
				   #if  !defined(SAVEFILE_BYSENSOR)
					OSTmrStart(&timer_creatnewrecfile,&oserr);						//������ʱ��
					
					char *   p_mem_blk;				 
					p_mem_blk = OSMemGet((OS_MEM      *)&mem,
									   (OS_ERR      *)&oserr);
					*p_mem_blk = RECORDER_ON;
					/* ����������Ϣ������ AppTaskRecorderTCB */
					OSTaskQPost ((OS_TCB      *)&AppTaskRecorderTCB,      //Ŀ������Ŀ��ƿ�
								 (void        *)p_mem_blk ,             //��Ϣ���ݵ��׵�ַ
								 (OS_MSG_SIZE  )1,                     //��Ϣ����
								 (OS_OPT       )OS_OPT_POST_FIFO,      //������������Ϣ���е���ڶ�
								 (OS_ERR      *)&oserr);                 //���ش�������			
								
				#endif
				return;
			}
			//---------------------У�����----------------------------------
			if((pstr[1]== TypeID)&&(pstr[4] == SERVER_ABNORMAL_MESSAGE)) 
			 {
				if(pstr[5] == SERVER_CHECK_MAC_ERR)  //MAC��֤����
				{
					if(Flag_COMDebug == 1)
					{
						printf("Server Return MAC Verify Error!\r\n");
					}
					Flag_StepStatus = STEP_SEND;
					LinkStep = CONNECTIP1;
					Flag_ErrInfo |= ERROR_NO_TOKEN2;
				}	
				if(pstr[5] == SERVER_CHECK_MD5_ERR)   //MD5��֤����
				{
					if(Flag_COMDebug == 1)
					{
						printf("Server Return MD5 Verify Error!\r\n");
					}
					LinkStep = GETTOKEN2;
					Flag_StepStatus = STEP_SEND;				
				}
				ClearUSARTBUF(LTE_UART);
				return;				
			} 	 			 
		}		
	 }
	if(Link_Time>= NETWORKLINK_TIMEOUT_10S)
	{
		Flag_StepStatus = STEP_SEND;
//		err=LTE_Query_TCPStatus();
//		if(err == LTE_TCP_CONNECT)
//		{
//			LinkStep = BACKSERVERVERFY;
//		}
//		else
		{
			LinkStep = CONNECTIP2;
		}
		if(Flag_COMDebug == 1)
		{					
			printf("Get MD5 verify time out:%s\r\n",LTEUART_RX_BUFFER);
		}
	}
	if(SentGetServerVerityCount > 6)
	{
		Flag_StepStatus = STEP_SEND;
		LinkStep = CONNECTIP1;
		Flag_ErrInfo |= ERROR_NO_TOKEN2;
	}
}
/****************************************************************************
*	�� �� ��: SendReConnectMode
*	����˵��: ��������������ԭ��
*	��    �Σ�st ��ʾ����ģʽ����Դ������������������lac��cidΪ��λ����
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendReConnectMode(uint8_t st,int lac,int cid)
{
	 uint8_t SendData[15];
	 uint8_t  i =0;
	 uint8_t jiaoyan = 0;
	
	 SendData[0] = CMD_START;	 
	 SendData[1] = TypeID;
	 SendData[2] = 0;
     SendData[3] = 0x08;	//���ݳ���8�ֽ�	
	 SendData[4] = CMD_RECONNECTMODE;
	 SendData[6] = st;
	 SendData[7] = lac/256;
	 SendData[8] = lac%256;
	 SendData[9] = cid/256;
	 SendData[10] = cid%256;
	 SendData[5] = GetDataHead(&SendData[6],5);  //����ͷ
	  
	 for(i=4;i<11;i++)
	 { 
		 jiaoyan += SendData[i];
	  }	 
	 SendData[11] = jiaoyan;
	 for(i=5;i<12;i++)
	 { 
		 SendData[i] |= 0x80;
	  }	
	 SendData[12] = CMD_LF1;
	 SendData[13] = CMD_LF2;	
	 LTE_Send_data(Socket,14,SendData);
}
/****************************************************************************
*	�� �� ��:  Req_Users_Binding
*	����˵��:  ��ѯ�Ƿ�����û�
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
void Req_Users_Binding(void)
{
	uint8_t senddata[8]={0};
	   
	senddata[0] = CMD_START;
	senddata[1] = TypeID;
	senddata[2] = 0;
	senddata[3] = 2;
	senddata[4] = REQ_BINDING_USERS;
	senddata[5] = 0xFF;
	senddata[6] = CMD_LF1;
	senddata[7] = CMD_LF2;
	LTE_Send_data(Socket,8,senddata);
	if(Flag_COMDebug == 1)
		printf("\r\n��ѯ�豸�Ƿ���û�\r\n"); 	  
}
/****************************************************************************
*	�� �� ��: Send_CARD_IMSI
*	����˵��: ���Ϳ��Ż���IMSI��
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void Send_CARD_IMSI(uint8_t *buf,uint8_t len)
{
	 uint8_t senddata[50]={0};
	 uint8_t  i =0;
	 uint8_t jiaoyan = 0;

	 uint8_t data_len=0;
    uint8_t iccid_len=strlen(SIMCard_ICCID);
    uint8_t imei_len=strlen(SIMCard_IMEI);
    senddata[data_len++] = CMD_START;
    senddata[data_len++] = TypeID;
    senddata[data_len++] = 0;
    senddata[data_len++] = iccid_len+imei_len+2;
    senddata[data_len++] = CARD_IMSI;
	
	 for(i=0;i<iccid_len;i++)
	 { 
		 senddata[data_len++] = SIMCard_ICCID[i];
       
	 }
     
	 for(i=0;i<imei_len;i++)
	 { 
		 senddata[data_len++] = SIMCard_IMEI[i];
	 }
     
	 for(i=0;i<iccid_len+imei_len+1;i++)
	 { 
		 jiaoyan += senddata[i+4];
	 }	 
	 senddata[data_len++] = jiaoyan;			
	 senddata[data_len++] = CMD_LF1;
	 senddata[data_len++] = CMD_LF2;

     LTE_Send_data(Socket,data_len,senddata);
     
     if(Flag_COMDebug == 1)
	{		 
		 printf("Send ICCID and IMEI to Server\r\n");
	}
 
}
void Send_CARD_IMEI(uint8_t *buf,uint8_t len)
{
	 uint8_t senddata[60]={0};
	 uint8_t  i =0;
	 uint8_t jiaoyan = 0;
	 uint8_t data_len=0;

    senddata[data_len++] = CMD_START;
    senddata[data_len++] = TypeID;
    senddata[data_len++] = 0;
    senddata[data_len++] = len+2;
    senddata[data_len++] = CARD_IMEI;
	senddata[data_len++] = strlen(SIMCard_ICCID);
	 for(i=0;i<len;i++)
	 { 
		 senddata[data_len++] = SIMCard_ICCID[i];
	 }
     senddata[data_len++] = strlen(SIMCard_IMEI);
	 for(i=0;i<len;i++)
	 { 
		 senddata[data_len++] = SIMCard_IMEI[i];
	 }
	 for(i=0;i<len+1;i++)
	 { 
		 jiaoyan += senddata[i+4];
	 }	 
	 senddata[data_len++] = jiaoyan;			
	 senddata[data_len++] = CMD_LF1;
	 senddata[data_len++] = CMD_LF2;
	 
	LTE_Send_data(Socket,data_len,senddata);
   if(Flag_COMDebug == 1)
	 {		 
		 printf("Send ICCID and IMEI to Server\r\n");
	}
}
/****************************************************************************
*	�� �� ��: GetServerTime
*	����˵��: ��ȡ������ʱ��
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ����
*****************************************************************************/
void GetServerTime(void)
{
	uint8_t i,jiaoyan = 0;
	uint8_t senddata[15]={0};
		   
	senddata[0] = CMD_START;
	senddata[1] = TypeID;
	senddata[2] = 0;
	senddata[3] = 8;
	senddata[4] = REQ_SERVER_TIME;
	senddata[5] =  HARDWARE_MAJORVER;
	senddata[6] =  HARDWARE_MINORVER;
	senddata[7] =  HARDWARE_TESTVER;

	senddata[8] =  SOFTWARE_MAJORVER;
	senddata[9] =  SOFTWARE_MINORVER;
	senddata[10] =  SOFTWARE_TESTVER;

	for(i=4;i<11;i++)
	{
		jiaoyan += senddata[i];	
	}
	senddata[11] = jiaoyan;
	senddata[12] = CMD_LF1;
	senddata[13] = CMD_LF2;
	LTE_Send_data(Socket,14,senddata);

}
/****************************************************************************
*	�� �� ��: HexToStr
*	����˵��: 16��������תΪ�ַ���
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void HexToStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    char ddl, ddh;
    int i;

    for (i = 0; i < nLen; i++)
    {
        ddh = 48 + pbSrc[i] / 16;
        ddl = 48 + pbSrc[i] % 16;
        if (ddh > 57) ddh = ddh + 7;
        if (ddl > 57) ddl = ddl + 7;
        pbDest[i * 2] = ddh;
        pbDest[i * 2 + 1] = ddl;
    }

    pbDest[nLen * 2] = '\0';
}
/****************************************************************************
*	�� �� ��: HexToLowerStr
*	����˵��: 16��������תΪ�ַ���
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void HexToLowerStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
    char ddl, ddh;
    int i;

    for (i = 0; i < nLen; i++)
    {
        ddh = 48 + pbSrc[i] / 16;
        ddl = 48 + pbSrc[i] % 16;
        if (ddh > 57) ddh = ddh + 39;//'9'��'a'���39
        if (ddl > 57) ddl = ddl + 39;
        pbDest[i * 2] = ddh;
        pbDest[i * 2 + 1] = ddl;
    }

    pbDest[nLen * 2] = '\0';
}
/****************************************************************************
*	�� �� ��: Comm_bcd_to_bin
*	����˵��: 16�������ݵ���10���ƣ�����ĸ����
* ˵    ������16���Ƶ�������10���ƵĿ�������ת��
*****************************************************************************/
int Comm_bcd_to_bin(uint8_t bcd)
{
	return (bcd>>4)*10 + (bcd&0x0F);
}
/****************************************************************************
*	�� �� ��:  GetDataHead
*	����˵��:  ��ȡ���ݰ�������ͷ�ֽ�
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
unsigned char GetDataHead(unsigned char* datas,unsigned char len)
{
	uint8_t DH = 0x00;
	uint8_t i = 0;
	
	for(i=0;i<len;i++)
	{
		DH |= (*(datas+i)&0x80)>>(7-i);
	}
	return  DH;
}
/****************************************************************************
*	�� �� ��: SendDataBegin
*	����˵��: ��ʼ��������
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
char SendDataBegin(void)
{
	char ch=0;
	char res = 0;
	
	if(Flag_COMDebug == 1)
	{
		printf("Check token and IP!\r\n");
	}
	
	ReadToken2FromFlash();
	if(Flag_COMDebug == 1)
	{
		printf("Token:%s\r\n",Token2);
	}	
	if((Flag_ErrInfo & ERROR_NO_TOKEN2) != ERROR_NO_TOKEN2) //�Ѿ���token����
	{	
		if((Flag_Start_Mode != START_LTE_RESTART)&&(Flag_PowerOn == 1))
		{	
			delay_ms(10);
			ReadIP2FromFlash();
			LinkStep = CONNECTIP2;		//�����֤��Ϸ���������һ��
			if(Flag_COMDebug == 1)
			{
				printf("Has token,connect IP2:%s\r\n",IP2);
			}
		}
		if(Flag_PowerOn == 0) 
		{
			LinkStep = CONNECTIP1;
			if(Flag_COMDebug == 1)
			{
				printf("Has token,connect IP1\r\n");
			}
		}			
		Flag_StepStatus = STEP_SEND;
			 
		if((Flag_ErrInfo & ERROR_NO_IP2) != ERROR_NO_IP2)  //IP2�Ѵ��ڣ����LTEģ���е�ip���бȽϣ����һ��ֱ�ӽ���У��
		{
			LinkStep = CONNECTIP2;
//			ch=LTE_Query_TCPStatus();
			if((ch==LTE_TCP_CONNECT)&&(Flag_PowerOn == 1))
			{
//				ch=LTE_ConnectIPCompare();
				if(ch==LTE_SUCCESS)
				{
					LinkStep = BACKSERVERVERFY;
//					LTE_Query_TCPConnectSocket();
				}
			}
		}
	}
	else
	{
		LinkStep = CONNECTIP1;
		Flag_StepStatus = STEP_SEND;
		if(Flag_COMDebug == 1)
		 {
				printf("No token,connect IP1\r\n");
		 }
	}

	return 1;
}
/****************************************************************************
*	�� �� ��: Send_CurrentLinkStatus  
*	����˵��: �����豸��ǰ������״̬
*	��    �Σ���
*	�� �� ֵ: 
*****************************************************************************/
void Send_CurrentLinkStatus(void)
{
	uint8_t send_data[5];
	
		if(Flag_InitStatus == WIRELESS_INIT)
		{
			 send_data[0] = CMD_REQMODULESTATUS;
			 send_data[1] = 0x01 ;
			 UART_Send_Order(BLE_UART,send_data,2);		
		}
		if(Flag_InitStatus == LINK_SERVER)
		{
			 if((LinkStep == CONNECTIP1)||(LinkStep == GETIP2))
			 {
					send_data[0] = CMD_REQMODULESTATUS;
					send_data[1] = 0x02 ;
					UART_Send_Order(BLE_UART,send_data,2);
			 }
			if((LinkStep == CONNECTIP2)||(LinkStep == GETTOKEN2)||(LinkStep == BACKSERVERVERFY))
			 {
					send_data[0] = CMD_REQMODULESTATUS;
					send_data[1] = 0x03 ;
					UART_Send_Order(BLE_UART,send_data,2);
			 }
			 if(LinkStep == SENDSLEEPDATA)
			 {
					send_data[0] = CMD_REQMODULESTATUS;
					send_data[1] = 0x04;
					UART_Send_Order(BLE_UART,send_data,2);
			 }
		}		
		SendLinkStatus_Time = 0;
		delay_ms(10);
		if(Flag_COMDebug == 1)
		{		
			printf("Send 4G link status to APP!\r\n");
			
		}
}
/****************************************************************************
*	�� �� ��: SendVerToServer
*	����˵��: ������Ӳ���汾�ŵ�������
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendVerToServer(void)
{
	uint8_t i=0;
	uint8_t jiaoyan = 0;
	uint8_t Verdata[15];

	Verdata[0] = CMD_START;
	Verdata[1] = TypeID;
	Verdata[2] =  0;
	Verdata[3] =  8;
	Verdata[4] = CMD_REQHARDSOFTVER;
	
	
    Verdata[5] =  HARDWARE_MAJORVER;
	Verdata[6] =  HARDWARE_MINORVER;
	Verdata[7] =  HARDWARE_TESTVER;

	Verdata[8] =  SOFTWARE_MAJORVER;
	Verdata[9] =  SOFTWARE_MINORVER;
	Verdata[10] =  SOFTWARE_TESTVER;

	for(i=4;i<11;i++)
	{
		jiaoyan += Verdata[i];	
	}
	Verdata[11] = jiaoyan;
	Verdata[12] = CMD_LF1;
	Verdata[13] = CMD_LF2;

	LTE_Send_data(Socket,14,Verdata);

	if(Flag_COMDebug == 1)
	{
		printf("������Ӳ���汾�ŵ�������\r\n");
	}		
}
/****************************************************************************
*	�� �� ��: SendRealTimeHRData
*	����˵��: ������������
*	��    �Σ�dat:���͵��������飬len  ���鳤��
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendRealTimeHRData(void)
{
	uint16_t i=0;
	uint8_t jiaoyan = 0;
	uint8_t HRData[1024];
    uint16_t heart_sum=0;
    uint16_t len = hearts_len;
    uint16_t data_len=0;
	HRData[data_len++] = CMD_START;
	HRData[data_len++] = TypeID;
	HRData[data_len++] =  (uint8_t)((len*4+10)/256);
	HRData[data_len++] = (uint8_t)((len*4+10)%256);
	HRData[data_len++] = 0x27;
    
    
	//mymemset(HRData,0,sizeof(HRData));
	for(i=0;i<6;i++)
	{
		HRData[data_len++] = RealTime[i];
	}
	
    HRData[data_len++] =  CSQNual;
    
	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)
        HRData[12] =1;//�ٴ�
	if((Flag_PeopleTurnforHert>0))
		HRData[12] =2;//�嶯
//    if(g_RespStatus ==1)
//        HRData[12] =7;//������ͣ
//    else if(g_RespStatus ==2)
//        HRData[12] =9;
    if(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED)
        HRData[12] =0;//�봲
    if(Status_ExtSensorOnbed == EXTSENSOR_CANNOTCAL)
        HRData[12] =5;//�޷�����
	
	data_len=13;
	for(i=0;i<len;i++)
	{
		
		
		heart_sum+= getHeartRate(hearts[0][i]);
//		HRData[14+i*2] =(uint8_t)( hearts[0][i]/256);
//		HRData[15+i*2] =(uint8_t)( hearts[0][i]%256);
//		hearts[0][i]; //����
//		hearts[1][i]; //�����ȶ���
		
		//HRData[13+i*3] = hearts[1][i];
                if(Flag_COMDebug == 1)
            printf("����ֵ��%d[%d] ",getHeartRate(hearts[0][i]),hearts[1][i]);
		HRData[data_len++] =(uint8_t)( hearts[0][i]/256);
		HRData[data_len++] =(uint8_t)( hearts[0][i]%256);		
	}
    heart_avg=heart_sum/len;
	for(i=0;i<len;i++)//������
	{
		HRData[data_len++]=hearts[1][i];
	}
    for(i=0;i<len;i++)//ƽ�ȶ�
	{
		HRData[data_len++]=hearts[2][i];
	}
    hearts_len = 0;
	for(i=4;i<data_len;i++)
	{
		jiaoyan += HRData[i];	
	}
	HRData[data_len++] = jiaoyan;
	HRData[data_len++] = CMD_LF1;
	HRData[data_len++] = CMD_LF2;
	
	
	if(Flag_COMDebug == 1)
	{
		printf("\r\n����ʵʱ���ʼ�����ݣ�");
		for(i=0;i<data_len;i++)
		{
			printf("%02x ",HRData[i]);
		}
		printf("\r\n");
	}

	if(LinkStep == SENDSLEEPDATA)
	{
		if(LTE_Send_data(Socket,data_len,HRData)==LTE_FAIL)
            AddStatistStatusData(&HRData[2],HRData[3]+2);
	}		
	else   //ͳ��
	{
        //24 11 00 0e 18 13 05 10 05 2a 32 01 01 08 c0 08 98 0b 69 42
        //+2����Ϊǰ��ĳ��ȣ�00 0e����2g�ֽ�
		AddStatistStatusData(&HRData[2],HRData[3]+2);
	}	
		
}
/****************************************************************************
*	�� �� ��: SendRealTimeRRData
*	����˵��: ���ͺ�������
*	��    �Σ�dat:���͵��������飬len  ���鳤��
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendRealTimeRRData(void)
{
	uint16_t i=0;
	uint8_t jiaoyan = 0;
	uint8_t RRData[256];
	uint16_t len = RespRate_len;
	uint16_t data_len=0;
    uint16_t breath_sum=0;
     //uint8_t test1[1500] = {0};
	RRData[data_len++] = CMD_START;
	RRData[data_len++] = TypeID;
	RRData[data_len++] = (uint8_t)((len*2+10)/256);
	RRData[data_len++] = (uint8_t)((len*2+10)%256);
	RRData[data_len++] = SEND_RRINTERTIME;
	//mymemset(RRData,0,sizeof(RRData));
	for(i=0;i<6;i++)
	{
		RRData[data_len++] = RealTime[i];
	}

	RRData[11] =1;    //�໤��
	
	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)
        RRData[12] =1;//�ٴ�
	if((Flag_PeopleTurnforHert>0))
		RRData[12] =2;//�嶯
//    if(g_RespStatus)
//        HRData[12] =7;//������ͣ
    if(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED)
        RRData[12] =0;//�봲
    if(Status_ExtSensorOnbed == EXTSENSOR_CANNOTCAL)
        RRData[12] =8;//�޷��������
    
	data_len=13;

	for(i=0;i<len;i++)
	{
        if(Flag_COMDebug == 1)
        {
             if (RespRate[1][i] == 0) 
             {
                        printf("����ֵ��%u ,��������",getRespRate(RespRate[0][i]));
             }
             else
             {
                        printf("����ֵ��0 ,������ͣ");
             
             }
                 
                 
            if (Flag_PeopleTurnforHert == 1)
            printf(" �嶯 \r\n");
            else
            printf(" ��Ϣ \r\n");
            
        }
        breath_sum+= getRespRate(RespRate[0][i]);
		RRData[data_len++] = (uint8_t)((RespRate[0][i]*40)/256);
		RRData[data_len++] = (uint8_t)((RespRate[0][i]*40)%256);	
	}
    breath_avg=breath_sum/len;
    RespRate_len =0;
	for(i=4;i<data_len;i++)
	{
		jiaoyan += RRData[i];	
	}
	
	RRData[data_len++] = jiaoyan;
	RRData[data_len++] = CMD_LF1;
	RRData[data_len++] = CMD_LF2;
	
	
	if(Flag_COMDebug == 1)
	{
		printf("\r\n����ʵʱ����������ݣ�");
		for(i=0;i<data_len;i++)
		{
			printf("%02x ",RRData[i]);
		}
		printf("\r\n");
	}
    
	if(LinkStep == SENDSLEEPDATA)
	{

        if(LTE_Send_data(Socket,data_len,RRData)==LTE_FAIL)
            AddStatistStatusData(&RRData[2],RRData[3]+2);
            
	}
	else   //ͳ��
	{
		AddStatistStatusData(&RRData[2],RRData[3]+2);
	}
																				 	 
}
/****************************************************************************
*	�� �� ��: SendNoHRData
*	����˵��: ����״̬�·���ȫ0����
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendNoHRData(uint8_t status)
{
	uint8_t i=0;
	uint8_t jiaoyan = 0;
	uint8_t HRData[50];

	HRData[0] = CMD_START;
	HRData[1] = TypeID;
	HRData[2] = 0;
	HRData[3] = 13;
    HRData[4] = SEND_HRINTERTIME;
 
	for(i=0;i<6;i++)
	{
		HRData[5+i] = RealTime[i]; 
	}

	HRData[11] =  CSQNual;

	if(status == STATUS_NOPEOPEL)
	{
		HRData[12] = 0;  //����໤
		HRData[13] = 0;
		HRData[14] = 0;	
		HRData[15] = 0;
		if(Flag_COMDebug == 1)
		{
			printf("��������״̬���ʵ�������\r\n");
		}
	}
	if(status == STATUS_NOHR)  //����������
	{
//		if(g_RespStatus ==1)
//			HRData[12] = 7;//������ͣ	
//        else if(g_RespStatus ==2)
//            HRData[12] =9;
//		else
			HRData[12] = 5;//�����޷�����
		HRData[13] = 0;
		HRData[14] = 0;	
		HRData[15] = 0;
		if(Flag_COMDebug == 1)
		{
			printf("��������������״̬��������\r\n");
		}
	}
    if(status == STATUS_HRCANNOTCAL)
    {
        HRData[12] = 5;//�����޷�����
		HRData[13] = 0;
		HRData[14] = 0;	
		HRData[15] = 0;
    }
	
    for(i=3;i<16;i++)
	{
		jiaoyan+=	HRData[i];	
	}
	HRData[16] = jiaoyan;
	HRData[17] = CMD_LF1;
	HRData[18] = CMD_LF2;
	
	if(LinkStep == SENDSLEEPDATA)
	{
		if(LTE_Send_data(Socket,19,HRData)==LTE_FAIL)
            AddStatistStatusData(&HRData[2],15);    
	}
	else
	{
		AddStatistStatusData(&HRData[2],15);
	}
		
}
/****************************************************************************
*	�� �� ��: SendPeopleTurnData
*	����˵��: �����嶯״̬
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendPeopleTurnData(uint8_t *timebuf)
{
	uint8_t i=0;
	uint8_t jiaoyan = 0;
	uint8_t HRData[50];

	HRData[0] = CMD_START;
	HRData[1] = TypeID;
	HRData[2] = 0;
	HRData[3] = 13;
    HRData[4] = SEND_HRINTERTIME;
 
	for(i=0;i<6;i++)
	{
		HRData[5+i] = timebuf[i];
	}
	
	HRData[11] =  CSQNual;
	HRData[12] = 1;   //�໤��
	
	HRData[13] = 3;
    HRData[14] = Last_Heart/256;
	HRData[15] = Last_Heart&256;		
    for(i=3;i<15;i++)
	{
		jiaoyan+=	HRData[i];	
	}
	HRData[16] = jiaoyan;
	HRData[17] = CMD_LF1;
	HRData[18] = CMD_LF2;
	
	if(Flag_COMDebug == 1)
	{
		printf("�����嶯״̬���ʵ�������\r\n");
	}
	
	if(LinkStep == SENDSLEEPDATA)
	{
		LTE_Send_data(Socket,19,HRData);
	}
	else
	{
		AddStatistStatusData(&HRData[2],15);
	}
		
}


/****************************************************************************
*	�� �� ��: SendNoRRData
*	����˵��: ����״̬�·���ȫ0����
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendNoRRData(uint8_t status)
{
	uint8_t i=0;
	uint8_t jiaoyan = 0;
	uint8_t RRData[50];

	RRData[0] = CMD_START;
	RRData[1] = TypeID;
	RRData[2] = 0;
	RRData[3] = 12;
	RRData[4] = SEND_RRINTERTIME;
    for(i=0;i<6;i++)
	{
		RRData[5+i] = RealTime[i];
	}

	if(status == STATUS_NOPEOPEL)//����
	{
		RRData[11] = 0;
		RRData[12] = 0;
		RRData[13] = 0;	
		RRData[14] = 0;
        if(Flag_COMDebug == 1)	
            printf("��������״̬������������\r\n");
	
	}
	if(status == STATUS_NORR)//�������޺���
	{
		RRData[11] = 8;
		RRData[12] = 0;
		RRData[13] = 0;	
		RRData[14] = 0;
        if(Flag_COMDebug == 1)	
            printf("�����������޺�����������\r\n");
	}
	if(status == STATUS_APNOEA)//������ͣ
	{
		RRData[11] = 7;
		RRData[12] = 0;
		RRData[13] = 0;	
		RRData[14] = 0;
        if(Flag_COMDebug == 1)	
            printf("���ͺ�����ͣ��������\r\n");
	}
    if(status == STATUS_RRCANNOTCAL)//�����޷�����
	{
		RRData[11] = 8;
		RRData[12] = 0;
		RRData[13] = 0;	
		RRData[14] = 0;
        if(Flag_COMDebug == 1)	
            printf("���ͺ�����ͣ��������\r\n");
	}
    if(status == STATUS_OBSAPNOEA)
	{
		RRData[11] = 9;
		RRData[12] = 0;
		RRData[13] = 0;	
		RRData[14] = 0;
        if(Flag_COMDebug == 1)	
            printf("���������Ժ�����ͣ��������\r\n");
	}
    
	for(i=3;i<15;i++)
	{
		jiaoyan+=	RRData[i];	
	}
	RRData[15] = jiaoyan;
	RRData[16] = CMD_LF1;
	RRData[17] = CMD_LF2;
	
	
	
	if(LinkStep == SENDSLEEPDATA)
	{
		LTE_Send_data(Socket,18,RRData);
	}
	else
	{
		AddStatistStatusData(&RRData[2],14);
	}
		
}

//���ͺ�����ͣ����&ʱ��
void SendRspStopStatus(void)
{
	uint8_t i=0;
	uint8_t jiaoyan = 0;
	uint8_t RRData[20] = {0};
	
	RRData[0] = CMD_START;
	RRData[1] = TypeID;
	RRData[2] = 0;
	RRData[3] = 11;
	RRData[4] = CMD_RESPSTOP;
	for(i=0;i<6;i++)
	{
		RRData[5+i] = RealTime[i];
	}
	RRData[11] = tp_rss[0][0];
	RRData[12] = tp_rss[1][0]/STATUS_FS;
	if(RRData[12] > (3*HRWave_Min1VataCount))
		RRData[13] = 0;
	else
		RRData[13] = 1;
	for(i=3;i<14;i++)
		jiaoyan += RRData[i];
	RRData[14] = jiaoyan;
	RRData[15] = CMD_LF1;
	RRData[16] = CMD_LF2;
	if(LinkStep == SENDSLEEPDATA)
		LTE_Send_data(Socket,17,RRData);
}
/****************************************************************************
*	�� �� ��: SendHeartWaveToserver
*	����˵��: �������ʲ���
*	��    �Σ�
*	�� �� ֵ: ���ʲ������鳤��
* 	˵    ����
*****************************************************************************/
uint16_t SendHeartWaveToserver(uint8_t *HRWData)
{
	
	uint16_t i=0;
	uint8_t jiaoyan = 0;
	uint16_t datalen = 0;
	unsigned int LastHvars = 0;
	static uint32_t coordinate = 0;   //������ֵ���ת��Ϊ����
	
	HRWData[0] = CMD_START;
	HRWData[1] = TypeID;
//	HRWData[2] = (HvarL*4+2)/256;
//	HRWData[3] = (HvarL*4+2)%256;
    
    HRWData[4] = SEND_HEARTWAVE1;
    
	
	
//	HRWData[5] =  (uint8_t)(((HvarPoint[0]/10)>>8)&0x00FF);
//	HRWData[6] =  (uint8_t)((HvarPoint[0]/10)&0x00FF);
//	HRWData[7] =  (uint8_t)(((Hvars[0]+5000)>>8)&0x00FF);
//	HRWData[8] = (uint8_t)((Hvars[0]+5000)&0x00FF);
//	LastHvars = Hvars[0];
	
	datalen = 5;
    float heart_y = 0.0f;
    uint32_t heart_x = 0;
    uint16_t heart_x_point=0;
    uint8_t ret1 = 0;
    //uint16_t left_len=0;
    uint16_t left_len = RingBuff_len(&ringBuff_heart_point);
    //if(SOFTWARE_MINORVER>5)
    {
        for(i=0;i<6;i++)
            HRWData[datalen++] = RealTime[i];
        datalen = 11;
    }
    
    for(i=1;i<left_len;i++)
	{	
//		if((HwavPiont[1][i]/10 != HwavPiont[1][i-1]/10 ) && (HwavPiont[0][i] != LastHvars ))
		{
            ret1 = Read_RingBuff(&ringBuff_heart_point ,&heart_x, &heart_y);
            
            if(ret1 == 0)
                break;
			heart_x_point += (uint16_t)heart_x;
            
			HRWData[datalen++] =  (uint8_t)(((heart_x_point/10)>>8)&0x00FF);
			HRWData[datalen++] =  (uint8_t)((heart_x_point/10)&0x00FF);
			HRWData[datalen++] =  (uint8_t)((((int)(heart_y*1.8)+5000)>>8)&0x00FF);
			HRWData[datalen++] = (uint8_t)(((int)(heart_y*1.8)+5000)&0x00FF);	
						
//			if(Flag_COMDebug == 1)
//			{
//				printf("%f,%d\r\n",heart_y,heart_x_point);
//			}
		}
	}	
	for(i=4;i<datalen;i++)
	{
		jiaoyan +=HRWData[i];	
	}
	HRWData[datalen++] = jiaoyan;
	HRWData[2] = (datalen-4)/256;
	HRWData[3] = (datalen-4)%256;
	
	HRWData[datalen++] = CMD_LF1;
	HRWData[datalen++] = CMD_LF2;
	

	if(Flag_COMDebug == 1)
	{
//		printf("���ʲ�������:");
//		for(i=0;i<HvarL*4+8;i++)
//		{
//			printf("%02x ",HRWData[i]);
//		}
//		printf("\r\n");
	}
	return datalen;
}
/****************************************************************************
*	�� �� ��: SendRespWaveToserver
*	����˵��: ���ͺ�������
*	��    �Σ�
*	�� �� ֵ: �����������鳤��
* 	˵    ����
*****************************************************************************/
uint16_t SendRespWaveToserver(uint8_t *RRWData)
{
	uint8_t i=0;
	uint8_t jiaoyan = 0;
    uint16_t datalen = 0;

	RRWData[0] = CMD_START;
	RRWData[1] = TypeID;
//	RRWData[2] = 0x00;
//	RRWData[3] = RvarL*4+2;
	RRWData[4] = SEND_RESPWAVE;

#if 0	
	RRWData[5] =  (uint8_t)(((RvarPoint[0]*40)>>8)&0x00FF);
	RRWData[6] =  (uint8_t)((RvarPoint[0]*40)&0x00FF);
	RRWData[7] =  (uint8_t)(((Rvars[0]+5000)>>8)&0x00FF);
	RRWData[8] = (uint8_t)((Rvars[0]+5000)&0x00FF);
	datalen = 9;
	if(Flag_COMDebug == 1)
	{
		printf("�����%dms  �������Σ�%d\r\n",RvarPoint[0]*40,Rvars[0]);
	}
    for(i=1;i<RvarL-1;i++)
	{
		RRWData[datalen++] =  (uint8_t)((((RvarPoint[i]-RvarPoint[i-1])*40)>>8)&0x00FF);
		RRWData[datalen++] =  (uint8_t)(((RvarPoint[i]-RvarPoint[i-1])*40)&0x00FF);
		RRWData[datalen++] =  (uint8_t)(((Rvars[i]+5000)>>8)&0x00FF);
		RRWData[datalen++] = (uint8_t)((Rvars[i]+5000)&0x00FF);
		if(Flag_COMDebug == 1)
		{
			printf("�����%dms  �������Σ�%d\r\n",(RvarPoint[i]-RvarPoint[i-1])*40,Rvars[i]);
		}
//		printf("%d,%d\r\n",RvarPoint[i],Rvars[i]);
	}
#endif	
	for(i=3;i<datalen;i++)
	{
		jiaoyan+=	RRWData[i];	
	}
	RRWData[datalen++] = jiaoyan;
	RRWData[2] = (datalen-4)/256;
	RRWData[3] = (datalen-4)%256;
	RRWData[datalen++] = CMD_LF1;
	RRWData[datalen++] = CMD_LF2;
	


	if(Flag_COMDebug == 1)
	{
//		printf("������������");
//		for(i=0;i<datalen;i++)
//		{
//			printf("%02x ",RRWData[i]);
//		}
//		printf("\r\n");
	}
	return datalen;
}
/****************************************************************************
*	�� �� ��: SendRespWaveToserver
*	����˵��: ���ͳ�����������
*	��    �Σ�RRWData �������ݣ�SampInv�������
*	�� �� ֵ: �����������鳤��
* 	˵    ����
*****************************************************************************/
uint16_t SendSampleRespWaveToserver(uint8_t *RRWData,float *rrv,uint8_t SampInv)
{
	
	uint16_t i=0;
	uint8_t jiaoyan = 0;
    uint16_t datalen = 0;
    
    int resp_x=0;
    float resp_y=0.0f;
	RRWData[0] = CMD_START;
	RRWData[1] = TypeID;
//	RRWData[2] = 0x00;
//	RRWData[3] = RvarL*4+2;
   
        RRWData[4] = SEND_RESPWAVE2;
   
   datalen=5;
	//uint16_t left_len = RingBuff_len(&ringBuff_resp_point);
   //if(SOFTWARE_MINORVER>5)
   {
         for(i=0;i<6;i++)        
            RRWData[5+i] = RealTime[i];
        
        datalen = 11;
    }
   RRWData[datalen++] =  (uint8_t)(SampInv*40/256);
   RRWData[datalen++] =  (uint8_t)(SampInv*40%256);
    //printf("RwavLen: %d\r\n",RwavLen);
  // return 0;
    for(i=0;i<RwavLen;i++)
	{
//        int ret = Read_RingBuff(&ringBuff_resp_point ,&resp_x, &resp_y);
//            
//            if(ret == 0)
//                break;
			
//		RRWData[datalen++] =  (uint8_t)(SampInv*40/256);
//		RRWData[datalen++] =  (uint8_t)(SampInv*40%256);
		RRWData[datalen++] =  (uint8_t)(((((int)rrv[i]-1500)*2+5000)>>8)&0x00FF);
		RRWData[datalen++] = (uint8_t)((((int)rrv[i]-1500)*2+5000)&0x00FF);
//        RRWData[datalen++] =  (uint8_t)(((((int)resp_y-1500)*2+5000)>>8)&0x00FF);
//		RRWData[datalen++] = (uint8_t)((((int)resp_y-1500)*2+5000)&0x00FF);
//		if(Flag_COMDebug == 1)
//		{
//////			printf("�����%dms  �������Σ�%0.2f\r\n",SampInv*40,rrv[i*SampInv]);
//			printf("�������Σ�%0.2f,%d\r\n",rrv[i*SampInv],(RRWData[datalen-2]<<8)|RRWData[datalen-1]);
            //printf("%f,%d\r\n",resp_y,resp_x);
//		}

	}
    
	RwavLen=0;
	for(i=4;i<datalen;i++)
	{
		jiaoyan+=	RRWData[i];	
	}
	RRWData[datalen++] = jiaoyan;
	RRWData[2] = (datalen-4)/256;
	RRWData[3] = (datalen-4)%256;
	RRWData[datalen++] = CMD_LF1;
	RRWData[datalen++] = CMD_LF2;
	


//	if(Flag_COMDebug == 1)
//	{
//		printf("������������");
//		for(i=0;i<datalen;i++)
//		{
//			printf("%02x ",RRWData[i]);
//		}
//		printf("\r\n");
//	}
	return datalen;
	
}

/****************************************************************************
*	�� �� ��: SendWaveDataToserver
*	����˵��: ���Ͳ���
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
//uint8_t data[2000]={0};
void SendWaveDataToserver(void)
{
	uint16_t i = 0;
	HrWaveData = mymalloc(SRAMCCM,sizeof(uint8_t)*10000);
	RrWaveData = mymalloc(SRAMCCM,sizeof(uint8_t)*10000);
	uint8_t *data = mymalloc(SRAMCCM,sizeof(uint8_t)*2000);
	float heart_y;
    u32 heart_x;
    float resp_x,resp_y;
    static u32 heart_x_point=0;
    int ret1=0;
    uint16_t left_len=0;
    uint16_t rrdatalen=0;
    uint16_t hrdatalen=0;
    u8 packages=0;
    uint16_t remainds_data=0;

    
         
	hrdatalen = SendHeartWaveToserver(HrWaveData);
	 rrdatalen = SendSampleRespWaveToserver(RrWaveData,RwavPiont,1);   //��������
	//printf("hrdatalen:%d\r\nrrdatalen:%d\r\n",hrdatalen,rrdatalen);
    if(Flag_COMDebug == 1)
    printf("hrlen:%d , rrlen:%d\r\n",hrdatalen,rrdatalen);
    if((hrdatalen+rrdatalen)>1460/*||(hrdatalen>500)||(rrdatalen>500)*/)
    { 
        if(Flag_COMDebug == 1)
        printf("RAM ERRO,WAV_DATA OUTSAIDE\r\n");
        myfree(SRAMCCM,HrWaveData);
        myfree(SRAMCCM,RrWaveData);
        myfree(SRAMCCM,data);
        return ;
    }
    
	for(i=0;i<hrdatalen;i++)
	{
		data[i] = HrWaveData[i];		
	}
	for(i=0;i<rrdatalen;i++)
	{
		data[i+hrdatalen] = RrWaveData[i];		
	}
//    for(i=0;i<6;i++)
//	{
//		RRW_StartTime[i]=HRW_StartTime[i] = RealTime[i];
//         
//	}
    /*If <access_mode> of the specified socket service is buffer access mode or direct push mode, data can be 
sent  via  AT+QISEND.  If  the  data  is  sent  to  the  module  successfully,  ��SEND  OK�� will  be  returned. 
Otherwise it will return ��SEND FAIL��or  ��ERROR��.  ��SEND FAIL��indicates the sending buffer is full and 
customers can try to resend the data. ��ERROR��indicates it encounters an error in the process of sending 
data. Customers should delay some time for the data to be sent. The maximum data length is 1460 bytes. 
��SEND  OK�� does not mean  the  data  has been  sent  to  the  server  successfully.  Customers  can  query 
whether the data has reached the server by AT+QISEND=<connectID>, 0 command.*/
	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)
	{
//		if(Flag_SendWave == ENABLE_SENDWAVE)   //lqs ����  for test
//		{
				LTE_Send_data( Socket , hrdatalen+rrdatalen , data);
				if(Flag_COMDebug == 1)
				{
						printf("\r\nTime is:%d-%d-%d %d:%d:%d\r\n",RealTime[0],RealTime[1],RealTime[2],RealTime[3],RealTime[4],RealTime[5]);
						printf("�������ʺ����������ݵ�������\r\n");
				}
//		}
	}

	myfree(SRAMCCM,HrWaveData);
	myfree(SRAMCCM,RrWaveData);
	myfree(SRAMCCM,data);

}
/****************************************************************************
*	�� �� ��: SendSampelWaveDataToserver
*	����˵��: ���Ͳ���
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendSampelWaveDataToserver(float *hrv,uint16_t hrlen,float *rrv,uint16_t rrlen)
{
	uint8_t i=0;
	uint8_t jiaoyan = 0;
    uint8_t HRWData[500];
	uint8_t RRWData[500];
	
	HRWData[0] = CMD_START;
	HRWData[1] = TypeID;
	HRWData[2] = 0x00;
	HRWData[3] = hrlen/50*4+2;
	HRWData[4] = SEND_HEARTWAVE;

//	if(Flag_COMDebug == 1)
//	{
//		printf("���ʲ���ֵ��");
//	}
    for(i=0;i<hrlen/50;i++)
	{
		HRWData[5+i*4] =  0;
		HRWData[6+i*4] =  100;
		HRWData[7+i*4] =  (uint8_t)(((int16_t)(hrv[50*i]+5000)>>8)&0x00FF);
		HRWData[8+i*4] = (uint8_t)((int16_t)(hrv[50*i]+5000)&0x00FF);
//		if(Flag_COMDebug == 1)
//		{
//			printf("%d ",(int16_t)(hrv[50*i]));
//		}
	}
//	if(Flag_COMDebug == 1)
//	{
//		printf("\r\n");
//	}
	jiaoyan = 0;
	for(i=3;i<hrlen/50*4+5;i++)
	{
		jiaoyan +=HRWData[i];	
	}
	HRWData[hrlen/50*4+5] = jiaoyan;
	HRWData[hrlen/50*4+6] = CMD_LF1;
	HRWData[hrlen/50*4+7] = CMD_LF2;
	
//	if(Flag_COMDebug == 1)
//	{
//		printf("���ʲ�������:");
//		for(i=0;i<hrlen/50*4+8;i++)
//		{
//			printf("%02x ",HRWData[i]);
//		}
//		printf("\r\n");
//	}
	
	RRWData[0] = CMD_START;
	RRWData[1] = TypeID;
	RRWData[2] = 0x00;
	RRWData[3] = rrlen/5*4+2;
	RRWData[4] = SEND_RESPWAVE;

//	if(Flag_COMDebug == 1)
//	{
//		printf("��������ֵ��");
//	}
    for(i=0;i<rrlen/5;i++)
	{
		RRWData[5+i*4] =  0;
		RRWData[6+i*4] =  200;
		RRWData[7+i*4] =  (uint8_t)(((int16_t)(rrv[5*i]+5000)>>8)&0x00FF);
		RRWData[8+i*4] =  (uint8_t)((int16_t)(rrv[5*i]+5000)&0x00FF);
//		if(Flag_COMDebug == 1)
//		{
//			printf("%d  ",(int16_t)rrv[5*i]);
//		}
	}
//	if(Flag_COMDebug == 1)
//	{
//		printf("\r\n");
//	}
	jiaoyan = 0;
	for(i=3;i<rrlen/5*4+5;i++)
	{
		jiaoyan +=RRWData[i];	
	}
	RRWData[rrlen/5*4+5] = jiaoyan;
	RRWData[rrlen/5*4+6] = CMD_LF1;
	RRWData[rrlen/5*4+7] = CMD_LF2;
//	if(Flag_COMDebug == 1)
//	{
//		printf("������������");
//		for(i=0;i<rrlen/5*4+8;i++)
//		{
//			printf("%02x ",RRWData[i]);
//		}
//		printf("\r\n");
//	}
//	SendWaveDataToserver(HRWData,hrlen/50*4+8,RRWData,rrlen/5*4+8);
//	if(Flag_COMDebug == 1)
//	{
//		printf("���ͳ������ʺ�������,���ȷֱ�Ϊ:%d  %d\r\n",hrlen/50*4+7,rrlen/5*4+7);
//	}
	
}

/****************************************************************************
*	�� �� ��: COMRetuenOneByte
*	����˵��: ���ڷ���һ���ֽڵ�����
*	��    �Σ�USARTx�������ݵĴ��ںţ�cmd���ص�ָ��data���ص�����
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void RetuenCammandToServer(uint8_t *cmd,uint8_t len)
{
	uint8_t i=0;
	uint8_t dat[25];
	uint8_t jiaoyan = 0 ;
	
	dat[0] = CMD_START;
	dat[1] = TypeID;
	dat[2] = 0;
	dat[3] = len+1;
	
	for(i=0;i<len;i++)
	{
		dat[i+4] = cmd[i];
	}
	for(i=4;i<len+4;i++)
	{
		jiaoyan += dat[i];
	}
	dat[len+4] = jiaoyan;
	dat[len+5] = CMD_LF1;
	dat[len+6] = CMD_LF2;
	

	LTE_Send_data(Socket,len+7,dat);
	
	
}

/****************************************************************************
*	�� �� ��: COMRetuenOneByte
*	����˵��: ���ڷ���һ���ֽڵ�����
*	��    �Σ�USARTx�������ݵĴ��ںţ�cmd���ص�ָ��data���ص�����
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void COMRetuenOneByte(USART_TypeDef* USARTx,uint8_t cmd,uint8_t data)
{
	 SendDataToUSART(USARTx,CMD_START);
	 SendDataToUSART(USARTx,0x01 );
	 SendDataToUSART(USARTx,3);
	 SendDataToUSART(USARTx,cmd);
	 SendDataToUSART(USARTx,data);
	 SendDataToUSART(USARTx,0xFF );
	 SendDataToUSART(USARTx,CMD_LF1 );
	 SendDataToUSART(USARTx,CMD_LF2 );
}
/****************************************************************************
*	�� �� ��:  SendDeviceVerInfoToUart
*	����˵��:  ͨ�����ڷ����豸�汾��Ϣ
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
void SendDeviceVerInfoToUart(USART_TypeDef* USARTx,char *str)
{
	uint8_t len;	

	len = strlen(str);	
	SendDataToUSART(USARTx,CMD_START);
	SendDataToUSART(USARTx,0x01 );
	SendDataToUSART(USARTx,len+2);
	SendDataToUSART(USARTx,CMD_READVER);
	while(*str != '\0')
	{
		SendDataToUSART(USARTx,*str++);
	}
	SendDataToUSART(USARTx,0xFF );
	SendDataToUSART(USARTx,CMD_LF1 );
	SendDataToUSART(USARTx,CMD_LF2 );
}
/****************************************************************************
*	�� �� ��:  SendDeviceMacToUart
*	����˵��:  ͨ������1�����豸MAC
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
void SendDeviceMacToUart(USART_TypeDef* USARTx)
{
	int i = 0;

	if(ReadMACFromFlash() == 0x01)
	{
		SendDataToUSART(USARTx,CMD_START);
		SendDataToUSART(USARTx,0x01 );
		SendDataToUSART(USARTx,MAC_Len+2);
		SendDataToUSART(USARTx,CMD_READMAC);
		for(i=0;i<MAC_Len;i++)
		{
			SendDataToUSART(USARTx,MAC_ID[i]);
		}
		SendDataToUSART(USARTx,0xFF );
		SendDataToUSART(USARTx,CMD_LF1 );
		SendDataToUSART(USARTx,CMD_LF2 );	

	}
	else  //���豸��ţ����ش���
	{
		SendDataToUSART(USARTx,CMD_START);
		SendDataToUSART(USARTx,0x01 );
		SendDataToUSART(USARTx,4);
		SendDataToUSART(USARTx,DEVICE_ABNORMAL_MESSAGE);
		SendDataToUSART(USARTx,0xFF);
		SendDataToUSART(USARTx,FLASH_No_MAC);
		SendDataToUSART(USARTx,0xFF );
		SendDataToUSART(USARTx,CMD_LF1 );
		SendDataToUSART(USARTx,CMD_LF2 );

	}
}

/****************************************************************************
*	�� �� ��:  SystemReset_CheckStatus
*	����˵��:  ���Ҹ�λ��ԭ��
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ������Դ��λ�����Ź���λ
*****************************************************************************/
void SystemReset_CheckStatus(void)
{

	if((__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST) == SET)||(__HAL_RCC_GET_FLAG(RCC_FLAG_WWDGRST) == SET))
	{
		 Flag_SystemReset = SYSTEMRESET_WATCHDOG;
		Flag_Start_Mode = START_IWDGRESET;  //���Ź���λ����
		 //if(Flag_COMDebug == 1)
				printf("\r\n���Ź���λ\r\n");
	}
	else if(__HAL_RCC_GET_FLAG(RCC_FLAG_LPWRRST) == SET)
	{
		 Flag_SystemReset = SYSTEMRESET_POWER;
		Flag_Start_Mode = START_POWERON;  //�ϵ�����
		// if(Flag_COMDebug == 1)
				printf("\r\n�͵�ѹ��λ\r\n");
	}
	else if((__HAL_RCC_GET_FLAG(RCC_FLAG_PORRST) == SET)||(__HAL_RCC_GET_FLAG(RCC_FLAG_PINRST) == SET))
	{
		 Flag_SystemReset = SYSTEMRESET_POWER;
		Flag_Start_Mode = START_POWERON;  //�ϵ�����
		// if(Flag_COMDebug == 1)
				printf("\r\n��Դ��λ\r\n");
	}
	else if(__HAL_RCC_GET_FLAG(RCC_FLAG_SFTRST) == SET)
	{
		 Flag_SystemReset = SYSTEMRESET_SOFT;
		Flag_Start_Mode = START_SOFTRESET;  //������λ����
		// if(Flag_COMDebug == 1)
				printf("\r\n������λ\r\n");
	}
	else
	{
		 Flag_SystemReset = SYSTEMRESET_UNKNOW ;
		Flag_Start_Mode = START_POWERON;  //�ϵ�����
		// if(Flag_COMDebug == 1)
				printf("\r\n����ԭ��λ\r\n");
	}
		
	
}
/****************************************************************************
* 	�� �� ��:  ArithmeticPara_Init
* 	����˵��:  �㷨��ʹ�õĲ�����ʼ��
* 	��    �Σ�
* 	�� �� ֵ:
* 	˵    ������Ҫ����������ڴ�
*****************************************************************************/
void ArithmeticPara_Init(void)
{
//	ADC_SampleData1 = mymalloc(SRAMCCM,sizeof(float)*NUM_ADCSAMBUF);	
//	ADC_SampleData2 = mymalloc(SRAMCCM,sizeof(float)*NUM_ADCSAMBUF);
//	HrWaveData = mymalloc(SRAMCCM,sizeof(uint8_t)*1000);
//	RrWaveData = mymalloc(SRAMCCM,sizeof(uint8_t)*1000);
	
}
/****************************************************************************
* 	�� �� ��:  ArithmeticPara_DeInit
* 	����˵��:  �㷨��ʹ�õĲ�������ʼ��
* 	��    �Σ�
* 	�� �� ֵ:
* 	˵    ������Ҫ�ͷ�������ڴ�
*****************************************************************************/
void ArithmeticPara_DeInit(void)
{
//	myfree(SRAMCCM,HrWaveData);//�ͷ��ڴ�
//	myfree(SRAMCCM,RrWaveData);//�ͷ��ڴ�
//	myfree(SRAMCCM,ADC_SampleData1);//�ͷ��ڴ�
//	myfree(SRAMCCM,ADC_SampleData2);//�ͷ��ڴ�
}
/**************************************************/
//#define BASE_LINE 1500
//#define S_INIT_LEN 10
//float signal_maxs[S_INIT_LEN];
//int signal_max_len = 0;
//float signal_max = 0;
//int signal_max_c = 0;
//float signal_avg = 0;
//int mutation_c = FREQUENCY;
//int mutation_delay_c = 0;


//void initSignalAvg(){
//		for (int i = 0; i < S_INIT_LEN; i++) {
//			signal_maxs[i] = 0;
//		}
//		signal_avg = 0;
//}

//void addsignalMaxs() {
//		if (signal_max_len >= S_INIT_LEN)
//			signal_max_len = 0;

//		signal_maxs[signal_max_len] = signal_max;
//		signal_max_len++;
//		signal_max = 0;// ��ʼ�����ֵ
//}

//int judeMoveBody(float signal) {
//		// �����嶯�����ź�
//		if (signal > SIGNAL_MAX || signal < SIGNAL_MIN) {
//			signal_count = 0;
//			return 1;
//		}
//		//�źų��ֱ��ͺ󣬼����ӳ�4S�ӣ����˲�
//		if (signal_count < SIGNAL_NUM) {
//			signal_count++;
//			return 1;
//		}
//		
//		//����1�����źŶ���ͻ��״̬���������û���λ�����˱仯����Ҫ��ʼ��ԭ����
//		if (mutation_delay_c >= FREQUENCY * 60) {
//			initSignalAvg();
//		}
//		
//		// ���ź�ͻ��ʶ�� �źŲ���ͻ�䣬����2���ľ�ֵ�ź�
//		if (signal_avg > 0 && (signal - BASE_LINE) > (signal_avg - BASE_LINE) * 2) {
//			mutation_c = 0;// �ź�����ı����
//			mutation_delay_c++;
//			return 2;// �ź�ͻ��
//		}
//		
//		//�źŷ���ͻ�䣬�ڽ���ͻ��󣬼����ӳ�1S��
//		if (mutation_c < FREQUENCY) {
//			mutation_c++;
//			mutation_delay_c++;
//			return 2;
//		}

//		signal_max_c++;
//		// �ҵ��ź����ֵ
//		if (signal_max < signal) {
//			signal_max = signal;
//		}
//		// 1���Ӵ洢���ֵ1�Σ�����ʼ�����ֵ
//		if (signal_max_c >= FREQUENCY) {
//			addsignalMaxs();
//			signal_max_c = 0;// ��ʼ��������
//		}

//		float sum = 0;
//		int num = 0;
//		for (int i = 0; i < S_INIT_LEN && 0 != signal_maxs[i]; i++) {
//			sum += signal_maxs[i];
//			num++;
//		}

//		if (num == S_INIT_LEN)
//			signal_avg = sum / num;

//		return 0;
//	}





/****************************************************************************
* 	�� �� ��:  CalculateHrRrData
* 	����˵��:  ���ʺͺ����˲��ͼ���
* 	��    �Σ�
* 	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
//float signals[SHIFTEDLEN];
int signalsLen = 0;
int shilftPoint =0 ;
//��ʼ������
void Arg_init(){
//    turnMutationRange = 3000;  //�嶯ͻ�����
//    turnSMaxRange = 3700;  //�嶯�����ź�������
//    turnSMinRange = 20;  //�嶯�����ź���С����
//    turnLowRange = 300;  //1S�����С�źŵ��ڸ÷���ʱ�����ж��嶯
//    respReduce = 0.3;//�������οsС����
     //   turn_m_range = 3000;  //�嶯ͻ�����
    //turn_s_ma_range = 3700;  //�嶯�����ź�������
    //turn_s_mi_range = 20;  //�嶯�����ź���С����
    //turn_l_range = 300;  //1S�����С�źŵ��ڸ÷���ʱ�����ж��嶯
    respReduce = 0.3;//�������οsС����
}
	
	
void CalculateHrRrData(void)
{
	OS_ERR      err;
    
    static unsigned int flagDownSampleRespHr = 0,flagDownSampleResp = 0;
    int fv = 150;
//    static float signalb[SHIFTEDLENB];
    static unsigned int shilftPoint = 0;
    static unsigned int signalsLen = 0;
	uint16_t i,j ;
    static u16 last_HwavLen=0;
    u32 pointx=0;
   
    float signalh,signalr;
    u32  time1=0,time2=0;
    uint32_t val_heart = 0;
    uint32_t val_breath = 0;
    char read_str[20]={0};
    float test_signalh=0;
    static u8 last_heart_len=0;
    static u8 last_resp_status=0;
    Arg_init();
    u16 simp_len=RingBuff_len(&ringBuff_ori);
	//if(simp_len>=NUM_CALCULATE)
	{
        //printf("%d\r\n",SimpleDataNum);
		//for(i=0;i<NUM_CALCULATE;i++)
		{
            int ret=0;
            float signal=0.0f;
                    
            ret = Read_RingBuff(&ringBuff_ori,&val_heart,&val_breath);

            signal=val_heart;  
            float signalrr=val_breath; 
            if(ret == 0 )
                return; 

            //turnOverTimes(signal);
            arithmeticHearts(signal);
            
            arithmeticResps(signalrr);
            //�����Ժ�����ͣ����
//            arithmeticAhi(signalrr);
            
            Flag_PeopleTurnforHert=move_body;
            //printf("gPeopleFlag=%d\r\n",gPeopleFlag);
            Status_ExtSensorOnbed = gPeopleFlag;
			if (hearts_len > 0) 
			{

				NoHeartTime = 0;
//				for (int j = 0; j < hearts_len; j++) 
//				{

//					
//                printf("����ֵ��%i",  getHeartRate(hearts[0][j]));
//                printf("[%i]", (int) hearts[1][j]);
                //printf("hearts_len = %d\r\n",hearts_len);
                if(last_heart_len!=hearts_len)
                {
                    last_heart_len=hearts_len;
                if (move_body == 0)
                    //printf(" ��Ϣ\r\n");
                ;
                else
                   // printf(" �嶯\r\n");
                ;
                }                
//					
//				}

				Last_Heart = hearts[0][hearts_len-1];
				//hearts_len = 0;
			}	
           // printf("hearts_len : %d\r\n",hearts_len);
            
				
				
								
				
								
//				if(resp_status==1)
//                {
//                    if(resp_status!=last_resp_status)
//                        printf("������ͣ\r\n");
//                }
//				last_resp_status=resp_status;		
				if(RespRate_len > 0)
				{
						NoRespTime = 0;
                        if(RespRate_len>20)
                            RespRate_len=0;
                        //printf("RespRate_len = %d\r\n",RespRate_len);
						for (int j = 0; j < RespRate_len; j++) 
						{
							
							
//                               if (RespRate[1][j] == 0) 
//                               {
//                                        resp_status=0;
////                                    printf("����ֵ��[%d] ,��������", getRespRate(RespRate[0][j]));
//                               } 
//                               else 
//                               {
//                                            resp_status=1;
//                                            
////                                    printf("����ֵ��[0] ,������ͣ");
//                               }
//                                if (move_body >0)
//                                    printf(" �嶯 \r\n");
//                                else
//                                    printf(" ��Ϣ \r\n");											
							
							
							
							   
							
						}
						
						Last_Resp = RespRate[0][RespRate_len-1];
												
						
						//RespRate_len = 0;
                        //memset(RespRate,0,sizeof(RespRate));
				}
//             int heartx;
//             float hearty;
            if(HwavLen>0)
            {
                if(HwavLen>300)
                            HwavLen=300;
                //printf("HwavLen = %d\r\n",HwavLen);
                 for (int z = 0; z < HwavLen; z++) 
                {

//                  
                     pointx=HwavPiont[1][z];
                  
                     Write_RingBuff(&ringBuff_heart_point,&pointx,&HwavPiont[0][z]);
                    
                }

                HwavLen=0;
                memset(HwavPiont,0,sizeof(HwavPiont));
            }
                      
            if(RwavLen>0)
            {
                if(RwavLen>300)
                            RwavLen=300;
                static u32 x=0;
                //printf("RwavLen = %d\r\n",RwavLen);
                for (int j = 0; j < RwavLen; j++) 
                {
                    
                    //pointx=RwavPiont[j];
                    //if(x%2==1)

                       // Write_RingBuff(&ringBuff_resp_point,&x,&RwavPiont[j]);
                        //Read_RingBuff(&ringBuff_resp_point ,&respx, &ringBuff_resp_point);
                    //x++;
                    //printf("%f\r\n",respx);
                }
               // RwavLen=0;
                //memset(RwavPiont,0,sizeof(RwavPiont));
            }
//			time2=OS_TS_GET();
//            printf("%d\r\n",time2-time1);
	
		}

	}
		
}

/****************************************************************************
*	�� �� ��:  SendOXHrDataToServer
*	����˵��:  ����Ѫ�����ʺ�������
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
void SendOXHrDataToServer(void)
{
	uint16_t i = 0;
	uint8_t jiaoyan = 0;
	uint8_t OXHRData[1024];
    uint16_t heart_sum = 0;
    uint16_t data_len = 0;
    
	OXHRData[data_len++] = CMD_START;
	OXHRData[data_len++] = TypeID;
	OXHRData[data_len++] = (uint8_t)((9)/256);
	OXHRData[data_len++] = (uint8_t)((9)%256);
	OXHRData[data_len++] = SEND_OXHRDATA;
    
    
	for(i=0;i<6;i++)
	{
		OXHRData[data_len++] = RealTime[i];
	}
    
	//for(i=0;i<len;i++)
	{
		OXHRData[data_len++] = spo2information.heart_breas;//OXHrData_Array[i];
    }
    //OXHrDataNum_Count = 0;
    //memset(OXHrData_Array, 0, sizeof(OXHrData_Array));
	for(i=4;i<data_len;i++)
	{
		jiaoyan += OXHRData[i];	
	}
	OXHRData[data_len++] = jiaoyan;
	OXHRData[data_len++] = CMD_LF1;
	OXHRData[data_len++] = CMD_LF2;
	
	

	if((LinkStep == SENDSLEEPDATA)&&(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEOFFBED))     //lqs change �봲����
	{
        LTE_Send_data(Socket,data_len,OXHRData);
	}		
	else   //ͳ��
	{
        //24 11 00 0e 18 13 05 10 05 2a 32 01 01 08 c0 08 98 0b 69 42
        //+2����Ϊǰ��ĳ��ȣ�00 0e����2g�ֽ�
		
        //AddStatistStatusData(&OXHRData[2],OXHRData[3]+2);
	}	
}
/****************************************************************************
*	�� �� ��:  SendOXPulseWaveToServer
*	����˵��:  �������ʲ���
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
void SendOXPulseWaveToServer(void)
{
    uint16_t i = 0;
	uint8_t jiaoyan = 0;
	uint8_t OXPulseWaveData[300];
    uint16_t heart_sum = 0;
    uint16_t len = 8+Pulse_Wave_Data_Num;
    uint16_t data_len = 0;
    
	OXPulseWaveData[data_len++] = CMD_START;
	OXPulseWaveData[data_len++] = TypeID;
	OXPulseWaveData[data_len++] = (uint8_t)(len/256);
	OXPulseWaveData[data_len++] = (uint8_t)(len%256);
	OXPulseWaveData[data_len++] = SEND_OXWAVE;
    
    
	for(i=0;i<6;i++)
	{
		OXPulseWaveData[data_len++] = RealTime[i];
	}
    
	for(i=0;i<Pulse_Wave_Data_Num;i++)
	{
		OXPulseWaveData[data_len++] = OX_Pulse_Wave_Data[i];
    }
    
    Pulse_Wave_Data_Num = 0;
    memset(OX_Pulse_Wave_Data, 0, sizeof(OX_Pulse_Wave_Data));
	
    for(i=4;i<data_len;i++)
	{
		jiaoyan += OXPulseWaveData[i];	
	}
	OXPulseWaveData[data_len++] = jiaoyan;
	OXPulseWaveData[data_len++] = CMD_LF1;
	OXPulseWaveData[data_len++] = CMD_LF2;
	
	if(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEOFFBED)     //lqs change �봲����
    LTE_Send_data(Socket,data_len,OXPulseWaveData);
	
}

/****************************************************************************
*	�� �� ��:  SendHrRrDataToServer
*	����˵��:  �������ʺ�������
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
void SendHrRrDataToServer(void)
{
	uint8_t i = 0;
	float averageresp  = 0;
	OS_ERR    err;
//	printf("gPeopleFlag:%d,		hearts_len:%d,RespRate_len:%d\r\n",Status_ExtSensorOnbed,hearts_len,RespRate_len); //test code
	if((Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)&&(hearts_len == 0)&&(NoHeartTime<15))  //15s���������������ʹ����һ�ε�����ֵ
	{
		 hearts[0][0] = Last_Heart;
		 hearts_len = 1;
	}
	if((Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)&&(RespRate_len == 0)&&(NoRespTime <6))   //15s��������޺���ֵ����ʹ����һ�εĺ���������15s��Ϊ�޺���
	{
		RespRate[0][0] = Last_Resp;
		RespRate_len = 1;
	}
//	if((Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)&&(RespRate_len == 0))
//	{
//		RespRate[0] =  (uint16_t)(avgRespFilter(0));
//		if(RespRate[0]>0)
//			RespRate_len = 1;
//		else
//			RespRate_len = 0;
//	}
	//--------------��������------------------------
	if((Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)&&(hearts_len > 0))
	{
		SendRealTimeHRData();				//������������		
	}
	else if((Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)&&(hearts_len == 0))    //���������ʺ���
	{
		SendNoHRData(STATUS_NOHR);						
	}
    else if(Status_ExtSensorOnbed == EXTSENSOR_CANNOTCAL)
    {
            SendNoHRData(STATUS_HRCANNOTCAL);
    }
	else
	{
		SendNoHRData(STATUS_NOPEOPEL);
	}
	
//	for(i=0;i<6;i++)
//	{
//		HR_StartTime[i] = RealTime[i];
//	}
	OSTimeDly ( 10, OS_OPT_TIME_DLY, & err );
	//------------���ͺ���--------------------------
//	g_RespStatus = getRespStatus();   //lqs add  ���ô˻�ȡ����״̬
	HRWave_Min1VataCount++;
	if(HRWave_Min1VataCount > 40)
		HRWave_Min1VataCount = 41;
	if(tpLen > 0)
	{
		printf("������ͣ����:%d  ����ʱ����%d\r\n",tp_rss[0][0],tp_rss[1][0]/STATUS_FS);
		SendRspStopStatus();          //���ͺ�����ͣ������&ʱ��
		moveArrayStatus();            //���øò���ʵ������״̬����
		HRWave_Min1VataCount = 0;
		return;
	}
//	if((Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)&&(g_RespStatus ==1))  //������ͣ
//	{
//		SendNoRRData(STATUS_APNOEA);
//	}	
//	if((Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)&&(g_RespStatus ==2))  //������ͣ
//	{
//		SendNoRRData(STATUS_OBSAPNOEA);
//	}			
	if((Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)&&(RespRate_len > 0))
	{
		SendRealTimeRRData();				//���ͺ�������	
	}
	else if((Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)&&(hearts_len>0)&&(RespRate_len == 0))    //�����������޺���
	{
		SendNoRRData(STATUS_NORR);			
	}
	else if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEOFFBED)//
	{
		SendNoRRData(STATUS_NOPEOPEL);

	}			
	else if(Status_ExtSensorOnbed == EXTSENSOR_CANNOTCAL)//
	{
		SendNoRRData(STATUS_RRCANNOTCAL);

	}	    
//	for( i=0;i<6;i++)
//	{
//		RR_StartTime[i] = RealTime[i];
//	}
		
   	
}
#if 0
/*******************************************************************************
*	�� �� ��:  SendApnoeaStatus
*	����˵��:  ���ͺ�����ͣ״̬
*	��    �Σ� 
*	�� �� ֵ:
* 	˵    ����
*******************************************************************************/
void SendApnoeaStatus(void)
{
	uint8_t i=0;
	uint8_t jiaoyan = 0;
	uint8_t RRData[15];

	RRData[0] = CMD_START;
	RRData[1] = TypeID;
	RRData[2] = 0;
	RRData[3] = 12;
	RRData[4] = SEND_APNOEA;
	RRData[5] = 1;
	
    for(i=0;i<6;i++)
	{
		RRData[6+i] = RealTime[i];
	}	
	for(i=4;i<12;i++)
	{
		jiaoyan+=	RRData[i];	
	}
	RRData[12] = jiaoyan;
	RRData[13] = CMD_LF1;
	RRData[14] = CMD_LF2;
	
	if(Flag_InitStatus == CONTINUE_SENDDATA)
	{
		LTE_Send_data(Socket,15,RRData);
	}
	else
	{
		AddStatistStatusData(&RRData[2],11);
	}
	if(Flag_COMDebug == 1)
	{
		printf("���ͺ�����ͣ״̬��������\r\n");
	}
}
#endif
/*******************************************************************************
*	�� �� ��:  SaveStartNewStatistStatusData
*	����˵��:  �����µ�ͳ�����ݵĿ�ʼ
*	��    �Σ� 
*	�� �� ֵ:
* 	˵    ����
*******************************************************************************/
void  SaveStartNewStatistStatusData(void)
{
	uint8_t i=0;
	char printfstr[50];
    
	StaticsSleepDataBuffTime = 0;
	
	StaticsSleepDataBuffLen = 7;
	StaticsSleepDataBuffer[0]=CMD_START;
	StaticsSleepDataBuffer[1]=TypeID;
	StaticsSleepDataBuffer[2]=(uint8_t)(StaticsSleepDataBuffLen/256);
	StaticsSleepDataBuffer[3]=(uint8_t)(StaticsSleepDataBuffLen%256);
	StaticsSleepDataBuffer[4]=SEND_DISCONNECT_HRRRTIME;
	StaticsSleepDataBuffer[5]=(uint8_t)(StaticsSleepDataSaveNum/256);
	StaticsSleepDataBuffer[6]=(uint8_t)(StaticsSleepDataSaveNum%256);


	if(Flag_COMDebug == 1)
	{
		printf("\r\n---------Save New Statistics Data:%d-----------\r\n",StaticsSleepDataSaveNum);
		printf("Start Time is:%d-%d-%d %d:%d:%d\r\n",RealTime[0],RealTime[1],RealTime[2],RealTime[3],RealTime[4],RealTime[5]);	 
	}	
		
}
/*******************************************************************************
*	�� �� ��:  AddStatistStatusData
*	����˵��:  ��Ҫ���͵�����������һ���µ����ʺ�����ֵ
*	��    �Σ� *buf���ӵ�����  len���ӵ����ݳ���
*	�� �� ֵ:
* 	˵    ����
*******************************************************************************/
void AddStatistStatusData(uint8_t *buf,uint8_t len)
{
	uint16_t i = 0;
	/*lqs test    begin*/
	if(StaticsSleepDataBuffLen == 0)  //�������һҳ���ݣ���Ҫ��д��֡ͷ����Ϣ
	{
		SaveStartNewStatistStatusData();
	}
	/*lqs test    end*/
	if((StaticsSleepDataBuffTime>=30)||(StaticsSleepDataBuffLen+len>1024))
	 {
		 EndStatistStatusData();
	 }
	 for(i=0;i<len;i++)
	 {
		StaticsSleepDataBuffer[StaticsSleepDataBuffLen++] = buf[i]; 
	 }
    
//	 if(Flag_COMDebug == 1)
//	 {
//			printf("\r\nAdd %dByte data in StaticsSleepDataBuffer\r\n",len);
//		    for(i=0;i<StaticsSleepDataBuffLen;i++)
//			{
//				printf("%02x ", StaticsSleepDataBuffer[i]);
//			}
//			printf("\r\n");
//	 }
	 


}
/*******************************************************************************
*	�� �� ��:  EndStatistStatusData
*	����˵��:  ��������ͳ������
*	��    �Σ� 
*	�� �� ֵ:
* ˵    ����������������,�������ݵ�flash�У��������ݵ�������
*******************************************************************************/
void  EndStatistStatusData(void)
{
	 uint16_t i=0;
	 uint8_t jiaoyan=0;
	 
	
	StaticsSleepDataBuffer[2]=(uint8_t)((StaticsSleepDataBuffLen-3)/256);
	StaticsSleepDataBuffer[3]=(uint8_t)((StaticsSleepDataBuffLen-3)%256);

	
	 for(i=4;i<StaticsSleepDataBuffLen;i++)
	 {
		  jiaoyan += StaticsSleepDataBuffer[i];
	 }
	 StaticsSleepDataBuffer[StaticsSleepDataBuffLen++]=jiaoyan;
	 StaticsSleepDataBuffer[StaticsSleepDataBuffLen++]=CMD_LF1;
	 StaticsSleepDataBuffer[StaticsSleepDataBuffLen++]=CMD_LF2;

	if(Flag_COMDebug == 1)
	{
		printf("StaticsSleepDataBuffer:%d is end,data len:%d\r\n\r\n",StaticsSleepDataSaveNum,StaticsSleepDataBuffLen);
	}
	
	 StaticsSleepDataSaveNum++;
	 if(StaticsSleepDataSaveNum>MAXSAVESLEEPDATANUM)
	 {
		 StaticsSleepDataSaveNum = MAXSAVESLEEPDATANUM;
//		 if(StaticsSleepDataSendNum == 0)
//		 {
//			 StaticsSleepDataSendNum = 8;  //�����ʱ���ɾ��4k�����ݣ���8��
//		 }
	 }
	 
//------------�������ݵ�flash��----------------------
	 SaveSleepDataToFlash();
   
//---------��������--------------------
 	 SaveSleepDataPosIndexToFlash(StaticsSleepDataSaveNum,StaticsSleepDataSendNum);
//------------------��һ�������ʼ��-----------------------		 
	if(LinkStep != SENDSLEEPDATA)	 
		SaveStartNewStatistStatusData();

}
/****************************************************************************
*	�� �� ��: ReadSleepDataPosIndexFromFlash
*	����˵��: ��flash�б����˯�����ݵ����һ��λ��
*	��    �Σ���
*	�� �� ֵ: ��������λ��
* 	˵    ����
*****************************************************************************/
char ReadSleepDataPosIndexFromFlash(void)
{
	uint8_t dat[5];
	W25QXX_Read(dat, FLASH_SaveSleepDataIndexAddress, 5);
	if(dat[0] == Flag_FirstRun)
	{
		StaticsSleepDataSaveNum = dat[1]*256+dat[2];
		StaticsSleepDataSendNum = dat[3]*256+dat[4];
		if(StaticsSleepDataSendNum>StaticsSleepDataSaveNum)
		{
			StaticsSleepDataSaveNum = 0;
			StaticsSleepDataSendNum = 0;
			SaveSleepDataPosIndexToFlash(0,0);
		}
	}
	else
	{
		StaticsSleepDataSaveNum = 0;
		StaticsSleepDataSendNum = 0;
		SaveSleepDataPosIndexToFlash(0,0);
	}

//	if(Flag_COMDebug == 1)
//	{
//		printf("StaticsSleepDataSaveNum=%d,StaticsSleepDataSendNum=%d\r\n",StaticsSleepDataSaveNum,StaticsSleepDataSendNum);		
//	}
	return 	1;	
}
/****************************************************************************
*	�� �� ��: SaveSleepDataPosIndexToFlash
*	����˵��: ��������ʹ�õĴ洢�ͷ��͵����ݱ�ű��
*	��    �Σ���
*	�� �� ֵ: ��������λ��
* 	˵    ����
*****************************************************************************/
char SaveSleepDataPosIndexToFlash(uint16_t savenum,uint16_t sendnum)
{
	 uint8_t dat[5];
	
	 dat[0] = Flag_FirstRun;	
	 dat[1] = (uint8_t)(savenum/256);
	 dat[2] = (uint8_t)(savenum%256);
	 dat[3] = (uint8_t)(sendnum/256);
	 dat[4] = (uint8_t)(sendnum%256);
	
	 W25QXX_Erase_Sector(FLASH_SaveSleepDataIndexAddress);
	 W25QXX_Write_Page(dat,FLASH_SaveSleepDataIndexAddress,5);
	
	 return 1;	
}
/****************************************************************************
*	�� �� ��: SaveSleepDataToFlash
*	����˵��: ����˯������
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
char SaveSleepDataToFlash(void)
{
	uint8_t dat[1024];
	uint16_t i = 0;
	uint32_t addr=0;

	addr = FLASH_SaveSleepDataStartAddress+0x200*(StaticsSleepDataSaveNum-1);  //512���ֽ�һ������
	/*lqs test    begin*/
	//lqs test    ���ӱ߽��ж�
	if(addr > FLASH_SaveSleepDataEndAddress)    //�ѵ���߽磬��ͷ��ʼ
	{
		addr = addr%FLASH_SaveSleepDataEndAddress - 0x200 + FLASH_SaveSleepDataStartAddress;
	}
	/*lqs test    end*/
	
	 if(addr%4096==0)
	 {
		W25QXX_Erase_Sector(addr);
	 }
		
	 dat[0] = (uint8_t)(StaticsSleepDataBuffLen/256);    //���鳤��
	 dat[1] = (uint8_t)(StaticsSleepDataBuffLen%256);
	
	 for(i=0; i<StaticsSleepDataBuffLen;i++)
	 {
		 dat[i+2] = StaticsSleepDataBuffer[i];
	 }			 
	 W25QXX_Write_Page(dat,addr, StaticsSleepDataBuffLen+2);
	
	 if(Flag_COMDebug == 1)
	{
		printf("Save statics data No:%d,data len:%d!\r\n",StaticsSleepDataSaveNum-1,StaticsSleepDataBuffLen);
		for(i=0;i<StaticsSleepDataBuffLen;i++)
		{
			printf("%02x ",StaticsSleepDataBuffer[i]);
		}
		printf("\r\n");
	}
	 
   return 1;
}
/****************************************************************************
*	�� �� ��: SendFlashSavedSleepDataToServer
*	����˵��: ��flash�б����˯�����ݷ��͵�������
*	��    �Σ�num ��Ҫ���͵�˯�����ݵı��
*	�� �� ֵ: err NBģ�������Ƿ��ͳɹ�
* 	˵    ����
*****************************************************************************/
char SendFlashSavedSleepDataToServer(uint16_t num)
{
	uint16_t i = 0;
	uint16_t sendno = 0;
	uint8_t dat[512] ={0};
	uint16_t len=0;
	uint32_t addr=0;
	char err = 0;

	addr = FLASH_SaveSleepDataStartAddress+0x200*num;
	/*lqs test    begin*/
	//lqs test    ���ӱ߽��ж�
	if(addr > FLASH_SaveSleepDataEndAddress)    //�ѵ���߽磬��ͷ��ʼ
	{
		addr = addr%FLASH_SaveSleepDataEndAddress - 0x200 + FLASH_SaveSleepDataStartAddress;
	}
	/*lqs test    end*/
	
	W25QXX_Read(dat,addr,2);
	len = dat[0]*256+dat[1];
	if(len <= 512)
	{
		W25QXX_Read(dat,addr+2,len);
	}
	sendno = dat[5]*256+dat[6];
	if((dat[0] == CMD_START)&&(dat[1] == TypeID)&&(dat[len-2] == CMD_LF1)&&(dat[len-1] == CMD_LF2)&&(sendno == num))  //��һ���������������ͣ���������
	{
	
		err=LTE_Send_data(Socket,len,dat);
		if(err == LTE_FAIL)
		{
			LTE_Send_data(Socket,len,dat);
		}
		if(Flag_COMDebug == 1)
		{
			printf("Send statics data No:%d,data len:%d!\r\n",num,len);
			for(i=0;i<len;i++)
			{
				printf("%02x ",dat[i]);
			}
			printf("\r\n");
		}
		delaytime1 = 0;
		while(1)
		{
			delay_ms(10);
			if(strstr(LTEUART_RX_BUFFER,"+QIURC: \"recv\""))  //�յ�������ָ��
			{
				Server_Order_Dispose();
				return LTE_SUCCESS;
			}
			if(delaytime1>1)
			{
				return err;
			}				
		}
	}
	else
	{
		if(Flag_COMDebug == 1)
		{
			printf("Statics data No:%d err!\r\n",num);
//			for(i=0;i<len;i++)
//			{
//				printf("%02x ",dat[i]);
//			}
		}
		SleepDataBuffer_SendTime = 4;
		StaticsSleepDataSendNum++;
		if(StaticsSleepDataSendNum >= StaticsSleepDataSaveNum)
		{
			Flag_CanSendStatistData = 0;
			StaticsSleepDataSendNum = 0;
			StaticsSleepDataSaveNum = 0;
			StaticsSleepDataSendCount = 0;			
		}
		SaveSleepDataPosIndexToFlash(StaticsSleepDataSaveNum,StaticsSleepDataSendNum);
		return LTE_FAIL;
	}
	
	
}
/****************************************************************************
*	�� �� ��: SaveMACToFlash
*	����˵��: �����豸MAC
*	��    �Σ���
*	�� �� ֵ: 0x01
* 	˵    ����
*****************************************************************************/
char SaveMACToFlash(void)	
{ 
	uint8_t dat[70]={0};
	uint8_t i;
	uint8_t err = 0;
	uint8_t maclen = strlen(MAC_ID);
    uint8_t iccidlen = strlen(SIMCard_ICCID);
    uint8_t imeilen = strlen(SIMCard_IMEI);
	uint8_t savecount=0;
	W25QXX_Erase_Sector(FLASH_MAC_NewAddress);
//	W25QXX_Erase_Sector(FLASH_MAC_BackUpAddress);
	dat[0] = Flag_FirstRun; 
	dat[1] = MAC_Len;	  //�豸��ų���
//	for(i=0; i<MAC_Len;i++)
//	{
//	 dat[i+2] = MAC_ID[i];
//	}
//	dat[MAC_Len+2] = len;
//	for(i=0;i<len;i++)
//	{
//		dat[MAC_Len+3+i] = SIMCard_ICCID[i];
//	}
    savecount=2;
	for(i=0;i<MAC_Len;i++)
        dat[savecount++] = MAC_ID[i];
    dat[savecount++] =iccidlen;
    for(i=0;i<iccidlen;i++)
        dat[savecount++] = SIMCard_ICCID[i];
    dat[savecount++] =imeilen;
    for(i=0;i<imeilen;i++)
        dat[savecount++] = SIMCard_IMEI[i];
//	W25QXX_Write_Page(dat,FLASH_EquipmentInfoAddress, 70);	   //lqs test  ����
	W25QXX_WriteVariable(dat,FLASH_MAC_NewAddress, 70);
	SaveMACTo_InsideFlash();
	return 1;
}

char SaveMACTo_InsideFlash(void)	
{ 
	uint32_t dat[30];
	uint8_t i;
	uint8_t err = 0;
	  
	dat[0] = (uint32_t)Flag_FirstRun; 
	dat[1] = 12;	  //�豸��ų���
	for(i=0; i<12;i++)
	{
		dat[i+2] = (uint32_t)MAC_ID[i];
	}		
	
	STMFLASH_Write(STM32_FLASH_MAC,dat, 14);
	Flag_ErrInfo &= ~ERROR_N0_MAC;
	return 1;
}

/****************************************************************************
*	�� �� ��: ReadMACFromFlash
*	����˵��: ���豸MAC
*	��    �Σ���
*	�� �� ֵ: ����1��ʾ��ȷ��ȡ������0��ʾ��һ�γ���������δ��ʼ��
* 	˵    ����
*****************************************************************************/

char ReadMACFromFlash(void)	
{
	uint8_t dat[70] ={0};
	uint8_t i=0;
	uint8_t readcount=0;
//	W25QXX_Read(dat, FLASH_EquipmentInfoAddress, 70); 
	
	/*
	 * �Ծɳ��������޸ģ�Ų����MAC��ַ��λ��   //lqs test ����
	 * �ȶ��µ�MAC��ַ���ж�ȡ�����û����Ӿɵ�ַ��ȡ���������д���µĵ�ַ
	 */	
	if(W25QXX_ReadVariable(dat, FLASH_MAC_NewAddress, 70) == 1)  //��ȡʧ��
	{
		W25QXX_Read(dat, FLASH_EquipmentInfoAddress, 70);  //�Ӿɵ�ַ��ȡ
		if(dat[0] == Flag_FirstRun)
		{
			MAC_Len=dat[1];	
			readcount=2;
			for(i=0;i<MAC_Len;i++)
			{
				MAC_ID[i] = dat[readcount++];
			}
			ICCID_LEN =  dat[readcount++];
			for(i=0;i<ICCID_LEN;i++)
			{
				ICCID_Save[i] = dat[readcount++];
			}
			IMEI_LEN = dat[readcount++];
			for(i=0;i<IMEI_LEN;i++)
			{
				IMEI_Save[i] = dat[readcount++];
			}
			Flag_ErrInfo &= ~ERROR_N0_MAC;
			W25QXX_WriteVariable(dat, FLASH_MAC_NewAddress, 70);    //��MAC���浽�ⲿflash�µ�ַ
			SaveMACTo_InsideFlash();                                //��MAC���浽�ڲ�flash
			return 1;
		}
		else                                              //�Ӿɵ�ַ��ȡҲʧ��
		{	
//			MAC_ID[0]=0x44;
//			MAC_ID[1]=0x42;
//			MAC_ID[2]=0x38;
//			MAC_ID[3]=0x33;
//			MAC_ID[4]=0x45;
//			MAC_ID[5]=0x38;
//			MAC_ID[6]=0x46;
//			MAC_ID[7]=0x37;
//			MAC_ID[8]=0x36;
//			MAC_ID[9]=0x45;
//			MAC_ID[10]=0x35;
//			MAC_ID[11]=0x41;
//			MAC_Len  = 12;
//			MAC_ID[ MAC_Len] = '\0';
//			Flag_ErrInfo &= ~ERROR_N0_MAC;
//			SaveMACToFlash();
			if(ReadMACFrom_InsideFlash() == 1)   //���ڲ�flash�ɹ�����
			{
				Flag_ErrInfo &= ~ERROR_N0_MAC;
				return 1;
			}
			Flag_ErrInfo |= ERROR_N0_MAC;
			return 0;
		}
	}
	else
	{
		if(dat[0] == Flag_FirstRun)
		{
			MAC_Len=dat[1];	
			readcount=2;
			for(i=0;i<MAC_Len;i++)
			{
				MAC_ID[i] = dat[readcount++];
			}
			ICCID_LEN =  dat[readcount++];
			for(i=0;i<ICCID_LEN;i++)
			{
				ICCID_Save[i] = dat[readcount++];
			}
			IMEI_LEN = dat[readcount++];
			for(i=0;i<IMEI_LEN;i++)
			{
				IMEI_Save[i] = dat[readcount++];
			}
			Flag_ErrInfo &= ~ERROR_N0_MAC;
					
			return 1;
		}
		else
		{			
			Flag_ErrInfo |= ERROR_N0_MAC;
			return 0;
		}
	}
}

char ReadMACFrom_InsideFlash(void)
{
	uint8_t i;
	uint32_t dat[30];
	STMFLASH_Read(STM32_FLASH_MAC,dat,1);
	if(dat[0] == Flag_FirstRun)
	{
		STMFLASH_Read( STM32_FLASH_MAC+2*4,&dat[2], 12);
		for(i=0;i<12;i++)
			MAC_ID[i] = (uint8_t)dat[i+2];
		return 1;
	}
	else
	{
		return 0;
	}
}

/****************************************************************************
*	�� �� ��: SaveIP2ToFlash
*	����˵��: ������÷�������IP��flash
*	��    �Σ���
*	�� �� ֵ: ����1��ʾ��ȷ��ȡ������0��ʾ��һ�γ���������δ��ʼ��
* 	˵    ��������IP�Ͷ˿�
*****************************************************************************/
char SaveIP2ToFlash(void)
{
	uint8_t dat[30];
	uint8_t i;
	uint8_t len1,len2;
	W25QXX_Erase_Sector(FLASH_ServerInfoAddress);

	len1 = strlen(IP2);
	len2 = strlen(Port2);
	dat[0] = Flag_FirstRun;    
	dat[1] = len1;	  //IP����
	dat[2] = len2;	  //IP����
	for(i=0; i<len1;i++)
	{
	 dat[i+3] = IP2[i];
	}
	for(i=0; i<len2;i++)
	{
	 dat[i+len1+3] = Port2[i];
	}		 
	W25QXX_Write_Page(dat,FLASH_ServerInfoAddress, 30);		
}
/****************************************************************************
*	�� �� ��: ReadIPToFlash
*	����˵��: ��flash�б���ķ�����IP����Ϣ
*	��    �Σ���
*	�� �� ֵ: ����1��ʾ��ȷ��ȡ������0��ʾ��һ�γ���������δ��ʼ��
* 	˵    ����
*****************************************************************************/
char ReadIP2FromFlash(void)
{
	uint8_t dat[5];
	uint8_t len1,len2;

	W25QXX_Read(dat, FLASH_ServerInfoAddress, 3);
	if(dat[0] == Flag_FirstRun)
	{
		len1=dat[1];
		len2=dat[2];
		W25QXX_Read(IP2, FLASH_ServerInfoAddress+3, len1);
		W25QXX_Read(Port2, FLASH_ServerInfoAddress+3+len1,len2);
		IP2[len1] = '\0';
		Port2[len2] = '\0';
		Flag_ErrInfo &= ~ERROR_NO_IP2;
		return 1;
	}
	else
	{
		Flag_ErrInfo |= ERROR_NO_IP2;
		return 0;
	}
}
/****************************************************************************
*	�� �� ��: SaveTokenToFlash
*	����˵��: ������÷�������У���뵽flash
*	��    �Σ���
*	�� �� ֵ: ����1��ʾ��ȷ��ȡ������0��ʾ��һ�γ���������δ��ʼ��
* 	˵    ��������IP�Ͷ˿�
*****************************************************************************/
char SaveToken2ToFlash(void)
{
	uint8_t dat[15];
	uint8_t i;

	W25QXX_Erase_Sector(FLASH_VerifyInfoAddress);


	dat[0] = Flag_FirstRun;    
	dat[1] = strlen(Token2);	  
	for(i=0; i<dat[1] ;i++)
	{
		dat[i+2] = Token2[i];
	}		 
	W25QXX_Write_Page(dat,FLASH_VerifyInfoAddress, 15);		
}
/****************************************************************************
*	�� �� ��: ReadTokenFromFlash
*	����˵��: ��flash�б���ķ�����У������Ϣ
*	��    �Σ���
*	�� �� ֵ: ����1��ʾ��ȷ��ȡ������0��ʾ��һ�γ���������δ��ʼ��
* 	˵    ����
*****************************************************************************/
char ReadToken2FromFlash(void)
{
	uint8_t dat[15];
	uint8_t len;

	W25QXX_Read(dat, FLASH_VerifyInfoAddress, 15);
	if(dat[0] == Flag_FirstRun)
	{
		len=dat[1];
		if(len>10)
		{
			len = 10;
		}
		W25QXX_Read(Token2, FLASH_VerifyInfoAddress+2, len);
		Token2[len] = '\0';
		Flag_ErrInfo &= ~ERROR_NO_TOKEN2;
		return 1;
	}
	else
	{
		Flag_ErrInfo |= ERROR_NO_TOKEN2;
		return 0;
	}
}

/****************************************************************************
*	�� �� ��: countHeartScore
*	����˵��:  ��ֵ�˲���
*	��    �Σ���
*	�� �� ֵ: �����˲�ֵ
*   ˵    ����
*****************************************************************************/
//uint16_t  avgFilter(uint16_t x)
//{  
//    uint16_t sumf = 0;
//	uint16_t sumnum = 0;
//	uint16_t midVal = 0;
//	
//	AdddataToavgFilter(x);
//	
//    for (int i = 0; i < HR_AVGLEN; i++) 
//	{
//		if(avgf[i] == 0)
//		{
//			continue;
//		}
//		sumf += avgf[i];
//		sumnum++;
//    }
//    if(sumnum > 0)
//		midVal = sumf/sumnum;   //������һ���ֵ
//    

//	
//    return midVal;
// }
///****************************************************************************
//*	�� �� ��: countHeartScore
//*	����˵��:  ��ֵ�˲���
//*	��    �Σ���
//*	�� �� ֵ: �����˲�ֵ
//*   ˵    ����
//*****************************************************************************/
//void AdddataToavgFilter(uint16_t x)
//{  
//   
//	if(avgFLen >= HR_AVGLEN)
//	{
//		avgFLen = 0;
//	}
//	avgf[avgFLen] = x;          //�������µ�����
//    avgFLen ++;	
//}
/****************************************************************************
*	�� �� ��: avgRespFilter
*	����˵��:  �����˲�
*	��    �Σ���
*	�� �� ֵ: �����˲�ֵ
*   ˵    ����
*****************************************************************************/
//float avgRespFilter(float x) 
//{
//	if (avgRespLen >= AVG_INIT_LEN)
//		avgRespLen = 0;
//	avgResps[avgRespLen] = x;
//	avgRespLen++;

//	float sum = 0, num = 0;
//	for (int i = 0; i < AVG_INIT_LEN && 0 != avgResps[i]; i++) {
//		sum += avgResps[i];
//		num++;
//	}
//	if (num < 1)
//		return 0;
//	return sum / num;
//}
/****************************************************************************
*	�� �� ��: HRRRWave_ChangeGainJudge
*	����˵��:  ���ʺ��������������
*	��    �Σ���·�źŵ�ADC����ֵ
*	�� �� ֵ: 
*   ˵    ��������5s�ڲ��ε����ֵ��ͳ��30�ǲ������ֵ�ĸ�������30s�����ֵ����2V
*             �ĸ�������3���������ֵС��1.5V�ĸ�������3���ı�Ŵ���
*****************************************************************************/
void HRRRWave_ChangeGainJudge(float wave1,float wave2)
{
	
	if(wave1 < RRWave_MinData)
	{
		if(wave1>100)
		{
			RRWave_MinData = wave1;
		}
		else
		{
			ADC_GainJudgeTime = 0;
			ADC_GainChangeTime = 0;
			RRWave_MinData = 3000;
		}
	}
	if(ADC_GainJudgeTime>=5)
	{
		
		if(RRWave_MinData< 500)
		{
			RRWave_Min1VDataCount++;
		}
		else if(RRWave_MinData>1400)
		{
			RRWave_Min2VDataCount++;
		}
		else
		{
			
		}
		if(Flag_COMDebug == 1)
			printf("RRWave_MinData=%f V\r\n",RRWave_MinData);
		ADC_GainJudgeTime  = 0;
		RRWave_MinData = 3000;
		
	}
	if(ADC_GainChangeTime>=30)
	{
	
		if(RRWave_Min1VDataCount>3)
		{			
			ADC_GAIN4(0);
			if(Flag_COMDebug == 1)
				printf("<<<<<<<<<Set RR gain pin low\r\n");			
		}
		else if(RRWave_Min2VDataCount>3)
		{
			ADC_GAIN4(1);
			if(Flag_COMDebug == 1)
				printf(">>>>>>>>>Set RR gain pin high\r\n");
		}
		else
		{
			if(Flag_COMDebug == 1)
				printf("RR gain pin do not change\r\n");
		}
		ADC_GainChangeTime = 0;
		RRWave_Min1VDataCount =0;
		RRWave_Min2VDataCount = 0;
	}
}

/****************************************************************************
*	�� �� ��: OXY_Data_Dispose
*	����˵��: Ѫ��ģ�����ݴ�������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/

void OXY_Data_Dispose(void)
{
	int i=0;
//	if(Flag_COMDebug == 1)
//	{
//		printf("OXY_Data: ");
//		for(i=0;i<OXYUART_RX_LEN;i++)
//			printf("0x%02x,",OXYUART_RX_BUFFER[i]);
//		printf("\r\n");
//	}
    SpO2_Data_Processe(OXYUART_RX_BUFFER,OXYUART_RX_LEN);
    //eChip_Data_Analysis(OXYUART_RX_BUFFER,OXYUART_RX_LEN);
	ClearUSARTBUF(OXY_UART);
    OXYUART_RX_LEN=0;
//	if(eChip_Data_Analysis(OXYUART_RX_BUFFER,OXYUART_RX_LEN) == 1)
//	{		
//		
//	}
}
void SendSpO2DataToserver(uint8_t *data,uint8_t len)
{
	uint8_t i=0;
	uint8_t dat[50];
	uint8_t jiaoyan = 0 ;
	uint8_t data_len=0;
	dat[0] = CMD_START;
	dat[1] = TypeID;
	dat[2] = 0;
	dat[3] = len+13;
	dat[4] = SEND_SPO2;
    data_len=5;
    for(i=0;i<6;i++)
	{
		dat[data_len++] = RealTime[i];
	}
    
	for(i=0;i<len;i++)
	{
        if(Flag_COMDebug == 1)
				printf("%d ", data[i]);
		dat[data_len++] = data[i];
	}
    
	for(i=4;i<data_len;i++)
	{
        
		jiaoyan += dat[i];
	}
    dat[3]=data_len-3;
	dat[data_len++] = jiaoyan;
	dat[data_len++] = CMD_LF1;
	dat[data_len++] = CMD_LF2;
	
  if(Flag_COMDebug == 1)
	{
		printf("\r\n����Ѫ��ֵ\r\n");
		for(i=0;i<data_len;i++)
			printf("%02x  ",dat[i]);
		printf("\r\n");
	}
		
	if(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEOFFBED)     //lqs change �봲����
    LTE_Send_data(Socket,data_len,dat);
	
	
}
void Add1SendSpO2Data(uint8_t *buff,uint8_t data)
{
    u8 i;
//    if(buff[5])
        for(i=0;i<4;i++)
        {
            buff[i]=buff[i+1];
            
        }
//    else
        buff[4]=data;
}
void Send_TestOvertag(uint32_t times)
{
    u8 senddata[20];
    u8 len=0;
    senddata[len++] = CMD_START;
	senddata[len++] = TypeID;
	senddata[len++] = 0;
    senddata[len++] = 0x04;
	senddata[len++] = SENSORTESTOVER;
	senddata[len++] = times/256;
    senddata[len++] = times%256;
	senddata[len++] = 0xFF;
	senddata[len++] = 0x69;
	senddata[len++] = 0x42;
    LTE_Send_data(Socket,len,senddata);

}
/*********zjt protocol**********/
void Send_Softver2uart(USART_TypeDef* USARTx)
{
    uint8_t i=0;
	uint8_t dat[25];
    uint8_t dat_len=0;
	uint8_t jiaoyan = 0 ;
	
	dat[dat_len++] = CMD_START;
    
	dat[dat_len++] = 4;
	dat[dat_len++] = 1;
	
	
	dat[dat_len++] = SOFTWARE_MAJORVER;
	dat[dat_len++] = SOFTWARE_MINORVER;
    dat[dat_len++] = SOFTWARE_TESTVER;
    
	
	dat[dat_len++] = CMD_LF1;
	dat[dat_len++] = CMD_LF2;
    
    SendDataBufToUSART(USARTx,dat,dat_len);
}
void Send_Hardver2uart(USART_TypeDef* USARTx)
{
    uint8_t i=0;
	uint8_t dat[25];
    uint8_t dat_len=0;
	uint8_t jiaoyan = 0 ;
	
	dat[dat_len++] = CMD_START;
    
	dat[dat_len++] = 4;
	dat[dat_len++] = 2;
	
	
	dat[dat_len++] = HARDWARE_MAJORVER;
	dat[dat_len++] = HARDWARE_MINORVER;
    dat[dat_len++] = HARDWARE_TESTVER;
    
	
	dat[dat_len++] = CMD_LF1;
	dat[dat_len++] = CMD_LF2;
    
    SendDataBufToUSART(USARTx,dat,dat_len);
}

void Send_Mac2uart(USART_TypeDef* USARTx)
{
    uint8_t i=0;
	uint8_t dat[25];
    uint8_t dat_len=0;
	uint8_t jiaoyan = 0 ;
	
	dat[dat_len++] = CMD_START;
    
	dat[dat_len++] = MAC_Len+1;
	dat[dat_len++] = 3;
	
	for(i=0;i<MAC_Len;i++)
        dat[dat_len++]=MAC_ID[i];  
	
	
	dat[dat_len++] = CMD_LF1;
	dat[dat_len++] = CMD_LF2;
    
    SendDataBufToUSART(USARTx,dat,dat_len);
}
void Send_Heart_breath2uart(USART_TypeDef* USARTx)
{
    uint8_t i=0;
	uint8_t dat[25];
    uint8_t dat_len=0;
	uint8_t jiaoyan = 0 ;
	
	dat[dat_len++] = CMD_START;
    
	dat[dat_len++] = 0x04;
	dat[dat_len++] = 0x10;
	
	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)
        dat[3] =1;//�ٴ�
    
	if((Flag_PeopleTurnforHert>0))
		dat[3]=2;//�嶯
    
    if(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED)
        dat[3] =3;//�봲

	dat_len=4;
    if(dat[3] !=3)
    {
        dat[dat_len++] =heart_avg;
        dat[dat_len++] =breath_avg;
    }
    else
    {
        dat[dat_len++] =0;
        dat[dat_len++] =0;
    }
	dat[dat_len++] = CMD_LF1;
	dat[dat_len++] = CMD_LF2;
    
    SendDataBufToUSART(USARTx,dat,dat_len);
}
/************end of zjt protocol*****************/