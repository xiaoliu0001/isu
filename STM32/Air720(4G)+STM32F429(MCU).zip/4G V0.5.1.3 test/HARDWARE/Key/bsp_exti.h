#ifndef __EXTI_H
#define	__EXTI_H



#include "stm32f4xx.h"



/************************** EXIT �������� ********************************/
#define             EXTI_GPIO_CLK                        RCC_AHB1Periph_GPIOE     
#define             EXTI_GPIO_PORT                       GPIOE   
#define             EXTI_GPIO_PIN                        GPIO_Pin_3
#define             EXTI_SOURCE_PORT                     EXTI_PortSourceGPIOE
#define             EXTI_SOURCE_PIN                      EXTI_PinSource3
#define             EXTI_LINE                            EXTI_Line3
#define             EXTI_IRQ                             EXTI3_IRQn
#define             EXTI_INT_FUNCTION                    EXTI3_IRQHandler



/************************** EXIT �������� ********************************/
void EXTI_Pxy_Config(void);



#endif /* __EXTI_H */

