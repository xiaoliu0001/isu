/******************************************************************************
 * @file     File.h
 * @brief   �ļ���������
 * @version  
 * @date     2018
 * @note
 * Copyright (C)  2018 ���
 *
 * @par       
*******************************************************************************/
#ifndef __FILE_H__
#define __FILE_H__

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "rtc.h"
#include "ff.h"
#include "Parameter.h"
#include "diskio.h"		/* FatFs lower layer API */
#include "sdio_sdcard.h"
#include "string.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>


extern FIL fadc;

char CreateNewTXTfile(void);
char CloseTXTfile(void);
char  SDcardFileInfo(uint8_t ind);
char WriteLogInfoToTXT(char *str);
char CreateNewLogfile(void);
char  ReadConfigFile(void);
char  ReadFileAndCalculate(void);
char StringToFloatDataBuf(char *str,uint16_t *buf);
char  ReadHrRrFile(char *filename);
FRESULT scan_files (char* path,int num);
int Scan_Files_Num(char* path);
FRESULT f_deldir(const TCHAR *path);
FRESULT DelEarlyDir(const TCHAR *path);
FRESULT scan_dir(char* path);
#endif


