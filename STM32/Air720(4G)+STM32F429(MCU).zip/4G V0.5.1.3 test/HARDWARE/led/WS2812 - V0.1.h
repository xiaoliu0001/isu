/***********************************************************************************
 * @file     WS2812.h
 * @brief    RGB  ���LED��Դ��
 * @version  V1.0
 * @date     2018.05
 * @note
 * Copyright (C) 2018 ���
 *
 * @par     RGB���ع�Դ������LED��������·�����߹�����ͨ�ŷ�ʽ
 ************************************************************************************/
 
 #ifndef __WS2812_H__
 #define __WS2812_H__
 
 #include "sys.h"
 
 
#define WS2812_FREQ											(800000) 			
#define TIMER_CLOCK_FREQ									(84000000)   	    
#define TIMER_PERIOD										(105)            //(SystemCoreClock / WS2812_FREQ)

#define LED_NUMBER											(5)		        
#define LED_DATA_SIZE										(LED_NUMBER * 24)
#define RESET_SLOTS_BEGIN									(50)
#define RESET_SLOTS_END										(50)
#define WS2812_LAST_SLOT									(1)
#define LED_BUFFER_SIZE										(RESET_SLOTS_BEGIN + LED_DATA_SIZE + WS2812_LAST_SLOT + RESET_SLOTS_END)
#define WS2812_0											(TIMER_PERIOD / 3)		
#define WS2812_1											(TIMER_PERIOD * 2 / 3)	
#define WS2812_RESET										(0)


// /* ֱ�Ӳ����Ĵ����ķ�������IO */
//#define	digitalHi(p,i)			{p->BSRR=i;}			//����Ϊ�ߵ�ƽ		
//#define digitalLo(p,i)			{p->BRR=i;}				//����͵�ƽ
//#define digitalToggle(p,i)		{p->ODR ^=i;}			//�����ת״̬


///********************LED������Ŷ���**************************************/
//#define WS2812_DOUT_PORT_RCC   RCC_AHBPeriph_GPIOC
//#define WS2812_DOUT_PORT       GPIOC
//#define WS2812_DOUT_PIN        GPIO_Pin_7



// #define WS2812_DOUT(a)	if (a)	\
//					GPIO_SetBits(WS2812_DOUT_PORT,WS2812_DOUT_PIN);\
//					else		\
//					GPIO_ResetBits(WS2812_DOUT_PORT,WS2812_DOUT_PIN)	
//					
//#define WS2812_DOUT_LOW		    digitalLo(WS2812_DOUT_PORT,WS2812_DOUT_PIN)
//#define WS2812_DOUT_HIGH		digitalHi(WS2812_DOUT_PORT,WS2812_DOUT_PIN)
					
 
void WS2812_GPIO_Config(void);
void WS2812_Delay50ns(uint16_t t);	
void WS2812_Delay400ns(void);
void WS2812_Delay850ns(void);					
 void WS2812_SendRGBData(uint8_t *buf,uint32_t rgb,uint8_t num);
					
void WS2812_Init (void);
void WS2812_update ( uint8_t group );
void SetLedColor ( uint8_t index, uint8_t RED, uint8_t GREEN, uint8_t BLUE );
void SetWholeColor ( uint8_t group, uint8_t red, uint8_t green, uint8_t blue );
void DMA1_Channel4_IRQHandler();
 void WS2812_Breathing(void);

					
					
 #endif
 
 
 
 
 