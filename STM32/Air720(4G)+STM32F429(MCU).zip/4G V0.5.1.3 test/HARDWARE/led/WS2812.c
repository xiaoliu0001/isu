/***********************************************************************************
 * @file     WS2812.C
 * @brief    RGB  ���LED��Դ��
 * @version  V3.0
 * @date     2018.09
 * @note
 * Copyright (C) 2018 ���
 *
 * @par     RGB���ع�Դ������LED��������·�����߹�����ͨ�ŷ�ʽ
 *       V1.0  STM32F0 ��Ƭ��  ��׼������
 *       V2.0  STM32F429��Ƭ��  HAL������,ʹ��SPI�ӿ�����
 ************************************************************************************/
 #include "WS2812.h"
 #include "Timer.h"
 #include "spi.h"
 #include "delay.h"
 
 
 uint8_t indexWave[] = { 
		1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 
		3, 4, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 8, 8, 9, 9, 10, 11, 
		11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 26, 27, 
		29, 31, 33, 35, 37, 39, 42, 45, 48, 51, 54, 57, 61, 65, 69, 
		74, 78, 83, 89, 94, 101, 107, 114, 121, 129, 137, 146, 156, 
		166, 176, 187, 200, 212, 226, 241, 255, 255, 241, 226, 212, 
		200, 187, 176, 166, 156, 146, 137, 129, 121, 114, 107, 101, 
		94, 89, 83, 78, 74, 69, 65, 61, 57, 54, 51, 48, 45, 42, 39, 
		37, 35, 33, 31, 29, 27, 26, 24, 23, 21, 20, 19, 18, 17, 16, 
		15, 14, 13, 12, 11, 11, 10, 9, 9, 8, 8, 7, 7, 6, 6, 6, 5, 5, 
		5, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 1,
		1, 1, 1, 1, 1, 1                   
                      };
 uint8_t BreathWave[] = { 1,1,1,2,2,2,3,3,3,4,
	                     4,4,5,5,6,6,7,7,8,8,
						9,9,10,10,11,12,13,14,15,16,
						17,18,19,20,21,22,23,24,25,26,
						27,28,29,30,31,32,33,34,35,36,
						36,35,34,33,32,31,30,29,28,27,
						26,25,24,23,22,21,20,19,17,16,
						15,14,13,12,11,10,10,9,9,8,
	                    8,7,7,6,6,5,5,5,4,4,
						3,3,3,2,2,2,
                      };
 
//����PWM���ж��ٸ�Ԫ��
uint16_t BreathPoint_NUM = sizeof(indexWave)/sizeof(indexWave[0]); 
					  
uint16_t  Index_Breath = 0;
uint8_t  Index_BreathCount = 0;					  
//uint8_t red = 0;
uint8_t green = 0;
uint8_t blue = 0;
uint8_t dirc = 0;
uint8_t WS2818_BrightStatus[LED_NUMBER] = {0};
uint8_t WS2818_StatusChaTim[LED_NUMBER] = {0};	//LED״̬�ı�ʱ��


TIM_HandleTypeDef TIM3_Handler;      //��ʱ��3��� 
TIM_OC_InitTypeDef TIM3_CH2Handler;	    //��ʱ��3ͨ��2���
DMA_HandleTypeDef  TIM3CH2DMA_Handler;
DMA_HandleTypeDef  SPIDMA_Handler;
static void TransferComplete(DMA_HandleTypeDef *DmaHandle);


/****************************************************************************
*	�� �� ��: 
*	����˵��: DMA����ʱ������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/


volatile  uint8_t LEDbuffer[LED_BUFFER_SIZE];  //��ʱ����ʽ


uint16_t PixelPointer = 0;


static void Timer3DMA_Config(void);
static void SPIDMA_Config(void);

/****************************************************************************
*	�� �� ��:SPIDMA_Config
*	����˵��: SPI��DMA����
*	��    �Σ���
*	�� �� ֵ: ��
*	˵    ����DMA_Streamx:DMA������,DMA1_Stream0~7/DMA2_Stream0~7
*				DMAͨ��ѡ��,@ref DMA_channel DMA_CHANNEL_0~DMA_CHANNEL_7
*****************************************************************************/
static  void SPIDMA_Config(void)
{
	__HAL_RCC_DMA1_CLK_ENABLE();//DMA1ʱ��ʹ�� 
	__HAL_LINKDMA(&SPI2_Handler,hdmatx,SPIDMA_Handler);    //��DMA��spi ������ϵ����
	
    //Tx DMA����
    SPIDMA_Handler.Instance=DMA1_Stream4;                            	//������ѡ��
    SPIDMA_Handler.Init.Channel=DMA_CHANNEL_0;                        	//ͨ��ѡ��
    SPIDMA_Handler.Init.Direction=DMA_MEMORY_TO_PERIPH;             	//���ݴ��䷽��
    SPIDMA_Handler.Init.PeriphInc=DMA_PINC_DISABLE;                 	//�����ַ����
    SPIDMA_Handler.Init.MemInc=DMA_MINC_ENABLE;                     	//�洢������ģʽ
    SPIDMA_Handler.Init.PeriphDataAlignment=DMA_PDATAALIGN_BYTE;    	//�������ݳ���:8λ
    SPIDMA_Handler.Init.MemDataAlignment=DMA_PDATAALIGN_BYTE;       	//�洢�����ݳ���:8λ
    SPIDMA_Handler.Init.Mode=DMA_NORMAL;                           	//ѭ������ģʽ
    SPIDMA_Handler.Init.Priority=DMA_PRIORITY_HIGH;              	 	//�е����ȼ�
    SPIDMA_Handler.Init.FIFOMode=DMA_FIFOMODE_DISABLE;              
    SPIDMA_Handler.Init.FIFOThreshold=DMA_FIFO_THRESHOLD_FULL;      
    SPIDMA_Handler.Init.MemBurst=DMA_MBURST_SINGLE;                 	//�洢��ͻ�����δ���
    SPIDMA_Handler.Init.PeriphBurst=DMA_PBURST_SINGLE;             		 //����ͻ�����δ���

	HAL_DMA_DeInit(&SPIDMA_Handler); 
    HAL_DMA_Init(&SPIDMA_Handler);
	

}

 /*************************************************************
* �� �� �� : WS2812_Init
* �������� : ��ʼ��
* �� �� ֵ : none
* ������� : none
* ˵   �� : none
*************************************************************/
void WS2812_Init (void)
{	
	SPI2_Init();		   			        //��ʼ��SPI

	for(int i = 0;i<LED_BUFFER_SIZE;i++)
	{
		LEDbuffer[i] = WS2812_00;		
	}
	delay_ms(10);
//	SetAllLEDOff();
	SetLEDOn(LED_EQUSTATUS,COLOR_YELLOW);
	WS2812_update(1);
	delay_ms(100);
//	SetWholeColor(COLOR_YELLOW);
//	WS2812_update(1);
//	delay_ms(100);
	
}
/*************************************************************
* �� �� �� : WS2812_update
* �������� : DMA��������
* ������� : none
* ������� : none
* ˵   �� : none
*************************************************************/
void WS2812_update ( uint8_t group )
{

	HAL_SPI_Transmit(&SPI2_Handler,&LEDbuffer[0],LED_BUFFER_SIZE, 500);

}

/*************************************************************
* �� �� �� : SetLedColor
* �������� : ����ĳһյLED��ɫ
* ������� : index  ��Ҫ������LED��ţ���һյ���ڶ�յ.....��
*			color�Ƶ���ɫ
* ˵   �� : none
* �� �� ֵ : none
*************************************************************/
void SetLedColor ( uint8_t index,uint32_t color )
{
    uint8_t tempBuffer[24] = {0};
    uint8_t i;
	uint8_t tmp = 0;
	uint8_t R =  (uint8_t)((color>>16)&0x000000FF);
	uint8_t G =  (uint8_t)((color>>8)&0x000000FF);
	uint8_t B =  (uint8_t)(color&0x000000FF);
    
    R*=0.01;
    G*=0.01;
    B*=0.01;
	
//    R>>=1;
//	G>>=1;
//	B>>=1;
#if 0	
    for ( i = 0; i < 8; i++ ) // GREEN data
        tempBuffer[i] = ( ( G << i ) & 0x80 ) ? WS2812_1 : WS2812_0;

    for ( i = 0; i < 8; i++ ) // RED
        tempBuffer[8 + i] = ( ( R << i ) & 0x80 ) ? WS2812_1 : WS2812_0;

    for ( i = 0; i < 8; i++ ) // BLUE
        tempBuffer[16 + i] = ( ( B << i ) & 0x80 ) ? WS2812_1 : WS2812_0;

    for ( i = 0; i < 24; i++ )
        LEDbuffer[RESET_SLOTS_BEGIN + index * 24 + i] = tempBuffer[i];

#else
	for ( i = 0; i < 4; i++ ) // GREEN data
	{
		tmp = G & 0xC0;
		if(tmp == 0xC0)
			tempBuffer[i] = WS2812_11;
		else if(tmp == 0x40)
			tempBuffer[i] = WS2812_01;
		else if(tmp == 0x80)
			tempBuffer[i] = WS2812_10;
		else
			tempBuffer[i] = WS2812_00;
       G = G<<2;	
	}
	tmp = 0;
    for ( i = 0; i < 4; i++ ) // RED
	{
        tmp = R &0xC0;
		if(tmp == 0xC0)
			tempBuffer[i+4] = WS2812_11;
		else if(tmp == 0x40)
			tempBuffer[i+4] = WS2812_01;
		else if(tmp == 0x80)
			tempBuffer[i+4] = WS2812_10;
		else
			tempBuffer[i+4] = WS2812_00;
       R = R<<2;	
	}
	tmp = 0;
    for ( i = 0; i < 4; i++ ) // BLUE
	{
        tmp = B &0xC0;
		if(tmp == 0xC0)
			tempBuffer[i+8] = WS2812_11;
		else if(tmp == 0x40)
			tempBuffer[i+8] = WS2812_01;
		else if(tmp == 0x80)
			tempBuffer[i+8] = WS2812_10;
		else
			tempBuffer[i+8] = WS2812_00;
       B = B<<2;	

	}
		
    for ( i = 0; i < 12; i++ )
	
        LEDbuffer[RESET_SLOTS_BEGIN + index * 12 + i] = tempBuffer[i];
	
	
	
#endif

}
/*************************************************************
* �� �� �� : SetLedColor
* �������� : ����ĳһյLED��ɫ
* ������� : index  ��Ҫ������LED��ţ���һյ���ڶ�յ.....��
* ˵   �� : none
* �� �� ֵ : none
*************************************************************/
void SetLedRGBColor ( uint8_t index,uint8_t R,uint8_t G,uint8_t B )
{
    uint8_t tempBuffer[24] = {0};
    uint8_t i;
	uint8_t tmp;
	
#if 0	
    for ( i = 0; i < 8; i++ ) // GREEN data
        tempBuffer[i] = ( ( G << i ) & 0x80 ) ? WS2812_1 : WS2812_0;

    for ( i = 0; i < 8; i++ ) // RED
        tempBuffer[8 + i] = ( ( R << i ) & 0x80 ) ? WS2812_1 : WS2812_0;

    for ( i = 0; i < 8; i++ ) // BLUE
        tempBuffer[16 + i] = ( ( B << i ) & 0x80 ) ? WS2812_1 : WS2812_0;

    for ( i = 0; i < 24; i++ )
        LEDbuffer[RESET_SLOTS_BEGIN + index * 24 + i] = tempBuffer[i];

#else
	for ( i = 0; i < 4; i++ ) // GREEN data
	{
		tmp = G &0xC0;
		if(tmp == 0x00)
			tempBuffer[i] = WS2812_00;
		else if(tmp == 0x40)
			tempBuffer[i] = WS2812_01;
		else if(tmp == 0x80)
			tempBuffer[i] = WS2812_10;
		else
			tempBuffer[i] = WS2812_11;
       G = G<<2;		
	}
    for ( i = 0; i < 4; i++ ) // RED
	{
        tmp = R &0xC0;
		if(tmp == 0x00)
			tempBuffer[i+4] = WS2812_00;
		else if(tmp == 0x40)
			tempBuffer[i+4] = WS2812_01;
		else if(tmp == 0x80)
			tempBuffer[i+4] = WS2812_10;
		else
			tempBuffer[i+4] = WS2812_11;
       R = R<<2;		
	}
    for ( i = 0; i < 4; i++ ) // BLUE
	{
        tmp = B &0xC0;
		if(tmp == 0x00)
			tempBuffer[i+8] = WS2812_00;
		else if(tmp == 0x40)
			tempBuffer[i+8] = WS2812_01;
		else if(tmp == 0x80)
			tempBuffer[i+8] = WS2812_10;
		else
			tempBuffer[i+8] = WS2812_11;
       B = B<<2;		
	}
		
    for ( i = 0; i < 12; i++ )
	
        LEDbuffer[RESET_SLOTS_BEGIN + index * 12 + i] = tempBuffer[i];
	
	
#endif

}
/****************************************************************************
*	�� �� ��: SetWholeColor
*	����˵��: �������е���ɫ
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void SetWholeColor ( uint32_t color)
{
    uint8_t i=0;
	
	for ( i = 0; i < LED_NUMBER; i++ )
		SetLedColor ( i, color );

}
/****************************************************************************
*	�� �� ��: SetWholeColorLED_Brightness
*	����˵��: �������еƵ�ĳ����ɫ������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void SetWholeColorLED_Brightness( uint32_t color,uint8_t bright)
{
    uint8_t i;
	
	if( color == COLOR_RED )
	{
		for ( i = 0; i < LED_NUMBER; i++ )
		SetLedRGBColor ( i, bright, 0, 0 );
		
	}
	if( color == COLOR_GREEN )
	{
		for ( i = 0; i < LED_NUMBER; i++ )
		SetLedRGBColor ( i, 0, bright, 0 );
		
	}
	if( color == COLOR_BLUE )
	{
		for ( i = 0; i < LED_NUMBER; i++ )
		SetLedRGBColor ( i, 0, 0, bright );
		
	}
   if( color == COLOR_WHITE )
	{
		for ( i = 0; i < LED_NUMBER; i++ )
		SetLedRGBColor ( i, bright, bright, bright );
		
	}
}
/****************************************************************************
*	�� �� ��: SetAllLEDOff
*	����˵��: �ر����е�LED
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void SetAllLEDOff(void)
{	
	SetWholeColor(COLOR_BLACK);
	
}
/****************************************************************************
*	�� �� ��: SetLEDOff
*	����˵��: �ر�ĳһ��LED
*	��    �Σ�indexҪ�رյ�LED���
*	�� �� ֵ: ��
*****************************************************************************/
void SetLEDOff(uint8_t index)
{
	SetLedRGBColor ( index, 0, 0, 0 );
	WS2818_BrightStatus[index] = LED_OFF;
}
/****************************************************************************
*	�� �� ��: SetLEDOff
*	����˵��: �ر�ĳһ��LED
*	��    �Σ�indexҪ�رյ�LED���
*	�� �� ֵ: ��
*****************************************************************************/
void SetLEDOn(uint8_t index,uint32_t color)
{
	if(color == COLOR_YELLOW)       //Ϊ������߻�ɫ���ȣ����ĵ���
		SetLedRGBColor ( index, 15, 4, 0 );
	else
		SetLedColor ( index, color );	
	WS2818_BrightStatus[index] = LED_ON;
}
/****************************************************************************
*	�� �� ��: WS2812_Breathing
*	����˵��: ������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
 void WS2812_Breathing(void)
 {
	 
	SetWholeColorLED_Brightness (COLOR_GREEN,BreathWave[Index_Breath]);
//	SetWholeColorLED_Brightness (COLOR_WHITE,indexWave[Index_Breath]);
	WS2812_update ( 1 );
	 Index_BreathCount++;
	 if(Index_BreathCount == 3)
	 {
		Index_Breath++;
		 Index_BreathCount = 0;
	 }
	 if(Index_Breath == BreathPoint_NUM)
		 Index_Breath = 0;
	 
//	if(dirc == 0)
//	{
//		Index_Breath++;
//		if(Index_Breath == BreathPoint_NUM)
//		{
//			dirc = 1;
//		}
//	}
//	else
//	{
//		Index_Breath--;
//		if(Index_Breath == 10)
//		{
//			dirc = 0;
//		}
//		
//	}
 }
/****************************************************************************
* ��    �ƣ�uint32_t Sw28_Color(uint8_t r, uint8_t g, uint8_t b)
* ��    �ܣ�
* ��ڲ�����
* ���ڲ�����
* ˵    ����
****************************************************************************/
uint32_t Sw28_Color(uint8_t r, uint8_t g, uint8_t b)
{
    return (((uint32_t)g << 16) | ((uint32_t)r <<  8) | b);
}
 /****************************************************************************
* ��    �ƣ�
* ��    �ܣ�����ֵ0��255�Ի�ȡ��ɫֵ������һ��������ɫ r-g-b��
* ��ڲ�����
* ���ڲ�����
* ˵    ����
****************************************************************************/
uint32_t Wheel(uint8_t WheelPos)
{
    WheelPos = 255 - WheelPos;
    if(WheelPos < 85)
    {
        return Sw28_Color(255 - WheelPos * 3, 0, WheelPos * 3);
    }
    if(WheelPos < 170) {
        WheelPos -= 85;
        return Sw28_Color(0, WheelPos * 3, 255 - WheelPos * 3);
    }
    WheelPos -= 170;
    return Sw28_Color(WheelPos * 3, 255 - WheelPos * 3, 0);
}
 /****************************************************************************
*	�� �� ��: WS2812_rainbow
*	����˵��: �ʺ��
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void WS2812_rainbow(void)
{
	uint16_t i, j;
    for(j=0; j<256; j++)
    {
        for(i=0; i<LED_NUMBER; i++)
        {
            SetLedColor(i, Wheel((i+j) & 255));
        }
		WS2812_update(1);
        HAL_Delay (10);
    }
	
}
/****************************************************************************
* ��    �ƣ�WS2812_rainbowCycle
* ��    �ܣ�WS2812_rainbow���в�ͬ, ��ʹ�òʺ���ȷֲ�������
* ��    �Σ�
* ˵    ����
****************************************************************************/
void WS2812_rainbowCycle(void)
{
    uint16_t i;
    static uint16_t j=0;
      // 5 cycles of all colors on wheel
        for(i=0; i< LED_NUMBER; i++)
        {
            SetLedColor(i, Wheel(((i * 256 / LED_NUMBER) + j) & 255));
        }
        j++;
        if(j>=256)
        j=0;
        //WS2812_update(1);
        //HAL_Delay (10);
    
}
/****************************************************************************
* ��    ��:WS2812_theaterChase
* ��    �ܣ��糡ʽ�����еơ�
* ��    �Σ�
* ˵    ����
****************************************************************************/
void WS2812_theaterChase( uint32_t color)
{
    for (int j=0; j<10; j++)
    {  
        for (int q=0; q < 3; q++)
        {
            for (uint16_t i=0; i < LED_NUMBER; i=i+3)
            {
                SetLedColor(i+q, color);    //turn every third pixel on
            }
            WS2812_update(1);
			HAL_Delay (100);

            for (uint16_t i=0; i < LED_NUMBER; i=i+3)
            {
                SetLedColor(i+q, 0);        //turn every third pixel off
            }
            WS2812_update(1);
			HAL_Delay (100);
        }
    }
}
/****************************************************************************
* ��    �ƣ�WS2812_theaterChaseRainbow
* ��    �ܣ����вʺ�Ч���ľ糡ʽ���е�
* ��    �Σ�
* ˵    ����
****************************************************************************/
void WS2812_theaterChaseRainbow(void)
{
    uint16_t j,q,i;
    for (j=0; j < 256; j++)
    {   // cycle all 256 colors in the wheel
        for (q=0; q < 3; q++)
        {
            for (i=0; i < LED_NUMBER; i=i+3)
            {
                SetLedColor(i+q, Wheel( (i+j) % 255));    //turn every third pixel on
            }
            WS2812_update(1);
			//HAL_Delay (100);
            //delay_ms(10);
            for (i=0; i < LED_NUMBER; i=i+3)
            {
                SetLedColor(i+q, 0);        //turn every third pixel off
            }
            WS2812_update(1);
            //delay_ms(10);
			//HAL_Delay (100);
        }
    }
}
/****************************************************************************
* ��    �ƣ�WS2812_Runninglight
* ��    �ܣ���ɫ������
* ��    �Σ�
color: ��ɫ
led_nums: 0~LED_NUMBER�����Ƹ���
mode: 0 ���� 1����
* ˵    ����
****************************************************************************/
void WS2812_Runninglight(uint32_t color,uint8_t led_nums, uint8_t mode)
{
    uint16_t i;
    static uint16_t j =0;
    
    //for(j=0;j<led_nums;j++)
    {
        if(mode)
            SetLedColor(j, color);
        else
            SetLedColor(j, 0);        //turn every third pixel off            
        for(i=0;i<led_nums;i++)
        {
                if((i-j)!=0)
                {
                    if(mode)
                        SetLedColor(i, 0);        //turn every third pixel off
                    else
                        SetLedColor(i, color);
                }
               
              
        }
          //WS2812_update(1);
        
    }
    j++;
    if(j>4)
        j=0;
    
}
void WS2812_Runninglight2(uint32_t color,uint8_t led_nums, uint8_t mode)
{
    uint16_t i;
    static uint16_t j =0;
    
    for(i=0;i<j;i++)
    {
        if(i==0)
            SetAllLEDOff();    
        SetLEDOn(i,color);
    }
    j++;
    if(j>led_nums)
        j=0;
    
}
void WS2812_Togglelight(uint8_t led_no,uint32_t color)
{
    if(WS2818_BrightStatus[led_no] == LED_ON)
    
        SetLEDOff(led_no);        
    
    else
    
        SetLEDOn(led_no,color);
    
    
            
}
void WS2812_ALLTogglelight(uint32_t color)
{
    static uint8_t i=0;
    if(i)
    {
        SetAllLEDOff();
        i=0;
    }
    else
    {
        SetWholeColor(color);
        i=1;
    }
    //WS2812_update(1);
}
void WS2812_BetterryMode(uint8_t bettery_val,uint32_t color)
{
    uint8_t i=0;
    
    for(i=0;i<bettery_val;i++)
        SetLEDOn(i,color);
}
void WS2812_ChargMode(uint8_t bettery_val,uint32_t color)
{
    uint8_t i=0;
    uint8_t val;
    if(bettery_val<=1)
    {
        WS2812_Togglelight(0,color);
        
    }
    else
    {
        val=bettery_val;
    for(i=0;i<val-1;i++)
        SetLEDOn(i,color);
//    for(i=val;i<LED_NUMBER;i++)
//        SetLEDOff(i);
    WS2812_Togglelight(val-1,color);
    }
}
void WS2812_rainbow1(uint8_t ledindex)
{
    uint16_t r,g,b;
    uint32_t rgbcolor;
    uint16_t full=1530;
    static uint16_t i=0;
    static uint8_t flag=0;
if(i<full/3){
    r=255;
    g=(255*3*i/full);
    b=0;
}else if(i<full/2){
    r=(750-i*(250*6/full));
    g=255;
    b=0;
}else if(i<full*2/3){
    r=0;
    g=255;
    b=(i*(250*6/full)-750);
}else if(i<full*5/6){
    r=0;
    g=(1250-i*(250*6/full));
    b=255;
}else{
    r=(150*i*(6/full)-750);
    g=0;
    b=255;
}
if(flag==0)
{
    i++;
    if(i>=full)
        flag=1;
}
if(flag==1)
{
    i--;
    if(i<=0)
        flag=0;
}

rgbcolor=r*65536+g*256+b;
SetLEDOn(ledindex,rgbcolor);
		
    
}
void jianbian(void)
{
    uint32_t start_color=COLOR_GREEN;
    uint32_t end_color=COLOR_BLUE;
    uint32_t color;
    u8 yr,yg,yb;
    u8 tr,tg,tb;
    uint8_t step=255;
    int8_t sr,sg,sb;
    static int8_t i=0,j;
    yr=(u8)(start_color>>16);
    yg=(u8)(start_color>>8);
    yb=(u8)start_color;
    
    tr=(u8)(end_color>>16);
    tg=(u8)(end_color>>8);
    tb=(u8)end_color;
    
    sr=(tr-yr)/step;
    sg=(tg-yg)/step;
    sb=(tb-yb)/step;
    
        color=((uint32_t)(yr+sr*i)<<16)|((uint32_t)(yg+sg*i)<<8)|((uint32_t)(yb+sb*i));
        SetWholeColor(color);
    i++;
    if(i>=step)
        i=0;
    
}