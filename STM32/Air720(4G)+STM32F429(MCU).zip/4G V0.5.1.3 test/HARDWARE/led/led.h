/***********************************************************************************
 * @file     LED.h
 * @brief    led�ļ�
 * @version  V1.0
 * @date     2018.08
 * @note
 * Copyright (C) 2018 ���
 *
 * @par      led��ʾ
************************************************************************************/
#ifndef __LED_H
#define	__LED_H

#include "sys.h"

//���Ŷ���
/*******************************************************/

#if 1

#define LED1_PIN                  GPIO_PIN_0                 
#define LED1_GPIO_PORT            GPIOB                     
#define LED1_GPIO_CLK_ENABLE      __HAL_RCC_GPIOB_CLK_ENABLE

#define LED2_PIN                  GPIO_PIN_1                 
#define LED2_GPIO_PORT            GPIOB                    
#define LED2_GPIO_CLK_ENABLE      __HAL_RCC_GPIOB_CLK_ENABLE

#define LED1(a)	if (a)	\
					HAL_GPIO_WritePin(LED1_GPIO_PORT,LED1_PIN,GPIO_PIN_SET);\
					else		\
					HAL_GPIO_WritePin(LED1_GPIO_PORT,LED1_PIN,GPIO_PIN_RESET)

#define LED2(a)	if (a)	\
					HAL_GPIO_WritePin(LED2_GPIO_PORT,LED2_PIN,GPIO_PIN_SET);\
					else		\
					HAL_GPIO_WritePin(LED2_GPIO_PORT,LED2_PIN,GPIO_PIN_RESET)

#else

#define LED1_PIN                  GPIO_PIN_15                
#define LED1_GPIO_PORT            GPIOG                      
#define LED1_GPIO_CLK_ENABLE      __HAL_RCC_GPIOB_CLK_ENABLE

#define LED2_PIN                  GPIO_PIN_14               
#define LED2_GPIO_PORT            GPIOG                  
#define LED2_GPIO_CLK_ENABLE      __HAL_RCC_GPIOB_CLK_ENABLE

#define LED3_PIN                  GPIO_PIN_13                
#define LED3_GPIO_PORT            GPIOG                      
#define LED3_GPIO_CLK_ENABLE      __HAL_RCC_GPIOB_CLK_ENABLE

#define LED4_PIN                  GPIO_PIN_11                
#define LED4_GPIO_PORT            GPIOG                      
#define LED4_GPIO_CLK_ENABLE      __HAL_RCC_GPIOB_CLK_ENABLE

#define LED5_PIN                  GPIO_PIN_9                
#define LED5_GPIO_PORT            GPIOG                      
#define LED5_GPIO_CLK_ENABLE      __HAL_RCC_GPIOB_CLK_ENABLE

#define LED6_PIN                  GPIO_PIN_6                
#define LED6_GPIO_PORT            GPIOD                      
#define LED6_GPIO_CLK_ENABLE      __HAL_RCC_GPIOB_CLK_ENABLE



#endif
void LED_GPIO_Config(void);

#endif /* __LED_H */
