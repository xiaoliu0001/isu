/***********************************************************************************
  * @file     WS2812.C
 * @brief    RGB  ���LED��Դ��
 * @version  V3.0
 * @date     2018.09
 * @note
 * Copyright (C) 2018 ���
 *
 * @par     RGB���ع�Դ������LED��������·�����߹�����ͨ�ŷ�ʽ
 *       V1.0  STM32F0 ��Ƭ��  ��׼������
 *       V2.0  STM32F429��Ƭ��  HAL������,ʹ��SPI�ӿ�����
 ************************************************************************************/
 
 #ifndef __WS2812_H__
 #define __WS2812_H__
 
 #include "sys.h"
 
 
#define WS2812_FREQ											800000 			
#define TIMER_CLOCK_FREQ									84000000  	    
#define TIMER_PERIOD										105            //(SystemCoreClock / WS2812_FREQ)

#define LED_NUMBER											5	

#if 0          //��ʱ����ʽ
#define LED_DATA_SIZE										LED_NUMBER * 24
#define RESET_SLOTS_BEGIN									50
#define RESET_SLOTS_END										50
#define WS2812_LAST_SLOT									1
#define LED_BUFFER_SIZE										(RESET_SLOTS_BEGIN + LED_DATA_SIZE + WS2812_LAST_SLOT + RESET_SLOTS_END)
#define WS2812_0											(TIMER_PERIOD / 3)		
#define WS2812_1											(TIMER_PERIOD * 2 / 3)	
#define WS2812_RESET										(0)

#else	//spi��ʽ

#define LED_DATA_SIZE										LED_NUMBER * 12
#define RESET_SLOTS_BEGIN									0
#define RESET_SLOTS_END										0
#define WS2812_LAST_SLOT									1
#define LED_BUFFER_SIZE										(RESET_SLOTS_BEGIN + LED_DATA_SIZE + WS2812_LAST_SLOT + RESET_SLOTS_END)
#define WS2812_00											0x88		
#define WS2812_01											0x8E
#define WS2812_10											0xE8		
#define WS2812_11											0xEE

#define WS2812_RESET										(0)

#endif

extern DMA_HandleTypeDef  SPIDMA_Handler;
extern uint8_t WS2818_BrightStatus[LED_NUMBER];  //LED״̬
extern uint8_t WS2818_StatusChaTim[LED_NUMBER];	//LED״̬�ı�ʱ��

#define LED_EQUSTATUS   		0	//�豸״̬
#define LED_LTESTATUS      		1	//LTE״̬
#define LED_BLESTATUS      		2	//����״̬
#define LED_PEOPLESTATUS      	3	//�Ƿ��ڴ�״̬
#define LED_ARITH      			4	//�㷨״̬

#define LED_ON      	1
#define LED_OFF      	0

#define COLOR_RED   		0x00FF0000
#define COLOR_GREEN   		0x0000FF00
#define COLOR_BLUE   		0x000000FF
#define COLOR_WHITE   		0x00FFFFFF
#define COLOR_BLACK   		0x00000000
#define COLOR_YELLOW 		0x00FFFF00
#define COLOR_CYAN 		    0x0000FFFF
#define COLOR_GREY 		    0x00708090


void WS2812_GPIO_Config(void);
void WS2812_Delay50ns(uint16_t t);	
void WS2812_Delay400ns(void);
void WS2812_Delay850ns(void);					
 void WS2812_SendRGBData(uint8_t *buf,uint32_t rgb,uint8_t num);
					
void WS2812_Init (void);
void WS2812_update ( uint8_t group );
void SetLedColor ( uint8_t index,uint32_t color );
void SetLedRGBColor ( uint8_t index,uint8_t R,uint8_t G,uint8_t B );
void SetWholeColor ( uint32_t color);
void DMA1_Channel4_IRQHandler();
 void WS2812_Breathing(void);
void SetWholeColorLED_Brightness( uint32_t color,uint8_t bright);
void SetAllLEDOff(void);					
void SetLEDOff(uint8_t index);
void SetLEDOn(uint8_t index,uint32_t color);
void WS2812_rainbow(void);
void WS2812_rainbowCycle(void);
void WS2812_theaterChase( uint32_t color);
void WS2812_theaterChaseRainbow(void);

void WS2812_Runninglight(uint32_t color,uint8_t led_nums, uint8_t mode);
void WS2812_Togglelight(uint8_t led_no,uint32_t color);
void WS2812_ALLTogglelight(uint32_t color);
void WS2812_Runninglight2(uint32_t color,uint8_t led_nums, uint8_t mode);
void WS2812_BetterryMode(uint8_t bettery_val,uint32_t color);
void WS2812_ChargMode(uint8_t bettery_val,uint32_t color);
void WS2812_rainbow1(uint8_t ledindex);
void jianbian(void);
 #endif
 
 
 
 
 