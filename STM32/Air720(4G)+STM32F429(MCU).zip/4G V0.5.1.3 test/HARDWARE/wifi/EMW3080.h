/******************************************************************************
 * @file     EMW3080.h
 * @brief   WiFiͨѶ����
 * @version  
 * @date     2018.09
 * @note
 * Copyright (C)  
 *
 * @par      ���201809
 *        EMW3080 WiFiģ��ͨѶ����
*******************************************************************************/
#ifndef __EMW3080_H_
#define __EMW3080_H_

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "Parameter.h"
#include "Fun.h"
#include "Timer.h"
#include <stdlib.h>
#include "string.h"

#define WIFIROUTERTEST   1        //���ò���·����Ϊ  zangwii2008

//#define TESTROUTERNAME     "zangwii2008"
//#define TESTROUTERPWD      "zw853429"
#define TESTROUTERNAME     "iBreezee-DEV"
#define TESTROUTERPWD      "dev201805"



//LED�˿ڶ���
#define WIFI_POWER_PIN                  GPIO_PIN_11                 
#define WIFI_POWER_GPIO_PORT            GPIOH                      
#define WIFI_POWER_GPIO_CLK_ENABLE     __HAL_RCC_GPIOH_CLK_ENABLE

					

#define WIFI_POWER(a)	if (a)	\
					HAL_GPIO_WritePin(WIFI_POWER_GPIO_PORT,WIFI_POWER_PIN,GPIO_PIN_SET);\
					else		\
					HAL_GPIO_WritePin(WIFI_POWER_GPIO_PORT,WIFI_POWER_PIN,GPIO_PIN_RESET)
					
					
					
/****************************************************************/
	
#define SOCKETA         0
#define SOCKETB         1

#define  ATMODEIN       1     // ����ATָ��ķ�ʽ��1Ϊָ�ʽ��0Ϊgpio���ŵ�ƽ��ʽ

#define    WIFI_SUCCESS              0
#define    WIFI_FAIL                -1
#define    WIFI_CFG_ERROR           -2
					
#define    WIFI_CONNECT             1
#define    WIFI_NOCONNECT           2					
					
#define   WIFI_TCP_CONNECT           1
#define   WIFI_TCP_NOCONNECT         2
#define   WIFI_DATASEND_ATMODE       1
#define   WIFI_DATASEND_TRANSMODE    0

//----------- timeout Definition---------------------------------
       					 
#define WIFI_INC_TIMER               WIFI_Timer++
#define WIFI_RESET_TIMER             WIFI_Timer=0


#define WIFI_1S_TIMEOUT              1
#define WIFI_2S_TIMEOUT              2
#define WIFI_3S_TIMEOUT              3
#define WIFI_5S_TIMEOUT           	 5
#define WIFI_10S_TIMEOUT           	10
#define WIFI_20S_TIMEOUT           	20
#define WIFI_30S_TIMEOUT           	30
#define WIFI_1MIN_TIMEOUT           	60
#define WIFI_3MIN_TIMEOUT           	180
#define WIFI_5MIN_TIMEOUT           	300


extern uint8_t AP_Channel;          //AP���ӵ��ŵ�

/****************************************************************/
void WIFI_GPIO_CONFIG(void);
char WIFI_INIT(void);
char WIFI_Open_cmdMode(void);
char WIFI_STA_Status(void);
char WIFI_Query_STA_RSSI(void);
char WIFI_Set_TCPConnectIP(char *ip,char *port);
char WIFI_Query_TCPConnectSocket(void);
char WIFI_Send_data(uint8_t sock_fd, uint16_t send_len, uint8_t *buf);
char WIFI_Set_STAMode(void);
char WIFI_Open_STA(void);
char WIFI_Set_STASSID(char *stassid,char *stapwd);
char WIFI_Open_TCPConnect(void);
void WIFI_Query_macaddr(void);
void WIFI_Query_fwversion(void);
void WIFI_Reset(void);
void WIFI_Restore(void);
void WIFI_SaveConfig(void);
void WIFI_SetRFLowPower(void);
void WIFI_OpenDHCP(void);
void WIFI_Query_STAStatus(void);
void WIFI_Query_rssi(void);
void WIFI_Query_IPconifg(void);
char WIFI_Query_TCPStatus(void);
void WIFI_Open_Event(void);
void WIFI_Query_TCPConnectIP(void);
char WIFI_ConnectIPCompare(void);
void WIFI_UART_Send(char *tx_buf,uint16_t buflen);
char WIFI_Req_STASSID(void);
void WIFI_SetBaud(uint32_t baud);


#endif