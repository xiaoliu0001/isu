
#include "includes.h"
void Send_Softver2uart(USART_TypeDef* USARTx);
void Send_Hardver2uart(USART_TypeDef* USARTx);
void Send_Mac2uart(USART_TypeDef* USARTx);
void Send_Heart_breath2uart(USART_TypeDef* USARTx);
void Send_Softver2uart(USART_TypeDef* USARTx)
{
    uint8_t i=0;
	uint8_t dat[25];
    uint8_t dat_len=0;
	uint8_t jiaoyan = 0 ;
	
	dat[dat_len++] = CMD_START;
    
	dat[dat_len++] = 4;
	dat[dat_len++] = 1;
	
	
	dat[dat_len++] = SOFTWARE_MAJORVER;
	dat[dat_len++] = SOFTWARE_MINORVER;
    dat[dat_len++] = SOFTWARE_TESTVER;
    
	
	dat[dat_len++] = CMD_LF1;
	dat[dat_len++] = CMD_LF2;
    
    SendDataBufToUSART(USARTx,dat,dat_len);
}
void Send_Hardver2uart(USART_TypeDef* USARTx)
{
    uint8_t i=0;
	uint8_t dat[25];
    uint8_t dat_len=0;
	uint8_t jiaoyan = 0 ;
	
	dat[dat_len++] = CMD_START;
    
	dat[dat_len++] = 4;
	dat[dat_len++] = 2;
	
	
	dat[dat_len++] = HARDWARE_MAJORVER;
	dat[dat_len++] = HARDWARE_MINORVER;
    dat[dat_len++] = HARDWARE_TESTVER;
    
	
	dat[dat_len++] = CMD_LF1;
	dat[dat_len++] = CMD_LF2;
    
    SendDataBufToUSART(USARTx,dat,dat_len);
}

void Send_Mac2uart(USART_TypeDef* USARTx)
{
    uint8_t i=0;
	uint8_t dat[25];
    uint8_t dat_len=0;
	uint8_t jiaoyan = 0 ;
	
	dat[dat_len++] = CMD_START;
    
	dat[dat_len++] = MAC_Len+1;
	dat[dat_len++] = 3;
	
	for(i=0;i<MAC_Len;i++)
        dat[dat_len++]=MAC_ID[i];  
	
	
	dat[dat_len++] = CMD_LF1;
	dat[dat_len++] = CMD_LF2;
    
    SendDataBufToUSART(USARTx,dat,dat_len);
}
void Send_Heart_breath2uart(USART_TypeDef* USARTx)
{
    uint8_t i=0;
	uint8_t dat[25];
    uint8_t dat_len=0;
	uint8_t jiaoyan = 0 ;
	
	dat[dat_len++] = CMD_START;
    
	dat[dat_len++] = 0x04;
	dat[dat_len++] = 0x10;
	
	if(Status_ExtSensorOnbed == EXTSENSOR_PEOPLEONBED)
        dat[dat_len++] =1;//�ٴ�
    
	if((Flag_PeopleTurnforHert>0))
		dat[dat_len++]=2;//�嶯
    
    if(Status_ExtSensorOnbed != EXTSENSOR_PEOPLEONBED)
        dat[dat_len++] =3;//�봲
	
	dat[dat_len++] =heart_avg;
    dat[dat_len++] =breath_avg;
    
	dat[dat_len++] = CMD_LF1;
	dat[dat_len++] = CMD_LF2;
    
    SendDataBufToUSART(USARTx,dat,dat_len);
}