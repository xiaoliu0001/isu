/**************************************************************************//**
 * @file     spi.c
 * @brief    Ӳ��SPI�ӿ�����
 * @version  V1.0
 * @date     2018.09
 * @note
 * Copyright (C) 2018���
 *
 * @par    W25QXX HAL��spi��������
 *   
 ******************************************************************************/


#ifndef __SPI_H
#define __SPI_H
#include "sys.h"

extern SPI_HandleTypeDef SPI5_Handler;  //SPI5���
extern SPI_HandleTypeDef SPI2_Handler;  //SPI3���
extern SPI_HandleTypeDef SPI1_Handler;  //SPI1���


void SPI5_Init(void);
void SPI2_Init(void);
void SPI1_Init(void);
void SPI5_SetSpeed(uint8_t SPI_BaudRatePrescaler);
void SPI2_SetSpeed(uint8_t  SPI_BaudRatePrescaler);
void SPI1_SetSpeed(uint8_t  SPI_BaudRatePrescaler);
uint8_t SPI5_ReadWriteByte(uint8_t TxData);
uint8_t SPI2_ReadWriteByte(uint8_t TxData);
uint8_t SPI1_ReadWriteByte(uint8_t TxData);

#endif
