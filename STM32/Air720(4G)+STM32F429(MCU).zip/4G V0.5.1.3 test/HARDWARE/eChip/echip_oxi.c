#include "../eChip/echip_oxi.h"
#include "Parameter.h"
SpO2Info spo2information;
uint8_t Send_OXData_Flag = 0;
u8 OXY_DATA[]={0x81,0x4c,0x4b,0x49,0x47,0x44,0x40,0x3a,0x34,0x2c,0x24,0x7f,0x07,0x08,0x46,0x63,0x02,0x00,0x39,0x5c,0x81,0x1b,0x12,0x09,0x00,0x78,0x70,0x6a,0x64,0x60,0x5c,0x0f,0x00,0x02,0x46,0x63,0x02,0x00,0x39,0x1e};
uint8_t OX_Pulse_Wave_Data[256] = {0};
uint8_t Pulse_Wave_Data_Num = 0;
/****************************************************************************
*	�� �� ��: eChip_GPIO_Config
*	����˵��: eChip GPIO����
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void eChip_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_Initure;
	
	ECHIP_ID_GPIO_CLK_ENABLE();           //����ʱ��	
    GPIO_Initure.Pin=ECHIP_ID_PIN;
    GPIO_Initure.Mode=GPIO_MODE_OUTPUT_PP;  //�������
    GPIO_Initure.Pull=GPIO_PULLUP;          //����
    GPIO_Initure.Speed=GPIO_SPEED_HIGH;     //����
    HAL_GPIO_Init(ECHIP_ID_GPIO_PORT,&GPIO_Initure);
	
	ECHIP_RESET_GPIO_CLK_ENABLE();           //����ʱ��	
    GPIO_Initure.Pin=ECHIP_RESET_PIN;
    GPIO_Initure.Mode=GPIO_MODE_OUTPUT_PP;  //�������
    GPIO_Initure.Pull=GPIO_PULLUP;          //����
    GPIO_Initure.Speed=GPIO_SPEED_HIGH;     //����
    HAL_GPIO_Init(ECHIP_RESET_GPIO_PORT,&GPIO_Initure);
	
	eChip_ID(1);
	eChip_Reset(0);
}
    /******************************************/
/****************************************************************************
*	�� �� ��: Get_eChip_Info
*	����˵��: ��ȡechipģ�����Ϣ
*	��    �Σ�cmd��Ҫ��ȡ��Ϣ�����data����
*	�� �� ֵ: ��
* ˵    ����cmd�ο�DefineHost_CMD ��oxiCMD_SpO2AVERANGE������ �������������Ϊ0
*****************************************************************************/
void Get_eChip_Info(u8 cmd,u8 data)
{
	u8 send_data[3];
	u8 i;
	send_data[0]=cmd;
	send_data[1]=data;
	send_data[2]=(send_data[1]+send_data[2])&0x7f;
	for(i=0;i<3;i++)
		//SendDataToUSART(USART1,send_data);
		;
}
/**
* @file   SpO2_Data_SumCheck
* @brief  spo2����У��
* @param  data ����ָ�룬data_len���ݳ���
* @retval У����
*/
static u8 SpO2_Data_SumCheck(u8 *data,u8 data_len)
{
	char i,checksum=0;
	u8 result=0;
	for(i=0;i<19;i++)
		checksum+=data[i];
	checksum &= (~0x80);
	result = (checksum == data[data_len-1]) ? SUCCESS: FAILED;
	
	return result;

}
/**
* @file   SpO2_Data_Processe
* @brief  spo2���ݽ���
* @param  data ����ָ�룬data_len���ݳ���
* @retval null
*/
void SpO2_Data_Processe(u8 *data,u8 data_len)
{
	char i=0;
	char bit7=0;
	if(SpO2_Data_SumCheck(data,data_len))
	{
		switch(data[0])
		{
			case oxiCMD_SpO2DATA:
				for(i=0;i<7;i++)
				{
					bit7=(data[11]&(0x01<<i)) > 0 ? 1:0;
					bit7<<=7;
					spo2information.pulse_wave[i]=data[1+i]|bit7;

				}
				for(i=0;i<3;i++)
				{
					bit7=(data[12]&(0x01<<i)) > 0 ? 1:0;
					bit7<<=7;
					spo2information.pulse_wave[i+7]=data[8+i]|bit7;

				}
				spo2information.pulse_volume	= data[13]&0x07;//0000 0111 ���
				spo2information.heart_breas		= data[13]&0x60;//0110 0000
				spo2information.heart_breas	  <<= 1;
				spo2information.heart_breas	   |= data[14]; //����
				spo2information.spo2_val		= data[15];//Ѫ��
				spo2information.perfusion		= (data[17]&0x40)<<1;//0100 0000
				spo2information.perfusion	   |= data[18];//��עˮƽ
				if(data[16]&0x01)
					spo2information.sensor_sta = oxiPULSE_SEARCH;
				else if(data[16]&0x02)
					spo2information.sensor_sta = oxiSENSOR_ON;
				else if(data[16]&0x04)
					spo2information.sensor_sta = oxiSENSOR_OFF;
				else if(data[16]&0x08)
					spo2information.sensor_sta = oxiSENSOR_DISCON;
				else if(data[16]&0x10)
					spo2information.sensor_sta = oxiINT_MOTION;
				else if(data[16]&0x20)
					spo2information.sensor_sta = oxiINT_SUNLIGHT;
				else if(data[16]&0x40)
					spo2information.sensor_sta = oxiITN_POWER;

				else if(data[17]&0x04)
					spo2information.sensor_sta = oxiSENSOR_FAULT;
				else if(data[17]&0x08)
					spo2information.sensor_sta = oxiOVER_CURRENT;
				else if(data[17]&0x10)
					spo2information.sensor_sta = oxiOVER_VOLTAGE;
				else if(data[17]&0x20)
					spo2information.sensor_sta = oxiCHECK_EEROR;
				else if(data[13]&0x10)
					spo2information.sensor_sta = oxiLOW_BATTERY;

				spo2information.signal_qual=data[17]&0x03;
				#if 1
                /* ÿ��500ms��һ�����������ֵ */
              //  if (spo2information.sensor_sta == 2)
//                {
//					if (OX_Pulse_Wave_CountTimer >= 5)    //lqs test
//					{
//							for(uint8_t k=0; k<10; k++)   //���Ե�10���ֵ����ͬ������ֻȡһ��
//							{
//									//printf("pulse_wave[%d] = %d\r\n",k,spo2information.pulse_wave[k]);
//									OX_Pulse_Wave_Data[Pulse_Wave_Data_Num++] = spo2information.pulse_wave[k];
//							}
							OX_Pulse_Wave_Data[Pulse_Wave_Data_Num++] = spo2information.pulse_wave[5];  //lqs test
							if(Pulse_Wave_Data_Num > 250) 
									Pulse_Wave_Data_Num = 250;
							
							OX_Pulse_Wave_CountTimer = 0;
//					}
//                }
					if(Pulse_Wave_Data_Num >= 3)   //lqs test  �����ж�������Ϊ��ÿ֡����24���ֽ�
						Send_OXData_Flag = 1;
                #endif
				#if DEBUG_SSCOUT
                    printf("***************************************************\r\n");
                    printf("������״̬:\t%d\r\n",spo2information.sensor_sta);
					printf("Ѫ��:\t\t%d\r\n",spo2information.spo2_val);
					printf("����:\t\t%d\r\n",spo2information.heart_breas);
					printf("�ź�����:\t%d\r\n",spo2information.signal_qual);
					printf("��עˮƽ:\t%d\r\n",spo2information.perfusion);
					printf("��������:\t");
					for(i=0;i<10;i++)
						printf("%d\t",spo2information.pulse_wave[i]);
                    printf("\r\n�������:\t%d\r\n",spo2information.pulse_volume);
                    printf("***************************************************\r\n");
					
				#endif
				break;
				
				case oxiCMD_SpO2AVERANGE:
					spo2information.spo2_ave=data[1]&0x7f;
				break;

				case oxiCMD_VERSION:
					spo2information.version=data[1]&0x7f;
				break;

				case oxiCMD_SN:

					for(i=0;i<8;i++)
						spo2information.SN[i]=data[1+i]&0x7f;
				break;	

				case oxiCMD_SELFCHECK:
					spo2information.selfcheck=data[1]&0x7f;
				break;

				case oxiCMD_MANUFACTURER:
					for(i=0;i<17;i++)
					spo2information.manufacturer[i]=data[1+i]&0x7f;
				break;	
		}
		
	}
	else 
    {
//        printf("DATA_ERRO\r\n");
//        for(i=0;i<data_len;i++)
//            printf("%02x ",data[i]);
//        printf("\r\n");
    }
}
