/**************************************************************************//**
 * @file     USART.h
 * @brief    ����ͨ��
 * @version  V2.0
 * @date     2018.9
 * @note
 * Copyright (C) 2017 ���
 *
 * @par   V1.0 STM32ʹ�ñ�׼��
 *   	V2.0  STM32F429 ʹ��HAL��
 *		V2.1  ʹ��DMA�����жϷ�ʽ����
 ******************************************************************************/
#ifndef __USART_H
#define __USART_H

#include "stdio.h"	
#include "sys.h"
#include "Parameter.h"

/**********��ͬģ�����Ӳ�ͬ�Ĵ���ʱ����Ҫ�޸����µĺ궨��***********************/
#define UART_INTRXLEN  UARTBUF_MAX_LEN

extern UART_HandleTypeDef UART1_Handler; //UART���
extern UART_HandleTypeDef UART2_Handler;
extern UART_HandleTypeDef UART3_Handler;
extern UART_HandleTypeDef UART4_Handler;

extern uint8_t UART1_RXBUF[UART_INTRXLEN];
extern uint8_t UART2_RXBUF[UART_INTRXLEN];
extern uint8_t UART3_RXBUF[UART_INTRXLEN*3];
extern uint8_t UART4_RXBUF[UART_INTRXLEN];

extern DMA_HandleTypeDef DMA_UART1_RX;
extern DMA_HandleTypeDef DMA_UART2_RX;	
extern DMA_HandleTypeDef DMA_UART3_RX;
extern DMA_HandleTypeDef DMA_UART4_RX;

#define OXY_UART     	USART1
#define LTE_UART        USART3              
#define DEBUG_UART     	USART2
#define BLE_UART    	UART4

void UART1_Init(uint32_t bound);
void UART2_Init(uint32_t bound);
void UART3_Init(uint32_t bound);
void UART4_Init(uint32_t bound);
void ClearUSARTBUF(USART_TypeDef* USARTx);
void SendDataBufToUSART( USART_TypeDef* USARTx,uint8_t *buf,uint16_t len);
void SendDataToUSART( USART_TypeDef* USARTx,uint8_t ch);
void SendDatasToUSART( USART_TypeDef* USARTx,uint16_t ch);

void MYDMA_USART_Transmit(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size);
    
#define RXBUFFERSIZE   1 //�����С
extern u8 aRxBuffer[RXBUFFERSIZE];//HAL��USART����Buffer
#endif


