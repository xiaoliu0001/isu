/**************************************************************************//**
 * @file     USART.h
 * @brief    ����ͨ��
 * @version  V2.0
 * @date     2018.9
 * @note
 * Copyright (C) 2017 ���
 *
 * @par   V1.0 STM32ʹ�ñ�׼��
 *   	V2.0  STM32F429 ʹ��HAL��
 ******************************************************************************/
#ifndef __USART_H
#define __USART_H

#include "stdio.h"	
#include "sys.h"
#include "Parameter.h"

/**********��ͬģ�����Ӳ�ͬ�Ĵ���ʱ����Ҫ�޸����µĺ궨��***********************/
#define UART_INTRXLEN  1

extern UART_HandleTypeDef UART1_Handler; //UART���
extern UART_HandleTypeDef UART2_Handler;
extern UART_HandleTypeDef UART3_Handler;
extern UART_HandleTypeDef UART4_Handler;
extern uint8_t UART1_RXBUF[UART_INTRXLEN];
extern uint8_t UART2_RXBUF[UART_INTRXLEN];
extern uint8_t UART3_RXBUF[UART_INTRXLEN];
extern uint8_t UART4_RXBUF[UART_INTRXLEN];

//�޸����´���ָ��֮��ͬʱ��Ҫ�޸�USART.C�ļ��У� ����HAL_UART_RxCpltCallback�еĴ��ڽ���buf��UART1_RXBUF��
#define WiFi_UART       USART1              
#define DEBUG_UART     	USART2
#define BLE_UART    	USART3

#define   DebugUART_Handler     UART2_Handler
#define   WiFiUART_Handler      UART4_Handler
#define   BLEUART_Handler       UART3_Handler

void UART1_Init(uint32_t bound);
void UART2_Init(uint32_t bound);
void UART3_Init(uint32_t bound);
void UART4_Init(uint32_t bound);
void ClearUSARTBUF(USART_TypeDef* USARTx);
void SendDataBufToUSART( USART_TypeDef* USARTx,uint8_t *buf,uint16_t len);
void SendDataToUSART( USART_TypeDef* USARTx,uint8_t ch);
void SendDatasToUSART( USART_TypeDef* USARTx,uint16_t ch);

#endif


