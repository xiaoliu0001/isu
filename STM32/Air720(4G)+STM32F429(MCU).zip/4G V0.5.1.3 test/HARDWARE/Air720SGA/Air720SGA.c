/***********************************************************************************
 * @file     Air720SGA.c
 * @brief    main�ļ�
 * @version  V1.0
 * @date     2020.1.16
 * @note
 * Copyright 
 *
 * @par      ����4Gģ��Air720SGA����
************************************************************************************/

#include "Air720SGA.h"
#include "os.h"

uint8_t Command_SendCount = 0;
uint8_t Flag_Networkmode = NON_CDMAMODE;  //����ģʽ��NON_CDMAMODE or IN_CDMAMODE
uint16_t  Position_LAC;        //GPRS LACλ������
uint16_t  Position_CID;        //GPRS CIDλ������
uint16_t  Position_SID;        //GPRS SIDλ������
uint16_t  Position_NID;        //GPRS NIDλ������
uint16_t  Position_BID;        //GPRS BIDλ������
unsigned char CSQNual = 0;
uint8_t Socket = 0;



unsigned char SIMCard_IMEI[25];
uint8_t SIMCard_IMEI_Len=0;
unsigned char SIMCard_IMSI[20];
uint8_t SIMCard_IMSI_Len = 0;
unsigned char SIMCard_ICCID[25];
uint8_t SIMCard_ICCID_Len = 0;
uint8_t Flag_DataSendMode = 0;   //���ݴ���ģʽ
uint8_t Flag_LTEInitStep = 0;     //LTE��ʼ���Ĺ��̲���
uint16_t  LTE_InitTime=0;  //LTE��ʼ��ʱ��
uint16_t  LTE_Init_pauseTime =0 ; 
uint16_t  LTE_Time = 0;             //LTEģ��ָ��ʱ��
char  LTE_InquireIMEI(void);
/****************************************************************************
*	�� �� ��: LTE_GPIO_CONFIG
*	����˵��: LTE  4Gģ��IO����
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
void LTE_GPIO_CONFIG(void)
{

	GPIO_InitTypeDef GPIO_Initure;
	
	LTE_PWRKEY_GPIO_CLK_ENABLE();           //����ʱ��	
    GPIO_Initure.Pin=LTE_PWRKEY_PIN;
    GPIO_Initure.Mode=GPIO_MODE_OUTPUT_PP;  //�������
    GPIO_Initure.Pull=GPIO_PULLUP;          //����
    GPIO_Initure.Speed=GPIO_SPEED_HIGH;     //����
    HAL_GPIO_Init(LTE_PWRKEY_GPIO_PORT,&GPIO_Initure);

	LTE_RESETN_GPIO_CLK_ENABLE();           //����ʱ��	
    GPIO_Initure.Pin=LTE_RESETN_PIN;
    GPIO_Initure.Mode=GPIO_MODE_OUTPUT_PP;  //�������
    GPIO_Initure.Pull=GPIO_PULLUP;          //����
    GPIO_Initure.Speed=GPIO_SPEED_HIGH;     //����
    HAL_GPIO_Init(LTE_RESETN_GPIO_PORT,&GPIO_Initure);
	
	LTE_DTR_GPIO_CLK_ENABLE();           //����ʱ��	
    GPIO_Initure.Pin=LTE_DTR_PIN;
    GPIO_Initure.Mode=GPIO_MODE_OUTPUT_PP;  //�������
    GPIO_Initure.Pull=GPIO_PULLUP;          //����
    GPIO_Initure.Speed=GPIO_SPEED_HIGH;     //����
    HAL_GPIO_Init(LTE_DTR_GPIO_PORT,&GPIO_Initure);
	
	LTE_PWRKEY(0);	
	LTE_RESETN(0);
	LTE_DTR(0);

	
}
/****************************************************************************
*	�� �� ��: LTE_StartUP
*	����˵��: LTE����
*	��    �Σ�
*	�� �� ֵ:���س�ʼ����ɵĲ���
* 	˵    ����
*****************************************************************************/
char LTE_StartUP(void)
{
	
	if(Flag_COMDebug == 1)
	{						
		printf("Start up LTE \r\n");
	}
	delay_ms(50);
	LTE_PWRKEY(1);
	delay_ms(3000);
	LTE_PWRKEY(0);
	LTE_Time = 0;

	while(1)
	{		
		delay_ms(500);
        
		if(strstr(LTEUART_RX_BUFFER,"RDY")!= NULL)  //�����ɹ�
		{
			ClearUSARTBUF(LTE_UART);
            //printf("Start up LTE Success\r\n");
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_10S_TIMEOUT)
		{
			LTE_SoftPowerOff();
			ClearUSARTBUF(LTE_UART);
            //printf("Start up LTE Fail\r\n");
			return LTE_FAIL;
		}
		
	}
	
}
/****************************************************************************
*	�� �� ��: LTE_StartUP
*	����˵��: LTE����
*	��    �Σ�
*	�� �� ֵ:���س�ʼ����ɵĲ���
* 	˵    ����
*****************************************************************************/
char LTE_PowerDown(void)
{
	if(Flag_COMDebug == 1)
	{						
		printf("Power Down LTE \r\n");
	}
	if(LTE_SoftPowerOff()==LTE_FAIL)  //�ػ�
	{
		LTE_RESETN(1);
		delay_ms(1500);
		LTE_RESETN(0);
	}
}
/****************************************************************************
*	�� �� ��: LTE_INIT
*	����˵��: ����ģ���ʼ��
*	��    �Σ�
*	�� �� ֵ:���س�ʼ����ɵĲ���
* ˵    ����
*****************************************************************************/
char LTE_INIT(void)
{
    char res1,res2,res3;
	if(LTE_InitTime>=NETWORKLINK_TIMEOUT_60S)
	{
		LTE_PowerDown();
		LTE_StartUP();
		LTE_InitTime = 0;
		return LTE_INIT_STEP1;
	}
    switch(Flag_LTEInitStep)
    {
        case LTE_INIT_STEP1:
                if(LTE_Query_PIN()==LTE_SUCCESS)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP2;
                }
         
		
            break;
        case LTE_INIT_STEP2: 
                LTE_EchoEnable(0);  //�ر�ָ�����
                LTE_InquireIMEI();
                //LTE_InquireIMSI();
                LTE_InquireICCID();
                if(ICCID_Save[0]!=0)
                {
                    res1=strcmp(SIMCard_ICCID,ICCID_Save);
                    res2=strcmp(SIMCard_IMEI,IMEI_Save);

                    
                    if(res1!=0||res2!=0)//�������룬�ȴ�10���Ӽ���
                    {
                        Flag_CARD_ISCHANGE = CARD_HASCHANGE;
                        printf("ICCID NOT MATCH IMEI\r\n");
                        Flag_LTEInitStep = LTE_INIT_PAUSE;
                    }
                    else
                    {
                        Flag_CARD_ISCHANGE = CARD_NOCHANGE;
                        Flag_LTEInitStep = LTE_INIT_STEP3;
                    }
                }
                else
                {
                    printf("ICCID SAVED IS NULL\r\n");
                    Flag_LTEInitStep = LTE_INIT_STEP3;
                    LTE_Init_pauseTime=0;
                    LTE_InitTime=0;
                }
            break;
          case LTE_INIT_STEP3:
              if(LTE_Query_CSQ() == LTE_SUCCESS)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP4;
                }
              break;
          case LTE_INIT_STEP4:
              if(LTE_NetworkRegistration(2)==LTE_CONNECT)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP5;
                }
              break;
          case LTE_INIT_STEP5:
              /*
                if(LTE_Query_PDPstate()!=LTE_SUCCESS)
                {
                    if(LTE_Activate_PDPContext() == LTE_SUCCESS)
                    {			
                        
                        Flag_LTEInitStep = LTE_INIT_STEP6;
                    }
                    else
                    {
                        LTE_Query_PDPstate();
                        delay_ms(1000);
                        Flag_LTEInitStep = LTE_INIT_STEP1;
                    }
                }
                else
                {
                    Flag_LTEInitStep = LTE_INIT_STEP6;
                }
          */
                 if(GPRS_Attach_Detach()==LTE_SUCCESS)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP6;
                }
              break;
           case LTE_INIT_STEP6:
                 if(LTE_Set_ConnectIP_MUX()==LTE_SUCCESS)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP7;
                }
              break;
           case LTE_INIT_STEP7:
                 if(LTE_Select_Data_Sending_Mode()==LTE_SUCCESS)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP8;
                }
              break;
           case LTE_INIT_STEP8:
               
                 if(Set_APN_Function()==LTE_SUCCESS)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP9;
                }
              break;
           case LTE_INIT_STEP9:
                 if(Activate_Wireless_Connection()==LTE_SUCCESS)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP10;
                }
              break;
           case LTE_INIT_STEP10:
                 if(Get_LocalIP_Address()==LTE_SUCCESS)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP11;
                }
              break;
            case LTE_INIT_STEP11:
                 if(LTE_Query_TCPstate()==LTE_SUCCESS)
                {
                    Flag_LTEInitStep = LTE_INIT_STEP12;
                }
              break;
          case LTE_INIT_PAUSE:
              if(LTE_Init_pauseTime>=1)
                {
              //      printf("LTE Init continue\r\n");
                    Flag_LTEInitStep = LTE_INIT_STEP3;
                    LTE_Init_pauseTime=0;
                    LTE_InitTime=0;
                }
              break;
          default:
              break;
    }
    return Flag_LTEInitStep;
	
}
/****************************************************************************
*	�� �� ��: LTE_SoftPowerOff
*	����˵��: �����ػ�
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ����
*****************************************************************************/
char LTE_SoftPowerOff(void)
{
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CPOWD=1\r\n");  //�����ػ���=1�����ػ�
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(100);
		if(strstr(LTEUART_RX_BUFFER,"NORMAL POWER DOWN")!= NULL)
		{
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
	
	
}
/****************************************************************************
*	�� �� ��: LTE_EchoEnable
*	����˵��: ʹ�ܻ��߹ر�ʹ��ָ�����
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ��������1��ʾ��ȡ����ȷ��IMSI�ţ�����0��ʾ��ȡʧ��
*****************************************************************************/
char LTE_EchoEnable(uint8_t echo)
{
	char cmd[20]="";
	ClearUSARTBUF(LTE_UART);
	sprintf(cmd,"ATE%d\r\n",echo);
	LTE_Send_String(cmd);
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(50);
        //printf("ATE:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set echo:%d successed\r\n",echo);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set echo:%d time out:%s\r\n",echo,LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
		
	}
	
}
/****************************************************************************
*	�� �� ��: LTE_InquireIMEI
*	����˵��: ��ѯsim����IMEI��
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ��������1��ʾ��ȡ����ȷ��IMEI�ţ�����0��ʾ��ȡʧ��
*****************************************************************************/
char  LTE_InquireIMEI(void)
{
	char *pstr =NULL;
	char stringbuf1[30]={0};
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CGSN\r\n");
	LTE_Time = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
        //printf("AT+CGSN:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL)
		{
			sscanf(LTEUART_RX_BUFFER,"%s\r\n%s",&SIMCard_IMEI,stringbuf1);
			SIMCard_IMEI_Len = strlen(SIMCard_IMEI);
			SIMCard_IMEI[SIMCard_IMEI_Len]= '\0';					
									
				//printf("IMEI:%s\r\n",SIMCard_IMEI);
			
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(strstr(LTEUART_RX_BUFFER,"ERROR") != NULL)
		{			 
			LTE_Send_String("AT+CGSN\r\n");
			Command_SendCount++;
			ClearUSARTBUF(LTE_UART);
			delay_ms(50);
		}	
		if((LTE_Time>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("IMEI read time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: LTE_InquireIMSI
*	����˵��: ��ѯsim����IMSI��
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ��������1��ʾ��ȡ����ȷ��IMSI�ţ�����0��ʾ��ȡʧ��
*****************************************************************************/
/*
char  LTE_InquireIMSI(void)
{
	char *pstr =NULL;
	
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CIMI\r\n");
	LTE_Time = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL)
		{
			pstr = strstr(LTEUART_RX_BUFFER,"460");
			SIMCard_IMSI_Len = 0;
			while(*pstr != 0x0D)
			{
				SIMCard_IMSI[SIMCard_IMSI_Len++] = *pstr++;
			}
			SIMCard_IMSI[SIMCard_IMSI_Len]= '\0';					
			if(Flag_COMDebug == 1)
			{						
				printf("IMSI:%s\r\n",SIMCard_IMSI);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(strstr(LTEUART_RX_BUFFER,"ERROR") != NULL)
		{			 
			LTE_Send_String("AT+CIMI\r\n");
			Command_SendCount++;
			ClearUSARTBUF(LTE_UART);
			delay_ms(50);
		}	
		if((LTE_Time>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("IMSI read time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
}
*/
/****************************************************************************
*	�� �� ��: LTE_InquireICCID
*	����˵��: ��ѯsim����ICCID�� ���ɵ�·��ʶ���룬�����
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ��������1��ʾ��ȡ����ȷ��ICCID�ţ�����0��ʾ��ȡʧ��
*   ICCID��Integrate circuit card identity ���ɵ�·��ʶ���뼴SIM�����ţ��൱���ֻ����������֤�� 
*   ICCIDΪIC����Ψһʶ����룬����20λ������ɣ�������ʽΪ��XXXXXX 0MFSS YYGXX XXXX��
*   �ֱ�������£� 
*   ǰ��λ��Ӫ�̴��룺�й��ƶ���Ϊ��898600��898602 ��
*   �й���ͨ��Ϊ��898601��898609��
*   �й�����898603��898606��
*****************************************************************************/
char  LTE_InquireICCID(void)
{
	char *pstr =NULL;
	char stringbuf1[30]={0};
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+ICCID\r\n");
	LTE_Time = 0;
	Command_SendCount=0;
	
	
	while(1)
	{		
		delay_ms(50);
        //printf("AT+ICCID:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"+ICCID")!= NULL)
		{
//			pstr = strstr(LTEUART_RX_BUFFER,"8986");
			sscanf(LTEUART_RX_BUFFER,"%*[^:]: %s\r\n%s",&SIMCard_ICCID,stringbuf1);
			SIMCard_ICCID_Len = strlen(SIMCard_ICCID);
			SIMCard_ICCID[SIMCard_ICCID_Len]= '\0';					
			if(Flag_COMDebug == 1)
			{						
				printf("ICCID:%s\r\n",SIMCard_ICCID);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(strstr(LTEUART_RX_BUFFER,"ERROR") != NULL)
		{			 
			LTE_Send_String("AT+ICCID\r\n");
			Command_SendCount++;
			ClearUSARTBUF(LTE_UART);
			delay_ms(50);
		}
		if((LTE_Time>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("ICCID resd time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: LTE_NetworkRegistration
*	����˵��: LTE ����ע��
*	��    �Σ�0    Disable network registration unsolicited result code
*			1    Enable network registration unsolicited result code +CREG: <stat>
*			2    Enable network registration unsolicited result code with location information 
*				Non-CDMA mode +CREG: <stat>[,<lac>,<ci>[,<Act>]]	
*               CDMA mode   +CGREG: <n>,<stat>[,<sid>,<nid_bid>,<Act>] 
*	�� �� ֵ: 
*	˵    ����������Ϊ2ʱ�����Բ�ѯλ����Ϣ��
*	<stat>      0    Not registered, ME is not currently searching a new operator to register to 
*        1    Registered, home network 
*        2    Not registered, but ME is currently searching a new operator to register to 
*        3    Registration denied 
*        4    Unknown 
*  		5    Registered, roaming 
*****************************************************************************/
char LTE_NetworkRegistration(uint8_t NR)
{
	char *pstr =NULL;
	char cmd[30]={0};
	uint8_t  n=0;   //��ȡ2
	uint8_t stat=0;//��ȡ1
	char stringbuf1[30]={0};//��ȡ����
	
	ClearUSARTBUF(LTE_UART);
    /*
	sprintf(cmd,"AT+CREG=%d\r\n",NR);
	LTE_Send_String(cmd);
	LTE_Time = 0;
	
	
	while(1)
	{
		delay_ms(50);
        printf("AT+CREG=2:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL)
		{
			ClearUSARTBUF(LTE_UART);
			break;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set CREG=%d time out:%s\r\n",NR,LTEUART_RX_BUFFER);
			}
			return LTE_FAIL;
		}
	}
    */
	LTE_Send_String("AT+CREG?\r\n");
	LTE_Time = 0;
	Command_SendCount=0;
	
	while(1)
	{
		delay_ms(50);
        //printf("AT+CREG?:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"+CREG: ")!= NULL)
		{
			sscanf(LTEUART_RX_BUFFER,"%*[^:]: %d,%d,%s",&n,&stat,stringbuf1);
			if(stat == 1)
			{
				if(Flag_COMDebug == 1)
				{						
					printf("4G Registered home network\r\n");
				}
				ClearUSARTBUF(LTE_UART);
				return LTE_CONNECT;
			}
			else
			{
				if(Flag_COMDebug == 1)
				{					
					printf("4G Not registered\r\n");
				}
				ClearUSARTBUF(LTE_UART);
				return LTE_NOCONNECT;
			}		
			
		}		
		if(strstr(LTEUART_RX_BUFFER,"ERROR")!= NULL)
		{
			ClearUSARTBUF(LTE_UART);
			LTE_Send_String("AT+CREG?\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((LTE_Time>LTE_5S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Read registered status time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
		
	}
	
}
/****************************************************************************
*	�� �� ��: LTE_GetPosition
*	����˵��: LTE ��ȡλ����Ϣ
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����������Ϊ2ʱ�����Բ�ѯλ����Ϣ��In CDMA mode
*			+CREG: 2,1,"3614","0024352",100
*****************************************************************************/
/*
char LTE_GetPosition(void)
{
	char *pstr =NULL;
	uint8_t  n=0;   //��ȡ2
	uint8_t stat=0;//��ȡ1
	char stringbuf1[10]={0};//��ȡ3614
	char stringbuf2[10]={0};//��ȡ0024352
	uint8_t act=0;//��ȡ100
	char stringbuf3[10]={0};//��������
	
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CREG?\r\n");
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"+CREG: 2,1")!= NULL)   //��ȡλ����Ϣ
		{
			if(Flag_COMDebug == 1)
			{
				printf("%s",LTEUART_RX_BUFFER);
			}
			sscanf(LTEUART_RX_BUFFER,"%*[^:]: %d,%d,\"%[^\"]\",\"%[^\"]\",%d\r\n%s",&n,&stat,stringbuf1,stringbuf2,&act,stringbuf3);
			if(act == 100)  //In CDMA mode
			{
				Flag_Networkmode = IN_CDMAMODE;
				Position_SID = BCDstringTOINT(stringbuf1);
				
				if(Flag_COMDebug == 1)
				{
					printf("Position_SID = %x\r\n",Position_SID);
				}
				
			}
			else
			{
				Flag_Networkmode = NON_CDMAMODE;
				Position_LAC = BCDstringTOINT(stringbuf1);
				
				if(Flag_COMDebug == 1)
				{
					printf("Position_LAC = %x\r\n",Position_LAC);
				}
				
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(strstr(LTEUART_RX_BUFFER,"ERROR")!= NULL)
		{
			ClearUSARTBUF(LTE_UART);
			LTE_Send_String("AT+CREG?\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((LTE_Time>LTE_5S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Read registered status time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
}
*/
/****************************************************************************
*	�� �� ��: LTE_Query_CSQ
*	����˵��: LTE ��ȡCSQ
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/

char LTE_Query_CSQ(void)
{
	uint8_t k_flag =0;
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CSQ\r\n");
	LTE_Time = 0;
	
	
	while(1)
	{
		delay_ms(50);
        //printf("AT+CSQ=%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"+CSQ")!= NULL) 
		{
           // printf("Flag_LTEInitStep78=%d\r\n",Flag_LTEInitStep);
            k_flag = Flag_LTEInitStep;
			sscanf(LTEUART_RX_BUFFER,"%*[^:]: %d",&CSQNual);
            Flag_LTEInitStep = k_flag;
            //printf("Flag_LTEInitStep998=%d\r\n",Flag_LTEInitStep);
			if(Flag_COMDebug == 1)
			{
				printf("\r\nCSQ = %d\r\n",CSQNual);
			}
			ClearUSARTBUF(LTE_UART);
			if((CSQNual>0)&&(CSQNual<33))
			{
				return LTE_SUCCESS;
			}
			else
			{
				return LTE_FAIL;
			}
		}
		if((LTE_Time>LTE_3S_TIMEOUT))
		{
            ClearUSARTBUF(LTE_UART);
			LTE_Send_String("AT+CSQ\r\n");
            LTE_Time = 0;
			Command_SendCount++;
            if(Flag_COMDebug == 1)
			{						
				printf("\r\nRead CSQ time out:%d\r\n",Command_SendCount);
			}
			
		}
        if(Command_SendCount>10)
        {
            
			ClearUSARTBUF(LTE_UART);
            if(Flag_COMDebug == 1)
			{						
				printf("\r\nRead CSQ haven't CMD ACK \r\n");
			}
			return LTE_FAIL;
        }
            
	}
}
/*
char LTE_Query_CSQ(void)
{
	char stringbuf1[20]={0};
	
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CSQ\r\n");
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(50);
        printf("AT+CSQ:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"+CSQ")!= NULL) 
		{
            printf("Flag_LTEInitStep78=%d\r\n",Flag_LTEInitStep);
			sscanf(LTEUART_RX_BUFFER,"%*[^:]: %d,%s",&CSQNual,stringbuf1);
            printf("Flag_LTEInitStep9999=%d\r\n",Flag_LTEInitStep);

			if(Flag_COMDebug == 1)
			{
				printf("\r\nCSQ = %d\r\n",CSQNual);
			}
             
			ClearUSARTBUF(LTE_UART);
            
			if((CSQNual>0)&&(CSQNual<33))
			{
				return LTE_SUCCESS;
			}
			else
			{
				return LTE_FAIL;
			}
		}
		if(strstr(LTEUART_RX_BUFFER,"ERROR")!= NULL)
		{
			ClearUSARTBUF(LTE_UART);
			LTE_Send_String("AT+CSQ\r\n");
            LTE_Time = 0;
			Command_SendCount++;
			delay_ms(50);
		}
		if((LTE_Time>LTE_3S_TIMEOUT))
		{
            ClearUSARTBUF(LTE_UART);
			LTE_Send_String("AT+CSQ\r\n");
            LTE_Time = 0;
			Command_SendCount++;
            if(Flag_COMDebug == 1)
			{						
				printf("\r\nRead CSQ time out:%d\r\n",Command_SendCount);
			}
			
		}
        if(Command_SendCount>10)
        {
            
			ClearUSARTBUF(LTE_UART);
            if(Flag_COMDebug == 1)
			{						
				printf("\r\nRead CSQ haven't CMD ACK \r\n");
			}
			return LTE_FAIL;
        }
            
	}
}
*/
/****************************************************************************
*	�� �� ��: LTE_Set_ConnectIP_MUX
*	����˵��: LTE ����ģʽ��������
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char LTE_Set_ConnectIP_MUX(void)
{
	char stringbuf1[20]={0};
	char cmd[100]= "";
	
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CIPMUX=0\r\n");
	LTE_Time = 0;
	while(1)
	{
		delay_ms(50);
        //printf("AT+CIPMUX=0:%s\r\n",LTEUART_RX_BUFFER);

		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set IP Ϊ������\r\n");
			}

			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
            LTE_Send_String("AT+CIPMUX=0\r\n");
			if(Flag_COMDebug == 1)
			{						
				printf("Set IP fail\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
}

/****************************************************************************
*	�� �� ��: LTE_Set_ConnectIP_Mode
*	����˵��: LTE ͸��ģʽ����͸��
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
/*
char LTE_Set_ConnectIP_Mode(void)
{
	char stringbuf1[20]={0};
	char cmd[100]= "";
	
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CIPMODE=0\r\n");
	LTE_Time = 0;

	Flag_DataSendMode = LTE_DATASEND_ATMODE;

	while(1)
	{
		delay_ms(200);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set IP Mode succeed\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_TCP_CONNECT;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set IP Mode time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
}
*/
/****************************************************************************
*	�� �� ��: LTE_Set_ConnectIP_Parameter
*	����˵��:  ���� TCP ���ӻ�ע�� UDP �˿ں�
*	��    �Σ�ip ������IP��������������ʽ port �������˿�     
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char LTE_Set_ConnectIP_Parameter(char *ip,char *port)
{
	char stringbuf1[20]={0};
	char cmd[100]= "";
    ClearUSARTBUF(LTE_UART);
    sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",ip,port);  
	LTE_Send_String(cmd);	
	LTE_Time = 0;


	while(1)
	{
		delay_ms(50);
        //printf("AT+CIPSTART=:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL)
		{
            delay_ms(50);
            if((strstr(LTEUART_RX_BUFFER,"CONNECT OK")!= NULL)|| (strstr(LTEUART_RX_BUFFER,"ALREADY CONNECT")!= NULL))
            {
                if(Flag_COMDebug == 1)
                {						
                    printf("CIPSTART:%s\r\n",LTEUART_RX_BUFFER);
                }
                ClearUSARTBUF(LTE_UART);
                return LTE_TCP_CONNECT;
            }
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set IP Parameter time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: LTE_Query_TCPstate
*	����˵��: LTE ��ѯ����״̬
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char LTE_Query_TCPstate(void)
{
	uint8_t connectID = 0;
	char service_type[10]="";
	char IP_address[20]="";
	uint16_t remote_port = 0;
	uint16_t local_port = 0;
	uint8_t socket_state = 0;
	uint8_t contextID = 0;
	uint8_t serverID = 0;
	uint8_t access_mode = 0;
	char AT_port[10]="";
	char stringbuf1[10]="";
	static u8 LTE_FAILD_COUNT=0;
    
	ClearUSARTBUF(LTE_UART);	
	LTE_Send_String("AT+CIPSTATUS\r\n");
	LTE_Time = 0;
	while(1)
	{
		delay_ms(50);
        //printf("AT+CIPSTATUS:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
		{
            delay_ms(50);
			if (strstr(LTEUART_RX_BUFFER,"CONNECT OK")!= NULL)
			{
                LTE_FAILD_COUNT=0;
				if(Flag_COMDebug == 1)
				{
					printf("TCP CONNECT OK\r\n");
				}
                ClearUSARTBUF(LTE_UART);
				return LTE_TCP_CONNECT;
			}
            else if (strstr(LTEUART_RX_BUFFER,"IP STATUS")!= NULL)
			{
                LTE_FAILD_COUNT=0;
				if(Flag_COMDebug == 1)
				{
					printf("TCP IP STATUS\r\n");
				}
                ClearUSARTBUF(LTE_UART);
				return LTE_SUCCESS;
			}
			else
			{
				if(Flag_COMDebug == 1)
				{
					printf("TCP NOCONNECT\r\n");
				}
                ClearUSARTBUF(LTE_UART);
                return LTE_NOCONNECT;
			}
		}
		if(LTE_Time>LTE_1S_TIMEOUT)
		{
             LTE_FAILD_COUNT++;//������ݷ��Ͳ��ɹ�����״̬�Ʋ�����
            
            ClearUSARTBUF(LTE_UART);
            LTE_Send_String("AT+CIPSTATUS\r\n");
            LTE_Time = 0;
			if(Flag_COMDebug == 1)
			{						
				printf("Query TCP state time out:%s\r\n",LTEUART_RX_BUFFER);
			}
            ClearUSARTBUF(LTE_UART);
		}
        if(LTE_FAILD_COUNT>=3)
        {
            LTE_FAILD_COUNT=0;
            return LTE_NOCONNECT;
            if(Flag_COMDebug == 1)
			{						
				printf("Query TCP state haven't CMD ACK\r\n");
			}
            ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
        }
	}
}

/****************************************************************************
*	�� �� ��: LTE_Close_ConnectedIP
*	����˵��: LTE �Ͽ������ӵ�IP
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char LTE_Close_ConnectedIP(void)
{
	char cmd[20]={0};
	
	ClearUSARTBUF(LTE_UART);
	sprintf(cmd,"AT+CIPCLOSE\r\n"); 
	LTE_Send_String(cmd);
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"CLOSE OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{
				printf("Close IP successed\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(strstr(LTEUART_RX_BUFFER,"ERROR")!= NULL)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Close IP error:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
		if(LTE_Time>LTE_5S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("close IP time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: LTE_Activate_PDPContext
*	����˵��: LTE ����������
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
/*
char LTE_Activate_PDPContext(void)
{
	ClearUSARTBUF(LTE_UART); 
	LTE_Send_String("AT+CGACT=1\r\n");
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Active PDP contest successed\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(strstr(LTEUART_RX_BUFFER,"ERROR")!= NULL)
		{
            
			ClearUSARTBUF(LTE_UART);
			LTE_Send_String("AT+CGACT=1\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((LTE_Time>LTE_1MIN_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Active PDP contest time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}	
}
*/
/****************************************************************************
*	�� �� ��: LTE_Query_PIN(void)
*	����˵��: LTE ��ѯPIN��
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����READY�� MT is not pending for any password 
*****************************************************************************/
char LTE_Query_PIN(void)
{
	ClearUSARTBUF(LTE_UART); 
	LTE_Send_String("AT+CPIN?\r\n");
	LTE_Time = 0;
		
	while(1)
	{
		delay_ms(50);
        //printf("AT+CPIN?:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"+CPIN")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("PIN is ready\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Read PIN time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
		
	}

}
/****************************************************************************
*	�� �� ��: LTE_Query_Connection_Status(void)
*	����˵��: ��ѯLTE����״̬��
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
/*
char LTE_Query_Connection_Status(void)
{
	ClearUSARTBUF(LTE_UART); 
	LTE_Send_String("AT\r\n");
	LTE_Time = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Connection Succeed\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Connection Fail:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
		
	}

}
*/
/****************************************************************************
*	�� �� ��: LTE_EnterATmode
*	����˵��: LTE ��͸��ģʽ����ATģʽ
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
/*
char LTE_EnterATmode(void)
{
	ClearUSARTBUF(LTE_UART);
	delay_ms(1000);	
	LTE_Send_String("+++");
	LTE_Time = 0;
	while(1)
	{
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Enter at mode successed\r\n");
			}
			
			Flag_DataSendMode = LTE_DATASEND_ATMODE;

			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Enter at mode failed\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
	
}
*/
/****************************************************************************
*	�� �� ��: BCDstringTOINT
*	����˵��: ��ASCII��ʾ��BCD��ʽ����ת��Ϊ16��������
*	��    �Σ�str �ַ���
*	�� �� ֵ: ת���������
* ˵    ����
*****************************************************************************/
/*
uint16_t BCDstringTOINT(char *str)
{
	 uint8_t   data[4];
	 uint16_t  intdata=0;
	 uint8_t i=0;
	
	 for(i=0;i<4;i++)
	 {
		 if((*(str+i)>=0x30)&&(*(str+i)<=0x39))
		 {
			  data[i] = *(str+i)-0x30;
		 }
		 if((*(str+i)>=0x41)&&(*(str+i)<=0x46))
		 {
			  data[i] = *(str+i)-0x41+0x0A;
		 }
//		 printf("0x%02x ",data[i]);
	 }	 
	 intdata = data[0]<<12|data[1]<<8|data[2]<<4|data[3];
//	 printf("0x%04x ",intdata);
	 return intdata;
}
*/
/****************************************************************************
*	�� �� ��: LTE_Send_data
*	����˵��: LTE 4G���ڷ�������
*	��    �Σ�tx_buf��Ҫ���͵�����  buflen���͵����ݳ���
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char Send_Data2EC20(uint16_t send_len, uint8_t *buf)
{
    OS_ERR err;
    uint16_t i;
    static u8 retry=0;
	char cmd[20]="";
	/*
	if(Flag_DataSendMode == LTE_DATASEND_TRANSMODE)  //͸��ģʽ
	{
		MYDMA_USART_Transmit(&UART3_Handler, buf, send_len);
        
		return LTE_SUCCESS;
	}
	else*/
	//{
		ClearUSARTBUF(LTE_UART); 
		sprintf(cmd,"AT+CIPSEND=%d\r\n",send_len);
        //MYDMA_USART_Transmit(&UART3_Handler, cmd, strlen(cmd));
		LTE_Send_String(cmd);
        //printf("AT+CIPSEND=len:%s\r\n",LTEUART_RX_BUFFER);
        
		LTE_Time = 0;
		
		while(1)
		{
			OSTimeDly (100, OS_OPT_TIME_DLY, &err ); //lqs test  ���ɿ��Ź���λ�ɴ�����
			if(strstr(LTEUART_RX_BUFFER,">")!= NULL)
			{				 
				LTE_UART_Send(buf,send_len);
                //MYDMA_USART_Transmit(&UART3_Handler, buf, send_len);
                
				ClearUSARTBUF(LTE_UART);
                //printf(">:%s\r\n",LTEUART_RX_BUFFER);                
			}
            //If connection has been established but sending buffer is full,
			if(strstr(LTEUART_RX_BUFFER,"SEND FAIL")!= NULL)
			{
                if(Flag_COMDebug == 1)
				{
					printf("Send data to server FAIL\r\n");
				}
				ClearUSARTBUF(LTE_UART);
				
				LTE_Send_String(cmd);
                //MYDMA_USART_Transmit(&UART3_Handler, cmd, strlen(cmd));
			}
            //If connection has been established and sending is successful
			if(strstr(LTEUART_RX_BUFFER,"SEND OK")!= NULL)
			{
                LTE_send_result=1;
				if(Flag_COMDebug == 1)
				{
					printf("Send data to server over\r\n");
				}
				return LTE_SUCCESS ;
			}
			//If connection has not been established, abnormally closed, or parameter is incorrect, response
			if(strstr(LTEUART_RX_BUFFER,"ERROR") != NULL)
			{
                
				if(Flag_COMDebug == 1)
				{
					printf("Send data to server error\r\n");
				}
                LTE_Time=0;
                if(LTE_Query_CSQ()==LTE_FAIL)return LTE_FAIL;
				if(LTE_Query_TCPstate()==LTE_FAIL||LTE_Query_TCPstate()==LTE_NOCONNECT)return LTE_FAIL;
                LTE_Time=0;
                retry++;
                if(retry<5)
                {
                    ClearUSARTBUF(LTE_UART);
				
                    LTE_Send_String(cmd);
                }
                else
                {
                    LTE_send_result=0;
                    retry=0;
                    return LTE_FAIL ;
                }
				
			}

			if(LTE_Time> LTE_5S_TIMEOUT)
			{
                LTE_Time=0;
                if(LTE_Query_CSQ()==LTE_FAIL)return LTE_FAIL;
				if(LTE_Query_TCPstate()==LTE_FAIL||LTE_Query_TCPstate()==LTE_NOCONNECT)return LTE_FAIL;
                
				if(Flag_COMDebug == 1)
				{
					printf("Send data to server timeout\r\n");
				}
                LTE_Time=0;
                retry++;
                if(retry<5)
                {
                    ClearUSARTBUF(LTE_UART);
				
                    LTE_Send_String(cmd);
                }
                else
                {
                    LTE_send_result=0;
                    return LTE_FAIL ;
                }
			}
		}
		
	//}
}
/*
char Wait_EC20_Send2Sever(uint8_t sock_fd)
{
     uint16_t i;
    static u8 retry=0;
	char cmd[20]="";
    char datastr1[20]="";
    const char s1[2]=":";
    const char s2[2]=",";
    uint32_t total_send_length,ackedbytes,unackedbytes;
    char *str;
    ClearUSARTBUF(LTE_UART); 
    sprintf(cmd,"AT+CIPSEND=0\r\n");
    //MYDMA_USART_Transmit(&UART3_Handler, cmd, strlen(cmd));
    LTE_Send_String(cmd);
    LTE_Time = 0;
    while(1)
    {
        if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL)
        {	

            str= strtok(LTEUART_RX_BUFFER,s1);
            printf("%s",str);
            str= strtok(NULL,s2);
            printf("%s",str);
            total_send_length=atoi(str);
            str= strtok(NULL,s2);
            printf("%s",str);
            ackedbytes=atoi(str);
            str= strtok(NULL,s2);
            printf("%s",str);            
            unackedbytes=atoi(str);
            
            
           
           
            printf("total_send_length: %d\r\nackedbytes: %d\r\nunackedbytes: %d\r\n",total_send_length,ackedbytes,unackedbytes);            
            if(unackedbytes==0)
                return LTE_SUCCESS ;
            else
            {
                   
                ClearUSARTBUF(LTE_UART);				
                LTE_Send_String(cmd);
                LTE_Time=0;
            }                
        }
        if(LTE_Time> LTE_5S_TIMEOUT)
        {
                LTE_Time=0;
                LTE_Query_CSQ();
            
                printf("server timeout_2\r\n");
				LTE_Query_TCPstate();
                
				if(Flag_COMDebug == 1)
				{
					printf("Send data to server timeout\r\n");
				}
                LTE_Time=0;
                retry++;
                if(retry<5)
                {
                    ClearUSARTBUF(LTE_UART);
				
                    LTE_Send_String(cmd);
                }
                else
                {
                    LTE_send_result=0;
                    return LTE_FAIL ;
                }
		}
    }
    
}
*/
char LTE_Send_data(uint8_t sock_fd, uint16_t send_len, uint8_t *buf)
{
    #define PACKAGE_LEN 512
    u8 packages=0;
    uint16_t i;
    uint16_t remainds_data=0;
    char err;
    //AT+CIPSEND maxinum data length is 1460 bytes,if the data length over 1460 so that have to split a few packages
    if(send_len<1024)
    {
        Send_Data2EC20(send_len,buf);
        //LTE_Send_Data_Check();
    }
    else
    {
        packages        = send_len/PACKAGE_LEN;
        remainds_data   = send_len%PACKAGE_LEN;
        for(i=0;i<packages;i++)
        {
            //delay_ms(5000);
            err=Send_Data2EC20(PACKAGE_LEN,&buf[i*PACKAGE_LEN]);
            //LTE_Send_Data_Check();
            if(err!=LTE_FAIL)
                printf("���� �ְ�%d �ɹ�\r\n",i+1);
            //Wait_EC20_Send2Sever(sock_fd);
        }
        if(remainds_data)
        {
            Send_Data2EC20(remainds_data,&buf[packages*PACKAGE_LEN]);
            //LTE_Send_Data_Check();
        }
    }
}
/****************************************************************************
*	�� �� ��: LTE_UART_Send
*	����˵��: LTE 4G���ڷ���
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void LTE_UART_Send(char *tx_buf,uint16_t buflen)
{
	for (int i=0; i<buflen; i++)
	{
		 SendDataToUSART(LTE_UART,*tx_buf);
         tx_buf++;
         if(i%50==0)
            delay_ms(1);
	} 
}
/****************************************************************************
*	�� �� ��: LTE_Send_String
*	����˵��: LTE 4G���ڷ����ַ���
*	��    �Σ�* s���͵��ַ���ָ��
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
char LTE_Send_String(char *s)
{
    //printf(">>>>>>>>send toEC20:%s\r\n",s);
	while(*s)
	{
		 SendDataToUSART(LTE_UART,*s++);
	} 
	return LTE_SUCCESS;	
}
/****************************************************************************
*	�� �� ��: LTE_Ping_Test
*	����˵��: ping����
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
char LTE_Ping_Test(char * addr_ip)
{
    char send_str[128]="";
    char ip[20]="";
	uint8_t  resualt = 0;
	uint8_t  bytes = 0;
	uint8_t  time = 0;
    uint8_t  ttl = 0;
    
    uint16_t  finresualt = 0;
    uint8_t  sent = 0;
    uint8_t  rcvd = 0;
    uint8_t  lost = 0;
    uint8_t  min = 0;
    uint8_t  max = 0;
    uint8_t  avg = 0;
    
    u8 rcvd_count=0;
	ClearUSARTBUF(LTE_UART); 
    sprintf(send_str,"AT+QPING=1,\"%s\"\r\n",addr_ip);
	LTE_Send_String(send_str);
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(50);
        //if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL)            
        {
            //printf("%s\r\n",LTEUART_RX_BUFFER);
            while(strstr(LTEUART_RX_BUFFER,"+QPING:")!= NULL) 
            {
    			//printf("%s\r\n",LTEUART_RX_BUFFER);
                LTE_Time = 0;
//                sscanf(LTEUART_RX_BUFFER,"%*[^:]: %d,\"%[^\"]\",%d,%d,%d",
//                        &resualt,ip,&bytes,&time,&ttl);
//                printf(" resualt: %d\r\n ip: %s\r\n bytes: %d\r\n time: %d\r\n ttl: %d\r\n",resualt,ip,bytes,time,ttl);
                if(rcvd_count==3)
                {
                    sscanf(LTEUART_RX_BUFFER,"%*[^:]: %d,\"%[^\"]\",%d,%d,%d%*[^:]: %d,%d,%d,%d,%d,%d,%d",
                        &resualt,ip,&bytes,&time,&ttl,&finresualt,&sent,&rcvd,&lost,&min,&max,&avg);
                    //printf(" resualt: %d\r\n ip: %s\r\n bytes: %d\r\n time: %d\r\n ttl: %d\r\n",resualt,ip,bytes,time,ttl);
                    printf("finresualt:%d�ѷ��� = %d,�ѽ��� = %d,��ʧ = %d\r\n�����г̵Ĺ���ʱ�䣨�Ժ���Ϊ��λ����\r\n��� = %dms,� = %dms,ƽ�� = %dms ",
                    finresualt,sent,rcvd,lost,min,max,avg);
                }
                ClearUSARTBUF(LTE_UART);
                rcvd_count++;
                if (rcvd_count>3)
                return LTE_SUCCESS;
            }
        }
		if(strstr(LTEUART_RX_BUFFER,"ERROR")!= NULL)
		{
			ClearUSARTBUF(LTE_UART);
			LTE_Send_String(send_str);
			Command_SendCount++;
			delay_ms(50);
		}
		if((LTE_Time>LTE_10S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("PING CMD time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}

	
}


/****************************************************************************
*	�� �� ��: LTE_Query_APNstate
*	����˵��: LTE ��ѯ����״̬
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
<contextID>         Integer type. The context ID. The range is 1-16.
<context_type>      Integer type. The protocol type
                        1  IPV4
                        2    IPV4V6
<APN>               String type. The access point name.
<username>          String type. The username.
<password>          String type. The password.
<authentication>    Integer type. The authentication methods.
                    0     NONE
                    1      PAP
                    2      CHAP
                    3      PAP or CHAP
*****************************************************************************/
/*
char LTE_Query_APNstate(void)
{
	uint8_t connectID = 0;
	char APN[10]="";
	char username[20]="";
	uint16_t  context_ID = 0;
	uint16_t  protocol_type = 0;
	uint8_t authentication = 0;
	
	char password[10]="";
	char stringbuf1[10]="";
	static u8 LTE_FAILD_COUNT=0;
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+QICSGP=1\r\n");AT+CSTT
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"+QICSGP:")!= NULL) 
		{
            //printf("%s\r\n",LTEUART_RX_BUFFER);
			sscanf(LTEUART_RX_BUFFER,"%*[^:]: %d,\"%[^\"]\",\"%[^\"]\",\"%[^\"]\",%d",
					&connectID,APN,username,password,&authentication);
			if(Flag_COMDebug == 1)
			{
				printf("connectID=%d\r\n",connectID);
//				printf("protocol_typev=%d\r\n",protocol_type);
				printf("APN= \"%s\"\r\n",APN);
				printf("username= \"%s\"\r\n",username);
				printf("password= \"%s\"\r\n",password);
				printf("authentication=%d\r\n",authentication);
//				printf("contextID=%d\r\n",contextID);
//				printf("serverID=%d\r\n",serverID);
//				printf("access_mode=%d\r\n",access_mode);
//				printf("AT_port=%s\r\n",AT_port);
			}
			ClearUSARTBUF(LTE_UART);

            LTE_Time = 0;
            return LTE_TCP_CONNECT;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
             LTE_FAILD_COUNT++;//������ݷ��Ͳ��ɹ�����״̬�Ʋ�����
            
            ClearUSARTBUF(LTE_UART);
            LTE_Send_String("AT+QICSGP=1\r\n");
            LTE_Time = 0;
			if(Flag_COMDebug == 1)
			{						
				printf("Query APN state time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			
		}
        if(LTE_FAILD_COUNT>=3)
        {
            LTE_FAILD_COUNT=0;
            return LTE_NOCONNECT;
            if(Flag_COMDebug == 1)
			{						
				printf("Query APN state haven't CMD ACK\r\n");
			}
            ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
        }
		
	}
	
}
*/
/****************************************************************************
*	�� �� ��: Configure Parameters of a TCP/IP Context
*	����˵��: 
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
/*
char LTE_Configure_APN(void)
{
	ClearUSARTBUF(LTE_UART); 
	LTE_Send_String("AT+QICSGP=1,1,\"CMNET\",\"\",\"\",1\r\n");
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf(" Configure Parameters of a TCP/IP Context:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(strstr(LTEUART_RX_BUFFER,"ERROR")!= NULL)
		{
			ClearUSARTBUF(LTE_UART);
			LTE_Send_String("AT+QICSGP=1,1,\"CMNET\",\"\",\"\",1\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((LTE_Time>LTE_1MIN_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf(" Configure Parameters of a TCP/IP Context time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}

}
*/
/****************************************************************************
*	�� �� ��: LTE_Query_PDPstate
*	����˵��: LTE ��ѯ����״̬
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
<contextID>         Integer type. The context ID. The range is 1-16.
<context_type>      Integer type. The protocol type
                        1  IPV4
                        2    IPV4V6
<APN>               String type. The access point name.
<username>          String type. The username.
<password>          String type. The password.
<authentication>    Integer type. The authentication methods.
                    0     NONE
                    1      PAP
                    2      CHAP
                    3      PAP or CHAP
*****************************************************************************/
/*
char LTE_Query_PDPstate(void)
{
	uint8_t connectID = 0;
	char APN[10]="";
	char username[20]="";
	uint8_t  context_ID = 0;
	uint8_t  context_state = 0;
	uint8_t  context_type = 0;
	
	char local_IP[16]="";
	
	static u8 LTE_FAILD_COUNT=0;
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CGACT?\r\n");
	LTE_Time = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"+CGACT:")!= NULL) 
		{
            printf("%s\r\n",LTEUART_RX_BUFFER);
			sscanf(LTEUART_RX_BUFFER,"%*[^:]: %d,%d,%d,\"%[^\"]\"",
					&context_state,&connectID,&context_type,local_IP);
            
//			if(Flag_COMDebug == 1)
//			{
//				printf("connectID=%d\r\n",connectID);
//				printf("context_state= %d\r\n",context_state);
//				printf("context_type= %d\r\n",context_type);
//				printf("local_IP= \"%s\"\r\n",local_IP);
//				
//			}
			ClearUSARTBUF(LTE_UART);

            LTE_Time = 0;
            if(context_state==1)
                return LTE_SUCCESS;
            else
                return LTE_FAIL;
		}else if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL)
        
        return LTE_FAIL;
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
             LTE_FAILD_COUNT++;//������ݷ��Ͳ��ɹ�����״̬�Ʋ�����
            
            ClearUSARTBUF(LTE_UART);
            LTE_Send_String("AT+CGACT?\r\n");
            LTE_Time = 0;
			if(Flag_COMDebug == 1)
			{						
				printf("Query the  current  activated  contexts  and  their  IP addresses time out:%s\r\n",LTEUART_RX_BUFFER);
			}
			
		}
        if(LTE_FAILD_COUNT>=3)
        {
            LTE_FAILD_COUNT=0;
            //return LTE_NOCONNECT;
            if(Flag_COMDebug == 1)
			{						
				printf("Query the  current  activated  contexts  and  their  IP addresses haven't CMD ACK\r\n");
			}
            ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
        }
		
	}
	
}
*/
/****************************************************************************
*	�� �� ��: GPRS_Attach_Detach
*	����˵��: ѯ��LTE 4G����״̬
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char GPRS_Attach_Detach(void)
{
    ClearUSARTBUF(LTE_UART);
	delay_ms(1000);	
	LTE_Send_String("AT+CGATT?\r\n");
	LTE_Time = 0;
	while(1)
	{
		delay_ms(50);
        //printf("AT+CGATT?:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"+CGATT: 1")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("GPRS Attach Succeed\r\n");
			}
			ClearUSARTBUF(LTE_UART);
            return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
            ClearUSARTBUF(LTE_UART);
            LTE_Send_String("AT+CGATT?\r\n");
			if(Flag_COMDebug == 1)
			{						
				printf("GPRS Attach failed:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
            return LTE_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: Set_APN_Function
*	����˵��: ����APN
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char Set_APN_Function(void)
{
    uint8_t cid=0;
    char Set_APN[30]="";
    char Context_Type[30]="";
    char send_str[128]="";
    
    ClearUSARTBUF(LTE_UART);	
    LTE_Send_String("AT+CGDCONT?\r\n");
    LTE_Time = 0;
    while(1)
	{
        delay_ms(50);
        //printf("AT+CGATT?:%s\r\n",LTEUART_RX_BUFFER);
        if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
        {
            sscanf(LTEUART_RX_BUFFER,"%*[^:]:%d,\"%[^\"]\",\"%[^\"]\"",
			&cid,Context_Type,Set_APN);
            if(Flag_COMDebug == 1)
            {						
                printf("Ask APN Succeed\r\n");
            }
            ClearUSARTBUF(LTE_UART);
            break;
        }
        if(LTE_Time>LTE_3S_TIMEOUT)
		{
            ClearUSARTBUF(LTE_UART);
            LTE_Send_String("AT+CGDCONT?\r\n");
			if(Flag_COMDebug == 1)
			{						
				printf("Ask APN failed:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
            return LTE_FAIL;
		}
    }
    
    ClearUSARTBUF(LTE_UART);
    sprintf(send_str,"AT+CSTT=%s\r\n",Set_APN);
	LTE_Send_String(send_str);
	LTE_Time = 0;
	while(1)
	{
        delay_ms(50);
        //printf("AT+CSTT=:%s\r\n",LTEUART_RX_BUFFER);
        if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
        {
            if(Flag_COMDebug == 1)
            {						
                printf("Set APN Succeed\r\n");
            }
            ClearUSARTBUF(LTE_UART);
            return LTE_SUCCESS;
        }
        if(LTE_Time>LTE_3S_TIMEOUT)
		{
            ClearUSARTBUF(LTE_UART);
            sprintf(send_str,"AT+CSTT=%s\r\n",Set_APN);
            LTE_Send_String(send_str);
			if(Flag_COMDebug == 1)
			{						
				printf("Set APN failed:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
            return LTE_FAIL;
		}
    }
}
/****************************************************************************
*	�� �� ��: Activate_Wireless_Connection
*	����˵��: �����������ý���� APN���û���������
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char Activate_Wireless_Connection(void)
{
    ClearUSARTBUF(LTE_UART);	
	LTE_Send_String("AT+CIICR\r\n");
	LTE_Time = 0;
    while(1)
    {
        delay_ms(50);
        //printf("AT+CIICR:%s\r\n",LTEUART_RX_BUFFER);
        if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
        {
            if(Flag_COMDebug == 1)
            {						
                printf("Activate Wireless Connection Succeed\r\n");
            }
            ClearUSARTBUF(LTE_UART);
            return LTE_SUCCESS;
        }
        if(LTE_Time>LTE_3S_TIMEOUT)
		{
            ClearUSARTBUF(LTE_UART);
            LTE_Send_String("AT+CIICR\r\n");
			if(Flag_COMDebug == 1)
			{						
				printf("Activate Wireless Connection failed:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
            return LTE_FAIL;
		}
    }

}
/****************************************************************************
*	�� �� ��: Get_LocalIP_Address
*	����˵��: ���ñ���IP��ַ
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char Get_LocalIP_Address(void)
{
    ClearUSARTBUF(LTE_UART);	
	LTE_Send_String("AT+CIFSR\r\n");
	LTE_Time = 0;
    while(1)
    {
        delay_ms(50);
        //printf("AT+CIFSR:%s\r\n",LTEUART_RX_BUFFER);
        if(strstr(LTEUART_RX_BUFFER,".")!= NULL) 
        {
            if(Flag_COMDebug == 1)
            {						
                printf("Get_LocalIP_Address:%s\r\n",LTEUART_RX_BUFFER);
            }
            ClearUSARTBUF(LTE_UART);
            return LTE_SUCCESS;
        }
        if(LTE_Time>LTE_3S_TIMEOUT)
		{
            ClearUSARTBUF(LTE_UART);
            LTE_Send_String("AT+CIFSR\r\n");
			if(Flag_COMDebug == 1)
			{						
				printf("Get_LocalIP_Address failed:%s\r\n",LTEUART_RX_BUFFER);
			}
			ClearUSARTBUF(LTE_UART);
            return LTE_FAIL;
		}
    }
	
}
/****************************************************************************
*	�� �� ��:  Request_Product_Information
*	����˵��: ����4gLTE�̼��汾��
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
/*
char Request_Product_Information(void)
{
    ClearUSARTBUF(LTE_UART);
    delay_ms(1000);	
	LTE_Send_String("ATI\r\n");
	LTE_Time = 0;
    delay_ms(200);
    printf("module info:%s\r\n",LTEUART_RX_BUFFER);
    ClearUSARTBUF(LTE_UART);
}
*/
/****************************************************************************
*	�� �� ��: LTE_Enter_DataMode
*	����˵��: LTE ��ATģʽ����͸��ģʽ
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
/*
char LTE_Enter_DataMode(void)
{
	ClearUSARTBUF(LTE_UART);
	delay_ms(1000);	
	LTE_Send_String("ATO\r\n");
	LTE_Time = 0;
	while(1)
	{
		delay_ms(50);
		if(strstr(LTEUART_RX_BUFFER,"CONNECT")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Enter data mode successed\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Enter data mode failed\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
	
}
*/
/****************************************************************************
*	�� �� ��: LTE_Select_Data_Sending_Mode
*	����˵��: LTE ���÷�������ģʽ
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char LTE_Select_Data_Sending_Mode(void)
{
	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CIPQSEND=0\r\n");
	LTE_Time = 0;
	while(1)
	{
		delay_ms(50);
        //printf("AT+CIPQSEND=0:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set_Data_Sending_Mode successed\r\n");
			}            
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
            ClearUSARTBUF(LTE_UART);
            LTE_Send_String("AT+CIPQSEND=0\r\n");
			if(Flag_COMDebug == 1)
			{						
				printf("Set_Data_Sending_Mode failed\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	}
	
}
/****************************************************************************
*	�� �� ��: LTE_Send_Data_Check
*	����˵��: LTE ���÷�������ģʽ
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
/*
char LTE_Send_Data_Check(void)
{
   	ClearUSARTBUF(LTE_UART);
	LTE_Send_String("AT+CIPACK\r\n");
	LTE_Time = 0;
	while(1)
	{
		delay_ms(50);
        //printf("AT+CIPACK:%s\r\n",LTEUART_RX_BUFFER);
		if(strstr(LTEUART_RX_BUFFER,"CIPACK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Check data successed\r\n");
			}            
			ClearUSARTBUF(LTE_UART);
			return LTE_SUCCESS;
		}
		if(LTE_Time>LTE_3S_TIMEOUT)
		{
            ClearUSARTBUF(LTE_UART);
            LTE_Send_String("AT+CIPACK\r\n");
			if(Flag_COMDebug == 1)
			{						
				printf("Check data failed\r\n");
			}
			ClearUSARTBUF(LTE_UART);
			return LTE_FAIL;
		}
	} 
}
*/