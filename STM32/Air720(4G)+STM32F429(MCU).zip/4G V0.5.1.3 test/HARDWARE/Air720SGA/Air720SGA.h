/***********************************************************************************
 * @file     Air720SGA.c
 * @brief    main�ļ�
 * @version  V1.0
 * @date     2020.1.16
 * @note
 * Copyright
 *
 * @par      ����4Gģ��Air720SGA����
************************************************************************************/
 
 #ifndef __AIR720SGA_H__
 #define __AIR720SGA_H__
 
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "string.h"
#include "Parameter.h"
#include "includes.h"
#include <stdio.h>
//�˿ڶ���
#define LTE_PWRKEY_PIN                  GPIO_PIN_15                  //��������   
#define LTE_PWRKEY_GPIO_PORT            GPIOH                      
#define LTE_PWRKEY_GPIO_CLK_ENABLE     __HAL_RCC_GPIOH_CLK_ENABLE

#define LTE_RESETN_PIN                  GPIO_PIN_0             //��λ����       
#define LTE_RESETN_GPIO_PORT            GPIOI                      
#define LTE_RESETN_GPIO_CLK_ENABLE     __HAL_RCC_GPIOI_CLK_ENABLE

#define LTE_DTR_PIN                  GPIO_PIN_12             //��λ����       
#define LTE_DTR_GPIO_PORT            GPIOB                      
#define LTE_DTR_GPIO_CLK_ENABLE     __HAL_RCC_GPIOB_CLK_ENABLE



#define LTE_PWRKEY(a)	if (a)	\
					HAL_GPIO_WritePin(LTE_PWRKEY_GPIO_PORT,LTE_PWRKEY_PIN,GPIO_PIN_SET);\
					else		\
					HAL_GPIO_WritePin(LTE_PWRKEY_GPIO_PORT,LTE_PWRKEY_PIN,GPIO_PIN_RESET)
										
#define LTE_RESETN(a)	if (a)	\
					HAL_GPIO_WritePin(LTE_RESETN_GPIO_PORT,LTE_RESETN_PIN,GPIO_PIN_SET);\
					else		\
					HAL_GPIO_WritePin(LTE_RESETN_GPIO_PORT,LTE_RESETN_PIN,GPIO_PIN_RESET)
					
#define LTE_DTR(a)	if (a)	\
					HAL_GPIO_WritePin(LTE_DTR_GPIO_PORT,LTE_DTR_PIN,GPIO_PIN_SET);\
					else		\
					HAL_GPIO_WritePin(LTE_DTR_GPIO_PORT,LTE_DTR_PIN,GPIO_PIN_RESET)					
					
#define	LTE_SUCCESS              0
#define	LTE_FAIL                -1
#define	LTE_CFG_ERROR           -2					
#define	LTE_CONNECT             1
#define	LTE_NOCONNECT           2										
#define	LTE_TCP_CONNECT           1
#define	LTE_TCP_NOCONNECT         2
					
#define	LTE_DATASEND_ATMODE       1
#define	LTE_DATASEND_TRANSMODE    0
					
#define	LTE_1S_TIMEOUT              1
#define LTE_2S_TIMEOUT              2
#define LTE_3S_TIMEOUT              3
#define LTE_5S_TIMEOUT           	 5
#define LTE_10S_TIMEOUT           	10
#define LTE_20S_TIMEOUT           	20
#define LTE_30S_TIMEOUT           	30
#define LTE_1MIN_TIMEOUT           	60
#define LTE_3MIN_TIMEOUT           	180
#define LTE_5MIN_TIMEOUT           	300


#define LTE_INIT_STEP1        1       //LTE��ʼ������1
#define LTE_INIT_STEP2        2       //LTE��ʼ������2
#define LTE_INIT_STEP3        3       //LTE��ʼ������3
#define LTE_INIT_STEP4        4       //LTE��ʼ������4
#define LTE_INIT_STEP5        5       //LTE��ʼ������5
#define LTE_INIT_STEP6        6       //LTE��ʼ������6
#define LTE_INIT_STEP7        7       //LTE��ʼ������7
#define LTE_INIT_STEP8        9       //LTE��ʼ������8
#define LTE_INIT_STEP9        10       //LTE��ʼ������9
#define LTE_INIT_STEP10       11       //LTE��ʼ������10
#define LTE_INIT_STEP11       12       //LTE��ʼ������11
#define LTE_INIT_STEP12       13       //LTE��ʼ������12
#define LTE_INIT_PAUSE        8  

#define NON_CDMAMODE           1
#define IN_CDMAMODE            2

extern uint8_t Flag_Networkmode ;  //����ģʽ��NON_CDMAMODE or IN_CDMAMODE
extern uint16_t  Position_LAC;        //GPRS LACλ������
extern uint16_t  Position_CID;        //GPRS CIDλ������
extern uint16_t  Position_SID;        //GPRS SIDλ������
extern uint16_t  Position_NID;        //GPRS NIDλ������
extern uint16_t  Position_BID;        //GPRS BIDλ������
extern unsigned char CSQNual;
extern uint8_t Socket;


extern unsigned char SIMCard_IMEI[25];
extern uint8_t SIMCard_IMEI_Len;
extern unsigned char SIMCard_IMSI[20];
extern uint8_t SIMCard_IMSI_Len;
extern unsigned char SIMCard_ICCID[25];
extern uint8_t SIMCard_ICCID_Len;
extern uint8_t Flag_DataSendMode;   //���ݴ���ģʽ
extern uint8_t Flag_LTEInitStep;     //LTE��ʼ���Ĺ��̲���
extern uint16_t  LTE_InitTime;  //LTE��ʼ��ʱ��
extern uint16_t  LTE_Init_pauseTime ; 
extern uint16_t  LTE_Time ;             //LTEģ��ָ��ʱ��

void LTE_GPIO_CONFIG(void);
char LTE_StartUP(void);
char LTE_PowerDown(void);
char LTE_SoftPowerOff(void);
char LTE_INIT(void);
char LTE_EchoEnable(uint8_t echo);
char  LTE_InquireIMSI(void);
char  LTE_InquireICCID(void);
char LTE_NetworkRegistration(uint8_t NR);
char LTE_GetPosition(void);
char LTE_Query_CSQ(void);
char LTE_Set_ConnectIP(char *ip,char *port,uint8_t access_mode);
char LTE_Query_TCPstate(void);
char LTE_Close_ConnectedIP(void);
char LTE_Activate_PDPContext(void);
char LTE_Query_PIN(void);
char LTE_EnterATmode(void);
char LTE_SwitchAccessMode(uint8_t sock_fd,uint8_t access_mode);


uint16_t BCDstringTOINT(char *str);
char LTE_Send_data(uint8_t sock_fd, uint16_t send_len, uint8_t *buf);
void LTE_UART_Send(char *tx_buf,uint16_t buflen);
char LTE_Send_String(char *s);
char LTE_Ping_Test(char * addr_ip); 
char LTE_Query_APNstate(void); 
char LTE_Query_PDPstate(void);
char LTE_Set_ConnectIP_Mode();
char LTE_Set_ConnectIP_Parameter(char *ip,char *port);
char LTE_Set_ConnectIP_MUX();
char LTE_Query_Connection_Status();
char GPRS_Attach_Detach();
char Set_APN_Function(void);
char Activate_Wireless_Connection(void);
char Get_LocalIP_Address(void);
char Request_Product_Information(void);
char LTE_Select_Data_Sending_Mode(void);

#endif
