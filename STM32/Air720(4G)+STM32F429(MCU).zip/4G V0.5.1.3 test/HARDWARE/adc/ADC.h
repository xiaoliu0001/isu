/******************************************************************************
 * @file     ADC.C
 * @brief   ADC����
 * @version   V3.0
 * @date     2018 .09
 * @note
 * Copyright (C)  2018  ���
 *
 * @par     3·ADC����������һ·Ϊѹ��������
 *         2018.08.28 ����AD�Ŵ��·�е�����Ӧ�Ŵ�����ź�����
 *          2018.9.1 �޸�����ΪSTM32F4 HAL����������
*******************************************************************************/
#ifndef __ADC_H_
#define __ADC_H_

#include "sys.h"
#include "Parameter.h"

extern  DMA_HandleTypeDef  ADCDMA_Handler;   



#define  ADC3_NOFCHANEL      3



//#define GAIN1_PIN                  GPIO_PIN_10                 
//#define GAIN1_GPIO_PORT            GPIOH                      
//#define GAIN1_GPIO_CLK_ENABLE      __HAL_RCC_GPIOH_CLK_ENABLE        

//#define GAIN2_PIN                  GPIO_PIN_9                 
//#define GAIN2_GPIO_PORT            GPIOH                      
//#define GAIN2_GPIO_CLK_ENABLE      __HAL_RCC_GPIOH_CLK_ENABLE           

#define GAIN3_PIN                  GPIO_PIN_3                 
#define GAIN3_GPIO_PORT            GPIOD                      
#define GAIN3_GPIO_CLK_ENABLE      __HAL_RCC_GPIOD_CLK_ENABLE  

#define GAIN4_PIN                  GPIO_PIN_4                
#define GAIN4_GPIO_PORT            GPIOD                      
#define GAIN4_GPIO_CLK_ENABLE      __HAL_RCC_GPIOD_CLK_ENABLE            

//#define ADC_GAIN1(a)	if (a)	\
//					HAL_GPIO_WritePin(GAIN1_GPIO_PORT,GAIN1_PIN,GPIO_PIN_SET);\
//					else		\
//					HAL_GPIO_WritePin(GAIN1_GPIO_PORT,GAIN1_PIN,GPIO_PIN_RESET)
//					
//#define ADC_GAIN2(a)	if (a)	\
//					HAL_GPIO_WritePin(GAIN2_GPIO_PORT,GAIN2_PIN,GPIO_PIN_SET);\
//					else		\
//					HAL_GPIO_WritePin(GAIN2_GPIO_PORT,GAIN2_PIN,GPIO_PIN_RESET)

#define ADC_GAIN3(a)	if (a)	\
					HAL_GPIO_WritePin(GAIN3_GPIO_PORT,GAIN3_PIN,GPIO_PIN_SET);\
					else		\
					HAL_GPIO_WritePin(GAIN3_GPIO_PORT,GAIN3_PIN,GPIO_PIN_RESET)

#define ADC_GAIN4(a)	if (a)	\
					HAL_GPIO_WritePin(GAIN4_GPIO_PORT,GAIN4_PIN,GPIO_PIN_SET);\
					else		\
					HAL_GPIO_WritePin(GAIN4_GPIO_PORT,GAIN4_PIN,GPIO_PIN_RESET)

					
					
void MyADC_Init(void);					
uint16_t GetADCData(uint32_t ch);
uint16_t Get_Adc_Average(uint32_t ch,u8 sampletimes);
float Get_Temprate(void);
#endif
