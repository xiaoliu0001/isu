/***********************************************************************************
 * @file     bsp.h
 * @brief    �����ʼ��
 * @version  V1.0
 * @date     2018.02
 * @note
 * Copyright (C) 2018 ���
 *
 * @par      uC/OS III  ��·�� MCU����ģ������
************************************************************************************/
/*
*********************************************************************************************************
*                                                 MODULE
*
* Note(s) : (1) This header file is protected from multiple pre-processor inclusion through use of the
*               BSP present pre-processor macro definition.
*
*           (2) This file and its dependencies requires IAR v6.20 or later to be compiled.
*
*********************************************************************************************************
*/

#ifndef  BSP_PRESENT
#define  BSP_PRESENT


/*
*********************************************************************************************************
*                                                 EXTERNS
*********************************************************************************************************
*/

#ifdef   BSP_MODULE
#define  BSP_EXT
#else
#define  BSP_EXT  extern
#endif



/**********************************************************
*            INCLUDE FILES
***********************************************************/


#include  <stdio.h>
#include  <stdarg.h>

#include  <cpu.h>
#include  <cpu_core.h>

#include  <lib_def.h>
#include  <lib_ascii.h>

#include "stm32f4xx.h"
#include "usart.h"
#include "led.h" 
#include "bsp_exti.h"
#include "delay.h"
#include "Parameter.h"
#include "sys.h"
#include "rtc.h"
#include "ff.h"
#include "ADC.h"
#include "Timer.h"
#include "diskio.h"		/* FatFs lower layer API */
#include "sdio_sdcard.h"
#include "usbd_msc_core.h"
#include "usbd_usr.h"
#include "usbd_desc.h"
#include "usb_conf.h"
#include "clkconfig.h"
#include "string.h"
#include "file.h"
#include "Flash.h"
#include "EMW3080.h"

#define MCUID_ADDRESS          0x1FFF7A10
#define MCUFLASHSIZE_ADDRESS   0x1FFF7A22


void Parameter_Init(void);
void BSP_Init(void);

CPU_INT32U  BSP_CPU_ClkFreq(void);

void BSP_Tick_Init(void);



#endif            

