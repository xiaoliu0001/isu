/****************************************************************************
 * @file     mian.c
 * @brief    ������
 * @version  V1.0.0
 * @date     2018.10
 * @note
 * Copyright (C) 2018 ���
 *
 * @par    WIFI ��˯�ߴ�
 *         �ڶ��棺ʹ��ESP8266 WiFiģ��
*****************************************************************************/
#include "Parameter.h"
#include "USART.h"
#include "string.h"
#include "Fun.h"
#include "BERpara.h"
#include "Timer.h"
#include "SysTick.h"
#include "Fun.h"
#include "ADC.h"
#include "LED.h"



#define MCUID_ADDRESS          0x1FFFF7E8
#define MCUFLASHSIZE_ADDRESS   0x1FFFF7E0


void Server_Order_Dispose(uint8_t *dat);
void COMProcessCmd(void);
void  WIFIUART_Receive_Order_Analys(void);
/****************************************************************************
*	�� �� ��: COMProcessCmd
*	����˵��: ���ڲ������ô���
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void COMProcessCmd(void)
{
	uint8_t  i ,j;
	uint8_t order_data_len = 0;
    uint8_t order_data[UARTBUF_MAX_LEN];
	uint8_t dealorder = 0;
	uint8_t Res = 0;
    uint8_t send_data[10];
	uint16_t flashsize = 0;
    uint32_t mcuid[3];
	uint8_t len;
	char SoftVer[100];
		
//	for(i=0;i<UART1_RX_LEN;i++)
//	{
//		printf("%02x ",UART1_RX_BUFFER[i]);
//	}
	for(i=0;i<UART1_RX_LEN;i++)
	{
		if(UART1_RX_BUFFER[i] == CMD_START)
		{
			Delay_ms(10);
			order_data_len = (UART1_RX_BUFFER[i+2]&0x7F)+5;
//			printf("����ָ���:%d\r\n",order_data_len);
			if((UART1_RX_BUFFER[i+order_data_len-1] == CMD_LF2 )&&(UART1_RX_BUFFER[i+order_data_len-2] == CMD_LF1 ))  //a complete command
			{
				for(j=0;j<order_data_len;j++)
				{
					order_data[j] = UART1_RX_BUFFER[i+j];
				}
				if(UART1_RX_LEN == (i+order_data_len))
				{
					memset(UART1_RX_BUFFER,0,UARTBUF_MAX_LEN);
					UART1_RX_LEN = 0;
				}
				else
				{
					memset(UART1_RX_BUFFER,0,i+order_data_len);
					for(j=0;j<UART1_RX_LEN-order_data_len-i;j++)
					{
						UART1_RX_BUFFER[j] = UART1_RX_BUFFER[i+order_data_len+j];
						UART1_RX_BUFFER[i+order_data_len+j] = 0;
					}
					UART1_RX_LEN = UART1_RX_LEN - order_data_len - i;
				}
				dealorder=1;  //parse the order
			}
			else  //not a complete command
			{
				if(i>0)
				{
					memset(UART1_RX_BUFFER,0,i);
					for(j=0;j<UART1_RX_LEN-i;j++)
					{
						UART1_RX_BUFFER[j] = UART1_RX_BUFFER[i+j];
						UART1_RX_BUFFER[i+j] = 0;
					}
					UART1_RX_LEN = UART1_RX_LEN  - i;
				}
			}
			
		}
	}
	if(dealorder == 1)
	{
//		for(i=0;i<order_data_len;i++)
//		{
//			printf("%02x ",order_data[i]);
//		}
		dealorder = 0;
		switch( order_data[3])
		{
		 case CMD_DEBUG:     //��ӡ������־
			 if(order_data[4] == 0x01 )
			 {
					Flag_COMDebug = 1;
				    flashsize = (uint16_t)( *(__IO uint32_t*)MCUFLASHSIZE_ADDRESS&0x0000FFFF);  //оƬflash��С
					for(i=0;i<3;i++)
					{
						mcuid[i] = *(__IO uint32_t*)(MCUID_ADDRESS+i*4);  //�ڲ�оƬ���
					}
				    printf("\r\n******************************************************************************\r\n"); 								
					printf("	MCU:STM32F103RCT6\r\n");
					printf("	MCU Flash:%d kB\r\n",flashsize);
					printf("	MCU RAM:48 kB\r\n");   
					printf("	MCU ID:%08x%08x%08x \r\n",mcuid[0],mcuid[1],mcuid[2]); 
					printf("	HardVer:V%d.%d.%d\r\n",HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER);
					printf("	SoftVer:V%d.%d.%d\r\n",SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER);
					printf("	Soft release time:%s \r\n",RELEASE_TIME);
					printf("	Soft build time is:%s %s\r\n", __DATE__, __TIME__);
					printf("	MAC:%s \r\n",MAC_ID);
					printf("******************************************************************************\r\n");
			 }
			 else
					Flag_COMDebug = 0;	 
		 break;
		 
		 case CMD_SETMAC:      //�����豸MAC
			MAC_LEN = order_data_len-7;
			for(i=0;i<MAC_LEN;i++)
			{
				MAC_ID[i] = order_data[4+i];
			}
			MAC_ID[MAC_LEN] = 0x00;
			
			Res = SaveMACToFlash();
			if(Res == 0x00)
			{
				COMRetuenOneByte(DEBUG_UART,CMD_SETMAC,0x00);
			}
			else   
			 {					 
				 Flag_ErrInfo &= ~ERROR_N0_MAC;
				 COMRetuenOneByte(DEBUG_UART,CMD_SETMAC,0x01);
			 }
			

		 break;			 	 
			 
		 case CMD_READMAC:   //��ȡ�豸MAC
			SendDeviceMacToUart(DEBUG_UART);
					
		 break;
		 
		 case CMD_READVER:  //��ȡ�豸�汾��
			sprintf(SoftVer,"HardVer:V%d.%d.%d\r\nSoftVer:V%d.%d.%d\r\nSoft release time:%s\r\n",HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER,
							SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER,RELEASE_TIME);
			SendDeviceVerInfoToUart(DEBUG_UART,SoftVer);
		 break;
		 
		case CMD_DELFLASHDATA:          //ɾ��flash����
			if(order_data[4] == CMD_DELSAVENUM )
			{


			}			
			if(order_data[4] == CMD_DELSERVERIP )
			{
				Flag_InitStatus = WIRELESS_INIT;  //���Խ�������ģ���ʼ��
				Flag_WIFIInitStep = WIFI_INIT_STEP1;
				WiFi_InitTime = 0;
				LinkStep = GETIP2;
				Flag_PowerOn = 1;
				
			}
		break;

		case CMD_REQMOUDLE_INFO:   //��ѯ�豸״̬
			if(order_data[4] == MOUDLE_STATUS_RUNTIME )   //�豸������ʱ��
			{
				printf("\r\nTotal run time is:%d day %d Hour %d Min %d Sec!\r\n",TimerSim.Day,TimerSim.Hour,TimerSim.Min,TimerSim.Sec);
		
			}
			if(order_data[4] == MOUDLE_STATUS_ROUTERSSID )   //wifiģ�����ӵ�·��������
			{
//				if(WIFI_Req_STASSID()==WIFI_SUCCESS)
				{							 

					printf("Connected the WiFi:%s\r\n",RouterName_InWIFI);

				}					
			}
			if(order_data[4] == MOUDLE_STATUS_CONNECTIP )   //wifiģ�����ӵķ�����
			{
				printf("IP2:%s,Port2:%s",IP2,Port2);
			}
			if(order_data[4] == MOUDLE_DEL_ROUTERNAME )   //ɾ���豸�ڱ����WiFi�˺���Ϣ
			{
				STMFLASH_SectorErase(FLASH_WIFIInfoAddress);  //ɾ��WiFi��Ϣ	
				printf("Delete WiFi info\r\n");
				NVIC_SystemReset();
			}
			if(order_data[4] == MOUDLE_DEL_MAC )   //ɾ���豸�ڱ����mac��Ϣ
			{
				STMFLASH_SectorErase(FLASH_EquipmentInfoAddress);  //ɾ��MAC��Ϣ
				printf("Delete MAC\r\n");
			}

		break;
			
		case SET_ROUTER_NAME:     //����wifi����
			Router_NameLen=order_data[4];
			Router_PWDLen =order_data[5]; 
			for(i=0;i<Router_NameLen;i++)
			{
				Router_Name[i]=order_data[6+i];
			}
			for(i=0;i<Router_PWDLen;i++)
			{
				Router_PWD[i]=order_data[6+Router_NameLen+i];
			}
			Router_Name[Router_NameLen]= '\0';
			Router_PWD[Router_PWDLen]= '\0';
			SaveRouterNameToFlash();
							 
			printf("\r\nWiFi name len:%d,Name:%s\r\n",Router_NameLen,Router_Name);
			printf("WiFi pwd len:%d,pwd:%s\r\n",Router_PWDLen, Router_PWD);	
			
		 break;
		 
		 default :
			 
		 break;
		}
	}	 
}
/****************************************************************************
*	�� �� ��: UART_Receive_Order_Analys
*	����˵��: ģ�鴮��ָ�������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/ 
void  WIFIUART_Receive_Order_Analys(void)
{
	if(strstr(UART3_RX_BUFFER,"+IPD"))  //�յ�������ָ��
	{
//		Flag_ReceivedServerOrder = 1;
		Server_Order_Dispose(ReceiveServerData);
	}
}
/****************************************************************************
*	�� �� ��:Server_Order_Dispose
*	����˵��: ������ָ�������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void Server_Order_Dispose(uint8_t *dat)
{
	
	uint8_t receivetime[6];
    uint16_t  i ,j;
	uint16_t order_data_len = 0;
    uint8_t order_data[UARTBUF_MAX_LEN];
	uint8_t dealorder = 0;
	uint16_t num = 0;
	uint8_t jiaoyan = 0;
	uint8_t senddata[10];
	
	
	for(i=0;i<UART3_RX_LEN;i++)
	{
		if(UART3_RX_BUFFER[i] == CMD_START)
		{
			Delay_ms(20);
			order_data_len = (UART3_RX_BUFFER[i+2]&0x7F)+5;
			
			if(order_data_len>100)
			{
				Delay_ms(50);
			}
			if((UART3_RX_BUFFER[i+order_data_len-1] == CMD_LF2 )&&(UART3_RX_BUFFER[i+order_data_len-2] == CMD_LF1 ))  //a complete command
			{

				for(j=0;j<order_data_len;j++)
				{
					order_data[j] = UART3_RX_BUFFER[i+j];
				}
				if(UART3_RX_LEN == (i+order_data_len))
				{
					memset(UART3_RX_BUFFER,0,UARTBUF_MAX_LEN);
					UART3_RX_LEN = 0;
				}
				else
				{
					memset(UART3_RX_BUFFER,0,i+order_data_len);
					for(j=0;j<UART3_RX_LEN-order_data_len-i;j++)
					{
						UART3_RX_BUFFER[j] = UART3_RX_BUFFER[i+order_data_len+j];
						UART3_RX_BUFFER[i+order_data_len+j] = 0;
					}
					UART3_RX_LEN = UART3_RX_LEN - order_data_len - i;
				}
				dealorder=1;  //parse the order
				UART3_Data_Receive_Time = 0;
			}
			else  //not a complete command
			{
				if(i>0)
				{
					memset(UART3_RX_BUFFER,0,i);
					for(j=0;j<UART3_RX_LEN-i;j++)
					{
						UART3_RX_BUFFER[j] = UART3_RX_BUFFER[i+j];
						UART3_RX_BUFFER[i+j] = 0;
					}
					UART3_RX_LEN = UART3_RX_LEN  - i;
				}
			}
			
		}
	}
	if(dealorder == 1)
	{

		//---------------����Ϊ�Է��������ݵĽ���--------------------------------------------------------		 		 	 
		if((order_data[1]==TypeID_WIFI)&&(order_data[3]==SERVER_ABNORMAL_MESSAGE))   //���������ش���δ�����û�
		{
			if((order_data[2]== 0x84 )&&(order_data[5]== BINDING_USERS_NO))
			{
				Flag_Binding_Users = BINDING_USERS_NO;
				if(Flag_No_Binding_Users_Time == 0)  //δ�����û���ʱ��־
				{
					Flag_No_Binding_Users_Time = 1;
					No_Binding_Users_Time = 0;						 
				}
				if(Flag_COMDebug == 1)
					printf("The device does not binding to users!\r\n");   			 
			}
			if((order_data[2]== 0x84 )&&(order_data[5]== BINDING_USERS_YES))
			{
				Flag_Binding_Users = BINDING_USERS_YES;
				Flag_No_Binding_Users_Time = 0;			  
//				if(gPeopleFlag == TRUE)
					SleepData_SendTime = SLEEPDATA_SENDTIME_3S;
				if(Flag_COMDebug == 1)
					printf("The device is  binding to users!\r\n");
			}					 
		}
		if((order_data[1]==TypeID_WIFI)&&(order_data[3]==REQ_SERVER_TIME))//���������ظ��µ�ʱ��
		{				 
			for(i=0;i<6;i++)  //��ȡ������ʱ��
			{
				receivetime[i] = (order_data[4+i*2]&0x7F-0x30)*10+(order_data[5+i*2]&0x7F-0x30); //��ASCII�ַ��������ֽڵ�ʱ��ת��Ϊ1���ֽڵ�ʱ��		 
			}
			if((receivetime[0]>0)&&(receivetime[0]<99)&&(receivetime[1]>0)&&(receivetime[1]<13)&&(receivetime[2]>0)&&(receivetime[2]<32))
			{
				if((receivetime[3]>=0)&&(receivetime[3]<60)&&(receivetime[4]>=0)&&(receivetime[4]<60)&&(receivetime[5]>=0)&&(receivetime[5]<60))
				{
					for(i=0;i<6;i++)
					{
						RealTime[i] = receivetime[i];
					}
					Flag_TimeAdj = 3;
					if(Flag_COMDebug == 1)
					{							
						printf("Renew Server time is:%d-%d-%d %d:%d:%d\r\n",RealTime[0],RealTime[1],RealTime[2],RealTime[3],RealTime[4],RealTime[5]);
					}							
				}
			}
		}
		if((order_data[1]== TypeID_WIFI)&&(order_data[3]== SERVER_ABNORMAL_MESSAGE)) //MAC��֤����
		{
			if(order_data[4] == SERVER_CHECK_MAC_ERR)
			{
				if(Flag_COMDebug == 1)
					printf("Server Return MAC Verify Error\r\n");
				Flag_StepStatus = STEP_SEND;
				LinkStep = CONNECTIP1;	
				Flag_LED_Status = LED_SERVER_LINK;
				Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����
				STMFLASH_SectorErase(FLASH_ServerInfoAddress);  //ɾ��IP��Ϣ
				STMFLASH_SectorErase(FLASH_VerifyInfoAddress);  //ɾ��token��Ϣ
				Set_StatistStartTime();
			}								 
		}
		if((order_data[0]== CMD_START)&&(order_data[1]== TypeID_WIFI)&&(order_data[3]== SEND_STATISTICS_SLEEPDTAT)) //��Ӧ���͵�ͳ������
		{
			if((order_data[4] == 0x81)&&(Flag_SleepDataBuffer_Save != Flag_SleepDataBuffer_Send))   //���յ���ȷ��ͳ������
			{
				if(Flag_COMDebug == 1)
				{
					printf("Server Receive Right Statistics Data:%d!\r\n",Flag_SleepDataBuffer_Send);
				}
				Flag_CanSendStatistData = 1;
				CanSendStatistTime = 0;					
				Flag_SleepDataBuffer_Send++;			
				if(Flag_SleepDataBuffer_Send == Flag_SleepDataBuffer_Save)
				{
					Flag_SleepDataBuffer_Send = 0;
					Flag_SleepDataBuffer_Save = 0;
					Flag_SavepPos = 0;
					Flag_CanSendStatistData = 0;
					for(i=0;i<SLEEPDTATABUF;i++)
					{
						for(j=0;j<40;j++)
							Buffer_SleepData[i][j] = 0;
					}
				} 
				if(Flag_SleepDataBuffer_Send ==SLEEPDTATABUF )
				{
					Flag_SleepDataBuffer_Send = 0;
				}
			}	
			if(order_data[4] == 0x80)   //���յ������ͳ������
			{
				if(Flag_COMDebug == 1)
				{
					printf("Server Receive Error Statistics Data:%d,!Resend\r\n",Flag_SleepDataBuffer_Send);
				}
				Flag_CanSendStatistData = 1;
				CanSendStatistTime = 0;						
			}
		}
		#ifdef ENABLE_SENDPRESSSERSONSTATUS
		if((order_data[1]== TypeID_WIFI)&&(order_data[3]== CMD_PRESSSENSER)) //ѹ��������״̬����
		{
			if(order_data[4] == 0x81)
			{
				Flag_SendPresensorStatus = 0;
				SendPresensorStatus_Time = 0;
				if(Flag_COMDebug == 1)
					printf("Server Received pressure sensor status\r\n");
			}								 
		}
		#endif
		ClearUSARTBUF(WIFI_USART);		 
	}	
}


/****************************************************************************
*	�� �� ��: Power_ON
*	����˵��: �豸��������ʼ��������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
void Power_ON(void)
{	 		
	uint8_t i,j;
	uint8_t dat = 0;

//--------------------------����������ʼ��--------------------------------		
	uint8_t Time_RM = 0;
	uint8_t send_data[5];
	uint32_t ADC_SampleData[16];

	Flag_BT_Linkstatus = BT_NoCONNECT;  
	Flag_InitStatus = SYSTEM_INIT;
	Flag_LED_Status = 0;
	Flag_ErrInfo = NO_ERROR;
	Flag_PowerOn = 1;
	GetSleepDataTimeCount = 0;
	Flag_Reset_RouterSSID=0; 
	Flag_Binding_Users = BINDING_USERS_YES;
	Flag_No_Binding_Users_Time =0; //δ�����û���ʱ��־����

	Flag_Send_GPRS_Position = 0;
	Flag_SendDataAbnormal = NO_ERROR;
	Flag_TimeAdj = 0;
	Flag_LED_Status=0;
	WIFI_ConnetTime =0;
	Flag_SleepData_SendOver = 0;	
	Flag_WIFIInitStep = 0;

	ClearUSARTBUF(DEBUG_UART);
	for(i=0;i<ECG_COMPARE_TIMES;i++)
	{
		ECG_MAX[i] = STANDARD_VOLTAGE;
		ECG_MIN[i] = STANDARD_VOLTAGE;
		CHGECG_MAX[i] = STANDARD_VOLTAGE;
		CHGECG_MIN[i] = STANDARD_VOLTAGE;
	}
	ECG_COMPARE_COUNT = 0;
	Flag_ADC_ADJ = 0;
	ADC_COUNT = 0;
	CHGADC_COUNT = 0;
	LinkIPCount = 0;
	Flag_SendAMPCHGToServer = 0;
	Flag_SleepDataBuffer_Save = 0;
	Flag_SleepDataBuffer_Send = 0;
	Flag_DataSendMode =WIFI_DATASEND_ATMODE;   //ATģʽ
	SleepData_SendTime = SLEEPDATA_SENDTIME_3S;
	SendLinkStatus_Time = 0;
	Flag_SendLinkStatus = 0;
	APP_Receive_Right = 0;
	BLE_ReceiveDataTime = 0;

	Flag_WiFiSmartConfig = 0; 
	Status_ExtSensorIn = EXTSENSOR_ISOUT;      //ѹ������
	Status_ExtSensorOnbed = EXTSENSOR_PEOPLEOFFBED; 
	ExtSensor_OnbedStatus_Count = 0;
	OnbedStatus_CountTimer = 0;
	LastOnbedStatus = 0;
	Flag_SendPresensorStatus = 0; 
	 
	for(i=0;i<SLEEPDTATABUF;i++)
	{
		for(j=0;j<40;j++)
			Buffer_SleepData[i][j] = 0;
	}	
	TimerSim.Msec = 0;   //ʱ���ʼ��
	TimerSim.Sec = 0;
	TimerSim.Min = 0;
	TimerSim.Hour = 0;
	TimerSim.Day = 0;
		
	
//--------------------------������ģ������--------------------------------
//	  HSI_SetSysClock(RCC_PLLMul_16);  //�ڲ������ʼ����ϵͳʱ��64M
	SysTick_Init();
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable , ENABLE);               //	 �ı�ָ���ܽŵ�ӳ�� GPIO_Remap_SWJ_JTAGDisable ,JTAG���� + SWʹ��		   	


	USART1_Config(115200);
	DataInitial();					//�㷨������ʼ���������㷨��
	
	ADC_Comfig();
	LED_GPIO_Config();
	TIM2_Configuration();   //��ʱ����ʼ��,��ʱ1s	
	TIM3_Configuration();
	WIFI_GPIO_CONFIG();

}

/****************************************************************************
*	�� �� ��: main
*	����˵��: ������
*	��    �Σ���
*	�� �� ֵ: ��
*****************************************************************************/
int main(void)
{
	char err_code;
	uint16_t i,j;	 
//	char buf[100];
	uint32_t sFLASH_ID = 0;	
	
	Flag_COMDebug = 0;   //���Թر�	
	//-----------------------------------------------------	
	Power_ON();              //������ģ���ʼ��
	Delay_ms(500);
	
	
//	STMFLASH_SectorErase(FLASH_WIFIInfoAddress);  //ɾ��WiFi��Ϣ
//	STMFLASH_SectorErase(FLASH_EquipmentInfoAddress);  //ɾ��MAC��Ϣ
	
	ReadMACFromFlash();     //��ȡ�豸MAC 
    

	ReadRouterNameFromFlash(); //��ȡWiFi����
	
	printf("\r\n******************************************************************************\r\n"); 
	printf("	HardVer:V%d.%d.%d\r\n",HARDWARE_MAJORVER,HARDWARE_MINORVER,HARDWARE_TESTVER);
	printf("	SoftVer:V%d.%d.%d\r\n",SOFTWARE_MAJORVER,SOFTWARE_MINORVER,SOFTWARE_TESTVER);
	printf("	Soft release time:%s \r\n",RELEASE_TIME);
	printf("	Soft build time is:%s %s\r\n", __DATE__, __TIME__);
	printf("	MAC:%s \r\n",MAC_ID);
	printf("	Router name:%s,PWD:%s\r\n",Router_Name,Router_PWD);
	printf("******************************************************************************\r\n");

	SystemReset_CheckStatus();
	if((Flag_ErrInfo&ERROR_NO_ROUTERNAME) ==ERROR_NO_ROUTERNAME) //��WiFi�˺���Ϣ������Ҫ����
	{
		Flag_WiFiSmartConfig = 1;
	}
	if((Flag_ErrInfo&ERROR_N0_MAC) !=ERROR_N0_MAC)   //�����Mac���ʼ��wifiģ��
	{
		Flag_InitStatus = WIRELESS_INIT;  //���Խ�������ģ���ʼ��
		Flag_WIFIInitStep = WIFI_INIT_STEP1;
		WiFi_InitTime = 0;
		WIFI_POWER(1);
		WIFI_EN(1);
		Delay_ms(500);
		USART3_Config(115200);  //��ʼ��WiFi�ӿ�
		if(Flag_COMDebug == 1)
		{		
			printf("WIFI init\r\n");				
		}			
	}
	else
	{
		printf("MAC NULL\r\n");	
	}
					
	IWDG_Config(IWDG_Prescaler_64 ,1250);
	
    while (1)
    {
		if(Flag_PowerOn == 0)
		{
			Check_ExtSensor_PeopleOnBed(); //����ⲿ�������ڴ�״̬
		}
		#ifdef ENABLE_SENDPRESSSERSONSTATUS
		if((Flag_SendPresensorStatus ==1)&&(SendPresensorStatus_Time>4))
		{
//			SendPressSenserStatus(Status_ExtSensorOnbed);   //ȥ��ѹ��ֵ�Ϸ�
			SendPresensorStatus_Time = 0;
		}
		#endif
		
/*****************************wifiģ���ʼ��***********************************************/
#if 1		
		if(Flag_InitStatus == WIRELESS_INIT)
		{		
			Flag_LED_Status = LED_WIRELEE_INIT;  			
			err_code=WIFI_INIT();	
			if(err_code == WIFI_INIT_STEP5)   //·����������
			{
				//SendDataBegin();
               LinkStep= CONNECTIP1;
				Flag_InitStatus = LINK_SERVER; //����ģ���ʼ����ɣ����Խ�������������֤
				Flag_LED_Status = LED_SERVER_LINK;	
				LinkIPCount = 0;
				if(Flag_SendLinkStatus == 1)
				{
//					Send_CurrentLinkStatus();
				}					 
			}      							
		}
#endif
		if((WIFI_ConnetTime >600)&&(LinkStep != SENDSLEEPDATA)&&((Flag_ErrInfo&ERROR_N0_MAC) !=ERROR_N0_MAC)&&(Flag_PowerOn == 0))  //���豸10����δ�����Ϸ��������������ϵ�wifiģ��
		{
			WIFI_ConnetTime = 0;				 
			Flag_Start_Mode = START_WIFI_RESTART;  //wifiģ�������ϵ�
			RePowerOn_WIFI();			 
		}
		
		if((SendLinkStatus_Time >= SENDLINKSTATUS_TIME_5S)&&(Flag_SendLinkStatus == 1)&&(Flag_Reset_RouterSSID ==0))//��ʱ�����豸����״̬��APP
		{
			SendLinkStatus_Time = 0;
//			Send_CurrentLinkStatus();
		}
/*****************************����������ͨѶ***********************************************/
#if 1		
		if(Flag_InitStatus == LINK_SERVER)
		{				
			if(LinkStep != SENDSLEEPDATA)
			{
				LinkServerVerifyStep(LinkStep);   //��������
			}
		}
#endif
		if(Flag_InitStatus == CONTINUE_SENDDATA)
	    {
			//--------------------����ͳ������-------------------------------------------------		 
				if((Flag_SleepDataBuffer_Save != Flag_SleepDataBuffer_Send)&&(SleepDataBuffer_SendTime>1)&&(Flag_CanSendStatistData == 1))
				{
					SleepDataBuffer_SendTime = 0;
					Flag_CanSendStatistData = 2;
					CanSendStatistTime = 0;
					Send_StatistStatusData();   //����״̬ͳ������
					delaytime = 0;
					while(1)
					{
						Delay_ms(10);
						if(strstr(UART3_RX_BUFFER,"+IPD"))  //�յ�������ָ��
						{
							Server_Order_Dispose(ReceiveServerData);
							break;
						}
						if(delaytime>1)
						{
							break;
						}
					}
					//				StaticsSleepDataSendCount++;
//				if(StaticsSleepDataSendCount>=5)   //δ�յ���Ӧ�����ط�5�Σ�
//				{
//					StaticsSleepDataSendNum++;
//					if(StaticsSleepDataSendNum == StaticsSleepDataSaveNum)
//					{
//						Flag_CanSendStatistData = 0;
//						StaticsSleepDataSendNum = 0;
//						StaticsSleepDataSaveNum = 0;
//						StaticsSleepDataSendCount = 0;
//						SaveSleepDataPosIndexToFlash(0,0);
//					}
//				}
				}
			//-------------------------------��ѯ����״̬--------------------------------------------------
				if((Time_NetworkInquire >= GETNETWORKSTATUSTIME)&&(LinkStep == SENDSLEEPDATA))
				{					
					Time_NetworkInquire = 0;	
					if(Flag_SendAMPCHGToServer == 1)
					{
						Send_AMPCHGDataToServer();
						Flag_SendAMPCHGToServer = 0;
					}								
					if(Flag_Binding_Users == BINDING_USERS_NO)   //���δ�����û������ѯ����״̬,
					{
						Req_Users_Binding();
					}
					err_code = WIFI_Query_STA_RSSI();
					if(err_code == WIFI_NOCONNECT)   //wifiδ����
					{
						Flag_StepStatus = STEP_RECEIVE;
						LinkStep = CONNECTIP2;
						Flag_InitStatus = LINK_SERVER;
						Flag_LED_Status = LED_SERVER_LINK;					 									 
						Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����											
						Flag_Send_GPRS_Position = 0;								 
						Set_StatistStartTime();
						LinkIPCount = 0;									
						Link_Time = 0;
						WIFI_ConnetTime = 0;							
						if(Flag_COMDebug == 1)
							printf("WiFi has not connect,repower wifi moudle\r\n"); 
					}
					else  //wifi����
					{
						err_code=WIFI_Query_TCPStatus();
						if(err_code == WIFI_TCP_NOCONNECT)  //���δ����
						{	
							Flag_StepStatus = STEP_RECEIVE;
							LinkStep = CONNECTIP2;
							Flag_InitStatus = LINK_SERVER;
							Flag_LED_Status = LED_SERVER_LINK;					 									 
							Flag_Start_Mode = START_NETWOEK_RECONNECT;  //����ر�����											
							Flag_Send_GPRS_Position = 0;
							LinkIPCount = 0;
							Link_Time = 0;
							WIFI_ConnetTime = 0;										
							Set_StatistStartTime();								
							if(Flag_COMDebug == 1)
								printf("Reconnect Server\r\n");         							 
						}
					}
				}					
			if((Flag_TimeAdj == 1)&&(LinkStep == SENDSLEEPDATA)) //У׼ʱ��
			{
				GetServerTime();
				Flag_TimeAdj = 2;				
			}

		}
	//-------------����ʵʱ����-------------------------------------------------------------------
		if((GetSleepDataTimeCount >= SleepData_SendTime) && (Flag_PowerOn == 0))  //����ʵʱ����
		{	
			
			SendRealTimeSleepData();				//��������	
			GetSleepDataTimeCount=0;			
			if((Flag_SendDataAbnormal != NO_ERROR)&&(LinkStep == SENDSLEEPDATA))  //�����쳣ʱ����
			{
				Send_DataUnusual(Flag_SendDataAbnormal,ABN_gPulseRateHR,ABN_gPulseRateRR);
				if(Flag_COMDebug == 1)
				{
					printf("Sleep data abnormal:0x%x 0x%x 0x%x",Flag_SendDataAbnormal,ABN_gPulseRateHR,ABN_gPulseRateRR);
				}
				Flag_SendDataAbnormal = NO_ERROR;
			}
		}
/*****************************ָ���***********************************************/				
		if(UART1_RX_LEN > 0)//���Դ�������
		{
			COMProcessCmd();
		}
		if((UART3_RX_LEN > 0)&&(LinkStep == SENDSLEEPDATA))   //WIFIģ�鷢�͵����ݴ���
		{				
			WIFIUART_Receive_Order_Analys();
		}
//		if(Flag_ReceivedServerOrder ==1)  //������ָ���
//		{
//			Flag_ReceivedServerOrder = 0;
//			Server_Order_Dispose(ReceiveServerData);
//		}

/****************************************************************************/	
			
	}//end while		
}
