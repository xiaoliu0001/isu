/***********************************************************************************
 * @file     USART.h
 * @brief    ���ں���
 * @version  V1.0
 * @date     2017.09
 * @note
 * Copyright (C) 2017 ���
 *
 * @par      
************************************************************************************/

#ifndef __USART_H
#define	__USART_H

#include "stm32f10x.h"
#include <stdio.h>





void USART1_Config(uint32_t bps);
void USART3_Config(uint32_t bps);
void SendDataToUSART( USART_TypeDef* USARTx,uint8_t ch);
void SendDatasToUSART( USART_TypeDef* USARTx,uint16_t ch);
void ClearUSARTBUF(USART_TypeDef* USARTx);

#endif /* __USART1_H */
