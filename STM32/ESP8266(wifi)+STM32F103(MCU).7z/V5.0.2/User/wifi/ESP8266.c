/******************************************************************************
 * @file     ESP8266.c
 * @brief   WiFiͨѶ����
 * @version  v1.0
 * @date     2018.10
 * @note
 * Copyright (C)  
 *
 * @par      ���201810
 *    V1.0    ESP8266 WiFiģ��ͨѶ����
*******************************************************************************/


#include "ESP8266.h"



#define htons(n) 				(((n & 0xff) << 8) | ((n & 0xff00) >> 8))
#define htonl(n) 				(((n & 0xff) << 24) | ((n & 0xff00) << 8) | ((n & 0xff0000UL) >> 8) | ((n & 0xff000000UL) >> 24))
#define ntohs(n) 				htons(n)
#define ntohl(n) 				htonl(n)


uint8_t AP_Channel=0;          //AP���ӵ��ŵ�
static uint8_t WiFiSmartConfig = 0;
char cmd[100]="";
/****************************************************************************
*	�� �� ��: WIFI_GPIO_CONFIG
*	����˵��: ����ģ��IO����
*	��    �Σ�
*	�� �� ֵ:
* ˵    ����
*****************************************************************************/
void WIFI_GPIO_CONFIG(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(WIFI_POWER_GPIO_CLK, ENABLE); 				 							   
	GPIO_InitStructure.GPIO_Pin = WIFI_POWER_PIN ;	   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_Init(WIFI_POWER_GPIO_PORT, &GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(WIFI_EN_GPIO_CLK, ENABLE); 				 							   
	GPIO_InitStructure.GPIO_Pin = WIFI_EN_PIN ;	   
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_Init(WIFI_EN_GPIO_PORT, &GPIO_InitStructure);
			
	WIFI_POWER(0);
	WIFI_EN(0);
	
}
/****************************************************************************
*	�� �� ��: WIFI_INIT
*	����˵��: ����ģ���ʼ��
*	��    �Σ�
*	�� �� ֵ:���س�ʼ����ɵĲ���
* ˵    ����
*****************************************************************************/
char WIFI_INIT(void)
{
	 uint8_t buf[5];

//-------����ATָ��ģʽ---------------------------------
	if(Flag_WIFIInitStep == WIFI_INIT_STEP1)
	{	 
		if(WIFI_Open_cmdMode()==WIFI_SUCCESS)
		{
			if(Flag_PowerOn == 1)
				Flag_WIFIInitStep = WIFI_INIT_STEP2;
			else
				Flag_WIFIInitStep = WIFI_INIT_STEP3;
		}
		else     //ATָ��ģʽ�޷����룬��λģ��
		{
			if(WiFi_InitTime>=NETWORKLINK_TIMEOUT_30S)
			{

				WIFI_POWER(0);
				WIFI_EN(0);
				Delay_ms(5000);
				WIFI_POWER(1);
				WIFI_EN(1);
				Delay_ms(500);	
				//Flag_DataSendMode = WIFI_DATASEND_ATMODE;   //ATģʽ
				WiFi_InitTime = 0;
			}
				Delay_ms(2000);				 
				return WIFI_INIT_STEP1;
		} 
	}	 
//-------wifiģ������---------------------------------
	if(Flag_WIFIInitStep == WIFI_INIT_STEP2)
	{
		if(WIFI_Set_Mode(WIFIMODE_STA) != WIFI_SUCCESS)
		{
			WIFI_Reset();
			Delay_ms(500);
			Flag_WIFIInitStep = WIFI_INIT_STEP1;
			return  WIFI_INIT_STEP1;
		}
		WIFI_Set_ATE(0);  //�ر�ָ�����
		WIFI_OpenDHCP();
		WIFI_Set_MUXLINK(0);  //������
		if(Flag_WiFiSmartConfig ==1)  //��WiFi���棬��������������
		{
			if(WiFi_SmartConfig() == WIFI_SUCCESS)  //����
			{			
				Flag_WIFIInitStep = WIFI_INIT_STEP4;
				WiFi_InitTime = 0;
				Flag_WiFiSmartConfig = 0;
				Flag_LED_Status = LED_WIRELEE_INIT; 
			}
			else
			{
				WiFiSmartConfig++;
				if(WiFiSmartConfig>4)
				{
					WiFiSmartConfig = 0;
					Flag_WiFiSmartConfig = 0;
					WIFI_POWER(0);
					WIFI_EN(0);
					Delay_ms(5000);
					WIFI_POWER(1);
					WIFI_EN(1);
					Delay_ms(500);
					if(Flag_COMDebug == 1)
					{
						printf("Smart config time out,reconnected\r\n");
					}
				}
				else
				{
					WIFI_Reset();
					Delay_ms(500);
				}
				Flag_WIFIInitStep = WIFI_INIT_STEP1;
				return  WIFI_INIT_STEP1;
			}
		}
		else
		{
			Flag_WIFIInitStep = WIFI_INIT_STEP3;
		}
	}
//-------·��������״̬---------------------------------	 
	if(Flag_WIFIInitStep == WIFI_INIT_STEP3)
	{
		if(WIFI_Set_STASSID(Router_Name,Router_PWD)== WIFI_SUCCESS)
//		if(WIFI_Set_STASSID(TESTROUTERNAME,TESTROUTERPWD)== WIFI_SUCCESS)
		{
			//if(Flag_Reset_RouterSSID ==1)
			//{
			//	buf[0] = SET_ROUTER_NAME;
			//	buf[1] = MODULESTATUS_LINKSERVER;			 
//				APP_Send_Order(buf,2);	
			//}
			Flag_WIFIInitStep = WIFI_INIT_STEP4;	     
		}
		else
		{					
			Delay_ms(1000);
			//printf("WiFi_InitTime=%d s\r\n",WiFi_InitTime);
			if(WiFi_InitTime>=NETWORKLINK_TIMEOUT_30S)
			{
				if(Flag_COMDebug == 1)
				{
					printf("WiFi connect time out:%d s\r\n",WiFi_InitTime);
				}
				WiFi_InitTime = 0;
				WIFI_POWER(0);
				WIFI_EN(0);
				Delay_ms(5000);
				WIFI_POWER(1);
				WIFI_EN(1);
				Delay_ms(500);
				if(Flag_PowerOn == 1)
				{
					Flag_WiFiSmartConfig = 1;  //��������wifi
					WiFiSmartConfig = 0;	
                    
					if(Flag_COMDebug == 1)
					{
						printf("RePower and start smart config\r\n");
					}
				}
				Flag_WIFIInitStep = WIFI_INIT_STEP1;
				return  WIFI_INIT_STEP1;
			}
			else
			{
				return  WIFI_INIT_STEP3;
			}
		}					
	}
	if(Flag_WIFIInitStep == WIFI_INIT_STEP4)
	{
		WIFI_Query_STA_RSSI();
		Flag_WIFIInitStep = WIFI_INIT_STEP5;
		return WIFI_INIT_STEP5;
	}
}

/****************************************************************************
*	�� �� ��: WIFI_Open_cmdMode
*	����˵��: enter AT command mode from easytxrx mode
*	��    �Σ�
*	�� �� ֵ: 0��ʾ�ɹ�
* ˵    ����
*****************************************************************************/
char WIFI_Open_cmdMode(void)
{  
	 *cmd='\0';

	sprintf(cmd, "AT+CIPMODE?\r\n");	
	WIFI_USART_Send(cmd, strlen(cmd));

	ClearUSARTBUF(WIFI_USART);
	WiFi_Time =0;
	if(Flag_COMDebug == 1)
	{
		printf("Set WiFi in AT mode\r\n");
	}
	Delay_ms(50);
	
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"+CIPMODE:0")!=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("WiFi has in AT mode\r\n");
			}
			return  WIFI_SUCCESS;
		}
		if(strstr(UART3_RX_BUFFER,"+CIPMODE:1")!=NULL)
		{
			sprintf(cmd, "AT+CIPMODE=0\r\n");	
			WIFI_USART_Send(cmd, strlen(cmd));
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("WiFi not in AT mode\r\n");
			}
			return  WIFI_FAIL;
		}
		if(WiFi_Time > WIFI_3S_TIMEOUT )
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set WiFi in AT mode time out:%s\r\n",UART3_RX_BUFFER);
			}
			ClearUSARTBUF(WIFI_USART);
			return  WIFI_FAIL;
		}
	}

						
}
/****************************************************************************
*	�� �� ��: WIFI_Query_STA_RSSI
*	����˵��: ��ѯSTAģʽ��rssi���������ź�ǿ��
*	��    �Σ�
*	�� �� ֵ: �����ź�ǿ������
* 	˵    ������ѯSTA����״̬��AP�ź�ǿ��
*	+CWJAP_CUR:"zangwii2008","14:cf:92:bb:03:df",6,-42
*
*	OK
*****************************************************************************/
char WIFI_Query_STA_RSSI(void)
{
	char stringbuf1[20]={0};
	int csq= 0;
	
	Delay_ms(10); 
	ClearUSARTBUF(WIFI_USART);
	WIFI_Query_rssi();
	WiFi_Time =0;
	Delay_ms(10);	
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"+CWJAP_CUR:") !=NULL)   //���ص�ǰ���ӵ�AP��Ϣ
		{
			sscanf(UART3_RX_BUFFER,"%*[^:]: %*[^,],%*[^,],%d,%d\r\n%s",&AP_Channel,&csq,stringbuf1)	;								
			CSQNual = 113+ csq;
			CSQNual /= 2;
			if(Flag_COMDebug == 1)
			{
				printf("csq:%d apch:%d \r\n",CSQNual,AP_Channel);
			}
			return WIFI_CONNECT;
		}
		if((strstr(UART3_RX_BUFFER,"No AP")) !=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			return WIFI_NOCONNECT;
		}
		if(WiFi_Time>WIFI_3S_TIMEOUT) 
		{
			if(Flag_COMDebug == 1)
			{
				printf("Read rssi Time OUT:%s\r\n",UART3_RX_BUFFER);
			}
			ClearUSARTBUF(WIFI_USART);
			return WIFI_FAIL ;
		}	
		if(strstr(UART3_RX_BUFFER,"ERROR") != NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			WIFI_Query_rssi();
			Delay_ms(10);	
		}
	}
	
}

/****************************************************************************
*	�� �� ��: WIFI_Set_Mode
*	����˵��: ���ù���ģʽ
*	��    �Σ�mode  ����ģʽ
*	�� �� ֵ: 
* 	˵    ��������Ĭ�ϵĹ���ģʽ
*****************************************************************************/
char WIFI_Set_Mode(uint8_t mode)
{
	uint8_t count=0;
	
	char modebuf[20] = "";
	*cmd='\0';
	if(Flag_COMDebug == 1)
	  {
		  printf("Set wifi mode:%d!\r\n",mode);
	  }	
			  
	sprintf(cmd, "AT+CWMODE_DEF?\r\n");
	  sprintf(modebuf, "+CWMODE_DEF:%d\r\n",mode);
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	Delay_ms(10);
	WiFi_Time = 0;
	while(1)
	{
		 if(strstr(UART3_RX_BUFFER,modebuf) != NULL)  //�Ѿ��Ǹù���ģʽ����ֱ�ӷ��أ�������������
		 {
			  if(Flag_COMDebug == 1)
			  {
					printf("WIFI has in this mode\r\n");
			  }					
			  return WIFI_SUCCESS ;
		 }
		 else
		 {
			  break;
		 }
		 if(WiFi_Time>WIFI_3S_TIMEOUT)
		 {
			 if(Flag_COMDebug == 1)
			 {
				 printf("Inquire wifi mode time out");
			 }
			 break;
		 }
	}
	sprintf(cmd, "AT+CWMODE_DEF=%d\r\n",mode);
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	Delay_ms(200);
	WiFi_Time = 0;
	count = 0;
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"OK") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set WIFI  mode Successed\r\n");
			}
			Delay_ms(100);
			WIFI_Reset();
			Delay_ms(2000);
			WIFI_Open_cmdMode();
			return WIFI_SUCCESS ;
		}
		else
		{
			WIFI_USART_Send(cmd, strlen(cmd));
			ClearUSARTBUF(WIFI_USART);
			Delay_ms(200);
			count++;
		}
		if((count>5)||(WiFi_Time>WIFI_5S_TIMEOUT))
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set WIFI  mode time out\r\n");
			}
			return WIFI_FAIL ;
		}
	}
		
}
/****************************************************************************
*	�� �� ��: WIFI_Set_STASSID
*	����˵��: ����STAģʽ���ӵ�·����ssid������
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*	AT+CWJAP="zangwii2008","zw853429"
*
*	WIFI CONNECTED
*	WIFI GOT IP
*
*	OK
*	AT+CWJAP_DEF="zangwii2008","zw853429"
*
*	WIFI DISCONNECT
*	WIFI CONNECTED
*	WIFI GOT IP

*	OK
*****************************************************************************/
char WIFI_Set_STASSID(char *stassid,char *stapwd)
{
	//char cmd[100]="";
	*cmd='\0';
	sprintf(cmd,"AT+CWJAP_CUR=\"%s\",\"%s\"\r\n",stassid,stapwd);
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	Delay_ms(100);
	delaytime = 0;
	if(Flag_COMDebug == 1)
	{
		printf("Connect to wifi:%s,%s\r\n",stassid,stapwd);
	}
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"OK") != NULL)
		{				  				
			if(Flag_COMDebug == 1)
			{
				printf("Set ssid  Successed\r\n");
			}
			return WIFI_SUCCESS ;
		}
		if(strstr(UART3_RX_BUFFER,"+CWJAP=1") != NULL)  //�������ӳ�ʱ
		{
			if(Flag_COMDebug == 1)
			{
				printf("Link time out!\r\n");
			}
			return WIFI_FAIL ;
		}
		if(strstr(UART3_RX_BUFFER,"+CWJAP=2") != NULL)//�����������
		{
			if(Flag_COMDebug == 1)
			{
				printf("STA password error:%s\r\n",stapwd);
			}
			return WIFI_FAIL ;
		}
		if(strstr(UART3_RX_BUFFER,"+CWJAP=3") != NULL)//�����Ҳ���AP
		{
			if(Flag_COMDebug == 1)
			{
				printf("Can't find AP:%s\r\n",stassid);
			}
			return WIFI_FAIL ;
		}
		if(strstr(UART3_RX_BUFFER,"+CWJAP=4") != NULL)//��������ʧ��
		{
			if(Flag_COMDebug == 1)
			{
				printf("Link AP failed:%s\r\n",stassid);
			}
			return WIFI_FAIL ;
		}
		if(delaytime>WIFI_20S_TIMEOUT)
		{			 
			if(Flag_COMDebug == 1)
			{
				printf("Set ssid  failed\r\n");
			}
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Req_STASSID
*	����˵��: ��ѯwifiģ�����ӵ�·�������ƺ�����
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_Req_STASSID(void)
{
	//char cmd[20]="";
	char *pstr=NULL;
	uint8_t len=0;
	uint8_t i=0;
//	char buf[50];
	*cmd='\0';
	WIFI_Open_cmdMode();
	Delay_ms (10);
	sprintf(cmd,"AT+CWJAP_CUR?\r\n");
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delaytime = 0;
	while(1)
	{			
		pstr = strstr(UART3_RX_BUFFER,"AT+CWJAP_CUR:");
		if(pstr != NULL)
		{
			Delay_ms (10);
			memcpy(RouterName_InWIFI,0x00,75);
			for(i=0;i<UART3_RX_LEN-15;i++)
			{
				RouterName_InWIFI[i]=pstr[i+13];
			}
			ClearUSARTBUF(WIFI_USART);
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_5S_TIMEOUT)
		{			 
			if(Flag_COMDebug == 1)
			{
				printf("Req ssid  failed\r\n");
			}
			return WIFI_FAIL ;
		}
	}
	
	
}
/****************************************************************************
*	�� �� ��: WIFI_Set_TCPConnectIP
*	����˵��: ����ip�Ͷ˿ں�
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_Set_TCPConnectIP(char *ip,char *port)
{
	//char cmd[100]= "";
	*cmd='\0';
    
	sprintf(cmd,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",ip,port);
	WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	Delay_ms(50);
	WiFi_Time = 0;
	if(Flag_COMDebug == 1)
	{
		printf("\r\n%s",cmd);
	}
	while(1)
	{
		if((strstr(UART3_RX_BUFFER,"CONNECT") != NULL)&&(strstr(UART3_RX_BUFFER,"OK") != NULL))
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set IP successed\r\n");
			}        					
			return WIFI_SUCCESS ;
		}
		if(strstr(UART3_RX_BUFFER,"ERROR") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set IP failed\r\n");
			}        					
			return WIFI_FAIL ;
		}
		if(strstr(UART3_RX_BUFFER,"ALREAY CONNECT") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("IP has connect\r\n");
			}        					
			return WIFI_SUCCESS ;
		}
		if(WiFi_Time>WIFI_20S_TIMEOUT)
		{	       				 
			if(Flag_COMDebug == 1)
			{
				printf("Set IP failed��%s\r\n",UART3_RX_BUFFER);
			}
			return WIFI_FAIL ;
		}
	}
	
}
/****************************************************************************
*	�� �� ��: WIFI_Close_TCPConnect
*	����˵��: �ر�TCP����
*	��    �Σ�linkID ���Ӻţ�Ϊ5ʱ�ر���������
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_Close_TCPConnect(uint8_t linkID)
{
	//char cmd[30]="";
	*cmd='\0';
	ClearUSARTBUF(WIFI_USART);
	sprintf(cmd, "AT+CIPCLOSE\r\n");
	WIFI_USART_Send(cmd, strlen(cmd));
	delaytime = 0;
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"OK") != NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(strstr(UART3_RX_BUFFER,"ERROR") != NULL)
		{
			return WIFI_FAIL ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{
			return WIFI_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Reset
*	����˵��: reset module
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void WIFI_Reset(void)
{	 
	//char cmd[30]="";
	*cmd='\0';
	ClearUSARTBUF(WIFI_USART);
	sprintf(cmd, "AT+RST\r\n");
	WIFI_USART_Send(cmd, strlen(cmd));
	delaytime = 0;
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"ERROR") != NULL)
		{
			WIFI_USART_Send(cmd, strlen(cmd));
			ClearUSARTBUF(WIFI_USART);
		}
		if(strstr(UART3_RX_BUFFER,"OK") != NULL)
		{
			//Flag_DataSendMode = WIFI_DATASEND_ATMODE;   //ATģʽ
			return ;
		}
		if(delaytime>WIFI_5S_TIMEOUT)
		{
			return ;
		}
	}
	  
}
/****************************************************************************
*	�� �� ��: WIFI_Restore
*	����˵��: restore to factory mode
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void WIFI_Restore(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+RESTIRE\r\n");
    WIFI_USART_Send(cmd, strlen(cmd));
}

/****************************************************************************
*	�� �� ��: WIFI_OpenDHCP
*	����˵��: ����DHCP
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_OpenDHCP(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CWDHCP_DEF=1,1\r\n");
    WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	delaytime = 0;
	while(1)
	{			
		if(strstr(UART3_RX_BUFFER,"OK") != NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
	
}
/****************************************************************************
*	�� �� ��: WIFI_Query_constatus
*	����˵��: ��ѯSTA����״̬
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void WIFI_Query_STAStatus(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CIPSTATUS\r\n");
    WIFI_USART_Send(cmd, strlen(cmd));
	 
}

/****************************************************************************
*	�� �� ��: WIFI_Query_rssi
*	����˵��: ��ѯ��ǰ���ӵ��ź�ǿ��
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void WIFI_Query_rssi(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CWJAP_CUR?\r\n");
    WIFI_USART_Send(cmd, strlen(cmd));
}
/****************************************************************************
*	�� �� ��: WIFI_Set_MUXLINK
*	����˵��: ���ö�����
*	��    �Σ�linknum ������
*	�� �� ֵ: 
* 	˵    ����0Ϊ�����ӣ�1Ϊ������
*****************************************************************************/
char WIFI_Set_MUXLINK(uint8_t linknum)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CIPMUX=%d\r\n",linknum);
    WIFI_USART_Send(cmd, strlen(cmd));
	Delay_ms(50);
	delaytime = 0;
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"OK")!=NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(strstr(UART3_RX_BUFFER,"ERROR")!=NULL)
		{
			return WIFI_FAIL ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Set_ATE
*	����˵��: �����Ƿ���ָ�����
*	��    �Σ�status �Ƿ����
*	�� �� ֵ: 
* 	˵    ����0Ϊ�����ӣ�1Ϊ������
*****************************************************************************/
char WIFI_Set_ATE(uint8_t status)
{
    //char cmd[30]="";
	*cmd='\0';
	if(status == 1)
	{
		sprintf(cmd, "ATE1\r\n"); //��������
	}
	else
	{
		sprintf(cmd, "ATE0\r\n"); //�رջ���
	}
    WIFI_USART_Send(cmd, strlen(cmd));
	Delay_ms(50);
	delaytime = 0;
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"OK")!=NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Query_tcpstatus
*	����˵��: query tcp status
*	��    �Σ�
*	�� �� ֵ: 0��ʾδ���ӣ�1��ʾ���ӣ�-1��ʾ����
* 	˵    ����
*****************************************************************************/
char WIFI_Query_TCPStatus(void)
{
	//char cmd[30]="";
	char *pstr;
	*cmd='\0';
	Delay_ms(10);
	ClearUSARTBUF(WIFI_USART);
	WIFI_Query_STAStatus();
	Delay_ms(50);
	WiFi_Time = 0;
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"STATUS:3")!=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("TCP has connected\r\n");
			}
			return WIFI_TCP_CONNECT;
		}	
		if(strstr(UART3_RX_BUFFER,"STATUS:4")!=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("TCP has not connected\r\n");
			}
			return WIFI_TCP_NOCONNECT;
		}
		if(strstr(UART3_RX_BUFFER,"STATUS:5")!=NULL)
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("WiFi has not connect\r\n");
			}
			return WIFI_NOCONNECT;
		}		
		if(WiFi_Time > WIFI_10S_TIMEOUT )
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("Read sta status time out:%s\r\n",UART3_RX_BUFFER);
			}
			return WIFI_FAIL;			
		}

	}
}
/****************************************************************************
*	�� �� ��: WIFI_ConnectIPCompare
*	����˵��: �豸�����IP��wifi���ӵ�ip���бȽ�
*	��    �Σ�
*	�� �� ֵ:1��ʾ�ɹ�,0��ʾʧ�ܣ�-1��ʾһ������ʧ��
* 	˵    ����
*****************************************************************************/
char WIFI_ConnectIPCompare(void)
{
   //char cmd[30]="";
	char *pstr;
	*cmd='\0';
	sprintf(cmd, "AT+CIPSTATUS\r\n");	
	WIFI_USART_Send(cmd, strlen(cmd));

	ClearUSARTBUF(WIFI_USART);
	WIFI_Query_STAStatus();
	Delay_ms(50);
	WiFi_Time = 0;
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"+CIPSTATUS")!=NULL)
		{
			Delay_ms(50);
			 if( strstr(UART3_RX_BUFFER,IP2) != NULL)
			 {
				  if(Flag_COMDebug == 1)
				  {
						printf("IP2 has connected\r\n");
				  }					
				  return WIFI_SUCCESS ;
			 }
			 else
			 {
				 if(Flag_COMDebug == 1)
				  {
						printf("Wifi connected error IP:%s\r\n",UART3_RX_BUFFER);
				  }					
				  return WIFI_FAIL ;
			 }
		}				
		if(WiFi_Time > WIFI_5S_TIMEOUT )
		{
			ClearUSARTBUF(WIFI_USART);
			if(Flag_COMDebug == 1)
			{
				printf("Read sta status time out:%s\r\n",UART3_RX_BUFFER);
			}
			return WIFI_FAIL;			
		}

	}
}
/****************************************************************************
*	�� �� ��: WIFI_SmartConfig
*	����˵��: ��������
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ���������������Ӻ󣬷��ص��������£�
*	AT+CWSTARTSMART=1
*	
*	OK
*	WIFI DISCONNECT
*	smartconfig type:ESPTOUCH
*	Smart get wifi info
*	ssid:iBreezee-DEV
*	password:dev201805
*	WIFI CONNECTED
*	WIFI GOT IP
*	smartconfig connected wifi
*****************************************************************************/
char WiFi_SmartConfig(void)
{
	char err = 0;
	char *pstr = NULL;
	char Flag_receivessid = 0;
	uint8_t Command_SendCount=0;
    
	Flag_LED_Status = LED_WIFI_CONFIG;
	
	if(Flag_COMDebug == 1)
	{
		printf("Start smart config!\r\n");
	}
	WiFi_Time = 0;		
	if(WIFI_Start_SmartConfig() == WIFI_SUCCESS)
	{
		ClearUSARTBUF(WIFI_USART);
        //printf("send msg to es8266 succeed\r\n");
        //printf("Flag_receivessid:%d\r\n",Flag_receivessid);
        printf("WiFi_SmartConfig:%s\r\n",UART3_RX_BUFFER);
		while(1)
		{
			if((strstr(UART3_RX_BUFFER,"Smart get wifi info") != NULL)&&(Flag_receivessid == 0))  //��ȡ��������Ϣ
			{
				        //printf("Smart get wifi info\r\n");

				Delay_ms(50);
				pstr = strstr(UART3_RX_BUFFER,"ssid:");
				pstr += 5;
				Router_NameLen = 0;
				while( *pstr != 0x0D)
				{
					Router_Name[Router_NameLen++] = *pstr;
					pstr++;
				}
				Router_Name[Router_NameLen] = '\0';
                //printf("Router_Name :%s\r\n",Router_Name);
				pstr = strstr(UART3_RX_BUFFER,"password:");
				pstr += 9;
				Router_PWDLen = 0;
				while( *pstr != 0x0D)
				{
					Router_PWD[Router_PWDLen++] = *pstr;
					pstr++;
					
				}
				Router_PWD[Router_PWDLen] = '\0';
               //printf("Router_PWD :%s\r\n",Router_PWD);
				if(Flag_COMDebug == 1)
				{
					printf("Smart config info:Router_Name=%s;Router_PWD=%s\r\n",Router_Name,Router_PWD);
				}
				SaveRouterNameToFlash();
				Flag_receivessid = 1;
			}
			if((strstr(UART3_RX_BUFFER,"WIFI GOT IP") != NULL)&&(Flag_receivessid == 1))
			{
                printf("WIFI GOT IP\r\n");
				Delay_ms(500);
				Flag_receivessid = 0;
				ClearUSARTBUF(WIFI_USART);
				WIFI_Stop_SmartConfig();								
				return WIFI_SUCCESS;
			}
			if(WiFi_Time > WIFI_1MIN_TIMEOUT )
			{				
                printf("Smart config time out\r\n");
				if(Flag_COMDebug == 1)
				{
					printf("Smart config time out:%s\r\n",UART3_RX_BUFFER);
				}
				ClearUSARTBUF(WIFI_USART);
                
				return WIFI_FAIL;			
			}
		}
	}
	else
	{
		WIFI_Stop_SmartConfig();
		return WIFI_FAIL ;
	}
}
	
/****************************************************************************
*	�� �� ��: WIFI_Start_SmartConfig
*	����˵��: ��ʼsmartconfig
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*	�������ӵķ�ʽ�� 
*	0: ʹ�ð��ſ� AI-LINK ���� 
*	1: ʹ�� ESP-TOUCH ���� 
*	2: ʹ�� AIR-KISS ���� 
*   3�� ESP-TOUCH+AirKiss
*****************************************************************************/
char WIFI_Start_SmartConfig(void)
{
    //char cmd[30]="";
    //WIFI_Restore();//wifi�ָ���������
    //printf("clear 8266flash\r\n");
	*cmd='\0';
    sprintf(cmd, "AT+CWSTARTSMART=3\r\n");	//ʹ�� ESP-TOUCH+AirKiss ���� 
    WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	Delay_ms(50);
	WiFi_Time = 0;
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"OK") != NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Stop_SmartConfig
*	����˵��: ��ʼsmartconfig
*	��    �Σ�
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
char WIFI_Stop_SmartConfig(void)
{
    //char cmd[30]="";
	*cmd='\0';
    sprintf(cmd, "AT+CWSTOPSMART\r\n");	
    WIFI_USART_Send(cmd, strlen(cmd));
	ClearUSARTBUF(WIFI_USART);
	Delay_ms(50);
	WiFi_Time = 0;
	while(1)
	{
		if(strstr(UART3_RX_BUFFER,"OK") != NULL)
		{
			return WIFI_SUCCESS ;
		}
		if(delaytime>WIFI_3S_TIMEOUT)
		{			 
			return WIFI_FAIL ;
		}
	}
}
/****************************************************************************
*	�� �� ��: WIFI_Send_data
*	����˵��: send data via socket
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
char WIFI_Send_data(uint8_t sock_fd, uint16_t send_len, uint8_t *buf)
{
    //char cmd[50]="";
	uint8_t count = 0;
	*cmd='\0';
	ClearUSARTBUF(WIFI_USART);
	sprintf(cmd,"AT+CIPSEND=%d\r\n",send_len);   
	WIFI_USART_Send(cmd,strlen(cmd));	  
	WiFi_Time = 0;
	count++;
	while(1)
	{
		Delay_ms(5);
		if(strstr(UART3_RX_BUFFER,">")!= NULL)
		{				 
			break;
		}

		if(WiFi_Time> WIFI_1S_TIMEOUT)
		{
			if(count>2)
			{
	//			if(Flag_COMDebug == 1)
	//			{
	//				printf("Send data to server failed\r\n");
	//			}
	//			return WIFI_FAIL ;
				break;
			}
			else
			{
				ClearUSARTBUF(WIFI_USART);
				sprintf(cmd,"AT+CIPSEND=%d\r\n",send_len);   
				WIFI_USART_Send(cmd,strlen(cmd));
				WiFi_Time = 0;
				count++;
			}
		}

	}
	WIFI_USART_Send(buf,send_len);	
	WiFi_Time = 0;
	Delay_ms(10);
	while(1)
	{
		
		if(strstr(UART3_RX_BUFFER,"SEND OK")!= NULL)
		{
//			if(Flag_COMDebug == 1)
//			{
//				printf("Send data to server over\r\n");
//			}
			return WIFI_SUCCESS ;
		}
		if(strstr(UART3_RX_BUFFER,"ERROR") != NULL)
		{
			if(Flag_COMDebug == 1)
			{
				printf("TCP has not connect\r\n");
			}
			
			return WIFI_TCP_NOCONNECT ;
		}
		if(WiFi_Time> WIFI_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{
				printf("Send data to server failed\r\n");
			}
			return WIFI_FAIL ;
		}
	}			
}

/****************************************************************************
*	�� �� ��: WIFI_USART_Send
*	����˵��: WiFi���ڷ�������
*	��    �Σ�tx_buf��Ҫ���͵�����  buflen���͵����ݳ���
*	�� �� ֵ: 
* ˵    ����
*****************************************************************************/
void WIFI_USART_Send(char *tx_buf,uint16_t buflen)
{
    uint16_t i;
    uint32_t err_code;

	for (i=0; i<buflen; i++)
	{
		SendDataToUSART(WIFI_USART,tx_buf[i]);
	}  
}
