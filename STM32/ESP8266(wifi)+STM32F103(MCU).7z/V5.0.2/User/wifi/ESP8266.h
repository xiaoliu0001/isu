/******************************************************************************
 * @file     ESP8266.c
 * @brief   WiFiͨѶ����
 * @version  v1.0
 * @date     2018.10
 * @note
 * Copyright (C)  
 *
 * @par      ���201810
 *    V1.0    ESP8266 WiFiģ��ͨѶ����
*******************************************************************************/
#ifndef __ESP8266_H_
#define __ESP8266_H_

#include "Parameter.h"
#include "Fun.h"
#include <stdlib.h>
#include "string.h"
#include "USART.h"


#define WIFI_POWER_PIN                  GPIO_Pin_14                 
#define WIFI_POWER_GPIO_PORT            GPIOB                      
#define WIFI_POWER_GPIO_CLK             RCC_APB2Periph_GPIOB

#define WIFI_POWER(a)	if (a)	\
					GPIO_SetBits(WIFI_POWER_GPIO_PORT,WIFI_POWER_PIN);\
					else		\
					GPIO_ResetBits(WIFI_POWER_GPIO_PORT,WIFI_POWER_PIN)
					
#define WIFI_EN_PIN                  GPIO_Pin_15                
#define WIFI_EN_GPIO_PORT            GPIOB                     
#define WIFI_EN_GPIO_CLK             RCC_APB2Periph_GPIOB

#define WIFI_EN(a)	if (a)	\
					GPIO_SetBits(WIFI_EN_GPIO_PORT,WIFI_EN_PIN);\
					else		\
					GPIO_ResetBits(WIFI_EN_GPIO_PORT,WIFI_EN_PIN)										
/****************************************************************/
#define TESTROUTERNAME     "zangwii2008"
#define TESTROUTERPWD      "zw853429"
//#define TESTROUTERNAME     "iBreezee-DEV"
//#define TESTROUTERPWD      "dev201805"
					
#define SOCKETA         0
#define SOCKETB         1

#define  WIFIMODE_STA   	1   //WiFiģʽ
#define  WIFIMODE_AP		2
#define  WIFIMODE_AP_STA	3
					
#define  ATMODEIN       1     // ����ATָ��ķ�ʽ��1Ϊָ�ʽ��0Ϊgpio���ŵ�ƽ��ʽ

#define    WIFI_SUCCESS              0
#define    WIFI_FAIL                -1
#define    WIFI_CFG_ERROR           -2
					
#define    WIFI_CONNECT             1
#define    WIFI_NOCONNECT           2										
#define   WIFI_TCP_CONNECT           3
#define   WIFI_TCP_NOCONNECT         4

#define   WIFI_DATASEND_ATMODE       1
#define   WIFI_DATASEND_TRANSMODE    0

//----------- timeout Definition---------------------------------
       					 
#define WIFI_INC_TIMER               WIFI_Timer++
#define WIFI_RESET_TIMER             WIFI_Timer=0


#define WIFI_1S_TIMEOUT              1
#define WIFI_3S_TIMEOUT              3
#define WIFI_4S_TIMEOUT           	 4
#define WIFI_5S_TIMEOUT              5
#define WIFI_10S_TIMEOUT           	10
#define WIFI_20S_TIMEOUT           	20
#define WIFI_30S_TIMEOUT           	30
#define WIFI_1MIN_TIMEOUT           	60
#define WIFI_3MIN_TIMEOUT           	180
#define WIFI_5MIN_TIMEOUT           	300


extern uint8_t AP_Channel;          //AP���ӵ��ŵ�
/****************************************************************/
void WIFI_GPIO_CONFIG(void);
char WIFI_INIT(void);
char WIFI_Open_cmdMode(void);
char WIFI_STA_Status(void);
char WIFI_Query_STA_RSSI(void);
char WIFI_Set_TCPConnectIP(char *ip,char *port);
char WIFI_Query_TCPConnectSocket(void);
char WIFI_Send_data(uint8_t sock_fd, uint16_t send_len, uint8_t *buf);
char WIFI_Set_Mode(uint8_t mode);
char WIFI_Set_STASSID(char *stassid,char *stapwd);
void WIFI_Reset(void);
void WIFI_Restore(void);
char WIFI_OpenDHCP(void);
void WIFI_Query_STAStatus(void);
void WIFI_Query_rssi(void);
char WIFI_Query_TCPStatus(void);
char WIFI_Set_ATE(uint8_t status);
void WIFI_USART_Send(char *tx_buf,uint16_t buflen);
char WIFI_Req_STASSID(void);
char WiFi_SmartConfig(void);
char WIFI_Start_SmartConfig(void);
char WIFI_Stop_SmartConfig(void);
char WIFI_Set_MUXLINK(uint8_t linknum);
char WIFI_Close_TCPConnect(uint8_t linkID);
char WIFI_ConnectIPCompare(void);

#endif