/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c  �жϷ�����
  * @author  ���
  * @version V1.0
  * @date    2017.2
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "stm32f10x.h"
#include "usart.h"
#include <stdio.h>
#include "SysTick.h"
#include "BERpara.h"
#include "Fun.h"

extern void SYSCLKConfig_STOP(void);
extern void TimingDelay_Decrement(void);
extern void Time_Control(void);
extern void  Key_Handle(void);
extern void Set_MP3Player_Silence(void);
void Analysis_USART3_Order(void);
extern uint8_t indexWave[];

//volatile uint16_t  Time_ms = 0;	




/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/


/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
	TimingDelay_Decrement();
}


/*******************************************************************************
*	�� �� ��: TIM2_IRQHandler
*	����˵��: ��ʱ��2 1ms��ʱ�жϣ�����ģ��ʱ��
*	��    �Σ���
*	�� �� ֵ: ��
 *******************************************************************************/
void TIM2_IRQHandler(void)
{
	uint8_t i =0;
	if ( TIM_GetITStatus(TIM2 , TIM_IT_Update) != RESET ) 
	{	
		TIM_ClearITPendingBit(TIM2 , TIM_IT_Update); 
		TimerSim.Sec++;
		if(TimerSim.Sec == 60)
		{
			TimerSim.Sec = 0;
			TimerSim.Min++;
		}
		if(TimerSim.Min == 60)
		{
			TimerSim.Min = 0;
			TimerSim.Hour++;
		}	
		if(TimerSim.Hour == 24)
		{
			TimerSim.Hour = 0;
			TimerSim.Day++;
		}	
		delaytime++;
		delaytime1++;
		Link_Time++;
		WiFi_Time++;  //WiFiģ��ȴ�ʱ��
		GetSleepDataTimeCount++;				
		Command_SendCount = 0;
		SleepDataBuffer_SendTime++;
		IWDG_Feed();
		RenewRealTime();		
		if(Flag_TimeAdj != 0)
		{
			Adj_Time++;
			if( Adj_Time == 60)
			{
				Adj_Time = 0;
				if(Flag_TimeAdj == 2)
					Flag_TimeAdj = 1;
				if(Flag_TimeAdj == 3)
					Flag_TimeAdj = 0; 					
			}			
		}
		if(Flag_SendLinkStatus == 1)
		{
			SendLinkStatus_Time++;
		}
		if(APP_Receive_Right == 1)   //ָ���ַ�������ʱ��
		{
			BLE_ReceiveDataTime++;
		}			 
		if(LinkStep != SENDSLEEPDATA)
		{
			WIFI_ConnetTime++;
			if(WIFI_ConnetTime%60==0)
			{
				
				if(Flag_COMDebug == 1)
					printf("WIFI_ConnetTime = %d s\r\n",WIFI_ConnetTime); 
			}			
		}
		if(Flag_InitStatus == WIRELESS_INIT)
		{
			WiFi_InitTime++;
		}
		if(Flag_CanSendStatistData == 2)
		{
			CanSendStatistTime++;
			if(CanSendStatistTime == 10)
			{
				CanSendStatistTime = 0;
				Flag_CanSendStatistData = 1;
			}
		}
		if(Flag_ADC_ADJ == 1)
		{
			ADC_AdjTime++;
		}
		if(Flag_InitStatus == CONTINUE_SENDDATA)
		{
			Time_NetworkInquire++;
		}
		
		#ifdef ENABLE_SENDPRESSSERSONSTATUS
		if(Flag_SendPresensorStatus == 1)  //����ѹ��״̬
		{
			SendPresensorStatus_Time++;
		}
		#endif
		//-----------------������ʱ��5min�����ݷ���ʱ�����ӳ�-----------					
		if(gPeopleFlag == TRUE)   //��Ա���ߣ������ʱ�����ݷ���ʱ��3s
		{
			if(Flag_Binding_Users == BINDING_USERS_YES)
				SleepData_SendTime = SLEEPDATA_SENDTIME_3S;
			Monitor_Offline_Time = 0;
		}
		if((gPeopleFlag == FALSE )&&(Monitor_Offline_Time >SLEEPDATA_CHANGETIME))
		{
			SleepData_SendTime = SLEEPDATA_SENDTIME_20S;
			Monitor_Offline_Time = SLEEPDATA_CHANGETIME;
		}		
		if((gPeopleFlag == FALSE)&&(Flag_PowerOn == 0))        //����Ա������������ӳɹ���ʼ��ʱ�����2017525����
		{
			Monitor_Offline_Time++;
		}	
		if(Flag_No_Binding_Users_Time == 1)  //δ�����û���ʱ�����2017525����
		{
			No_Binding_Users_Time++;
			if(No_Binding_Users_Time >= SLEEPDATA_CHANGETIME)
			{
				No_Binding_Users_Time = SLEEPDATA_CHANGETIME;
				SleepData_SendTime = SLEEPDATA_SENDTIME_20S;
			}
		}
		
		//---------------����12�㿪ʼ�µ�ͳ��-------------------------------		
		if((RealTime[3] ==12)&&(RealTime[4] ==0)&&(RealTime[5] ==0)&&(Flag_PowerOn == 0)&&(LinkStep != SENDSLEEPDATA))      //ÿ������12��ͳ��һ������
		{
			Statist_NextDayStart();
		}
	}		
		
}
/*******************************************************************************
*	�� �� ��: TIM2_IRQHandler
*	����˵��: ��ʱ��3 ��ʱ�ж�
*	��    �Σ���
*	�� �� ֵ: ��
 *******************************************************************************/
void TIM3_IRQHandler(void)
{	
	if ( TIM_GetITStatus(TIM3 , TIM_IT_Update) != RESET ) 
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update  );  	//���TIMx�����жϱ�־ 		
//		ADCTimer++;										//����ʱ���ۼ�
		LedFlash+=20;										//���ƵƵ���˸
		
		if(Flag_LED_Status > 0)		
			LED_Status();
		
		if(Flag_PowerOn == 0)
		 {
			OnbedStatus_CountTimer++;
			 SleepDataCalculate();
		 }
	}
}



/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
