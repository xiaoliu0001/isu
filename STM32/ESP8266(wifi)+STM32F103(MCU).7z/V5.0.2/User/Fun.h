/******************************************************************************
 * @file     Fun.h
 * @brief   ���ܺ���
 * @version  
 * @date     2017
 * @note
 * Copyright (C)  2017 ���
 *
 * @par       
*******************************************************************************/
#ifndef __FUN_H_
#define __FUN_H_

#include <stdint.h>
#include "SysTick.h"
#include "Parameter.h"
#include "ESP8266.h"
#include "BERpara.h"
#include "MD5.h"
#include "USART.h"
#include "LED.h"
#include "STMFlash.h"


typedef struct status{
	unsigned char isOnbed;//�Ƿ��ڴ�, 0: �� 1:��
	unsigned char isMove;//�Ƿ��嶯, 0: �� 1:��
	unsigned char isStopBreath;//�Ƿ�ֹͣ����0:�� 1:��
}STATUS;


void RenewRealTime(void);
void RePowerOn_WIFI(void);
void getFilterWave(int* wave);
void putWaveDataToBuf(int org,int hrWave,int rrWave);
void filter(int src[],int len,int interval,int* dest);
int getAverage(int datas[],int srcIndex,int len);
int getUpOrDown(int datas[],int index ,int len);
int getAbsAverage(int datas[],int srcIndex,int len);
int getMax(int datas[],int srcIndex,int len);
int getMin(int datas[],int srcIndex,int len);
void putHrWaveData(int data);
void putRrWaveData(int data);
void  DealADCSampleData(void);
void  DealSmallADCSampleData(float status);
void SleepDataCalculate(void);
void CheckAmpADCData(void);
void HexToStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen);
void HexToLowerStr(unsigned char *pbDest, unsigned char *pbSrc, int nLen);

char LinkServerVerifyStep(uint8_t step);
void ConnectFrontServer(void);
void FrontServerLinkStatus(void);
void GetBackServerIP(void);
void AnalysisBackServerIP(void);	
void ConnectBackServer(void);
void BackServerLinkStatus(void);
void GetBackServerToken2(void);
void AnalysisBackServerToken2(void);
void SendBackServerVerify(void);
void GetBackServerVerifyResult(void);
char SendDataBegin(void);
void Send_AMPCHGDataToServer(void);
void SendReConnectMode(uint8_t st,int lac,int cid);
void Send_DataUnusual(uint8_t flag_un,uint8_t unHr,uint8_t unRr);
void Req_Users_Binding(void);
void GetServerTime(void);
unsigned char GetDataHead(unsigned char* datas,unsigned char len);
char SendRealTimeSleepData(void);
void GetADCSampleData(void);
void Statist_SleepStatus(void);
void  Save_StatistStatusData(unsigned char *starttime,unsigned char *endtime,uint8_t status,uint8_t len,unsigned char *averavehr,unsigned char *averagerr);
void  Send_StatistStatusData(void);
void  Set_StatistStartTime(void);
void  Set_StatistEndTime(void);
void  Statist_NextDayStart(void);
char	SendSleepDataBuff(void);
void SendPressSenserStatus(uint8_t status);

void SystemReset_CheckStatus(void);
void SendDeviceMacToUart(USART_TypeDef* USARTx);
void SendDeviceVerInfoToUart(USART_TypeDef* USARTx,char *str);
void COMRetuenOneByte(USART_TypeDef* USARTx,uint8_t cmd,uint8_t data);


char ReadMACFromFlash(void);	
char SaveMACToFlash(void);
char ReadIPFromFlash(void);
char SaveIPToFlash(void);
char SaveTokenToFlash(void);
char ReadTokenFromFlash(void);
char SaveRouterNameToFlash(void);
char ReadRouterNameFromFlash(void);
void Check_ExtSensor_PeopleOnBed(void);

void IWDG_Config(uint8_t prv ,uint16_t rlv);
void IWDG_Feed(void);


#endif

