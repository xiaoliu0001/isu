/******************************************************************************
 * @file     ADC.H
 * @brief   ADC����
 * @version  V1.1
 * @date     2018
 * @note
 * Copyright (C)  
 *
 * @par     ADC���� 
*******************************************************************************/
#ifndef __ADC_H_
#define __ADC_H_

#include "Parameter.h"



void ADC_Comfig(void);
uint16_t GetADCData(void);
void ADC_GPIO_Comfig(void);
void ADC1_Mode_Config(void);


#endif
