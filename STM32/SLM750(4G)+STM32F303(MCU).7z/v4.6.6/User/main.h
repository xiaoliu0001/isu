/******************************************************************************
 * @file     main.n
 * @brief   ������
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par   �ϱ� 2016   
*******************************************************************************/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/

#include "stm32f30x_conf.h"
#include "LED_Key.h"
#include "USART.h"
#include "stdio.h"
#include "Stm32f30x.h"
#include "TIM.h"
#include "MD5.h"
#include "stdlib.h"


unsigned char SelectWorkModule(void);
void WIFIUPDATE(void);
void GetMac(unsigned char Type);
void COM1ProcessCmd(void);
void LinkServer(uint8_t AP);







#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
