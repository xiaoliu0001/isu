#ifndef __M26_H
#define __M26_H
#include "Fun.h"
#include "Parameter.h"
#include "USART.h"
//#if _NEW_MODULE
#define GPRS_CQ_GPIO_PORT        		GPIOB
#define GPRS_CQ_GPIO_CLK                RCC_AHBPeriph_GPIOB
#define CHIR_PIN                    	GPIO_Pin_1
#define GPRS_CQ_PIN                    	GPIO_Pin_14	


//�˿ڶ���
#define LTE_PWRKEY_PIN                  GPIO_Pin_3                  //��������   
#define LTE_PWRKEY_GPIO_PORT            GPIOB                      


#define LTE_RESETN_PIN                  GPIO_Pin_4             //��λ����       
#define LTE_RESETN_GPIO_PORT            GPIOB                      


#define LTE_DTR_PIN                  GPIO_Pin_12             //��λ����       
#define LTE_DTR_GPIO_PORT            GPIOB                

#define LTE_PWRKEY(a)	if (a)	\
					GPIO_SetBits(LTE_PWRKEY_GPIO_PORT,LTE_PWRKEY_PIN);\
					else		\
					GPIO_ResetBits(LTE_PWRKEY_GPIO_PORT,LTE_PWRKEY_PIN);
										
#define LTE_RESETN(a)	if (a)	\
					GPIO_SetBits(LTE_RESETN_GPIO_PORT,LTE_RESETN_PIN);\
					else		\
					GPIO_ResetBits(LTE_RESETN_GPIO_PORT,LTE_RESETN_PIN);
					
#define LTE_DTR(a)	if (a)	\
					GPIO_SetBits(LTE_DTR_GPIO_PORT,LTE_DTR_PIN);\
					else		\
					GPIO_ResetBits(LTE_DTR_GPIO_PORT,LTE_DTR_PIN);		

#define GPRS_POWER(a) if (a)	\
					GPIO_SetBits(GPRS_CQ_GPIO_PORT,GPRS_CQ_PIN);\
					else		\
					GPIO_ResetBits(GPRS_CQ_GPIO_PORT,GPRS_CQ_PIN);
//#endif
extern unsigned char SIMCard_IMEI[25];
extern uint8_t SIMCard_IMEI_Len;
extern unsigned char SIMCard_IMSI[20];
extern uint8_t SIMCard_IMSI_Len;
extern unsigned char SIMCard_ICCID[25];
extern uint8_t SIMCard_ICCID_Len;
extern u8 Flag_Init_Step;    
extern uint16_t  Init_pauseTime ;                     
                    
void Init_M26(u8 int_step);
uint8_t Set_Baund(void);
uint8_t Check_PIN(void);
uint8_t Wait_CREG(void);
uint8_t Wait_CGREG(void);
uint8_t AT_CGATT_Ctrl(void);
uint8_t Set_Connext(void);
int8_t  Read_Card_IMSI(void);
int8_t  Read_Card_CCID(void);
int8_t  Read_Card_IMEI(void);
uint8_t InquireCSQ(void);
void GPRSSendData(unsigned char *p,unsigned int Len);
void GetGPRSPosition(void);
char MyCountChar(unsigned char *p,int pLen);
u8 GPRS_CloseSocket(void);
uint8_t Set_IPLink_Mode(uint8_t mode);
void GetBackServerIP(void);
void AnalysisBackServerIP(void);
void Connect_BackServer(void);
void Analysis_BackServer(void);
void GetBackServerToken2(void);
void AnalysisBackServerToken2(void);
void SendBackServerVerify(void);
u8 GPRS_Send_Data(char *data,uint16_t len);
void Send_AMPCHGData2Server(void);
uint8_t InquireTCPstat(void);
#endif