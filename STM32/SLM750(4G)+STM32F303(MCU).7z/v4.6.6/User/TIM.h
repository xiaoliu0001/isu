/******************************************************************************
 * @file     TIM.c
 * @brief   ��ʱ������
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par       �ϱ� 2016
*******************************************************************************/
#ifndef __TIM_H_
#define __TIM_H_


void TIM2_Config(void);
void TIM3_Config(void);
void TIM4_Config(void);

#endif

