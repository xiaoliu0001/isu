/******************************************************************************
 * @file     LED_Key.C
 * @brief   �����Լ�LED����
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par       �ϱ� 2016
*******************************************************************************/

#ifndef __LED_KEY_H
#define __LED_KEY_H
#include "Fun.h"

#include "stm32f30x_rcc.h"
#include "stm32f30x_gpio.h"
#include "delay.h"
#include "USART.h"
#include "stm32f30x_misc.h"

#define LED_GPIO_PORT        		GPIOA
#define LED_GPIO_CLK                    RCC_AHBPeriph_GPIOA
#define LED2_PIN                         GPIO_Pin_15
#define LED3_PIN                         GPIO_Pin_14
#define LED4_PIN                         GPIO_Pin_13
#if _NEW_MODULE
#define LED5_PIN                         GPIO_Pin_9
#else
#define LED5_PIN                         GPIO_Pin_7
#endif



#define Toggle_LED             GPIO_WriteBit(LED_GPIO_PORT,LED2_PIN,1-(BitAction)(GPIO_ReadOutputDataBit(LED_GPIO_PORT,LED2_PIN)))
#define LED_ON                 GPIO_WriteBit(LED_GPIO_PORT,LED2_PIN,0);
#define LED_OFF                GPIO_WriteBit(LED_GPIO_PORT,LED2_PIN,1);
#define KEY_GPIO_CLK                   RCC_AHBPeriph_GPIOC
#define KEY_GPIO_PORT 			GPIOC
#define KEY_GPIO_PIN			GPIO_Pin_13


void LED_Init(void);
void delay_ms_YB(void);
void delay_ms_YB2(void);



#endif/*__LED_H*/


