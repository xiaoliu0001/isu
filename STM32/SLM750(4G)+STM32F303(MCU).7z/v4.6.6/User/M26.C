#include "m26.h"

#include <stdlib.h>
#include "Fun.h"
#include "Parameter.h"
#include "string.h"
#include "Delay.h"

#define SETBAUND        1
#define CHECKPIN        9
#define READCARD        2
#define CHECKCSQ        3
#define INIT_PAUSE      10
#define WAITREG         4
#define GPRSREG         5
#define CGATT           6
#define CONFIGCONNEXT   7

#define SETLINK_MODE    8
unsigned char SIMCard_IMEI[25];
uint8_t SIMCard_IMEI_Len=0;
unsigned char SIMCard_IMSI[20];
uint8_t SIMCard_IMSI_Len = 0;
unsigned char SIMCard_ICCID[25];
uint8_t SIMCard_ICCID_Len = 0;
uint16_t  Init_pauseTime =0 ; 
uint16_t  LTE_InitTime=0;  //LTE��ʼ��ʱ��
u8 Flag_Init_Step=1;
u8 GPRS_QIMUX(void);
uint8_t Set_ATE(uint8_t x);
char SLM750V_Query_VER(void);
char SLM750V_Query_MNOReg(void);
char SLM750V_Query_NetTyp(void);
char SLM750V_Query_APNstate(void);
char SLM750V_Query_Link(void);
char SLM750V_Close_Socket(void);
char SLM750V_Open_Socket(char *ipaddr,char *ipport);
char SLM750V_Send_Data(uint8_t *data,uint16_t len );


/****************************************************************************
*	�� �� ��: SLM750V_GPIO_CONFIG
*	����˵��: ��ʼ��SLM750�Ŀ������ź͸�λ����
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
void SLM750V_GPIO_CONFIG(void)
{

	GPIO_InitTypeDef GPIO_InitStruct;
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);	
    GPIO_InitStruct.GPIO_Pin=LTE_PWRKEY_PIN|LTE_RESETN_PIN;
    GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;
    GPIO_Init(LTE_PWRKEY_GPIO_PORT, &GPIO_InitStruct);

	
	
	
	LTE_RESETN(1);
	LTE_PWRKEY(1);	
	
	
}
/****************************************************************************
*	�� �� ��: LTE_StartUP
*	����˵��: LTE����
*	��    �Σ�
*	�� �� ֵ:���س�ʼ����ɵĲ���
* 	˵    ����
*****************************************************************************/
char SLM750V_StartUP(void)
{
	
	if(Flag_COMDebug == 1)
	{						
		printf("Start up LTE \r\n");
	}
		
	delay_ms(100);
	LTE_PWRKEY(0);
	//delay_ms(500);//slm750
    delay_ms(2000);//air720g
	LTE_PWRKEY(1);
	mytime = 0;
	LTE_RESETN(0);
    //delay_ms(450);//slm750
    delay_ms(60);//air720g
    LTE_RESETN(1);
    delay_ms(1000);
RePowerOn_GPRS();
	
}
void Init_M26(u8 int_step)
{
    char res1,res2;
    #if 0
    switch(int_step)
    {
        case SETBAUND:
            SLM750V_GPIO_CONFIG();
            SLM750V_StartUP();
            //if(Set_Baund())
                Flag_Init_Step = CHECKPIN;
        break;
        
        case CHECKPIN:
            
                if(Check_PIN())
                {
                    Flag_Init_Step = READCARD;
                }
        break;
        case READCARD:
            Set_ATE(0);
            Read_Card_IMEI();
            if(Read_Card_IMSI())
                Read_Card_CCID();
            if(ICCID_Save[0]!=0)    
            {        
                
                 res1=strcmp(SIMCard_ICCID,ICCID_Save);
                 res2=strcmp(SIMCard_IMEI,IMEI_Save);

                if(res1!=0||res2!=0)//�������룬�ȴ�10���Ӽ���
                {
                    Flag_CARD_ISCHANGE = CARD_HASCHANGE;
                    printf("ICCID NOT MATCH IMEI\r\n");
                    Flag_Init_Step = INIT_PAUSE;
                }
                else
                    {
                        Flag_CARD_ISCHANGE = CARD_NOCHANGE;
                        Flag_Init_Step = CHECKCSQ;
                    }
            }
            else
            {
                printf("ICCID SAVED IS NULL\r\n");
                   
                Init_pauseTime=0;
                GPRS_ConnetTime=0;
                    
                Flag_CARD_ISCHANGE = CARD_NOCHANGE;
                Flag_Init_Step = CHECKCSQ;
            }
        break;
        case CHECKCSQ:
        
           
                if(InquireCSQ())
                {
                    Flag_Init_Step = WAITREG;
                }
        break;
        
        case WAITREG:
            if(Wait_CREG())
                Flag_Init_Step = GPRSREG;
        break;
        
        case GPRSREG:
            
            if(Wait_CGREG())
                Flag_Init_Step = CGATT;
            
        break;
        
        case CGATT:
            if(AT_CGATT_Ctrl())
                Flag_Init_Step = CONFIGCONNEXT;
        break;
        
        case CONFIGCONNEXT:
                Set_Connext();
                GPRS_QIMUX();
                Flag_Init_Step = SETLINK_MODE;
            
        break;
        
        case SETLINK_MODE:
            Set_IPLink_Mode(1);            //ip  or   addr
			Flag_init = WIRELESS_INIT_OK; //����ģ���ʼ����ɣ����Խ�������������֤
        case INIT_PAUSE:
              if(Init_pauseTime>=60*10)
                {
                    printf("LTE Init continue\r\n");
                    Flag_Init_Step = CHECKCSQ;
                    Init_pauseTime=0;
                    GPRS_ConnetTime=0;
                }
              break;
        default:
            
        break;
    }
    #else
    switch(int_step)
    {
        case 1:
            SLM750V_GPIO_CONFIG();//����io
            SLM750V_StartUP();//�ϵ翪��
            Flag_Init_Step=2;
        break;
        case 2:
            if(Set_ATE(0))//ate
            if(SLM750V_Query_VER())
            if(Check_PIN())//�鿴SIM����״̬
            if(Read_Card_IMEI())//�鿴SIM����״̬            
                if(Read_Card_CCID())//��ȡ�����
                    if(SLM750V_Query_MNOReg())//Write command forces an attempt to select and register the GSM/UMTS network operator
                Flag_Init_Step=3;
            delay_ms(1000);
        break;
        case 3:
            if(InquireCSQ())//�ź�ǿ��
                if(Wait_CREG())
                    if(Wait_CGREG())
                        Flag_Init_Step=4;
            delay_ms(1000);
        break;
        case 4:
            if(SLM750V_Query_NetTyp())
                Flag_Init_Step=5;
            delay_ms(1000);
        break;
        case 5:
            
                Flag_Init_Step=6;
           // delay_ms(1000);
        break;
        case 6:
            if(SLM750V_Query_APNstate())
                Flag_Init_Step=7;
            delay_ms(1000);
        break;
        case 7:
            if(SLM750V_Query_Link())
            {
                Flag_init = WIRELESS_INIT_OK;
                Flag_Init_Step=8;
            }
            delay_ms(1000);
        break;
        default:
            
        break;
    
    }
    #endif
//    while(Set_Baund()==0);
//    while(Check_PIN()==0);
//    Read_Card_IMSI();
//    Read_Card_CCID();
//    Wait_CREG();
//    Wait_CGREG();
//    AT_CGATT_Ctrl();
//    Set_Connext();
//    GPRS_QIMUX();
}
uint8_t Set_Baund(void)
{
	 char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+IPR=115200&W\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"OK")!=NULL)
        {
            printf("set baund ok\r\n");
            return 1;
        }
        if(mytime >5)
        {
            printf("set baund time out\r\n");
            return 0;
        }
    }
}
uint8_t Set_ATE(uint8_t x)
{
	 char *pstr;
    char cmd[5]="";
	 ClearUSART3BUF(); 
	 mytime = 0;	
        
    sprintf(cmd,"ATE%d\r\n",x);
    UART3_SendString(cmd);
    while(1)
    {
        
        delay_ms(500);
        if(strstr(ucUar3tbuf,"OK")!=NULL)
        {
            printf("%s OK\r\n",cmd);
            return 1;
        }
        if(mytime >5)
        {
            printf("set %s time out\r\n",cmd);
            return 0;
        }
    }
}
uint8_t Check_PIN(void)
{
	 char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+CPIN?\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"READY")!=NULL)
        {
            printf("SIM Card is already\r\n");
            return 1;
        }
        if(mytime >5)
        {
            printf("Read PIN time out:%s\r\n",ucUar3tbuf);
            return 0;
        }
    }
}
uint8_t Wait_CREG(void)
{
	 char *pstr;
    
    u8 cfg;
    u8 state;
    u8 lac[10]={0};
    u8 ci[10]={0};
    uint32_t t_lac,t_cid;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+CREG?\r\n");
        delay_ms(1000);
        if((strstr(ucUar3tbuf,"+CREG:")!= NULL))  //��ȡλ����Ϣ
        {
            printf("%s\r\n",ucUar3tbuf);
            sscanf(ucUar3tbuf,"%*[^:]: %d,%d,\"%[^\"]\",\"%[^\"]\"",&cfg,&state,lac,ci);						
			sscanf(lac,"%x",&t_lac);
            sscanf(ci,"%x",&t_cid);
            Position_LAC=t_lac;
            Position_CID=t_cid;
            printf("lac: %x,cid: %x",t_lac,t_cid);
            if(state==1)
            {
                printf("����ע��ɹ� \r\n");
				
                return 1;
            }
            else
            {
                printf("����δע�� \r\n");
                ClearUSART3BUF();
                UART3_SendString("AT+CREG?\r\n");
            }
        }
        if(mytime >5)
        {
            printf("����ע�ᳬʱ \r\n");
            return 0;
        }
    }
}
uint8_t AT_CGATT_Ctrl(void)
{
	 char *pstr;
     u8 state;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+CGATT?\r\n");
        delay_ms(500);
        if((strstr(ucUar3tbuf,"+CGATT:")!= NULL))  //��ȡλ����Ϣ
        {
             printf("%s\r\n",ucUar3tbuf);
            sscanf(ucUar3tbuf,"%*[^:]: %d",&state);
            if(state==1)
            printf("MT ���� GPRS ҵ��");
            return 1;
        }
        if(mytime >5)
        {
            printf("GPRS����ʧ��");
            return 0;
        }
    }
}
uint8_t Set_Connext(void)
{
	 char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+QIFGCNT=0\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"OK")!=NULL)
        {
            return 1;
        }
        if(mytime >5)
        {
            return 0;
        }
    }
}
uint8_t InquireCSQ(void)
{
	 char *pstr;
	u8 stringbuf1[20]={0}; 
    u8   Command_SendCount=0;
    ClearUSART3BUF(); 
  
	 mytime = 0;  
    while(1)
    {
        UART3_SendString("AT+CSQ\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"+CSQ")!= NULL) 
		{
			sscanf(ucUar3tbuf,"%*[^:]: %d,%s",&CSQNual,stringbuf1);
			
			printf("\r\nCSQ = %d\r\n",CSQNual);
			
			ClearUSART3BUF();
			if((CSQNual>0)&&(CSQNual<33))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+CSQ\r\n");
            mytime = 0;
			Command_SendCount++;
			delay_ms(50);
		}
        if((mytime >5)||(Command_SendCount>5))
        {
            return 0;
        }
    }
}
uint8_t InquireTCPstat(void)
{
	 char *pstr;
	u8 state[20]={0}; 
    u8 index =0;
    u8 mode[20]={0};
    u8 addr[20]={0}; 
    u8 port[20]={0};     
    u8   Command_SendCount=0;
    ClearUSART3BUF(); 
  
	 mytime = 0;  
    while(1)
    {
        UART3_SendString("AT+QISTAT\r\n");
        delay_ms(500);
        pstr=strstr(ucUar3tbuf,"CONNECT OK");
        if(pstr!= NULL) 
		{
//            printf("u3: %s\r\n",ucUar3tbuf);
//			sscanf(ucUar3tbuf,"%*[^:]: %s",state);
			
			printf("\r\nSTATE = %s\r\n",pstr);
			
			ClearUSART3BUF();
			mytime = 0;
				return 1;
			
			
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+QISTAT\r\n");
            mytime = 0;
			Command_SendCount++;
			delay_ms(50);
		}
        if((mytime >5)||(Command_SendCount>3))
        {
            return 0;
        }
    }
}
uint8_t Wait_CGREG(void)
{
	 char *pstr;
    
    u8 cfg;
    u8 state;
    u8 lac[10]={0};
    u8 ci[10]={0};
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+CGREG?\r\n");
        delay_ms(500);
        if((strstr(ucUar3tbuf,"+CGREG:")!= NULL))  //��ȡλ����Ϣ
        {
            printf("%s\r\n",ucUar3tbuf);
            sscanf(ucUar3tbuf,"%*[^:]: %d,%d,\"%[^\"]\",\"%[^\"]\"",&cfg,&state,lac,ci);						
			
            if(state==1)
            {
                printf("GPRS����ע��ɹ� \r\n");
				
                return 1;
            }
            else
            {
                printf("GPRS����δע�� \r\n");
                ClearUSART3BUF();
                UART3_SendString("AT+CGREG?\r\n");
            }
        }
        if(mytime >5)
        {
            printf("GPRS����ע�ᳬʱ \r\n");
            return 0;
        }
    }
}
int8_t  Read_Card_IMSI(void)
{
	 char *pstr;
	 uint8_t d[20];
	 uint8_t i =0;
	 delay_ms(100);
	 ClearUSART3BUF();
	 UART3_SendString("AT+CIMI\r\n");
	 mytime = 0;
	 delay_ms(100);
	 while(1)
	 {
         delay_ms(50);
        if(strstr(ucUar3tbuf,"+CSQ")!=NULL)  //��һ�����з���CSQû������
        {
            ClearUSART3BUF();
            UART3_SendString("AT+CIMI\r\n");
            mytime = 0;
            delay_ms(100);
		}				
//		if((strstr(ucUar3tbuf,"OK")!=NULL)&&(strstr(ucUar3tbuf,"460")!=NULL))  //ģ�鷵��IMSI��
//		{
//            if(Flag_COMDebug == 1)
//            printf("%s",ucUar3tbuf);
//            pstr = strstr(ucUar3tbuf,"460");
//            CARD_ID[0] = 0x39;
//            ICCID_LEN = 1;			 
//            while(*pstr != 0x0D)
//            {
//                CARD_ID[ICCID_LEN++] = *pstr++;
//            }					 
//            CARD_ID[ICCID_LEN] = '\0';
//            if(Flag_COMDebug == 1)
//            printf("SIM CARD IMSI is:%s len is:%d\r\n",CARD_ID,ICCID_LEN);
//            ClearUSART3BUF();
//            return 1;
//		}
//        if(strstr(ucUar3tbuf,"NO SIM CARD")!=NULL)  //δ����SIM��
//        {
//             if(Flag_COMDebug == 1)
//             {
//                 printf("%s",ucUar3tbuf);
//                 printf("No SIM Card! Please Check!\r\n");
//             }
//             return -1;
//        }
		if(strstr(ucUar3tbuf,"OK")!= NULL)
		{
			pstr = strstr(ucUar3tbuf,"460");
			//CARD_ID[0] = 0x39;
            ICCID_LEN = 0;
			while(*pstr != 0x0D)
			{
				SIMCard_IMSI[SIMCard_IMSI_Len++] = *pstr++;
			}
			SIMCard_IMSI[SIMCard_IMSI_Len]= '\0';					
									
				printf("IMSI:%s\r\n",SIMCard_IMSI);
			
			 ClearUSART3BUF(); 
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CIMI\r\n");
			//Command_SendCount++;
			 ClearUSART3BUF(); 
			delay_ms(50);
		}
        if(mytime >5)  //5sδ��Ӧ����ʱ
        {
            if(Flag_COMDebug == 1)
            {
                printf("%s",ucUar3tbuf);
                printf("Read IMSI time out:%s\r\n",ucUar3tbuf);
            }
            ClearUSART3BUF();
            return 0;
        }
	 }
	
}
/****************************************************************************
*	�� �� ��: Read_Card_CID
*	����˵��: ��ȡ�����
*	��    �Σ�id���ű����λ��,len���ų���
*	�� �� ֵ: ����1��ʶ��ȷ��ȡ������-1��ʾû�в��뿨������0��ʾ��ȡʧ��
* ˵    ����
*****************************************************************************/
int8_t  Read_Card_CCID(void)
{
    
	 char *pstr;
	 uint8_t d[20];
	 uint8_t i =0;
    char stringbuf1[30]={0};
    u8 Command_SendCount=0;
	 delay_ms(100);
	 ClearUSART3BUF();
	 UART3_SendString("AT+ICCID\r\n");
    
	  mytime = 0;
	 delay_ms(300);
	 while(1)
	 {
         delay_ms(50);
        if(strstr(ucUar3tbuf,"+CSQ")!=NULL)  //��һ�����з���CSQû������
		{
            ClearUSART3BUF();
            UART3_SendString("AT+ICCID\r\n");
            mytime = 0;
            delay_ms(300);
		}				
//		  if(strstr(ucUar3tbuf,"OK")!=NULL)  //ģ�鷵��CCID��
//			{
//				 if(Flag_COMDebug == 1)
//						printf("%s",ucUar3tbuf);				 
////				 ICCID_LEN = strcspn(ucUar3tbuf,"OK")-15;
//				 ICCID_LEN = 20;
//                 memcpy(CARD_ID,ucUar3tbuf+11,ICCID_LEN);
//				 CARD_ID[ICCID_LEN] = '\0';
//				 if(Flag_COMDebug == 1)
//						printf("SIM CARD CCID is:%s len is:%d\r\n",CARD_ID,ICCID_LEN);
//				 ClearUSART3BUF();
//				 return 1;
//			}
        if(strstr(ucUar3tbuf,"ICCID:")!= NULL)
		{
//			pstr = strstr(LTEUART_RX_BUFFER,"8986");
			sscanf(ucUar3tbuf,"%*[^:]: %s\r\n%s",&SIMCard_ICCID,stringbuf1);
			SIMCard_ICCID_Len = strlen(SIMCard_ICCID);
			SIMCard_ICCID[SIMCard_ICCID_Len]= '\0';					
									
				printf("ICCID:%s\r\n",SIMCard_ICCID);
			
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+QCCID\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}
			if(mytime >5)  //5sδ��Ӧ����ʱ
			{
				//if(Flag_COMDebug == 1)
						printf("Read CCID time out:%s\r\n",ucUar3tbuf);
				ClearUSART3BUF();
				return 0;
			}
	 }
	
}
int8_t  Read_Card_IMEI(void)
{
    
	 char *pstr;
	 uint8_t d[20];
	 uint8_t i =0;
    char stringbuf2[30]={0};
    char stringbuf1[30]={0};
    u8 Command_SendCount=0;
	 delay_ms(100);
	 ClearUSART3BUF();
	 UART3_SendString("AT+CGSN\r\n");
    
	  mytime = 0;
	 delay_ms(300);
	 while(1)
	 {
         delay_ms(50);

        if(strstr(ucUar3tbuf,"OK")!= NULL)
		{
//			pstr = strstr(LTEUART_RX_BUFFER,"8986");
            printf("%s\r\n",ucUar3tbuf);
			sscanf(ucUar3tbuf,"%s\r\n%s\r\n%s",&stringbuf2,&SIMCard_IMEI,stringbuf1);
			SIMCard_IMEI_Len = strlen(SIMCard_IMEI);
			SIMCard_IMEI[SIMCard_IMEI_Len]= '\0';					
									
				printf("IMEI:%s\r\n",SIMCard_IMEI);
			
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CGSN\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}
			if(mytime >5)  //5sδ��Ӧ����ʱ
			{
				//if(Flag_COMDebug == 1)
						printf("Read IMEI time out:%s\r\n",ucUar3tbuf);
				ClearUSART3BUF();
				return 0;
			}
	 }
	
}
void GPRSSendData(unsigned char *p,unsigned int Len)
{
	ClearUSART3BUF();
//	printf("SendData len:%d :%s\r\n",Len,p);
	UART3_SendString_YB(p,Len);
	UART3_SendLR();

}
u8 GPRS_Send_Data(char *data,uint16_t len)
{
    #if 1
    char *pstr;
    char cmd[20]="0";
    u8 waittime = 0;
    ClearUSART3BUF(); 
    
    //sprintf(cmd,"AT+QISEND=%d\r\n",len);
    sprintf(cmd,"AT+MIPTPS=3,1,3,%d\r\n",len);//����͸��ģʽ
    while(1)
    {
        UART3_SendString(cmd);//����ָ��
        delay_ms(50);//��ʱ50����ȴ�����
        if(strstr(ucUar3tbuf,">")!=NULL)//�б���յ��ַ�����û����Ӧ�ַ�
        {
            mytime = 0;
            ClearUSART3BUF();
            UART3_SendData(data,len);
            while(1)
            {
                if(strstr(ucUar3tbuf,"+MIPOK")!=NULL)
                {
                    ClearUSART3BUF();
                    printf("���ͳɹ�\r\n");
                    return 1;
                }
                if(mytime >3)
                {
                    printf("����ʧ��\r\n");
                    return 0;
                }
            }
        }
        waittime++;
        if(waittime >60)
        {
            printf("����ʧ��\r\n");
            return 0;
        }
    }
    #else
    SLM750V_Send_Data(data,len);
    #endif
}
void GetGPRSPosition(void)
{
	  uint8_t i;
	  char *ppos = NULL;
    unsigned char lacstring[5]={0};
		unsigned char cidstring[5]={0};
	  unsigned char posstring[15]={0};
    int len = 0;
		
	  ClearUSART3BUF();
	  UART3_SendString("AT+CREG\r\n");
		mytime = 0;
	  delay_ms_YB();
//	  printf("%s",ucUar3tbuf);
		while(1)
		{			
			ppos = strstr(ucUar3tbuf,"+CREG");
			if( ppos != NULL )
			{
				 memcpy(posstring,ppos+11,11);
				 if(Flag_COMDebug == 1)
						printf("grpsλ��Ϊ��%s ",posstring);
				 ppos = strstr(posstring,",");
				 memcpy(cidstring,ppos+1,5);
				 len = strlen(posstring)-strlen(cidstring);
				 memcpy(lacstring,posstring,len-1);				 
//				 printf("LAC string:%s  CID string:%s  \r\n",lacstring,cidstring);
				 Position_LAC = atoi(lacstring);			
				 Position_CID = atoi(cidstring);
         if(Flag_COMDebug == 1)				 
						printf("LAC 16data:0x%x  CID 16data:0x%x  \r\n",Position_LAC,Position_CID);
				 ClearUSART3BUF();
				 break;
			}
			if(mytime > 2)
			{
				 if(Flag_COMDebug == 1)
						printf("Get GPRS position error!\r\n");
				 ClearUSART3BUF();
				break;
			}
	 }

}
char MyCountChar(unsigned char *p,int pLen)
{
	int i=0;
	char icount=0;
	for(i=0;i<pLen;i++){
		if(p[i]=='.'){
			icount++;
		}
	}
	return icount;
}
u8 GPRS_QIMUX(void)
{

    char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+QIMUX=0\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"OK")!=NULL)
        {
            return 1;
        }
        if(mytime >5)
        {
            return 0;
        }
    }
}
/****************************************************************************
*	�� �� ��: Set_IPLink_Mode
*	����˵��: ������������ģʽ
*	��    �Σ�0ΪIP���ӣ�1Ϊ��������
*	�� �� ֵ: 0Ϊ����ʧ�ܣ�1Ϊ���óɹ�
* ˵    ����
*****************************************************************************/
uint8_t Set_IPLink_Mode(uint8_t mode)
{
	  char *pstr;
	  uint8_t count=0;
	 	ClearUSART3BUF(); 
	  mytime = 0;	 
	 while(1)
	 {
		   if(mode == 0)
			 {
					UART3_SendString("AT+QIDNSIP=0\r\n");
			 }
			 else
			 {
					UART3_SendString("AT+QIDNSIP=1\r\n");
			 }
			 count++;
			 delay_ms(300);
			 if(strstr(ucUar3tbuf,"OK")!=NULL)
			 {
				  return 1;
			 }
			 if(count >5)
			 {
				 return 0;
			 }
	 }
}
u8 GPRS_Query_TCPstate(void)
{
    char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+QISTAT\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"TCP CONNECTING")!=NULL)
        {
            return 1;
        }
        if(strstr(ucUar3tbuf,"CONNECT OK")!=NULL)
        {
            return 0;
        }
        if(strstr(ucUar3tbuf,"IP INITIAL")!=NULL)
        {
            return 0;
        }
        if(strstr(ucUar3tbuf,"IP START")!=NULL)
        {
            return 0;
        }
        if(strstr(ucUar3tbuf,"IP CONFIG")!=NULL)
        {
            return 0;
        }
        if(mytime >5)
        {
            return 0;
        }
    }
}
u8 GPRS_CloseSocket(void)
{
    #if 0
	 char *pstr;
	 ClearUSART3BUF(); 
	 mytime = 0;	 
    while(1)
    {
        UART3_SendString("AT+QICLOSE\r\n");
        delay_ms(500);
        if(strstr(ucUar3tbuf,"CLOSE OK")!=NULL)
        {
            printf("�ر����ӳɹ�\r\n");
            return 1;
        }
        if(mytime >5)
        {
            printf("�ر�����ʧ��\r\n");
            return 0;
        }
    }
    #else
    SLM750V_Close_Socket();
    #endif
}
u8 GPRS_ConnectIP(char *ip,char *port)
{
    char stringbuf1[20]={0};
	char cmd[100]= "";
	u8 Socket;
	ClearUSART3BUF();;
	sprintf(cmd,"AT+QIOPEN=\"TCP\",\"%s\",%s\r\n",ip,port);  //
    UART3_SendString(cmd);
    mytime = 0;
    while(1)
    {
        delay_ms(50);
        if(strstr(ucUar3tbuf,"CONNECT")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{
				printf("Set IP successed\r\n");
			}
			ClearUSART3BUF();
			return 1;
		}
//		if(strstr(ucUar3tbuf,"OK")!= NULL) 
//		{
//			sscanf(ucUar3tbuf,"%*[^:]: %d,%s",&Socket,stringbuf1);
//			if(Flag_COMDebug == 1)
//			{
//				printf("Set IP successed,Socket=%d\r\n",Socket);
//			}

//			ClearUSART3BUF();
//			return 1;
//		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set IP error:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
        if(mytime >5)
        {
            return 0;
        }
    
    }
    
}
void GetBackServerIP(void)
{
	 uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
	 uint8_t data_len=0;
	 SendData[data_len++] = CMD_START;
	 SendData[data_len++] = TypeID;
	 SendData[data_len++] = (12+2)|0x80;
	 SendData[data_len++] = REQ_SECOND_SERVER;
	 for(i=0;i<12 ;i++)
	 {
			SendData[data_len++]=MAC_IDstring[i];
	 }
	 for(i = 0;i< 12;i++)
	 {
			jiaoyan += MAC_IDstring[i];
	 }
	 jiaoyan +=REQ_SECOND_TOKEN;
	 SendData[data_len++] = jiaoyan|0x80 ;
	 SendData[data_len++] = CMD_LF1;
	 SendData[data_len++] = CMD_LF2;
     ClearUSART3BUF();
	 GPRS_Send_Data(SendData,data_len);
    							//�������
    mytime = 0;										//��ʼ��ʱ��ʱ
    memset(SendDataBuff, 0x00, sizeof(SendDataBuff));
    memset(IP2, 0x00, sizeof(IP2));
    memset(chanl2, 0x0, sizeof(chanl2));
     if(Flag_COMDebug == 1)
     {
         printf("Get IP2 from front server:");
         for(i=0;i<data_len;i++)
         {
             printf("%02x ",SendData[i]);
         }
         printf("\r\n");
     }
     SendDataStatus = OK;
}
void AnalysisBackServerIP(void)
{
	 char *pstr,*pstr1;
	 uint8_t len;
	 uint8_t i=0;
	 uint8_t ip[6];
	 char buf[100];
	 char err;
	 
//	 if(strstr(ucUar3tbuf,"+QIURC: \"recv\"") != NULL)   //�յ�����������
//	 {
//	    delay_ms(100);	
		  pstr = strstr(ucUar3tbuf, "$");
		  pstr1 = strstr(ucUar3tbuf, "iB");
		  
		  if((pstr!=NULL)&&(pstr1!=NULL))
			{
				 if((pstr[1] == TypeID)&&(pstr[3] == REQ_SECOND_SERVER))
				{   
					memset(IP2,0X00,20);
					memset(chanl2,0X00,5);
					 for(i=0;i<6;i++)
					{
						 if(((pstr[4]<<(7-i))&0x80)==0x80)
						    ip[i]= pstr[5+i];
						 else
							  ip[i]= pstr[5+i]&0x7F;
					 }	
					 sprintf(IP2, "%d.%d.%d.%d", ip[0],ip[1],ip[2],ip[3]);
					 sprintf(chanl2, "%d", ip[4]*100+ip[5]);
					 //SaveIP2ToFlash();
					 if(Flag_COMDebug == 1)
						{						
							printf("IP2:%s\r\n", IP2);
							printf("Port2:%s\r\n", chanl2);
						}
					 AngelPace = GETBACKSERVERIPOK;
                    SendDataStatus = NO;
				}
				if((pstr[1]== TypeID)&&(pstr[3] ==SERVER_ABNORMAL_MESSAGE)) 
				 {
					 if(pstr[4] == SERVER_CHECK_MAC_ERR)  //MAC��֤����
					 {
							 if(Flag_COMDebug == 1)
							 {
									printf("Server Return MAC Verify Error!\r\n");
							 }
							 AngelPace = CONECTIP1;					//��������ǰ�÷�����
                            SendDataStatus = NO;
					 }	
				   		 
				 } 	 			 
			}		
	 //}
 if(mytime > GetDataTimerOut)
        {
					  if(Flag_COMDebug == 1)
							printf("Timer out!%s\r\n", ucUar3tbuf);
            AngelPace = CONECTIP1;					//��������ǰ�÷�����
            SendDataStatus = NO;
        }

}
void Connect_BackServer(void)
{
    char cmd[100]={0};
    //if((GPRS_or_WIFI == GPRS) && (AngelPace == CONECTIP1))
    {
        GPRS_CloseSocket();
        //if(SendDataStatus != OK) 			//��������
        {
            ClearUSART3BUF();
//            UART3_SendString_YB(IPstring, strlen(IPstring));
//            UART3_SendLR();
            //sprintf(cmd,"AT+QIOPEN=\"TCP\",\"%s\",\"%s\"\r\n",IP2,chanl2);  //
             sprintf(cmd,"AT+MIPOPEN=1,0,\"%s\",%s,0\r\n",IP2,chanl2);
            UART3_SendString(cmd);
					  //if(Flag_COMDebug == 1)
							printf("%s", cmd);
            SendDataStatus = OK;
            mytime = 0;
            while(1)
            {
                if(mytime>5)return;
                if((strstr(ucUar3tbuf, "+MIPOPEN:1,1") != NULL))					//�Ƿ񷵻�ָ���ַ���
                {
                              if(Flag_COMDebug == 1)
                                {
                                    printf("%s\r\n", ucUar3tbuf);
                                    printf("CMD Success!\r\n");
                                }
                    //AngelPace = CONECTIP1OK;							//���ӷ������ɹ�
                       AngelPace = CONECTIP2OK;
                    SendDataStatus = NO;
                                return;
                }
                if(strstr(ucUar3tbuf, "ERROR") != NULL || strstr(ucUar3tbuf, "error") != NULL) 		//����error�Ļ������������ط����ݣ�ȥ�����ݴ��䲻�ȶ���Ӱ��
                {
                              if(Flag_COMDebug == 1)
                                    printf("%s\r\n", ucUar3tbuf);
                    SendDataStatus = NO;
                              return;
                }
                if(strstr(ucUar3tbuf, "CONNECT FAIL") != NULL)
                {
                    AngelPace = CONECTIP1;
                              if(Flag_COMDebug == 1)
                                    printf("%s\r\n", ucUar3tbuf);
                    SendDataStatus = NO;
                              return;
                }
                if(mytime > ConnetServerTimeOut) 						//��ʱ
                {
                              if(Flag_COMDebug == 1)
                                    printf("Timer Out:%s\r\n", ucUar3tbuf);
                    SendDataStatus = NO;
                              return;
                }
 
            }
        }
    }
}
 void Analysis_BackServer(void)
 {
     if(GPRS_or_WIFI == GPRS)
    {
        if((strstr(ucUar3tbuf, "CONNECT") != NULL))					//�Ƿ񷵻�ָ���ַ���
        {
					  if(Flag_COMDebug == 1)
						{
							printf("%s\r\n", ucUar3tbuf);
							printf("CMD Success!\r\n");
						}
            //AngelPace = CONECTIP1OK;							//���ӷ������ɹ�
               AngelPace = CONECTIP2OK;
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "ERROR") != NULL || strstr(ucUar3tbuf, "error") != NULL) 		//����error�Ļ������������ط����ݣ�ȥ�����ݴ��䲻�ȶ���Ӱ��
        {
					  if(Flag_COMDebug == 1)
							printf("%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "CONNECT FAIL") != NULL)
        {
            AngelPace = CONECTIP1;
					  if(Flag_COMDebug == 1)
							printf("%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        if(mytime > ConnetServerTimeOut) 						//��ʱ
        {
					  if(Flag_COMDebug == 1)
							printf("Timer Out:%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        if(strstr(ucUar3tbuf, "SHUT OK") != NULL)
        {
            delay_ms_YB();
					  if(Flag_COMDebug == 1)
							printf("%s\r\n", ucUar3tbuf);
            SendDataStatus = NO;
        }
        CheckSystemErrorContrl();								//ģ������쳣���
    }
 }     
/****************************************************************************
*	�� �� ��: GetBackServerToken2
*	����˵��: ��ȡ���÷�����token
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void GetBackServerToken2(void)
{
   	 uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
     uint8_t    DATA[200]="";
     
	 uint16_t data_len=0;
	 SendData[data_len++] = CMD_START;
	 SendData[data_len++] = TypeID;
	 SendData[data_len++] = (12+2)|0X80;
	 SendData[data_len++] = REQ_SECOND_TOKEN;
	 for(i=0;i<12 ;i++)
	 {
			SendData[data_len++]=MAC_IDstring[i];
	 }
	 for(i = 0;i< 12;i++)
	 {
			jiaoyan += MAC_IDstring[i];
	 }
	 jiaoyan +=REQ_SECOND_TOKEN;
	 SendData[data_len++] = jiaoyan|0X80 ;
	 SendData[data_len++] = CMD_LF1;
	 SendData[data_len++] = CMD_LF2;
     ClearUSART3BUF();
     GPRS_Send_Data(SendData,data_len);
     							//�������
     mytime = 0;										//��ʼ��ʱ��ʱ
	  if(Flag_COMDebug == 1)
     {
         printf("Get TOKEN2 from front server:");
         for(i=0;i<data_len;i++)
         {
             printf("%02x ",SendData[i]);
         }
         printf("\r\n");
     }
     SendDataStatus = OK;
}	
/****************************************************************************
*	�� �� ��: AnalysisBackServerToken2
*	����˵��: �������÷�����token
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void AnalysisBackServerToken2(void)
{
	char *pstr,*pstr1;
	uint8_t len,i;
	char buf[100];
	char err;
    char retry=0;
//	if(strstr(LTEUART_RX_BUFFER,"+QIURC: \"recv\"") != NULL)   //�յ�����������
    //while(1)
	{
		delay_ms(100);	
        
		pstr = strstr(ucUar3tbuf, "$");
		if(pstr!=NULL)
		{			
//            while(*pstr !='\0')
//             {
//                 printf("%02x ",*pstr++);
//             }
            printf("rec token data :%s\r\n",ucUar3tbuf);
            i=0;
            while(pstr[i]!='B')
                printf("%02x",pstr[i++]);
            printf("%02x\r\n",'B');
            memset(Token2,0,sizeof(Token2));
			if((pstr[1] == TypeID)&&(pstr[3] == REQ_SECOND_TOKEN))
			{   												 	         
				TOKEN2_LEN = (pstr[2]&0x7F)-2;
						 for(i = 0;i< TOKEN2_LEN;i++)
								{
									Token2[i] = pstr[i+4];
								}
						 
				if(Flag_COMDebug == 1)
				{
					printf("Token2 is:%s\r\n",Token2);
				}
                ClearUSART3BUF();
				AngelPace = GETBACKSERVEROK;
                SendDataStatus = NO;
                //break;
			}
			if((pstr[1]== TypeID)&&(pstr[3] ==SERVER_ABNORMAL_MESSAGE)) 
			{
				if(pstr[4] == SERVER_CHECK_MAC_ERR)  //MAC��֤����
				{
					if(Flag_COMDebug == 1)
					{
						printf("Server Return MAC Verify Error!\r\n");
					}
                    ClearUSART3BUF();
					AngelPace = CONECTIP2OK;
                    mytime=0;
                    SendDataStatus = NO;
                   // break ;
				}	
							 
			} 	 			 
		}
        if(mytime > 5)
        {
           retry++;
            mytime=0;
            ClearUSART3BUF();
            GetBackServerToken2();
            if(retry>=3)
            {
					  if(Flag_COMDebug == 1)
							printf("Timer out!%s\r\n", ucUar3tbuf);
                    AngelPace = CONECTIP1;					//��������ǰ�÷�����
                    SendDataStatus = NO;
                      //break;
            }
        }		
	}

}
/****************************************************************************
*	�� �� ��: SendBackServerVerify
*	����˵��: ��ȡ���÷�����У��
*	��    �Σ���
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void SendBackServerVerify(void)
{
	 uint8_t  SendData[100] = {0};
	 uint8_t  jiaoyan=0;
	 uint8_t i=0;
	 uint8_t len=0;
	 char buf[100];
	 unsigned char ucMd5data[30] = {0};
     unsigned char ucMd5string[40] = {0};
     unsigned char ucMd5string1[40] = {0};
	 uint16_t data_len=0;	 
	 sprintf(ucMd5data,"%s123456%s",MAC_IDstring,Token2);
     MDString(ucMd5data,ucMd5string);
	 HexToLowerStr(ucMd5string1,ucMd5string,16);
	 if(Flag_COMDebug == 1)
		{			
			printf("ucMd5data:%s\r\n",ucMd5data);					
			printf("ucMd5string1:%s\r\n",ucMd5string1);		
		}
				
	 SendData[data_len++] = CMD_START;
	 SendData[data_len++] = TypeID;
	 len = strlen(ucMd5string1);
	 	
	 SendData[data_len++]= (len+MAC_LEN+2)|0x80;
	 SendData[data_len++]=REQ_SECOND_VERIFY;
	 for(i=0;i<len ;i++)
	 {
			SendData[data_len++]=ucMd5string1[i];
	 }
	 for(i=0;i<MAC_LEN ;i++)
	 {
			SendData[data_len++]=MAC_IDstring[i];
	 } 
	 for(i = 0;i< len;i++)
		{
			jiaoyan += ucMd5string1[i];
		}								 
	 for(i = 0;i< MAC_LEN;i++)
		{
			jiaoyan += MAC_IDstring[i];
		}
	 jiaoyan +=REQ_SECOND_VERIFY;
	 SendData[data_len++] = jiaoyan|0x80 ;
	 SendData[data_len++] = CMD_LF1;
	 SendData[data_len++] = CMD_LF2;
	 ClearUSART3BUF();
        printf("Verify MD5:\r\n");
        for(i=0;i<data_len;i++)
            printf("%02x ",SendData[i]);
         printf("\r\n");
     if(GPRS_Send_Data(SendData,data_len))
     {
       // printf("���ͳɹ�\r\n");
     };
     SendDataStatus = OK;							//�������
     mytime = 0;
	
	
}
void Send_AMPCHGData2Server(void)
{
    uint8_t dat[20];
	 uint8_t  i = 0;
	 dat[i++]=CMD_START;
    dat[i++]=TypeID;
    dat[i++]=0x8a;
    dat[i++]=AMP_CHG;
    
	 dat[i++]= (uint8_t)(ADC_AmpMultiple*10)|0x80;
    
	 dat[i++] = (SEND_ECG_MAX[0]/256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[0]%256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[1]/256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[1]%256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[2]/256)|0x80;
	 dat[i++] = (SEND_ECG_MAX[2]%256)|0x80;
	 dat[i++] = (GetDataHead(&dat[4],7))|0x80;  //����ͷ
     dat[i++]=0xFF;
     dat[i++]=0x69;
     dat[i++]=0x42;
	 
    
	 Flag_SleepData_SendOver = 1;
	 GPRS_Send_Data(dat,i);
     delay_ms(10);
	 Flag_SleepData_SendOver = 0;
	 if(Flag_COMDebug == 1)
		 printf("Send Amplification Data:%f To Server!\r\n",ADC_AmpMultiple);
}
void Net_Work_Link_Sever(uint8_t step)
{

}
char SLM750V_Query_MNOReg(void)
{
    char *pstr =NULL;
     char Command_SendCount=0;
	char mode,format,act;
    char oper[18]={0};//��ȡ����
    act =0;
	ClearUSART3BUF();
	UART3_SendString("AT+COPS?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+COPS:")!= NULL)
		{
            printf("%s\r\n",ucUar3tbuf);
			sscanf(ucUar3tbuf,"%*[^:]: %d,%d,\"%[^\"]\",%d",&mode,&format,oper,&act);
			printf("%d,%d,%s,%d\r\n",mode,format,oper,act);
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+COPS?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(100);
		}	
		if((mytime>3)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Operator read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Query_NetTyp(void)
{
    char *pstr =NULL;
     char Command_SendCount=0;
	char stringbuf1[30]={0};//��ȡ����
	ClearUSART3BUF();
	UART3_SendString("AT+PSRAT?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+PSRAT:")!= NULL)
		{
			sscanf(ucUar3tbuf,"%*[^:]:%s",stringbuf1);
			printf("NETTyp:%s\r\n",stringbuf1);
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+PSRAT?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}	
		if((mytime>3)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("NetTyp read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Query_APNstate(void)
{
    char *pstr =NULL;
	 char Command_SendCount=0;
    char cid;
    char pdp_typ[10]={0};
    char apn[10]={0};
    char pdp_addr[16]={0};
    char d_comp,h_comp,ipv4alloc,request_type;
   
	ClearUSART3BUF();
	UART3_SendString("AT+CGDCONT?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+CGDCONT")!= NULL)
		{
            printf("%s\r\n",ucUar3tbuf);
//			sscanf(ucUar3tbuf,"%*[^:]:%d,\"%[^\"]\",\"%[^\"]\",\"%[^\"]\",%d,%d,%d,%d",&cid,pdp_typ,apn,pdp_addr,&d_comp,&h_comp,&ipv4alloc,&request_type);
//			printf("%d,%s\r\n",cid,apn);
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CGDCONT?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}	
		if((mytime>3)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("CGDCONT read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Query_Link(void)
{
    char state=0;
     char Command_SendCount=0;
    uint8_t ip[4]={0};
    ClearUSART3BUF(); 
	UART3_SendString("AT+MIPCALL=1\r\n");
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+MIPCALL:")!= NULL) 
		{
            sscanf(ucUar3tbuf,"%*[^:]:%d,%d.%d.%d.%d",&state,&ip[0],&ip[1],&ip[2],&ip[3]);
			printf("%s",ucUar3tbuf);						
			printf("Query LTE Link state success:\r\n state:%d  ip: %d.%d.%d.%d\r\n",state,ip[0],ip[1],ip[2],ip[3]);
			
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+MIPCALL?\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>10)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Query Wireless Link state time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Close_Socket(void)
{
    char Command_SendCount=0;
    ClearUSART3BUF(); 
	UART3_SendString("AT+MIPCLOSE=1\r\n");
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
            if(strstr(ucUar3tbuf,"+MIPCLOSE:1")!= NULL)
            {
                if(Flag_COMDebug == 1)
                {						
                    printf("Close a Socket successed:%s\r\n",ucUar3tbuf);
                }
                ClearUSART3BUF();
                return 1;
            }
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+MIPCLOSE=1\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>10)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Close a Socket time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
}
char SLM750V_Open_Socket(char *ipaddr,char *ipport)
{
    char cmd[100]="";
    char Command_SendCount=0;
     ClearUSART3BUF(); 
    
   // UART3_SendString("AT+MIPOPEN=1,10002,\"112.74.59.250\",10002,0\r\n");
    //112.74.59.250\",10002
    
    
    sprintf(cmd,"AT+MIPOPEN=1,0,\"%s\",%s,0\r\n",ipaddr,ipport);
	UART3_SendString(cmd);
    printf("%s",cmd);
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+MIPOPEN:1,1")!= NULL) 
		{
            
			if(Flag_COMDebug == 1)
			{						
				printf("Open a Socket successed:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString(cmd);
			Command_SendCount++;
			delay_ms(100);
		}
		if((mytime>10)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Open a Socket time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}
    
} 
char SLM750V_Send_Data(uint8_t *data,uint16_t len )
{
//24 01 8e 03 39 31 43 32 36 42 33 30 36 31 44 45 ad 69 42
//24 11 8e 02 42 33 33 38 34 44 38 32 41 39 45 35 b9 69 42 
  //24 01 8e 03 39 31 43 32 36 42 33 30 36 31 44 45 ad 69 42
   // uint8_t data[19]={0x24 ,0x01 ,0x8e ,0x03 ,0x39 ,0x31 ,0x43 ,0x32 ,0x36 ,0x42 ,0x33 ,0x30 ,0x36 ,0x31 ,0x44 ,0x45 ,0xad ,0x69 ,0x42};
    char Command_SendCount=0; 
    char cmd[20]="";
    ClearUSART3BUF(); 
    
    sprintf(cmd,"AT+MIPTPS=3,1,3,%d\r\n",len);
	//UART3_SendString("AT+MIPSEND=1,\"24018e03393143323642333036314445ad6942\"\r\n");
    UART3_SendString(cmd);
	mytime = 0;
	delay_ms(100);
	while(1)
	{
		delay_ms(50);
        if(strstr(ucUar3tbuf,">")!= NULL)
        {	
            ClearUSART3BUF();  
            mytime=0;            
            UART3_SendData(data,len);
            //MYDMA_USART_Transmit(&UART3_Handler, buf, send_len);
            			
        }
		if(strstr(ucUar3tbuf,"+MIPOK")!= NULL) 
		{
            
			if(Flag_COMDebug == 1)
			{						
				//printf("Send data2mode successed\r\n",ucUar3tbuf);
			}
			//ClearUSART3BUF();
			return 1;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			//ClearUSART3BUF();
			//UART3_SendString("AT+MIPSEND=1,\"24018e03393143323642333036314445ad6942\"\r\n");
			Command_SendCount++;
			delay_ms(50);
            ClearUSART3BUF();
			return 0;
		}
		if((mytime>3))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Send data2mode time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
	}    
}
char SLM750V_Query_VER(void)
{
	ClearUSART3BUF(); 
	UART3_SendString("AT+SGSW\r\n");
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 1;
		}
        
		if(mytime>3)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Read versoin time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return 0;
		}
		
	}

}