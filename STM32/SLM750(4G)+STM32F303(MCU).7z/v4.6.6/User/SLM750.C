#include <stdlib.h>
#include "Fun.h"
#include "Parameter.h"
#include "string.h"
#include "Delay.h"
#include "slm750.h"
char CHINA_MOBILE[]="cmnet";
 char CHINA_UNICOM[]="3gnet";
 char CHINA_TELECOM[]="ctnet";
char *APN;
uint8_t Command_SendCount = 0;
//uint8_t Flag_Networkmode = NON_CDMAMODE;  //����ģʽ��NON_CDMAMODE or IN_CDMAMODE
//uint16_t  Position_LAC;        //GPRS LACλ������
//uint16_t  Position_CID;        //GPRS CIDλ������
uint16_t  Position_SID;        //GPRS SIDλ������
uint16_t  Position_NID;        //GPRS NIDλ������
uint16_t  Position_BID;        //GPRS BIDλ������

uint8_t Socket = 0;
unsigned char SIMCard_IMSI[20];
uint8_t SIMCard_IMSI_Len = 0;
unsigned char SIMCard_ICCID[25];
uint8_t SIMCard_ICCID_Len = 0;
unsigned char SIMCard_IMEI[25];
uint8_t SIMCard_IMEI_Len = 0;
uint8_t Flag_DataSendMode = 0;   //���ݴ���ģʽ
uint8_t Flag_LTEInitStep = 0;     //LTE��ʼ���Ĺ��̲���
uint16_t  LTE_InitTime=0;  //LTE��ʼ��ʱ��
uint16_t  LTE_Init_pauseTime =0 ; 

uint8_t CID=0;
void RecodeBackServerToken2(void);
char SLM750V_Close_Socket(void);
char SLM750V_HEX_Config1(void);
char SLM750V_HEX_Config(void);
char SLM750V_Query_MNOReg(void);
char SLM750V_Query_NetTyp(void);
char SLM750V_Query_APN(void);
char SLM750V_Query_IP(void);
char SLM750V_Query_Link(void);
char SLM750V_InquireIMEI(void);
char SLM750V_Query_VER(void);

/****************************************************************************
*	�� �� ��: LTE_UART_Send
*	����˵��: LTE 4G���ڷ���
*	��    �Σ�
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
void LTE_UART_Send(char *tx_buf,uint16_t buflen)
{
//	for (int i=0; i<buflen; i++)
//	{
//		 SendDataToUSART(LTE_UART,*tx_buf);
//         tx_buf++;
//        if(i%50==0)
//            delay_ms(1);
//	} 
    
	UART3_SendData(tx_buf,buflen);
}
/****************************************************************************
*	�� �� ��: UART3_SendString
*	����˵��: LTE 4G���ڷ����ַ���
*	��    �Σ�* s���͵��ַ���ָ��
*	�� �� ֵ: 
* 	˵    ����
*****************************************************************************/
char UART3_SendString(char *s)
{
    //printf(">>>>>>>>send toEC20:%s\r\n",s);
//	while(*s)
//	{
//		 SendDataToUSART(LTE_UART,*s++);
//	} 
    UART3_SendString(s);
//	return LTE_SUCCESS;	
}
/****************************************************************************
*	�� �� ��: LTE_GPIO_CONFIG
*	����˵��: LTE  4Gģ��IO����
*	��    �Σ�
*	�� �� ֵ:
* 	˵    ����
*****************************************************************************/
void SLM750V_GPIO_CONFIG(void)
{

	GPIO_InitTypeDef GPIO_InitStruct;
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);	
    GPIO_InitStruct.GPIO_Pin=LTE_PWRKEY_PIN|LTE_RESETN_PIN;
    GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;
    GPIO_Init(LTE_PWRKEY_GPIO_PORT, &GPIO_InitStruct);

	
	
	
	LTE_RESETN(0);
	LTE_PWRKEY(0);	
	
	
}
/****************************************************************************
*	�� �� ��: LTE_StartUP
*	����˵��: LTE����
*	��    �Σ�
*	�� �� ֵ:���س�ʼ����ɵĲ���
* 	˵    ����
*****************************************************************************/
char SLM750V_StartUP(void)
{
	
	if(Flag_COMDebug == 1)
	{						
		printf("Start up LTE \r\n");
	}
		
	delay_ms(100);
	LTE_PWRKEY(1);
	delay_ms(500);
	LTE_PWRKEY(0);
	mytime = 0;
	LTE_RESETN(1);
		delay_ms(450);
		LTE_RESETN(0);
        delay_ms(1000);

	
}
/****************************************************************************
*	�� �� ��: LTE_StartUP
*	����˵��: LTE����
*	��    �Σ�
*	�� �� ֵ:���س�ʼ����ɵĲ���
* 	˵    ����
*****************************************************************************/
char SLM750V_PowerDown(void)
{
	if(Flag_COMDebug == 1)
	{						
		printf("Power Down LTE \r\n");
	}
	if(SLM750V_SoftPowerOff()==LTE_FAIL)  //�ػ�
	{
		LTE_RESETN(1);
		delay_ms(450);
		LTE_RESETN(0);
        delay_ms(1000);
    }
//    delay_ms(100);
//	LTE_PWRKEY(1);
//	delay_ms(1000);
//	LTE_PWRKEY(0);
//	mytime = 0;
}
char SLM750V_SoftPowerOff(void)
{
	ClearUSART3BUF();
	UART3_SendString("AT+RESET\r\n");  //�����ػ���=1�����ػ�
	mytime = 0;
    delay_ms(1000);
	return LTE_FAIL;
//	while(1)
//	{
//		delay_ms(100);
//		if(strstr(ucUar3tbuf,"POWERED DOWN")!= NULL)
//		{
//			ClearUSART3BUF();
//			return LTE_SUCCESS;
//		}
//		if(mytime>LTE_3S_TIMEOUT)
//		{
//			ClearUSART3BUF();
//			return LTE_FAIL;
//		}
//	}
	
	
}    
/****************************************************************************
*	�� �� ��: LTE_INIT
*	����˵��: ����ģ���ʼ��
*	��    �Σ�
*	�� �� ֵ:���س�ʼ����ɵĲ���
* ˵    ����
*****************************************************************************/
#if 0
char SLM750V_INIT(void)
{
    char res1,res2;
    if(LTE_InitTime>=NETWORKLINK_TIMEOUT_60S)
	{
		SLM750V_PowerDown();
		SLM750V_StartUP();
		LTE_InitTime = 0;
		Flag_LTEInitStep= LTE_INIT_STEP1;
	}
    switch(Flag_LTEInitStep)
    {
        case LTE_INIT_STEP1:
            if(SLM750V_Query_PIN()==LTE_SUCCESS)
            {
                Flag_LTEInitStep = LTE_INIT_STEP2;
            }
            else
            {	
                if(LTE_InitTime>=NETWORKLINK_TIMEOUT_30S)
                {
                    LTE_InitTime = 0;
                    Flag_LTEInitStep= LTE_INIT_STEP1;
                    SLM750V_PowerDown();
                    SLM750V_StartUP();
                }
                delay_ms(3000);				
                
            }
        break;
            
        case LTE_INIT_STEP2:
            SLM750V_EchoEnable(0);  //�ر�ָ�����
            if(SLM750V_InquireIMEI()==LTE_SUCCESS)
            {
    //            SLM750V_InquireIMSI();
    //            SLM750V_InquireICCID();
                res1=strcmp(SIMCard_ICCID,ICCID_Save);
                res2=strcmp(SIMCard_IMEI,IMEI_Save);

                if(res1!=0||res2!=0)//�������룬�ȴ�10���Ӽ���
                {
                    Flag_CARD_ISCHANGE = CARD_HASCHANGE;
                    printf("ICCID NOT MATCH IMEI\r\n");
                    Flag_LTEInitStep = LTE_INIT_PAUSE;
                }
                else
                {
                    Flag_CARD_ISCHANGE = CARD_NOCHANGE;
                    Flag_LTEInitStep = LTE_INIT_STEP3;
                }
                Flag_CARD_ISCHANGE = CARD_NOCHANGE;
                Flag_LTEInitStep = LTE_INIT_STEP3;
            }
        break;
            
        case LTE_INIT_STEP3:
            if(SLM750V_Query_CSQ() == LTE_SUCCESS)
            {
                Flag_LTEInitStep = LTE_INIT_STEP4;
            }
            
        break;
            
        case LTE_INIT_STEP4:
            if(SLM750V_NetworkRegistration(2)==LTE_CONNECT)
            {
                Flag_LTEInitStep = LTE_INIT_STEP5;
            }
        break;
            
        case LTE_INIT_STEP5:
//            SLM750V_Query_APN();
            if(SLM750V_Query_MNOReg()==LTE_SUCCESS)
                if(SLM750V_Query_Link()==LTE_SUCCESS)
                    
                    Flag_LTEInitStep = LTE_INIT_STEP6;
            //SLM750V_HEX_Config();
//            SLM750V_Close_Link();
           
            delay_ms(3000);
            
        break;
        
        case LTE_INIT_PAUSE:
            if(LTE_Init_pauseTime>=60*10)
            {
                
                printf("LTE Init continue\r\n");
                Flag_LTEInitStep = LTE_INIT_STEP3;
                LTE_Init_pauseTime=0;
                LTE_InitTime=0;
            }
        break;
        
    }
    return Flag_LTEInitStep;
}
#else
char SLM750V_INIT(void)
{
    switch(Flag_LTEInitStep)
    {
        case 1:
            if(SLM750V_Query_PIN()==LTE_SUCCESS)
            {  SLM750V_Query_VER();
                Flag_LTEInitStep=2;
            }
            delay_ms(1000);
        break;
        case 2:
            if(SLM750V_Query_MNOReg()==LTE_SUCCESS)
                Flag_LTEInitStep=3;
            delay_ms(1000);
        break;
        case 3:
            if(SLM750V_NetworkRegistration(2)==LTE_SUCCESS)
                Flag_LTEInitStep=4;
            delay_ms(1000);
        break;
        case 4:
            if(SLM750V_Query_NetTyp()==LTE_SUCCESS)
                Flag_LTEInitStep=5;
            delay_ms(1000);
        break;
        case 5:
            if(SLM750V_Query_CSQ()==LTE_SUCCESS)
                Flag_LTEInitStep=6;
            delay_ms(1000);
        break;
        case 6:
            if(SLM750V_Query_APNstate()==LTE_SUCCESS)
                Flag_LTEInitStep=7;
            delay_ms(1000);
        break;
        case 7:
            if(SLM750V_Query_Link()==LTE_SUCCESS)
                Flag_LTEInitStep=8;
            delay_ms(1000);
        break;
        default:
            
        break;
    
    }
//    if(SLM750V_Query_PIN()==LTE_SUCCESS)//CPIN
//        if(SLM750V_Query_MNOReg()==LTE_SUCCESS)//CPOS
//            if(SLM750V_NetworkRegistration(2)==LTE_SUCCESS)//CGREG
//               if( SLM750V_Query_NetTyp()==LTE_SUCCESS)//PSART
//                   if( SLM750V_Query_CSQ()==LTE_SUCCESS)
//                        if(SLM750V_Query_APNstate()==LTE_SUCCESS)//CGDCONT
//                            if(SLM750V_Query_Link()==LTE_SUCCESS)
//                    
//                                Flag_LTEInitStep = LTE_INIT_STEP6;
}
#endif
/****************************************************************************
*	�� �� ��: LTE_EchoEnable
*	����˵��: ʹ�ܻ��߹ر�ʹ��ָ�����
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ��������1��ʾ��ȡ����ȷ��IMSI�ţ�����0��ʾ��ȡʧ��
*****************************************************************************/
char SLM750V_EchoEnable(uint8_t echo)
{
	char cmd[20]="";
	ClearUSART3BUF();
	sprintf(cmd,"ATE%d\r\n",echo);
	UART3_SendString(cmd);
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set echo:%d successed\r\n",echo);
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(mytime>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Set echo:%d time out:%s\r\n",echo,ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
		
	}
	
}
/****************************************************************************
*	�� �� ��: LTE_Query_PIN(void)
*	����˵��: LTE ��ѯPIN��
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����READY�� MT is not pending for any password 
*****************************************************************************/
char SLM750V_Query_PIN(void)
{
	ClearUSART3BUF(); 
	UART3_SendString("AT+CPIN?\r\n");
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"READY")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("PIN is ready\r\n");
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
        if(strstr(ucUar3tbuf,"ready")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("PIN is ready\r\n");
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(mytime>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Read PIN time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
		
	}

}
char SLM750V_Query_VER(void)
{
	ClearUSART3BUF(); 
	UART3_SendString("AT+SGSW\r\n");
	mytime = 0;
		
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
        if(strstr(ucUar3tbuf,"ready")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("PIN is ready\r\n");
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(mytime>LTE_3S_TIMEOUT)
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Read PIN time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
		
	}

}
char SLM750V_InquireIMEI(void)
{
	char *pstr =NULL;
	char stringbuf1[30]={0};
	ClearUSART3BUF();
	UART3_SendString("AT+CGSN\r\n");
	mytime = 0;
	Command_SendCount=0;
	
	
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL)
		{
//			pstr = strstr(ucUar3tbuf,"8986");
			sscanf(ucUar3tbuf,"%s\r\n%s",&SIMCard_IMEI,stringbuf1);
			SIMCard_IMEI_Len = strlen(SIMCard_IMEI);
			SIMCard_IMEI[SIMCard_IMEI_Len]= '\0';		
            
			if(Flag_COMDebug == 1)
			{						
				printf("IMEI:%s\r\n ",SIMCard_IMEI);
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CGSN=1\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}
		if((mytime>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("IMEI read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: LTE_InquireIMSI
*	����˵��: ��ѯsim����IMSI��
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ��������1��ʾ��ȡ����ȷ��IMSI�ţ�����0��ʾ��ȡʧ��
*****************************************************************************/
char SLM750V_InquireIMSI(void)
{
	char *pstr =NULL;
	
	ClearUSART3BUF();
	UART3_SendString("AT+CIMI\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL)
		{
			pstr = strstr(ucUar3tbuf,"460");
			SIMCard_IMSI_Len = 0;
			while(*pstr != 0x0D)
			{
				SIMCard_IMSI[SIMCard_IMSI_Len++] = *pstr++;
			}
			SIMCard_IMSI[SIMCard_IMSI_Len]= '\0';					
			if(Flag_COMDebug == 1)
			{						
				printf("IMSI:%s\r\n",SIMCard_IMSI);
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CIMI\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}	
		if((mytime>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("IMSI read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: LTE_InquireICCID
*	����˵��: ��ѯsim����ICCID�� ���ɵ�·��ʶ���룬�����
*	��    �Σ���
*	�� �� ֵ: ��
* 	˵    ��������1��ʾ��ȡ����ȷ��ICCID�ţ�����0��ʾ��ȡʧ��
*   ICCID��Integrate circuit card identity ���ɵ�·��ʶ���뼴SIM�����ţ��൱���ֻ����������֤�� 
*   ICCIDΪIC����Ψһʶ����룬����20λ������ɣ�������ʽΪ��XXXXXX 0MFSS YYGXX XXXX��
*   �ֱ�������£� 
*   ǰ��λ��Ӫ�̴��룺�й��ƶ���Ϊ��898600��898602 ��
*   �й���ͨ��Ϊ��898601��898609��
*   �й�����898603��898606��
*****************************************************************************/
char SLM750V_InquireICCID(void)
{
	char *pstr =NULL;
	char stringbuf1[30]={0};
	ClearUSART3BUF();
	UART3_SendString("AT+ICCID\r\n");
	mytime = 0;
	Command_SendCount=0;
	
	
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+ICCID")!= NULL)
		{
//			pstr = strstr(ucUar3tbuf,"8986");
			sscanf(ucUar3tbuf,"%*[^:]: %s\r\n%s",&SIMCard_ICCID,stringbuf1);
			SIMCard_ICCID_Len = strlen(SIMCard_ICCID);
			SIMCard_ICCID[SIMCard_ICCID_Len]= '\0';		
            if(SIMCard_ICCID[4]=='0')
            {
                if((SIMCard_ICCID[5]=='0')||(SIMCard_ICCID[5]=='2')||(SIMCard_ICCID[5]=='4')||(SIMCard_ICCID[5]=='7'))
                    APN=CHINA_MOBILE;
                else if((SIMCard_ICCID[5]=='1')||(SIMCard_ICCID[5]=='6')||(SIMCard_ICCID[5]=='9'))
                    APN=CHINA_UNICOM;
            }
            else
                APN=CHINA_TELECOM;
			if(Flag_COMDebug == 1)
			{						
				printf("ICCID:%s\r\n APN:%s\r\n",SIMCard_ICCID,APN);
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CCID\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}
		if((mytime>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("ICCID resd time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
/****************************************************************************
*	�� �� ��: LTE_Query_CSQ
*	����˵��: LTE ��ȡCSQ
*	��    �Σ�
*	�� �� ֵ: 
*	˵    ����
*****************************************************************************/
char SLM750V_Query_CSQ(void)
{
	char stringbuf1[20]={0};
	
	ClearUSART3BUF();
	UART3_SendString("AT+CSQ\r\n");
	mytime = 0;
	
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+CSQ")!= NULL) 
		{
			sscanf(ucUar3tbuf,"%*[^:]: %d,%s",&CSQNual,stringbuf1);
			if(Flag_COMDebug == 1)
			{
				printf("\r\nCSQ = %d\r\n",CSQNual);
			}
			ClearUSART3BUF();
			if((CSQNual>0)&&(CSQNual<33))
			{
				return LTE_SUCCESS;
			}
			else
			{
				return LTE_FAIL;
			}
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+CSQ\r\n");
            mytime = 0;
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>LTE_3S_TIMEOUT))
		{
            ClearUSART3BUF();
			UART3_SendString("AT+CSQ\r\n");
            mytime = 0;
			Command_SendCount++;
            if(Flag_COMDebug == 1)
			{						
				printf("\r\nRead CSQ time out:%d\r\n",Command_SendCount);
			}
			
		}
        if(Command_SendCount>10)
        {
            
			ClearUSART3BUF();
            if(Flag_COMDebug == 1)
			{						
				printf("\r\nRead CSQ haven't CMD ACK \r\n");
			}
			return LTE_FAIL;
        }
            
	}
}
char SLM750V_Query_MNOReg(void)
{
    char *pstr =NULL;
	char mode,format,act;
    char oper[18]={0};//��ȡ����
    act =0;
	ClearUSART3BUF();
	UART3_SendString("AT+COPS?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+COPS:")!= NULL)
		{
            printf("%s\r\n",ucUar3tbuf);
			sscanf(ucUar3tbuf,"%*[^:]: %d,%d,\"%[^\"]\",%d",&mode,&format,oper,&act);
			printf("%d,%d,%s,%d\r\n",mode,format,oper,act);
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+COPS?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(100);
		}	
		if((mytime>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Operator read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
char SLM750V_NetworkRegistration(uint8_t NR)
{
	char *pstr =NULL;
	char cmd[30]={0};
	uint8_t  n=0;   //��ȡ2
	uint8_t stat=0;//��ȡ1
	char stringbuf1[30]={0};//��ȡ����
	
	ClearUSART3BUF();
    sprintf(cmd,"AT+CGREG=%d\r\n",NR);
	UART3_SendString(cmd);
	mytime = 0;
	Command_SendCount=0;
	
	while(1)
	{
		delay_ms(50);
        if(strstr(ucUar3tbuf,"OK")!= NULL)
        {
            ClearUSART3BUF();
            UART3_SendString("AT+CGREG?\r\n");
            delay_ms(50);
            if(strstr(ucUar3tbuf,"+CGREG: ")!= NULL)
		{
			sscanf(ucUar3tbuf,"%*[^:]: %d,%d,%s",&n,&stat,stringbuf1);
			if(stat == 1)
			{
				if(Flag_COMDebug == 1)
				{						
					printf("4G Registered home network %s\r\n",ucUar3tbuf);
				}
				ClearUSART3BUF();
				return LTE_SUCCESS;
			}
			else
			{
				if(Flag_COMDebug == 1)
				{						
					printf("4G Not registered\r\n %s",ucUar3tbuf);
				}
				ClearUSART3BUF();
				return LTE_FAIL;
			}		
			
		}		
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString(cmd);
			Command_SendCount++;
			delay_ms(50);
		}
        }
		
		if((mytime>LTE_5S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Read registered status time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
		
	}
	
}
char SLM750V_Query_NetTyp(void)
{
    char *pstr =NULL;
	char stringbuf1[30]={0};//��ȡ����
	ClearUSART3BUF();
	UART3_SendString("AT+PSRAT?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+PSRAT:")!= NULL)
		{
			sscanf(ucUar3tbuf,"%*[^:]:%s",stringbuf1);
			printf("NETTyp:%s\r\n",stringbuf1);
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+PSRAT?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}	
		if((mytime>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("NetTyp read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
char SLM750V_Query_NetReg(void)
{
    char *pstr =NULL;
	char act,act1,act2;
    act =act1=act2=0;
	ClearUSART3BUF();
	UART3_SendString("AT+GTRAT?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+GTRAT")!= NULL)
		{
			sscanf(ucUar3tbuf,"%*[^:]: %d,%d,%d",&act,&act1,&act2);
			printf("%d,%d,%d\r\n",act,act1,act2);
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+GTRAT?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}	
		if((mytime>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("GTRAT read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
char SLM750V_Query_APNstate(void)
{
    char *pstr =NULL;
	
    char cid;
    char pdp_typ[10]={0};
    char apn[10]={0};
    char pdp_addr[16]={0};
    char d_comp,h_comp,ipv4alloc,request_type;
   
	ClearUSART3BUF();
	UART3_SendString("AT+CGDCONT?\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+CGDCONT")!= NULL)
		{
            printf("%s\r\n",ucUar3tbuf);
//			sscanf(ucUar3tbuf,"%*[^:]:%d,\"%[^\"]\",\"%[^\"]\",\"%[^\"]\",%d,%d,%d,%d",&cid,pdp_typ,apn,pdp_addr,&d_comp,&h_comp,&ipv4alloc,&request_type);
//			printf("%d,%s\r\n",cid,apn);
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+CGDCONT?\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}	
		if((mytime>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("CGDCONT read time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
char SLM750V_Set_APN(void)
{
	ClearUSART3BUF(); 
	UART3_SendString("AT+CGDCONT=1,\"\",\"CMNET\"\r\n");
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf(" Configure Parameters of a TCP/IP Context:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+CGDCONT=1,1,\"\",\"CMNET\"\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>LTE_1MIN_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf(" Configure Parameters of a TCP/IP Context time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}


}
char SLM750V_Activate_PDPContext(void)
{
    	ClearUSART3BUF(); 
	UART3_SendString("AT$QCPDPP=1,1,\"card\",\"card\"\r\n");
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Active PDP contest successed:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT$QCPDPP=1,1,\"card\",\"card\"\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>LTE_1MIN_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Active PDP contest time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
char SLM750V_Query_Link(void)
{
    char state=0;
    uint8_t ip[4]={0};
    ClearUSART3BUF(); 
	UART3_SendString("AT+MIPCALL=1\r\n");
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+MIPCALL:")!= NULL) 
		{
            sscanf(ucUar3tbuf,"%*[^:]:%d,%d.%d.%d.%d",&state,&ip[0],&ip[1],&ip[2],&ip[3]);
									
			printf("Query LTE Link state success:\r\n state:%d  ip: %d.%d.%d.%d\r\n",state,ip[0],ip[1],ip[2],ip[3]);
			
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+MIPCALL?\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>LTE_1MIN_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Query Wireless Link state time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
char LTE_Send_data(uint8_t sock_fd, uint16_t send_len, uint8_t *buf)
{
    if(SLM750V_Send_Data(buf,send_len)==LTE_FAIL)
    {
        //LTE_send_result=0;
        return LTE_FAIL ;
    }
    else
        return LTE_SUCCESS ;
    //SLM750V_Push_Data();
}
char SLM750V_Close_Socket(void)
{
    ClearUSART3BUF(); 
	UART3_SendString("AT+MIPCLOSE=1\r\n");
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
            if(strstr(ucUar3tbuf,"+MIPCLOSE:1")!= NULL)
            {
                if(Flag_COMDebug == 1)
                {						
                    printf("Close a Socket successed:%s\r\n",ucUar3tbuf);
                }
                ClearUSART3BUF();
                return LTE_SUCCESS;
            }
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+MIPCLOSE=1\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>LTE_10S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Close a Socket time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
char SLM750V_Open_Socket(char *ipaddr,char *ipport)
{
    char cmd[100]="";
     ClearUSART3BUF(); 
    Socket=1;
   // UART3_SendString("AT+MIPOPEN=1,10002,\"112.74.59.250\",10002,0\r\n");
    //112.74.59.250\",10002
    
    
    sprintf(cmd,"AT+MIPOPEN=1,0,\"%s\",%s,0\r\n",ipaddr,ipport);
	UART3_SendString(cmd);
    printf("%s",cmd);
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"+MIPOPEN:1,1")!= NULL) 
		{
            
			if(Flag_COMDebug == 1)
			{						
				printf("Open a Socket successed:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
//		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
//		{
//			ClearUSART3BUF();
//			UART3_SendString(cmd);
//			Command_SendCount++;
//			delay_ms(100);
//		}
		if((mytime>LTE_1MIN_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Open a Socket time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
    
} 
char SLM750V_HEX_Config(void)
{
    ClearUSART3BUF(); 
	UART3_SendString("AT+MIPHEX=1\r\n");
	mytime = 0;
	
	while(1)
	{
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL) 
		{
			if(Flag_COMDebug == 1)
			{						
				printf("HEX config The format of received data successed:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			ClearUSART3BUF();
			UART3_SendString("AT+MIPHEX=1\r\n");
			Command_SendCount++;
			delay_ms(50);
		}
		if((mytime>LTE_1MIN_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("HEX config The format of received data time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
char SLM750V_Send_Data(uint8_t *data,uint16_t len )
{
//24 01 8e 03 39 31 43 32 36 42 33 30 36 31 44 45 ad 69 42
//24 11 8e 02 42 33 33 38 34 44 38 32 41 39 45 35 b9 69 42 
  //24 01 8e 03 39 31 43 32 36 42 33 30 36 31 44 45 ad 69 42
   // uint8_t data[19]={0x24 ,0x01 ,0x8e ,0x03 ,0x39 ,0x31 ,0x43 ,0x32 ,0x36 ,0x42 ,0x33 ,0x30 ,0x36 ,0x31 ,0x44 ,0x45 ,0xad ,0x69 ,0x42};
     char cmd[20]="";
    ClearUSART3BUF(); 
    Socket=1;
    sprintf(cmd,"AT+MIPTPS=3,1,3,%d\r\n",len);
	//UART3_SendString("AT+MIPSEND=1,\"24018e03393143323642333036314445ad6942\"\r\n");
    UART3_SendString(cmd);
	mytime = 0;
	delay_ms(100);
	while(1)
	{
		delay_ms(50);
        if(strstr(ucUar3tbuf,">")!= NULL)
        {	
            ClearUSART3BUF();  
            mytime=0;            
            LTE_UART_Send(data,len);
            //MYDMA_USART_Transmit(&UART3_Handler, buf, send_len);
            			
        }
		if(strstr(ucUar3tbuf,"+MIPOK")!= NULL) 
		{
            
			if(Flag_COMDebug == 1)
			{						
				//printf("Send data2mode successed\r\n",ucUar3tbuf);
			}
			//ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR")!= NULL)
		{
			//ClearUSART3BUF();
			//UART3_SendString("AT+MIPSEND=1,\"24018e03393143323642333036314445ad6942\"\r\n");
			Command_SendCount++;
			delay_ms(50);
            ClearUSART3BUF();
			return LTE_FAIL;
		}
		if((mytime>LTE_3S_TIMEOUT))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("Send data2mode time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}    
}
char SLM750V_Push_Data(void)
{
    char *pstr =NULL;
	
    char cid;
    char pdp_typ[10]={0};
    char apn[10]={0};
    char pdp_addr[16]={0};
    char d_comp,h_comp,ipv4alloc,request_type;
   
	ClearUSART3BUF();
	UART3_SendString("AT++MIPPUSH=1\r\n");
	mytime = 0;
	Command_SendCount=0;
		
	while(1)
	{		
		delay_ms(50);
		if(strstr(ucUar3tbuf,"OK")!= NULL)
		{
            printf("%s\r\n",ucUar3tbuf);
//			sscanf(ucUar3tbuf,"%*[^:]:%d,\"%[^\"]\",\"%[^\"]\",\"%[^\"]\",%d,%d,%d,%d",&cid,pdp_typ,apn,pdp_addr,&d_comp,&h_comp,&ipv4alloc,&request_type);
//			printf("%d,%s\r\n",cid,apn);
			ClearUSART3BUF();
			return LTE_SUCCESS;
		}
		if(strstr(ucUar3tbuf,"ERROR") != NULL)
		{			 
			UART3_SendString("AT+MIPPUSH=1\r\n");
			Command_SendCount++;
			ClearUSART3BUF();
			delay_ms(50);
		}	
		if((mytime>LTE_3S_TIMEOUT)||(Command_SendCount>5))
		{
			if(Flag_COMDebug == 1)
			{						
				printf("SLM750V_Push_Data time out:%s\r\n",ucUar3tbuf);
			}
			ClearUSART3BUF();
			return LTE_FAIL;
		}
	}
}
//void ConnectServer1(void)
//{
//	 char res;  
//	 SLM750V_Close_Socket();
//	 res=SLM750V_Open_Socket(SERVER_IP1,SERVER_IP1_PORT);
//	  if(res == LTE_SUCCESS)
//		{
//                    
//			Flag_StepStatus = STEP_RECEIVE;
//			Link_Time = 0 ;
//		}
//		else
//		{
//			 delay_ms(3000);
//		}

//}
//void FrontServerStatus(void)
//{

//	delay_ms(500);

//			 if(Flag_COMDebug == 1)
//				{
//					printf("TCP1 has connected\r\n");
//				}
//			 ClearUSART3BUF();
//			 Flag_StepStatus = STEP_SEND;
//			 LinkStep = GETIP2;
//			 LinkIPCount = 0;
//			SentGetServerVerityCount = 0;
//		

//}
//void GetBackIP(void)
//{
//	 uint8_t  SendData[100] = {0};
//	 uint8_t  jiaoyan=0;
//	 uint8_t i=0;
//	 uint8_t len=0;
//	 SendData[len++] = CMD_START;
//	 SendData[len++] = TypeID;
//	 SendData[len++] = (MAC_Len+2)|0x80;
//	 SendData[len++] = REQ_SECOND_SERVER;
//	 for(i=0;i<MAC_Len ;i++)
//	 {
//			SendData[len++]=MAC_ID[i];
//	 }
//	 for(i = 0;i< MAC_Len;i++)
//	 {
//			jiaoyan += MAC_ID[i];
//	 }
//	 jiaoyan +=REQ_SECOND_TOKEN;
//	 SendData[len++] = jiaoyan|0x80 ;
//	 SendData[len++] = CMD_LF1;
//	 SendData[len++] = CMD_LF2;
//	 
//	 Link_Time = 0;
//	 Flag_StepStatus = STEP_RECEIVE;
//	 SentGetServerVerityCount++;
//	 if(Flag_COMDebug == 1)
//	 {
//		 printf("Get IP2 from front server:");
//		 for(i=0;i<len;i++)
//		 {
//			 printf("%02x ",SendData[i]);
//		 }
//		 printf("\r\n");
//	 }
//     
//     SLM750V_Send_Data(SendData,len);
////     SLM750V_Push_Data();
//}
//void AnalysisBackIP(void)
//{
//	 char *pstr,*pstr1;
//	 uint8_t len;
//	 uint8_t i=0;
//	 uint8_t ip[6];
//	 char buf[100];
//	 char err;
//	 //printf("step1:-------------%s\r\n",ucUar3tbuf);
//	 if(strstr(ucUar3tbuf,"+MIPRTCP") != NULL)   //�յ�����������
//	 {
//         printf("step2:-------------%s\r\n",ucUar3tbuf);
//	    delay_ms(100);	
//		  pstr = strstr(ucUar3tbuf, "$");
//		  pstr1 = strstr(ucUar3tbuf, "iB");
//		  
//		  if((pstr!=NULL)&&(pstr1!=NULL))
//			{
//				 if((pstr[1] == TypeID)&&(pstr[3] == REQ_SECOND_SERVER))
//				{   
//					memset(IP2,0X00,20);
//					memset(Port2,0X00,5);
//					 for(i=0;i<6;i++)
//					{
//						 if(((pstr[4]<<(7-i))&0x80)==0x80)
//						    ip[i]= pstr[5+i];
//						 else
//							  ip[i]= pstr[5+i]&0x7F;
//					 }	
//					 sprintf(IP2, "%d.%d.%d.%d", ip[0],ip[1],ip[2],ip[3]);
//					 sprintf(Port2, "%d", ip[4]*100+ip[5]);
//					 SaveIP2ToFlash();
//					 if(Flag_COMDebug == 1)
//						{						
//							printf("IP2:%s\r\n", IP2);
//							printf("Port2:%s\r\n", Port2);
//						}
//					Flag_StepStatus = STEP_SEND;
//					LinkStep = CONNECTIP2;
//					LinkIPCount = 0;
//					ClearUSART3BUF();
//				}
//				if((pstr[1]== TypeID)&&(pstr[3] ==SERVER_ABNORMAL_MESSAGE)) 
//				 {
//					 if(pstr[4] == SERVER_CHECK_MAC_ERR)  //MAC��֤����
//					 {
//							 if(Flag_COMDebug == 1)
//							 {
//									printf("Server Return MAC Verify Error!\r\n");
//							 }
//							 Flag_StepStatus = STEP_SEND;
//							LinkStep = GETIP2;
//					 }	
//				   ClearUSART3BUF();			 
//				 } 	 			 
//			}		
//	 }
//	 if(Link_Time>= NETWORKLINK_TIMEOUT_10S)
//    {
//         Flag_StepStatus = STEP_SEND;
//         LinkStep = GETIP2;
////			 err=LTE_Query_TCPStatus();
//         if(err == LTE_TCP_CONNECT)
//         {
//                LinkStep = GETIP2;
//         }
//         else
//         {
//             LinkStep = CONNECTIP1;
//         }

//         if(Flag_COMDebug == 1)
//        {					
//            printf("Get ip2 time out:%s\r\n",ucUar3tbuf);
//        }
//    }
//	if(SentGetServerVerityCount > 6)
//	{
//		Flag_StepStatus = STEP_SEND;
//		LinkStep = CONNECTIP1;
//	}
//}
//void ConnectServer2(void)
//{
//	 char res;  
//	 SLM750V_Close_Socket();    
//	 res=SLM750V_Open_Socket(IP2,Port2);
//	  if(res == LTE_SUCCESS)
//		{
//                    
//			Flag_StepStatus = STEP_RECEIVE;
//			Link_Time = 0 ;
//		}
//		else
//		{
//			 delay_ms(3000);
//		}

//}
//void BackServerStatus(void)
//{

//	delay_ms(500);
//	
//		if(Flag_COMDebug == 1)
//		{
//			printf("TCP2 has connected\r\n");
//		}
//		ClearUSART3BUF();
//		Flag_StepStatus = STEP_SEND;
//		SentGetServerVerityCount = 0;
//		LinkIPCount = 0;
//		if((Flag_ErrInfo&ERROR_NO_TOKEN2) == ERROR_NO_TOKEN2 )
//		{
//			LinkStep = GETTOKEN2;
//		}
//		else
//		{
//			LinkStep = BACKSERVERVERFY;
//		}
//	
//}
//void GetToken2(void)
//{
//    uint8_t  SendData[100] = {0};
//    uint8_t  jiaoyan=0;
//    uint8_t i=0;
//    uint8_t len=0;
//    SendData[len++] = CMD_START;
//    SendData[len++] = TypeID;
//    SendData[len++] = 0;
//    SendData[len++] = MAC_Len+2;
//    SendData[len++] = REQ_SECOND_TOKEN;
//    for(i=0;i<MAC_Len ;i++)
//    {
//        SendData[len++]=MAC_ID[i];
//    }
//    for(i = 0;i< MAC_Len;i++)
//    {
//        jiaoyan += MAC_ID[i];
//    }
//    jiaoyan +=REQ_SECOND_TOKEN;
//    SendData[len++] = jiaoyan ;
//    SendData[len++] = CMD_LF1;
//    SendData[len++] = CMD_LF2;
//    
//    //SLM750V_Push_Data();	
//    Link_Time = 0;	 
//    Flag_StepStatus = STEP_RECEIVE;
//    SentGetServerVerityCount++;
//    if(Flag_COMDebug == 1)
//    {
//        printf("Get token2 from IP2!\r\n");
//    }
//    SLM750V_Send_Data(SendData,len);
//}
//void RecodeBackServerToken2(void)
//{
//	char *pstr,*pstr1;
//	uint8_t len,i;
//	char buf[100];
//	char err;

//	if(strstr(ucUar3tbuf,"+MIPRTCP") != NULL)   //�յ�����������
//	{
//        pstr = strstr(ucUar3tbuf, "$");
//        //pstr1 = strstr(ucUar3tbuf, "iB");
//		delay_ms(100);	
//        printf("rec:%s",ucUar3tbuf);
//        while(*pstr!='\r')
//        {
//            printf("%02x ",*pstr);
//            pstr++;
//        }
//		pstr = strstr(ucUar3tbuf, "$");
//        //pstr1 = strstr(ucUar3tbuf, "iB");
//        //24 11 00 09 03 37 30 36 39 30 32 37 72 69 42
//		if((pstr!=NULL)/*&& (pstr1!=NULL)*/)
//		{			 
//			//if((pstr[1] == TypeID)&&(pstr[4] == REQ_SECOND_TOKEN))
//			{   												 	         
//				Token2_Len = pstr[2]*256+pstr[3]-2;
//				if(Token2_Len>10)
//				{
//					Token2_Len = 10;
//				}
//				memset(Token2,0X00,15);
//				for(i = 0;i< Token2_Len;i++)
//				{
//					if((pstr[i+5]<0x3A)&&(pstr[i+5]>0x2F))
//					{
//						Token2[i] = pstr[i+5];
//					}
//				}
//				Token2[Token2_Len] = 0;
//				if(Flag_COMDebug == 1)
//				{
//					printf("Token2 is:%s\r\n",Token2);
//				}
//				SaveToken2ToFlash();
//				Flag_StepStatus = STEP_SEND;
//				LinkStep = BACKSERVERVERFY;	
//				SentGetServerVerityCount = 0;						
//				ClearUSART3BUF();
//			}
//			if((pstr[1]== TypeID)&&(pstr[4] ==SERVER_ABNORMAL_MESSAGE)) 
//			{
//				if(pstr[5] == SERVER_CHECK_MAC_ERR)  //MAC��֤����
//				{
//					if(Flag_COMDebug == 1)
//					{
//						printf("Server Return MAC Verify Error!\r\n");
//					}
//					Flag_StepStatus = STEP_SEND;
//					LinkStep = CONNECTIP1;
//				}	
//				ClearUSART3BUF();			 
//			} 	 			 
//		}		
//	}
//	if(Link_Time>= NETWORKLINK_TIMEOUT_30S)
//	{
//		Flag_StepStatus = STEP_SEND;
////		err=LTE_Query_TCPStatus();
//		if(err == LTE_TCP_CONNECT)
//		{
//			LinkStep = GETTOKEN2;
//		}
//		else
//		{
//			LinkStep = CONNECTIP2;
//		}
//		if(Flag_COMDebug == 1)
//		{					
//			printf("Get token2 time out��%s\r\n",ucUar3tbuf);
//		}
//	}
//	if(SentGetServerVerityCount > 6)
//	{
//		Flag_StepStatus = STEP_SEND;
//		LinkStep = CONNECTIP1;
//		Flag_ErrInfo |= ERROR_NO_TOKEN2;
//	}
//}
//void SendBackVerify(void)
//{
//	  uint8_t  SendData[100] = {0};
//	 uint8_t  jiaoyan=0;
//	 uint8_t i=0;
//	 uint8_t len=0;
//	 char buf[100];
//	 unsigned char ucMd5data[30] = {0};
//     unsigned char ucMd5string[40] = {0};
//     unsigned char ucMd5string1[40] = {0};
//		 
//	 sprintf(ucMd5data,"%s123456%s",MAC_ID,Token2);
//     MDString(ucMd5data,ucMd5string);
//	 HexToLowerStr(ucMd5string1,ucMd5string,16);
//	 if(Flag_COMDebug == 1)
//		{			
//			printf("ucMd5data:%s\r\n",ucMd5data);					
//			printf("ucMd5string1:%s\r\n",ucMd5string1);		
//		}
//				
//	 SendData[0] = CMD_START;
//	 SendData[1] = TypeID;
//	 len = strlen(ucMd5string1);
//	 SendData[2]= 0;	
//	 SendData[3]= len+MAC_Len+2;
//	 SendData[4]=REQ_SECOND_VERIFY;
//	 for(i=0;i<len ;i++)
//	 {
//			SendData[5+i]=ucMd5string1[i];
//	 }
//	 for(i=0;i<MAC_Len ;i++)
//	 {
//			SendData[5+len+i]=MAC_ID[i];
//	 } 
//	 for(i = 0;i< len;i++)
//		{
//			jiaoyan += ucMd5string1[i];
//		}								 
//	 for(i = 0;i< MAC_Len;i++)
//		{
//			jiaoyan += MAC_ID[i];
//		}
//	 jiaoyan +=REQ_SECOND_VERIFY;
//	 SendData[5+len+MAC_Len] = jiaoyan ;
//	 SendData[6+len+MAC_Len] = CMD_LF1;
//	 SendData[7+len+MAC_Len] = CMD_LF2;
//	SLM750V_Send_Data(SendData,8+len+MAC_Len);
//	Link_Time = 0;	 
//	 Flag_StepStatus = STEP_RECEIVE;
//	SentGetServerVerityCount ++;
//	
//}
//void GetBackServerResult(void)
//{
//	 char *pstr,*pstr1;
//	 uint8_t len,i;
//	 char err;
//	 char buf[100];
//	 unsigned char receivetime[6];
//	 OS_ERR      oserr;

//	 if(strstr(ucUar3tbuf,"+MIPRTCP") != NULL)   //�յ�����������
//	 {
//		delay_ms(100);	
//		pstr = strstr(ucUar3tbuf, "$");
//		if(pstr!=NULL)
//		{
//			//---------------------MD5У��ͨ��----------------------------------
//			if((pstr[1] == TypeID)&&(pstr[4] == REQ_SECOND_VERIFY)) //
//			{   												 	         
//				for(i=0;i<6;i++)  //��ȡ������ʱ��
//				{
//					receivetime[i] = (pstr[5+i*2]&0x7F-0x30)*10+(pstr[6+i*2]&0x7F-0x30); //��ASCII�ַ��������ֽڵ�ʱ��ת��Ϊ1���ֽڵ�ʱ��		 
//				}
//			
//				if((receivetime[0]>17)&&(receivetime[0]<99)&&(receivetime[1]>0)&&(receivetime[1]<13)&&(receivetime[2]>0)&&(receivetime[2]<32))
//				{
//					for(i=0;i<6;i++)
//					{
//						RealTime[i] = receivetime[i];
//					}
//					RenewRTCTime(RealTime);  //��Ӳ��ʵʱʱ��
//					if(Flag_COMDebug == 1)
//					{
//						printf("Login success��Server time is:%d-%d-%d %d:%d:%d\r\n",receivetime[0],receivetime[1],receivetime[2],receivetime[3],receivetime[4],receivetime[5]);
//					}
//				}														      					
//				Flag_TimeAdj = 0;  														 
//				LTE_ConnetTime = 0;	
//				Position_LAC=0xFFFF;
//				Position_CID=0xFFFF;
//				SendReConnectMode(Flag_Start_Mode,Position_LAC,Position_CID); 
//				delay_ms(100);
//				
////				LED1(0); //���ӳɹ�,ledϨ��										 
//				
//				LinkStep = SENDSLEEPDATA;				//���뷢��˯������ģʽ			 				  
//				Flag_StepStatus = STEP_SEND;				
//				SentGetServerVerityCount = 0;
//				Flag_InitStatus = CONTINUE_SENDDATA;
//				Time_NetworkInquire = 0;
//				UpdataPackagenum = 0;
//				Updata_packagelen = 0;
//				Updata_codelen = 0;
//				GetSleepDataTimeCount = 0;
//				
//				for(i=0;i<6;i++)
//				{
//					HR_StartTime[i] = RealTime[i];
//					RR_StartTime[i] = RealTime[i];
//                    HRW_StartTime[i] = RealTime[i];
//					RRW_StartTime[i] = RealTime[i];
//                    SPO_StartTime[i] = RealTime[i];
//				}
//				
//				if(Flag_CARD_ISCHANGE == CARD_HASCHANGE)  //���Ϳ���IMSI��
//				  {
//						if(Flag_COMDebug == 1)
//								printf("SIM Card has changed!\r\n");
//						Send_CARD_IMSI(SIMCard_ICCID,strlen(SIMCard_ICCID));
//						CARD_IMSI_Time = 0;
//				  }	
//				  
//				if((Flag_PowerOn == 0)&&(Flag_Updata == 0))
//				{
//					if(StaticsSleepDataBuffLen>8)  //������һ������
//						EndStatistStatusData();   //����ͳ��
////					HRDataNum = 0;
////					RRDataNum = 0;
//					CalculateCount = 0;
//					SimpleDataNum1 = 0;
//					SimpleDataNum2 = 0;
//					SleepDataBuffer_SendTime = 3;
//					Flag_CanSendStatistData = 1;
//				}
//				else
//				{
//					#ifdef  LOGFILE_SAVE
//					CreateNewLogfile();
//					if(Flag_PowerOn == 1)
//					{
//						char WriteData[30];
//						sprintf(WriteData,"�豸������%s\r\n",SystemReset[Flag_SystemReset]);
//						WriteLogInfoToTXT(WriteData);
//						
//					}
//					#endif
//				
//					Flag_PowerOn = 0;					
////					TIM3_Configuration();   //��ʱ�ɼ����ϵ���һ�������ɹ�����
////					HRDataNum = 0;
////					RRDataNum = 0;
//					CalculateCount = 0;
//					SimpleDataNum1 = 0;
//					SimpleDataNum2 = 0;
//					OnbedStatus_CountTimer = 0;
//				}			  
//				if(StaticsSleepDataSendNum != StaticsSleepDataSaveNum)
//				{
//					SleepDataBuffer_SendTime = 0;
//					Flag_CanSendStatistData = 1;
//					StaticsSleepDataSendCount = 0;
//				}
//				#if (defined(ADCFILE_SAVE)   | defined(BCGFILE_SAVE) | defined(RESPFILE_SAVE)| defined(LOGFILE_SAVE))&& (!defined(SAVEFILE_BYSENSOR))
//				char *   p_mem_blk2;	
//						 
//				p_mem_blk2 = OSMemGet((OS_MEM      *)&mem,
//								   (OS_ERR      *)&oserr);
//				*p_mem_blk2 = CREATE_DATAFILE;
//				/* ����������Ϣ������ AppTaskCreatNewFileTCB */
//				OSTaskQPost ((OS_TCB      *)&AppTaskCreatNewFileTCB,      //Ŀ������Ŀ��ƿ�
//							 (void        *)p_mem_blk2 ,             //��Ϣ���ݵ��׵�ַ
//							 (OS_MSG_SIZE  )1,                     //��Ϣ����
//							 (OS_OPT       )OS_OPT_POST_FIFO,      //������������Ϣ���е���ڶ�
//							 (OS_ERR      *)&oserr);                 //���ش�������
//				
//				#endif
//				   #if  !defined(SAVEFILE_BYSENSOR)
////					OSTmrStart(&timer_creatnewrecfile,&oserr);						//������ʱ��
////					
////					char *   p_mem_blk;				 
////					p_mem_blk = OSMemGet((OS_MEM      *)&mem,
////									   (OS_ERR      *)&oserr);
////					*p_mem_blk = RECORDER_ON;
////					/* ����������Ϣ������ AppTaskRecorderTCB */
////					OSTaskQPost ((OS_TCB      *)&AppTaskRecorderTCB,      //Ŀ������Ŀ��ƿ�
////								 (void        *)p_mem_blk ,             //��Ϣ���ݵ��׵�ַ
////								 (OS_MSG_SIZE  )1,                     //��Ϣ����
////								 (OS_OPT       )OS_OPT_POST_FIFO,      //������������Ϣ���е���ڶ�
////								 (OS_ERR      *)&oserr);                 //���ش�������			
////								
//				#endif
//				return;
//			}
//			//---------------------У�����----------------------------------
//			if((pstr[1]== TypeID)&&(pstr[4] == SERVER_ABNORMAL_MESSAGE)) 
//			 {
//				if(pstr[5] == SERVER_CHECK_MAC_ERR)  //MAC��֤����
//				{
//					if(Flag_COMDebug == 1)
//					{
//						printf("Server Return MAC Verify Error!\r\n");
//					}
//					Flag_StepStatus = STEP_SEND;
//					LinkStep = CONNECTIP1;
//					Flag_ErrInfo |= ERROR_NO_TOKEN2;
//				}	
//				if(pstr[5] == SERVER_CHECK_MD5_ERR)   //MD5��֤����
//				{
//					if(Flag_COMDebug == 1)
//					{
//						printf("Server Return MD5 Verify Error!\r\n");
//					}
//					LinkStep = GETTOKEN2;
//					Flag_StepStatus = STEP_SEND;				
//				}
//				ClearUSART3BUF();
//				return;				
//			} 	 			 
//		}		
//	 }
//	if(Link_Time>= NETWORKLINK_TIMEOUT_10S)
//	{
//		Flag_StepStatus = STEP_SEND;
////		err=LTE_Query_TCPStatus();
////		if(err == LTE_TCP_CONNECT)
////		{
////			LinkStep = BACKSERVERVERFY;
////		}
////		else
//		{
//			LinkStep = CONNECTIP2;
//		}
//		if(Flag_COMDebug == 1)
//		{					
//			printf("Get MD5 verify time out:%s\r\n",ucUar3tbuf);
//		}
//	}
//	if(SentGetServerVerityCount > 6)
//	{
//		Flag_StepStatus = STEP_SEND;
//		LinkStep = CONNECTIP1;
//		Flag_ErrInfo |= ERROR_NO_TOKEN2;
//	}
//}
//char LinkServerStep(uint8_t step)
//{
//	
//	 switch(step)
//	 {
//		 case CONNECTIP1:      //����ǰ�÷�����
//			 if(Flag_StepStatus == STEP_SEND)
//			 {
//				  ConnectServer1();
//			 }
//			 if(Flag_StepStatus == STEP_RECEIVE)
//			 {
//				  FrontServerStatus();
//			 }
//		 break;
//		 		 
//		case GETIP2:         //��ȡ���÷�����IP
//			 if(Flag_StepStatus == STEP_SEND)
//			 {
//				  GetBackIP();
//			 }
//			 else
//			 {
//                  //printf("recv:-------------\r\n");
//				 AnalysisBackIP();
//			 }
//		 break;
//			 
//		case CONNECTIP2:        //���Ӻ��÷�����
//			 if(Flag_StepStatus == STEP_SEND)
//			 {
//				  ConnectServer2();
//			 }
//			 if(Flag_StepStatus == STEP_RECEIVE)
//			 {
//				  BackServerStatus();
//			 }
//		 break;
//			 
//		case GETTOKEN2:        //��ȡ���÷�����У����
//			 if(Flag_StepStatus == STEP_SEND)
//			 {
//				  GetToken2();
//			 }
//			 if(Flag_StepStatus == STEP_RECEIVE)
//			 {
//				  RecodeBackServerToken2();
//			 }
//		 break;
//			 
//		case BACKSERVERVERFY:     //���÷�����У��
//			 if(Flag_StepStatus == STEP_SEND)
//			 {
//				 SendBackVerify();
//			 }
//			 if(Flag_StepStatus == STEP_RECEIVE)
//			 {
//				 GetBackServerResult();
//			 }
//		 break;
//	 }	
//}