/******************************************************************************
 * @file     TIM.c
 * @brief   ��ʱ������
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par       �ϱ� 2016
*******************************************************************************/
#include "main.h"
#include "TIM.h"
#include "Parameter.h"

/****************************************************************************
*	�� �� ��: TIM2_Config
*	����˵��: ��ʱ��2���ú���
*	��    �Σ���
*	�� �� ֵ: ��
* ˵    �������ö�ʱ��2�ж�ʱ��Ϊ20ms
*          ��ʱʱ�䣺��1+TIM_Prescaler)/8M*(TIM_Period+1)
*****************************************************************************/
void TIM2_Config(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE); 

	
	TIM_DeInit(TIM2);//��λTIM3��ʱ��

	/* Time base configuration */
	TIM_TimeBaseStructure.TIM_Period = (200-1);		//20ms  һ��
	TIM_TimeBaseStructure.TIM_Prescaler = (3200-1);
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	

 	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);  			//����жϱ�־λ	  
	TIM_SelectOutputTrigger(TIM2,TIM_TRGOSource_Update);	//ѡ��TIM3��Update�¼���Ϊ����Դ

	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);				// �ж�Դ 
	TIM_Cmd(TIM2, ENABLE); 									// TIM3 enable counter
}
/****************************************************************************
*	�� �� ��: TIM3_Config
*	����˵��: ��ʱ��3���ú���
*	��    �Σ���
*	�� �� ֵ: ��
* ˵    �������ö�ʱ��3�ж�ʱ��Ϊ1s
*****************************************************************************/
void TIM3_Config(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); 

	
	TIM_DeInit(TIM3);//��λTIM3��ʱ��

	/* Time base configuration */
	TIM_TimeBaseStructure.TIM_Period = 10000-1;		//1s  һ��
	TIM_TimeBaseStructure.TIM_Prescaler = 3200-1;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	
	//TIM_PrescalerConfig(TIM3, ((SystemCoreClock/7200) - 1), TIM_PSCReloadMode_Immediate);

 	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);  			//����жϱ�־λ	  
	TIM_SelectOutputTrigger(TIM3,TIM_TRGOSource_Update);	//ѡ��TIM3��Update�¼���Ϊ����Դ

	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);				// �ж�Դ 
	TIM_Cmd(TIM3, ENABLE); 									// TIM3 enable counter
}
void TIM4_Config(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE); 

	
	TIM_DeInit(TIM4);//��λTIM3��ʱ��

	/* Time base configuration */
	TIM_TimeBaseStructure.TIM_Period = 10000-1;		//1ms  һ��
	TIM_TimeBaseStructure.TIM_Prescaler = 3200-1;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
	
	//TIM_PrescalerConfig(TIM3, ((SystemCoreClock/7200) - 1), TIM_PSCReloadMode_Immediate);

 	TIM_ClearITPendingBit(TIM4,TIM_IT_Update);  			//����жϱ�־λ	  
	TIM_SelectOutputTrigger(TIM4,TIM_TRGOSource_Update);	//ѡ��TIM3��Update�¼���Ϊ����Դ

	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);				// �ж�Դ 
	TIM_Cmd(TIM4, ENABLE); 									// TIM3 enable counter
}
#ifdef  USE_FULL_ASSERT

/***************************************************************************
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif



/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
