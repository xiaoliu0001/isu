/******************************************************************************
 * @file     WIFI.h
 * @brief   WIFI�趨
 * @version  
 * @date     2016
 * @note
 * Copyright (C)  
 *
 * @par       �ϱ� 2016
*******************************************************************************/
#ifndef __WIFI_H_
#define __WIFI_H_

#include "stm32f30x.h"
#include "stm32f30x_rcc.h"
#include "stm32f30x_usart.h"
#include "stm32f30x_misc.h"
#include "stdio.h"

void InitWIFI(void);
void AT_Command_WIFI(char *b,char *a,u8 wait_time);
char AT_Command_WIFI_1(char *b,char *a,u8 wait_time);
char AT_Command_WIFI_2(char *b,char *a,u8 wait_time);
void AT_Command_WIFI_RST(char *b,char *a,u8 wait_time);
char Mystrstr(unsigned char *p);
void WIFISendData(unsigned char *p,unsigned int Len,unsigned int chaule);
void WIFISendData_1(unsigned char *p,unsigned int Len,unsigned int chaule);









#endif
