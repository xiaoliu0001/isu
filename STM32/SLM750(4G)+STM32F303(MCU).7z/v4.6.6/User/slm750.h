 #ifndef __SLM750_H__
 #define __SLM750_H__
 
#include "Fun.h"
#include "Parameter.h"
#include "USART.h"

//�˿ڶ���
#define LTE_PWRKEY_PIN                  GPIO_Pin_3                  //��������   
#define LTE_PWRKEY_GPIO_PORT            GPIOB                      


#define LTE_RESETN_PIN                  GPIO_Pin_4             //��λ����       
#define LTE_RESETN_GPIO_PORT            GPIOB                      


#define LTE_DTR_PIN                  GPIO_Pin_12             //��λ����       
#define LTE_DTR_GPIO_PORT            GPIOB                      




#define LTE_PWRKEY(a)	if (a)	\
					GPIO_SetBits(LTE_PWRKEY_GPIO_PORT,LTE_PWRKEY_PIN);\
					else		\
					GPIO_ResetBits(LTE_PWRKEY_GPIO_PORT,LTE_PWRKEY_PIN);
										
#define LTE_RESETN(a)	if (a)	\
					GPIO_SetBits(LTE_RESETN_GPIO_PORT,LTE_RESETN_PIN);\
					else		\
					GPIO_ResetBits(LTE_RESETN_GPIO_PORT,LTE_RESETN_PIN);
					
#define LTE_DTR(a)	if (a)	\
					GPIO_SetBits(LTE_DTR_GPIO_PORT,LTE_DTR_PIN);\
					else		\
					GPIO_ResetBits(LTE_DTR_GPIO_PORT,LTE_DTR_PIN);				
					
#define	LTE_SUCCESS              0
#define	LTE_FAIL                -1
#define	LTE_CFG_ERROR           -2					
#define	LTE_CONNECT             1
#define	LTE_NOCONNECT           2										
#define	LTE_TCP_CONNECT           1
#define	LTE_TCP_NOCONNECT         2
					
#define	LTE_DATASEND_ATMODE       1
#define	LTE_DATASEND_TRANSMODE    0
					
#define	LTE_1S_TIMEOUT              1
#define LTE_2S_TIMEOUT              2
#define LTE_3S_TIMEOUT              3
#define LTE_5S_TIMEOUT           	 5
#define LTE_10S_TIMEOUT           	10
#define LTE_20S_TIMEOUT           	20
#define LTE_30S_TIMEOUT           	30
#define LTE_1MIN_TIMEOUT           	60
#define LTE_3MIN_TIMEOUT           	180
#define LTE_5MIN_TIMEOUT           	300


#define LTE_INIT_STEP1        1       //LTE��ʼ������1
#define LTE_INIT_STEP2        2       //LTE��ʼ������2
#define LTE_INIT_STEP3        3       //LTE��ʼ������3
#define LTE_INIT_STEP4        4       //LTE��ʼ������4
#define LTE_INIT_STEP5        5       //LTE��ʼ������5
#define LTE_INIT_STEP6        6       //LTE��ʼ������6
#define LTE_INIT_STEP7        7       //LTE��ʼ������7
#define LTE_INIT_PAUSE        8 

#define NON_CDMAMODE           1
#define IN_CDMAMODE            2

extern uint8_t Flag_Networkmode ;  //����ģʽ��NON_CDMAMODE or IN_CDMAMODE
//extern uint16_t  Position_LAC;        //GPRS LACλ������
//extern uint16_t  Position_CID;        //GPRS CIDλ������
extern uint16_t  Position_SID;        //GPRS SIDλ������
extern uint16_t  Position_NID;        //GPRS NIDλ������
extern uint16_t  Position_BID;        //GPRS BIDλ������
extern unsigned char CSQNual;
extern uint8_t Socket;
extern unsigned char SIMCard_IMSI[20];
extern uint8_t SIMCard_IMSI_Len;
extern unsigned char SIMCard_ICCID[25];
extern uint8_t SIMCard_ICCID_Len;
extern unsigned char SIMCard_IMEI[25];
extern uint8_t SIMCard_IMEI_Len;
extern uint8_t Flag_DataSendMode;   //���ݴ���ģʽ
extern  uint8_t Flag_LTEInitStep;     //LTE��ʼ���Ĺ��̲���
extern uint16_t  LTE_InitTime;  //LTE��ʼ��ʱ��
extern uint16_t  LTE_Init_pauseTime;
extern uint16_t  LTE_Time ;             //LTEģ��ָ��ʱ��

void SLM750V_GPIO_CONFIG(void);
char SLM750V_StartUP(void);
char SLM750V_PowerDown(void);
char SLM750V_SoftPowerOff(void);
char SLM750V_INIT(void);
char SLM750V_EchoEnable(uint8_t echo);
char SLM750V_InquireIMSI(void);
char SLM750V_InquireICCID(void);
char SLM750V_NetworkRegistration(uint8_t NR);
char SLM750V_Query_NetReg(void);
char LTE_GetPosition(void);
char SLM750V_Query_CSQ(void);
char LTE_Set_ConnectIP(char *ip,char *port,uint8_t access_mode);
char LTE_Query_TCPstate(void);
char LTE_Close_ConnectedIP(uint8_t socket_id);
char SLM750V_Activate_PDPContext(void);
char SLM750V_Set_APN(void);
char SLM750V_Query_APNstate(void); 
char SLM750V_Query_PIN(void);
char LTE_EnterATmode(void);
char LTE_SwitchAccessMode(uint8_t sock_fd,uint8_t access_mode);


uint16_t BCDstringTOINT(char *str);
char LTE_Send_data(uint8_t sock_fd, uint16_t send_len, uint8_t *buf);
void LTE_UART_Send(char *tx_buf,uint16_t buflen);
char LTE_Send_String(char *s);
char LTE_Ping_Test(char * addr_ip); 


char LTE_Query_PDPstate(void);
char SLM750V_Close_Link(void);
char SLM750V_Creat_Link(void);
char SLM750V_Query_FreeSockets(void);
char SLM750V_Open_Socket(char *ipaddr,char *ipport);
char SLM750V_Set_Size(void);
char SLM750V_Send_Data(uint8_t *data,uint16_t len );
char SLM750V_Push_Data(void);

char LinkServerStep(uint8_t step);
char LTE_Query_Soketstate(void);
#endif