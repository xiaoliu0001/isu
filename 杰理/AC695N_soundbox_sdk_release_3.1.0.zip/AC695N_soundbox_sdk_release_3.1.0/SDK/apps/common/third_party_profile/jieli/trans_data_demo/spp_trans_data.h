#ifndef __SPP_TRANS_DATA_H__
#define __SPP_TRANS_DATA_H__

#include "typedef.h"
#include "bt_common.h"

void transport_spp_init(void);

#endif//__RCSP_SPP_USER_H__
