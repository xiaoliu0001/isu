#ifndef __RCSP_ADV_OPT_H__
#define __RCSP_ADV_OPT_H__

void deal_sibling_setting(u8 *buf);

#endif
