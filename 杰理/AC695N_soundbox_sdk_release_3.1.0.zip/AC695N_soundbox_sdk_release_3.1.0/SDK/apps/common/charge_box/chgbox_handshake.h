#ifndef _CHGBOX_HANDSHAKE_H_
#define _CHGBOX_HANDSHAKE_H_

void chgbox_handshake_run_app(void);
void chgbox_handshake_init(void);
void chgbox_handshake_set_repeat(u8 times);

#endif
