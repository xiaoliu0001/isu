#ifndef __DEV_UPDATE_H__
#define __DEV_UPDATE_H__

#include "typedef.h"
#include "system/includes.h"

void *dev_update_get_parm(int type);
u16  dev_update_check(char *logo);

#endif//__DEV_UPDATE_H__
