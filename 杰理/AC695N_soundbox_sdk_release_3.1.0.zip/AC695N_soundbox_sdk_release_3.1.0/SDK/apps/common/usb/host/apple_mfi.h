#ifndef _APPLE_MFI_H_
#define _APPLE_MFI_H_

int usb_apple_mfi_parser(struct usb_host_device *host_dev, u8 interface_num, const u8 *pBuf);



#endif
