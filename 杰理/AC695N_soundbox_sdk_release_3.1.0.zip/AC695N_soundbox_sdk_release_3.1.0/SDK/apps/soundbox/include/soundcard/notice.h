#ifndef __NOTICE_H__
#define __NOTICE_H__

#include "generic/typedef.h"
#include "app_config.h"

void soundcard_make_notice_electric(u8 mode);
void soundcard_make_some_noise(u8 id);

#endif//__NOTICE_H__
