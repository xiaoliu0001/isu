
#ifndef __APP_COMMON_H__
#define __APP_COMMON_H__

#include "typedef.h"

extern u8 app_common_key_var_2_event(u32 key_var);

#endif
