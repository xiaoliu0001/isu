#ifndef __DEV_STATUS_H__
#define __DEV_STATUS_H__

#include "typedef.h"
#include "system/includes.h"

int dev_status_event_filter(struct sys_event *event);

#endif//__DEV_STATUS_H__
