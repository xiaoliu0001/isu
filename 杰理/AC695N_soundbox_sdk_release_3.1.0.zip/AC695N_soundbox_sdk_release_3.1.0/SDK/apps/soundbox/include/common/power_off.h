#ifndef __POWER_OFF_H__
#define __POWER_OFF_H__
#include "generic/typedef.h"
#include "app_config.h"
#include "event.h"

void power_off_deal(struct sys_event *event, u8 step);

#endif//__POWER_OFF_H__
