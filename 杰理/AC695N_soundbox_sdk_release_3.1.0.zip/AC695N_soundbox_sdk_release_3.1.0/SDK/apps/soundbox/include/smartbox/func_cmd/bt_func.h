#ifndef __BT_FUNC_H__
#define __BT_FUNC_H__
#include "typedef.h"
#include "app_config.h"
#endif
