#ifndef __MUSIC_FUNC_H__
#define __MUSIC_FUNC_H__
#include "typedef.h"
#include "app_config.h"


#endif
