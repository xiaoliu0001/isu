#ifndef __SMARTBOX_SWITCH_DEVICE_H__
#define __SMARTBOX_SWITCH_DEVICE_H__

#include "typedef.h"
#include "app_config.h"

void smartbox_switch_device(u8 *data);

#endif//__SMARTBOX_FEATURE_H__

