#ifndef HDMI_CEC_API_H
#define HDMI_CEC_API_H

void hdmi_cec_init(void);
extern void hdmi_cec_decode_irq_resume();

#endif

